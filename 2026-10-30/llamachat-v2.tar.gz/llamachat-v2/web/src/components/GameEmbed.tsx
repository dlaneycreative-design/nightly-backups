import { useState } from "react";
import type { GameInfo } from "../lib/gameEmbed.ts";

/**
 * Playable game inside a tweet (!Game). At rest it is just the cover
 * art with a big Play button — the game iframe is NOT loaded until
 * Play is tapped, so the feed stays light. Tapping Play swaps in the
 * live game iframe; "Play on Open Arcade" links out to the game's
 * Open Arcade page URL.
 */
export function GameEmbed({ game }: { game: GameInfo }) {
  const [playing, setPlaying] = useState(false);
  return (
    <div className="game-embed" onClick={(e) => e.stopPropagation()}>
      {playing ? (
        <iframe
          className="game-frame"
          src={game.playUrl}
          title={`${game.name} — playable game`}
          allow="fullscreen; autoplay; gamepad"
          allowFullScreen
          loading="lazy"
        />
      ) : (
        <button
          type="button"
          className="game-cover"
          aria-label={`Play ${game.name}`}
          onClick={() => setPlaying(true)}
        >
          <img src={game.coverUrl} alt={`${game.name} cover art`} loading="lazy" decoding="async" />
          <span className="game-play-btn" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>
            Play
          </span>
        </button>
      )}
      <div className="game-embed-foot">
        <span className="game-embed-name">🕹️ {game.name}</span>
        <a href={game.pageUrl} target="_blank" rel="noopener" onClick={(e) => e.stopPropagation()}>
          Play on Open Arcade ↗
        </a>
      </div>
    </div>
  );
}
