// Self-serve signup form (Dave's order Oct 19 2026): a cold visitor
// creates a REAL account, no hand-vetting queue. Used by the join modal
// and by the /approved page we send invited people to.
// Fields (Dave's final word): display name, username they choose, and
// their Instagram. Account creation is POST /api/v2/profiles; the old
// /signups store still gets a copy as Dave's notification record.
// Oct 19 2026 quick fixes (Dave-approved, from the signup audit):
// live username availability check, suggested simple handles, Instagram
// optional, the new account is signed in at signup, and forgiving
// handle input that tidies spaces, dots, and dashes as you type.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Profile } from "../lib/api.ts";
import { setCallerId } from "../lib/session.ts";
import { HOME_URL, appPath } from "../lib/theme.ts";

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "12px 16px",
  fontSize: 16,
  border: "1px solid #cfd9de",
  borderRadius: 9999,
  marginBottom: 6,
  outline: "none",
  boxSizing: "border-box",
};
const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 14,
  fontWeight: 700,
  margin: "14px 0 6px",
  textAlign: "left",
};
const hintStyle: React.CSSProperties = { fontSize: 13, color: "#536471", margin: "0 0 6px", textAlign: "left" };
const chipStyle: React.CSSProperties = {
  padding: "4px 12px",
  fontSize: 13,
  fontWeight: 700,
  color: "#1d9bf0",
  background: "#fff",
  border: "1px solid #cfd9de",
  borderRadius: 9999,
  cursor: "pointer",
};

// Mirror of the server's reserved set (routes/profiles.js). The server
// stays the authority; this only powers instant "reserved" feedback.
const RESERVED_HANDLES = new Set([
  "dave", "sally", "dinesh", "admin", "starvard", "support", "llamachat",
  "e2", "mike", "finn",
  "search", "login", "logout", "signup", "join", "approved", "profile",
  "profiles", "settings", "notifications", "messages", "explore", "home",
  "terms", "privacy", "help", "api", "media", "official", "system", "root",
]);

const HANDLE_RE = /^[a-z0-9_]{3,20}$/;
type Avail = "free" | "taken" | "reserved" | "unknown";

/** Tidy what a person naturally types into a valid handle shape:
 * lowercase, spaces removed, dots and dashes become underscores,
 * anything else unusable is dropped. */
function tidyHandle(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/^@+/, "")
    .replace(/\s+/g, "")
    .replace(/[.-]+/g, "_")
    .replace(/[^a-z0-9_]/g, "");
}

export function SignupForm({ apiBase, onCreated }: { apiBase: string; onCreated?: () => void }) {
  const [displayName, setDisplayName] = useState("");
  const [handleRaw, setHandleRaw] = useState("");
  const [tidiedNote, setTidiedNote] = useState<string | null>(null);
  const [instagram, setInstagram] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Profile | null>(null);
  const [avail, setAvail] = useState<{ handle: string; status: Avail | "checking" } | null>(null);
  const [suggStatus, setSuggStatus] = useState<Record<string, Avail>>({});

  // handleRaw already holds the tidied value (onChange tidies first).
  const handle = handleRaw;
  const handleValid = HANDLE_RE.test(handle);
  const ig = instagram.trim().replace(/^@/, "");

  // Availability: GET /profiles/:handle (200 = taken, 404 = free).
  // Reserved names resolve locally; results are cached per handle and
  // shared between the field check and the suggestion chips.
  const cacheRef = useRef(new Map<string, Avail>());
  const checkHandle = useCallback(
    async (h: string): Promise<Avail> => {
      if (RESERVED_HANDLES.has(h)) return "reserved";
      const hit = cacheRef.current.get(h);
      if (hit) return hit;
      try {
        const res = await fetch(`${apiBase}/profiles/${encodeURIComponent(h)}`);
        const s: Avail = res.status === 200 ? "taken" : res.status === 404 ? "free" : "unknown";
        if (s !== "unknown") cacheRef.current.set(h, s);
        return s;
      } catch {
        return "unknown";
      }
    },
    [apiBase],
  );

  // Debounced live check for the typed handle. A result only lands if
  // the field still holds the handle it was checked for.
  const handleRef = useRef(handle);
  handleRef.current = handle;
  useEffect(() => {
    if (!handleValid) {
      setAvail(null);
      return;
    }
    if (RESERVED_HANDLES.has(handle)) {
      setAvail({ handle, status: "reserved" });
      return;
    }
    setAvail({ handle, status: "checking" });
    const t = setTimeout(() => {
      void checkHandle(handle).then((s) => {
        if (handleRef.current === handle) setAvail({ handle, status: s });
      });
    }, 400);
    return () => clearTimeout(t);
  }, [handle, handleValid, checkHandle]);
  const availNow: Avail | "checking" | null = avail && avail.handle === handle ? avail.status : null;

  // Suggested simple handles from the name (and Instagram, if given).
  const candidates = useMemo(() => {
    const parts = displayName
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .map((p) => p.replace(/[^a-z0-9]/g, ""))
      .filter(Boolean);
    const out: string[] = [];
    const push = (c: string) => {
      if (HANDLE_RE.test(c) && !out.includes(c)) out.push(c);
    };
    if (parts.length) {
      push(parts[0]);
      if (parts.length > 1) push(parts[0] + parts[parts.length - 1][0]);
    }
    const igTidy = tidyHandle(instagram);
    if (igTidy) push(igTidy);
    return out.slice(0, 3);
  }, [displayName, instagram]);

  useEffect(() => {
    if (!candidates.length) return;
    const t = setTimeout(() => {
      void Promise.all(candidates.map(async (c) => [c, await checkHandle(c)] as const)).then((pairs) => {
        setSuggStatus((prev) => {
          const next = { ...prev };
          for (const [c, s] of pairs) next[c] = s;
          return next;
        });
      });
    }, 400);
    return () => clearTimeout(t);
  }, [candidates, checkHandle]);
  const visibleSuggestions = candidates.filter((c) => suggStatus[c] === "free" && c !== handle);

  let handleHint: string;
  let handleHintColor = "#536471";
  if (!handle) {
    handleHint = "Pick a short, simple username, like @koko or @maria.";
  } else if (!handleValid) {
    handleHint = "3-20 characters: lowercase letters, numbers, or underscores only.";
    handleHintColor = "#f4212e";
  } else if (availNow === "taken") {
    handleHint = `@${handle} is taken, try another.`;
    handleHintColor = "#f4212e";
  } else if (availNow === "reserved") {
    handleHint = `@${handle} is reserved, please pick another.`;
    handleHintColor = "#f4212e";
  } else if (availNow === "free") {
    handleHint = `✓ @${handle} is available`;
    handleHintColor = "#0b8a44";
  } else if (tidiedNote === handle) {
    handleHint = `We tidied that to @${handle}`;
  } else {
    handleHint = `This will be your @${handle}`;
  }

  const canSubmit =
    !busy &&
    displayName.trim().length > 0 &&
    handleValid &&
    availNow !== "taken" &&
    availNow !== "reserved";

  const onHandleChange = (rawValue: string) => {
    const tidied = tidyHandle(rawValue);
    const typed = rawValue.toLowerCase().replace(/^@/, "").trim();
    setTidiedNote(tidied && tidied !== typed ? tidied : null);
    setHandleRaw(tidied);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`${apiBase}/profiles`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          handle,
          display_name: displayName.trim(),
          instagram: ig || undefined,
        }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(body?.error?.message || "Something went wrong. Try again?");
      }
      const profile = body.profile as Profile;
      // Notification record for Dave (the old /signups store), best effort.
      void fetch(`${apiBase}/signups`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: displayName.trim(), instagram: ig }),
      }).catch(() => {});
      if (ig) {
        try {
          localStorage.setItem("llama_signup_instagram", ig);
        } catch { /* non-fatal */ }
      }
      // Sign the new account in right away, the same way login does.
      setCallerId(profile.id, profile.handle);
      setCreated(profile);
      onCreated?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again?");
    } finally {
      setBusy(false);
    }
  };

  if (created) {
    return (
      <div style={{ textAlign: "center" }}>
        <h2 style={{ fontSize: 24, margin: "0 0 8px" }}>You're in! 🎉</h2>
        <p style={{ color: "#536471", margin: "0 0 8px", fontSize: 15 }}>
          Welcome to the honor roll, <b>@{created.handle}</b>. Your account is live and you are signed in.
        </p>
        <p style={{ color: "#536471", margin: "0 0 24px", fontSize: 15 }}>
          No password needed: your handle is your key for now.
        </p>
        <button
          type="button"
          onClick={() => { window.location.href = HOME_URL; }}
          style={{ width: "100%", padding: "12px", fontSize: 16, fontWeight: 700, background: "#1d9bf0", color: "#fff", border: "none", borderRadius: 9999, cursor: "pointer" }}
        >
          Start posting
        </button>
        <p style={{ fontSize: 13, marginTop: 16 }}>
          <a href={appPath(`/${created.handle}`)} style={{ color: "#1d9bf0" }}>See my profile</a>
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit}>
      <label style={labelStyle} htmlFor="su-name">Your name</label>
      <input
        id="su-name"
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
        placeholder="e.g. Maria Santos"
        aria-label="Your name"
        autoFocus
        style={inputStyle}
      />
      <label style={labelStyle} htmlFor="su-handle">Choose your username</label>
      <input
        id="su-handle"
        value={handleRaw}
        onChange={(e) => onHandleChange(e.target.value)}
        placeholder="@yourname"
        aria-label="Choose your username"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        style={inputStyle}
      />
      <p style={{ ...hintStyle, color: handleHintColor }}>{handleHint}</p>
      {visibleSuggestions.length > 0 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center", margin: "2px 0 4px" }}>
          <span style={{ fontSize: 13, color: "#536471" }}>Short and simple:</span>
          {visibleSuggestions.map((c) => (
            <button
              key={c}
              type="button"
              style={chipStyle}
              onClick={() => {
                setHandleRaw(c);
                setTidiedNote(null);
              }}
            >
              @{c}
            </button>
          ))}
        </div>
      )}
      <label style={labelStyle} htmlFor="su-ig">Instagram (optional)</label>
      <input
        id="su-ig"
        value={instagram}
        onChange={(e) => setInstagram(e.target.value)}
        placeholder="@yourhandle"
        aria-label="Your Instagram handle"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        style={inputStyle}
      />
      <p style={hintStyle}>So we can find you and say hi.</p>
      {error && <p style={{ color: "#f4212e", fontSize: 14, margin: "8px 0" }}>{error}</p>}
      <button
        type="submit"
        disabled={!canSubmit}
        style={{ width: "100%", padding: "12px", fontSize: 16, fontWeight: 700, background: "#1d9bf0", color: "#fff", border: "none", borderRadius: 9999, cursor: "pointer", opacity: canSubmit ? 1 : 0.5, marginTop: 10 }}
      >
        {busy ? "Creating..." : "Create my account"}
      </button>
    </form>
  );
}
