// X-style compose modal. Clicking the sidebar Post button opens this:
// "What's happening?" composer in a modal, posts via the API, adds the new
// tweet to the store, and closes.
import { useCallback, useEffect, useState } from "react";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { upsertTweets } from "../lib/store.ts";
import { getCallerId } from "../lib/session.ts";
import {
  subscribeComposeModal,
  closeComposeModal,
  isComposeOpen,
} from "../lib/composeModal.ts";
import { Composer } from "./Composer.tsx";

interface ModalProps {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
  onClose: () => void;
}

function ComposeModal({ api, apiBase, me, onClose }: ModalProps) {
  // Lock body scroll + close on Escape while the modal is open.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const onPosted = useCallback(
    (tweet: TweetT) => {
      upsertTweets([tweet]);
      // Tell any mounted Feed to prepend this tweet; the modal lives outside
      // the Feed tree so it can't update the feed's order state directly.
      window.dispatchEvent(new CustomEvent("llama:posted", { detail: tweet }));
      onClose();
    },
    [onClose]
  );

  const avatarSrc = me ? resolveImageUrl(me.avatar_url) : null;

  return (
    <div className="rm-backdrop" onClick={onClose} role="presentation">
      <div
        className="rm-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Create a post"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="rm-top">
          <button type="button" className="rm-close" onClick={onClose} aria-label="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
          <button type="button" className="rm-drafts" onClick={onClose}>
            Drafts
          </button>
        </div>

        <div className="rm-composer" style={{ borderTop: "none", marginTop: 0 }}>
          <Composer
            api={api}
            apiBase={apiBase}
            getCallerId={getCallerId}
            avatarUrl={avatarSrc}
            placeholder="What's happening?"
            autofocus
            onPosted={onPosted}
          />
        </div>
      </div>
    </div>
  );
}

interface HostProps {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
}

/** Mounted once in App. Shows the modal whenever openComposeModal() fires. */
export function ComposeModalHost({ api, apiBase, me }: HostProps) {
  const [open, setOpen] = useState<boolean>(() => isComposeOpen());

  useEffect(() => subscribeComposeModal(setOpen), []);

  const onClose = useCallback(() => closeComposeModal(), []);

  if (!open) return null;
  if (!getCallerId()) {
    closeComposeModal();
    return null;
  }
  return <ComposeModal api={api} apiBase={apiBase} me={me} onClose={onClose} />;
}
