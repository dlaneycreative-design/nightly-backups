import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { subscribeToast, type ToastAction } from "../lib/toast.ts";

interface ToastMsg {
  text: string;
  action?: ToastAction;
}

/** Blue notification bar, bottom-right. Shows after actions like posting. */
export function Toast() {
  const [msg, setMsg] = useState<ToastMsg | null>(null);
  useEffect(() => subscribeToast(setMsg), []);
  if (!msg) return null;
  return (
    <div className="toast-bar" role="status">
      <span>{msg.text}</span>
      {msg.action ? (
        <Link to={msg.action.href} className="toast-link">
          {msg.action.label}
        </Link>
      ) : null}
    </div>
  );
}
