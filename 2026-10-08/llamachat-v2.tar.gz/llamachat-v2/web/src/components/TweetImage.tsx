// Lazy tweet image. Feed shows the 200px thumb; tap opens the full
// variant in a lightbox. Images only load when near the viewport
// (IntersectionObserver) so 500-image feeds stay fast.
import { useRef, useState } from "react";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  /** The medium image_url stored on the tweet. */
  imageUrl: string;
  alt?: string;
}

export function TweetImage({ imageUrl, alt = "Tweet image" }: Props) {
  const imgRef = useRef<HTMLImageElement>(null);
  const [lightbox, setLightbox] = useState(false);

  const constrain = (img: HTMLImageElement | null) => {
    if (img && img.naturalHeight > 510) {
      img.style.height = '510px';
      img.style.objectFit = 'cover';
    }
  };

  const src = resolveImageUrl(imageUrl) || imageUrl;

  return (
    <>
      <div className="tweet-img-wrap" style={{overflow:'hidden',borderRadius:16,maxHeight:510,marginTop:12}}>
        <img
          ref={imgRef}
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          onClick={() => setLightbox(true)}
          className="tweet-img"
          style={{maxWidth:'100%',maxHeight:510,width:'100%',height:'auto',display:'block',objectFit:'cover'}}
          onLoad={(e) => constrain(e.currentTarget)}
        />
      </div>
      {lightbox ? (
        <div className="lightbox" onClick={() => setLightbox(false)}>
          <img src={src} alt={alt} className="lightbox-img" />
        </div>
      ) : null}
    </>
  );
}
