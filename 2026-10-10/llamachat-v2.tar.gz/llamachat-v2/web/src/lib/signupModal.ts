// Instagram-first signup modal: Dave's call Oct 9 2026.
// Step 1: "What is your Instagram?" Then we vet them.
type Listener = (open: boolean) => void;
let isOpen = false;
const listeners = new Set<Listener>();

export function openSignupModal(): void {
  isOpen = true;
  listeners.forEach((l) => l(true));
}

export function closeSignupModal(): void {
  isOpen = false;
  listeners.forEach((l) => l(false));
}

export function subscribeSignupModal(l: Listener): () => void {
  listeners.add(l);
  return () => { listeners.delete(l); };
}

export function isSignupOpen(): boolean {
  return isOpen;
}
