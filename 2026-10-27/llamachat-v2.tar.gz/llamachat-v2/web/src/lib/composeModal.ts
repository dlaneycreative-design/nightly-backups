// Global compose-modal opener. The sidebar Post button opens the X-style
// new-post modal without prop drilling: App.tsx calls openComposeModal(),
// and ComposeModalHost (mounted once in App) renders the modal.
import type { Tweet } from "./api.ts";

type Listener = (open: boolean) => void;
const listeners = new Set<Listener>();

let isOpen = false;
// The tweet being quoted when the modal was opened via Quote
// (openQuoteComposer). The host reads it at open time and passes it to
// the Composer as the attached quote. Cleared on close and on a plain
// open, so a quote can never leak into a later fresh post.
let quoteTarget: Tweet | null = null;

/** Open the compose modal. */
export function openComposeModal(): void {
  quoteTarget = null;
  isOpen = true;
  for (const l of listeners) l(isOpen);
}

/** Open the compose modal as a quote composer for `tweet` (X's Quote). */
export function openQuoteComposer(tweet: Tweet): void {
  quoteTarget = tweet;
  isOpen = true;
  for (const l of listeners) l(isOpen);
}

/** The quote target captured when the modal opened (null = plain post). */
export function getComposeQuote(): Tweet | null {
  return quoteTarget;
}

/** Close the compose modal. */
export function closeComposeModal(): void {
  isOpen = false;
  quoteTarget = null;
  for (const l of listeners) l(isOpen);
}

/** Whether the compose modal is currently open. */
export function isComposeOpen(): boolean {
  return isOpen;
}

export function subscribeComposeModal(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

// The profile currently on screen, registered by ProfileView while it is
// mounted. When the compose modal opens over a profile, the composer
// prefills a mention of that person (Dave's call Oct 13 2026: "it should
// say @Jen when I pop up that modal").
let viewedProfileHandle: string | null = null;

export function setViewedProfileHandle(handle: string | null): void {
  viewedProfileHandle = handle;
}

export function getViewedProfileHandle(): string | null {
  return viewedProfileHandle;
}
