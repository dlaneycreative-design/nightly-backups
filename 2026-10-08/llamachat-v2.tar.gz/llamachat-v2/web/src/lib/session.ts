// Caller identity: localStorage "llama_user_id" sent as the x-llama-user
// header. Dev default: look up the seeded Dave profile once and cache it;
// until then the app works read-only (public reads need no auth).
import type { ApiClient, Profile } from "./api.ts";

const KEY = "llama_user_id";
const HANDLE_KEY = "llama_user_handle";
const DEV_HANDLE = "dlaney";

type StorageLike = {
  getItem: (k: string) => string | null;
  setItem: (k: string, v: string) => void;
  removeItem: (k: string) => void;
};

function memStorage(): StorageLike {
  const m = new Map<string, string>();
  return {
    getItem: (k) => (m.has(k) ? m.get(k)! : null),
    setItem: (k, v) => {
      m.set(k, v);
    },
    removeItem: (k) => {
      m.delete(k);
    },
  };
}

let backing: StorageLike | null = null;
function storage(): StorageLike {
  if (!backing) {
    try {
      backing = typeof localStorage !== "undefined" ? localStorage : memStorage();
    } catch {
      backing = memStorage();
    }
  }
  return backing;
}

/** For tests: swap the backing store. */
export function _setStorage(s: StorageLike): void {
  backing = s;
}

export function getCallerId(): string | null {
  try {
    return storage().getItem(KEY);
  } catch {
    return null;
  }
}

export function setCallerId(id: string, handle?: string): void {
  try {
    storage().setItem(KEY, id);
    if (handle) storage().setItem(HANDLE_KEY, handle);
  } catch {
    /* non-fatal */
  }
}

export function getCallerHandle(): string | null {
  try {
    return storage().getItem(HANDLE_KEY);
  } catch {
    return null;
  }
}

export function clearCallerId(): void {
  try {
    storage().removeItem(KEY);
    storage().removeItem(HANDLE_KEY);
  } catch {
    /* non-fatal */
  }
}

/**
 * Dev sign-in: if no caller id is stored, try the seeded Dave profile
 * handle once and cache its id. Resolves to the profile or null.
 * Until a profile resolves, the app works read-only (public reads
 * need no auth).
 */
let tried = false;
let cachedProfile: Profile | null = null;
export async function ensureDevSession(api: ApiClient): Promise<Profile | null> {
  if (cachedProfile) return cachedProfile;
  const existing = getCallerId();
  if (existing) {
    // ID is known (user logged in). Fetch the profile by stored handle
    // so `me` is populated correctly after a fresh page load.
    const handle = getCallerHandle();
    if (handle) {
      try {
        const { profile } = await api.profile(handle);
        if (profile?.id) {
          cachedProfile = profile;
          return profile;
        }
      } catch {
        /* fall through */
      }
    }
    return null;
  }
  if (tried) return null;
  tried = true;
  try {
    const { profile } = await api.profile(DEV_HANDLE);
    if (profile?.id) {
      setCallerId(profile.id, profile.handle);
      cachedProfile = profile;
      return profile;
    }
  } catch {
    /* API not seeded yet; stay anonymous */
  }
  return null;
}
