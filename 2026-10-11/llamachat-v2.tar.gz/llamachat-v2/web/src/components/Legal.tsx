// Static legal pages: Terms of Service and Privacy Policy.
// Dave's call Oct 10 2026 (legal audit): every property gets both.
import React from "react";
import { Link } from "react-router-dom";

const pageStyle: React.CSSProperties = {
  maxWidth: 720,
  margin: "0 auto",
  padding: "48px 20px 80px",
  lineHeight: 1.7,
  fontSize: 16,
};

const h1Style: React.CSSProperties = {
  fontSize: 32,
  fontWeight: 800,
  letterSpacing: "-0.02em",
  marginBottom: 8,
};

const h2Style: React.CSSProperties = {
  fontSize: 20,
  fontWeight: 700,
  marginTop: 36,
  marginBottom: 8,
};

const metaStyle: React.CSSProperties = {
  color: "#8e8e93",
  fontSize: 13,
  marginBottom: 32,
};

function Back() {
  return (
    <p style={{ marginTop: 48 }}>
      <Link to="/" style={{ color: "#8e8e93", fontSize: 14 }}>
        &larr; Back to Llama Chat
      </Link>
    </p>
  );
}

export function TermsPage() {
  return (
    <div style={pageStyle}>
      <h1 style={h1Style}>Terms of Service</h1>
      <p style={metaStyle}>Last updated: October 10, 2026</p>
      <p>
        Llama Chat is a kinder corner of the internet: a social network with real profiles,
        real conversations, and zero doom. These terms keep it that way. Plain language, no gotchas.
      </p>

      <h2 style={h2Style}>1. The service</h2>
      <p>
        Llama Chat lets you create a profile, post short public messages, reply, message people
        directly, and follow accounts you like. Posts are public by default. Direct messages are
        private to the participants.
      </p>

      <h2 style={h2Style}>2. Your content</h2>
      <p>
        You own what you post. By posting it on Llama Chat, you grant us a license to display,
        distribute, and promote it as part of the service (so the app can, you know, show it).
        You promise that what you post is yours to share or that you have permission.
      </p>

      <h2 style={h2Style}>3. Be kind. It is the whole point.</h2>
      <p>
        No harassment, no hate speech, no spam, no scams, nothing illegal. We may remove content
        or suspend accounts that break the kindness rule, with or without warning.
      </p>

      <h2 style={h2Style}>4. No impersonation</h2>
      <p>
        Do not pretend to be a real person. Fictional characters are welcome; tribute characters
        honoring real people must say so plainly in their bio, use a different name and original
        art, and never claim to be the person. See our{" "}
        <a href="https://www.thestudio.io/legal/tribute/" target="_blank" rel="noopener">
          tribute character policy
        </a>
        .
      </p>

      <h2 style={h2Style}>5. Fictional characters are fiction</h2>
      <p>
        Some accounts are fictional characters. They are entertainment, not real people, and not a
        source of advice. Do not rely on a character for medical, legal, financial, or other
        professional guidance.
      </p>

      <h2 style={h2Style}>6. Accounts</h2>
      <p>
        You are responsible for what happens under your account. Keep your login secure. You must
        be at least 13 years old to use Llama Chat.
      </p>

      <h2 style={h2Style}>7. Experimental, no warranties</h2>
      <p>
        Llama Chat is an experiment that will change and occasionally break. We provide it as-is,
        with no warranties of any kind, and our liability is limited to the maximum extent the law
        allows.
      </p>

      <h2 style={h2Style}>8. Changes</h2>
      <p>
        We may update these terms as Llama Chat grows. The current version always lives at this
        URL. Continuing to use the service after changes means you accept them.
      </p>

      <h2 style={h2Style}>9. Contact</h2>
      <p>
        Questions about these terms: <a href="mailto:Dave@Tugboat.io">Dave@Tugboat.io</a>.
        Our privacy policy lives at <Link to="/privacy">llamachat.io/privacy</Link>.
      </p>
      <Back />
    </div>
  );
}

export function PrivacyPage() {
  return (
    <div style={pageStyle}>
      <h1 style={h1Style}>Privacy Policy</h1>
      <p style={metaStyle}>Last updated: October 10, 2026</p>
      <p>
        We collect as little as possible, we never sell your data, and we tell you exactly what
        we do with what we have.
      </p>

      <h2 style={h2Style}>1. What we collect</h2>
      <p>
        <strong>Account information:</strong> your handle, display name, and anything else you put
        on your profile. <strong>Your content:</strong> posts (public by design), replies, and
        direct messages (private to participants, stored so we can deliver them).{" "}
        <strong>Usage data:</strong> aggregate analytics about how the app is used, used to make it
        better.
      </p>

      <h2 style={h2Style}>2. What we never do</h2>
      <p>
        <strong>We do not sell your personal data. We do not share it with advertisers. We do not
        buy data about you from brokers.</strong>
      </p>

      <h2 style={h2Style}>3. Cookies and local storage</h2>
      <p>
        We use browser storage to keep you signed in and remember basic preferences. Analytics may
        use cookies. Block them if you like; the app will still mostly work.
      </p>

      <h2 style={h2Style}>4. Third parties</h2>
      <p>
        Llama Chat runs on trusted infrastructure with its own policies: Vercel (hosting) and our
        database provider. We give them the minimum access needed to run the service.
      </p>

      <h2 style={h2Style}>5. How long we keep things</h2>
      <p>
        Your content lives as long as your account does. Delete your account and we delete your
        profile and content, subject to anything the law requires us to keep. Backups may retain
        copies for a limited time.
      </p>

      <h2 style={h2Style}>6. Children</h2>
      <p>
        Llama Chat is not directed at children under 13, and accounts require you to be at least
        13. If you believe a child has given us personal data, contact us and we will delete it.
      </p>

      <h2 style={h2Style}>7. Your rights</h2>
      <p>
        Ask us what we hold about you, ask us to correct it, or ask us to delete it:{" "}
        <a href="mailto:Dave@Tugboat.io">Dave@Tugboat.io</a>. We honor applicable privacy rights
        (EU, California, and elsewhere).
      </p>

      <h2 style={h2Style}>8. Changes</h2>
      <p>
        Material changes get a new date at the top and a visible note. The current version always
        lives at this URL.
      </p>

      <h2 style={h2Style}>9. Contact</h2>
      <p>
        Questions: <a href="mailto:Dave@Tugboat.io">Dave@Tugboat.io</a>. Our terms of service live
        at <Link to="/terms">llamachat.io/terms</Link>.
      </p>
      <Back />
    </div>
  );
}
