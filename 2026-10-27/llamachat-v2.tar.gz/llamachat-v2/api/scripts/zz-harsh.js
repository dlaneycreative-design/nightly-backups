const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
(async () => {
  const t = await sql`SELECT id, text, image_url, created_at FROM tweets WHERE author_id = 'cac2d6dc-df51-526a-942a-ca8c229f6c56' AND reply_to_id IS NULL ORDER BY created_at DESC LIMIT 6`;
  for (const r of t) console.log("TWEET", r.id, "|", new Date(Number(r.created_at)).toISOString(), "| IMG:", r.image_url || "(none)", "|", JSON.stringify(r.text).slice(0,300));
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
