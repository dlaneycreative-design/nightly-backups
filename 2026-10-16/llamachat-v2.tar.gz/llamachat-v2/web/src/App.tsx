import { useEffect, useMemo, useRef, useState, type JSX, type TouchEvent } from "react";
import { BrowserRouter, Link, NavLink, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import { createClient, type ApiClient, type Profile } from "./lib/api.ts";
import { getCallerId, ensureDevSession } from "./lib/session.ts";
import { upsertProfile } from "./lib/store.ts";
import { resolveImageUrl } from "./lib/images.ts";
import { lazy, Suspense } from "react";
import { ErrorBoundary } from "./components/ErrorBoundary.tsx";
import { Feed } from "./components/Feed.tsx";
import { SearchAutocomplete } from "./components/SearchAutocomplete.tsx";
const TweetThread = lazy(() => import("./components/TweetThread.tsx").then(m => ({ default: m.TweetThread })));
const ProfileHeader = lazy(() => import("./components/ProfileHeader.tsx").then(m => ({ default: m.ProfileHeader })));
const ProfileTabs = lazy(() => import("./components/ProfileTabs.tsx").then(m => ({ default: m.ProfileTabs })));
const DMSplit = lazy(() => import("./components/DMSplit.tsx").then(m => ({ default: m.DMSplit })));
const SearchView = lazy(() => import("./components/SearchView.tsx").then(m => ({ default: m.SearchView })));
const HashtagView = lazy(() => import("./components/HashtagView.tsx").then(m => ({ default: m.HashtagView })));
const ExploreView = lazy(() => import("./components/ExploreView.tsx").then(m => ({ default: m.ExploreView })));
const NotificationsView = lazy(() => import("./components/NotificationsView.tsx").then(m => ({ default: m.NotificationsView })));
import { ReplyModalHost } from "./components/ReplyModal.tsx";
import { ComposeModalHost, } from "./components/ComposeModal.tsx";
import { SignupModalHost } from "./components/SignupModal.tsx";
import { Toast } from "./components/Toast.tsx";
import { TermsPage, PrivacyPage } from "./components/Legal.tsx";
import { Login } from "./components/Login.tsx";
import { openComposeModal, setViewedProfileHandle } from "./lib/composeModal.ts";

// API base: VITE_API_BASE, defaulting to the same-origin /api/v2 (the API
// Worker is routed under llamachat.lol/api/* in production). Never default
// to localhost: a plain production build must talk to the real API.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "/api/v2";

interface Ctx {
  api: ApiClient;
  me: Profile | null;
}

function HomeView({ api, me }: Ctx) {
  const [tab, setTab] = useState<"foryou" | "chron" | "shuffle">("foryou");
  const [shuffleCount, setShuffleCount] = useState(0);
  const [tabsHidden, setTabsHidden] = useState(false);
  const [pullY, setPullY] = useState(0);
  const pullStartY = useRef(0);
  const pullArmed = useRef(false);
  const pullDist = useRef(0);
  const lastScrollY = useRef(0);

  // Dice button in the sidebar dispatches this to shuffle the feed.
  // Counter ensures every click reshuffles, even if already on shuffle tab.
  useEffect(() => {
    const onShuffle = () => {
      setTab("shuffle");
      setShuffleCount((c) => c + 1);
    };
    window.addEventListener("feed-shuffle", onShuffle);
    return () => window.removeEventListener("feed-shuffle", onShuffle);
  }, []);

  // Hide tabs on scroll down (mobile, like X). Show on scroll up.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const isMobile = () => window.matchMedia("(max-width: 999px)").matches;
    const onScroll = () => {
      if (!isMobile()) { setTabsHidden(false); return; }
      const y = window.scrollY;
      const dy = y - lastScrollY.current;
      lastScrollY.current = y;
      if (y < 50) { setTabsHidden(false); return; }
      if (dy > 5) setTabsHidden(true);
      else if (dy < -5) setTabsHidden(false);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Pull-to-refresh -> shuffle (mobile only). Dave's calls Oct 10 + Oct 15
  // 2026: mobile gets the dice button's behavior as a pull gesture. The
  // gesture is armed ONLY at the very top of the feed and can start anywhere
  // on the home view; it used to be bound to the thin tabs strip alone, so
  // a pull starting on the feed itself (the natural gesture) never fired.
  // Releasing past the threshold does exactly what the dice button does:
  // switch to the shuffle tab and reshuffle (random feed of 30). Gesture
  // state lives in refs so touchend reads the true final distance, and a
  // second finger or a mid-feed start cancels the pull outright.
  const PULL_THRESHOLD = 80;
  const onTouchStart = (e: TouchEvent) => {
    if (typeof window === "undefined") return;
    if (!window.matchMedia("(max-width: 999px)").matches) return;
    if (window.scrollY > 10 || e.touches.length !== 1) {
      pullArmed.current = false;
      return;
    }
    pullStartY.current = e.touches[0].clientY;
    pullDist.current = 0;
    pullArmed.current = true;
  };
  const onTouchMove = (e: TouchEvent) => {
    if (!pullArmed.current) return;
    if (e.touches.length !== 1 || window.scrollY > 10) {
      pullArmed.current = false;
      pullDist.current = 0;
      setPullY(0);
      return;
    }
    const dy = e.touches[0].clientY - pullStartY.current;
    pullDist.current = dy > 0 ? Math.min(dy, 120) : 0;
    setPullY(pullDist.current);
  };
  const endPull = (fire: boolean) => {
    if (!pullArmed.current) return;
    pullArmed.current = false;
    if (fire && pullDist.current > PULL_THRESHOLD) {
      setTab("shuffle");
      setShuffleCount((c) => c + 1);
    }
    pullDist.current = 0;
    setPullY(0);
  };

  return (
    <div
      className="home-view"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={() => endPull(true)}
      onTouchCancel={() => endPull(false)}
    >
      {pullY > 0 ? (
        <div className="pull-refresh" style={{ height: pullY, opacity: Math.min(pullY / 80, 1) }}>
          <span className="pull-dice">🎲</span>
          <span>{pullY > 80 ? "Release to shuffle!" : "Pull to shuffle"}</span>
        </div>
      ) : null}
      <div
        className={`feedtabs${tabsHidden ? " tabs-hidden" : ""}`}
        style={me ? undefined : { display: "none" }}
      >
        <button
          className={`ftab${tab === "foryou" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("foryou")}
        >
          For you
        </button>
        <button
          className={`ftab${tab === "chron" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("chron")}
        >
          Following
        </button>
        {tab === "shuffle" ? (
          <button
            className="ftab active"
            type="button"
            onClick={() => setTab("shuffle")}
            title="Shuffle again"
          >
            🎲 Shuffle
          </button>
        ) : null}
      </div>
      <Feed key={`${tab}-${shuffleCount}`} api={api} apiBase={API_BASE} me={me} sort={tab} />
    </div>
  );
}

function ThreadView({ api }: Ctx) {
  const { id } = useParams();
  if (!id) return <div className="empty"><p>Missing post id.</p></div>;
  return <TweetThread api={api} id={id} />;
}

function ProfileView({ api }: Ctx) {
  const { handle } = useParams();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);

  // While a profile is on screen, register it so the compose modal can
  // prefill "@Handle " when Dave hits Post from here.
  useEffect(() => {
    setViewedProfileHandle(handle ?? null);
    return () => setViewedProfileHandle(null);
  }, [handle]);

  useEffect(() => {
    if (!handle) return;
    let alive = true;
    setProfile(null);
    setError(null);
    api
      .profile(handle)
      .then(({ profile: p }) => {
        if (!alive) return;
        setProfile(upsertProfile(p));
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e.message : "Profile not found.");
      });
    return () => {
      alive = false;
    };
  }, [api, handle]);

  if (error) {
    return (
      <div className="empty">
        <h2>No such person</h2>
        <p>@{handle} does not exist here yet.</p>
      </div>
    );
  }
  if (!profile || !handle) {
    return (
      <div aria-label="Loading profile">
        <div className="pf-banner" />
        <div className="pf-idrow">
          <div className="skel skel-avatar" />
        </div>
        <div className="pf-bio">
          <div className="skel skel-line short" />
          <div className="skel skel-line" />
        </div>
      </div>
    );
  }
  return (
    <div>
      <ProfileHeader api={api} profile={profile} onProfile={setProfile} />
      <ProfileTabs api={api} handle={handle} />
    </div>
  );
}

function HashtagRoute({ api }: Ctx) {
  const { tag } = useParams();
  if (!tag) return <div className="empty"><p>Missing tag.</p></div>;
  return <HashtagView api={api} tag={tag} />;
}

function NotFound() {
  return (
    <div className="empty">
      <h2>Lost in the Studio</h2>
      <p>This page does not exist.</p>
    </div>
  );
}

// X-style SVG nav icons (from thestudio.io/llama)
const ICONS: Record<string, JSX.Element> = {
  home: <svg className="nic" viewBox="0 0 24 24"><path d="M12 3l9 8h-3v9h-4v-6H10v6H6v-9H3z"/></svg>,
  explore: <svg className="nic" viewBox="0 0 24 24"><path d="M10 2a8 8 0 105.3 14l4 4 1.4-1.4-4-4A8 8 0 0010 2zm0 2a6 6 0 110 12 6 6 0 010-12z"/></svg>,
  notifications: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a7 7 0 00-7 7v3.5L3.5 15h17L19 12.5V9a7 7 0 00-7-7zm0 2a5 5 0 015 5v4H7V9a5 5 0 015-5zm-3 14h6a3 3 0 01-6 0z"/></svg>,
  messages: <svg className="nic" viewBox="0 0 24 24"><path d="M4 4h16a1 1 0 011 1v12a1 1 0 01-1 1H8l-5 4V5a1 1 0 011-1zm1 2v12.7L8.7 15H20V6H5z"/></svg>,
  profile: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a5 5 0 110 10 5 5 0 010-10zm0 2a3 3 0 100 6 3 3 0 000-6zm-7 14c.8-3.2 3.9-5 7-5s6.2 1.8 7 5H5z"/></svg>,
};

const NAV: { to: string; label: string; icon: keyof typeof ICONS }[] = [
  { to: "/", label: "Home", icon: "home" },
  { to: "/explore", label: "Explore", icon: "explore" },
  { to: "/search", label: "Search", icon: "explore" },
  { to: "/notifications", label: "Notifications", icon: "notifications" },
  { to: "/messages", label: "Messages", icon: "messages" },
];

function SideNav({ me, api, mini = false }: { me: Profile | null; api: any; mini?: boolean }) {
  const navigate = useNavigate();
  const profileTo = me ? `/profile/${me.handle}` : "/login";
  if (mini) {
    return (
      <nav className="sidenav mini" aria-label="Primary">
        <div className="sidenav-scroll mini-scroll">
          <div className="logo mini-logo">
            <a href="/" onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label="LlamaChat home">
              <img src="/llama-logo.avif" alt="LlamaChat" />
            </a>
          </div>
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label={n.label}>
              <span className="nav-icon-wrap">{ICONS[n.icon]}{n.to === "/notifications" ? <NotifBadge api={api} /> : null}</span>
            </NavLink>
          ))}
          <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label="Profile">
            {ICONS.profile}
          </NavLink>
        </div>
      </nav>
    );
  }
  return (
    <nav className="sidenav" aria-label="Primary">
      <div className="sidenav-scroll">
        <div className="logo">
          <a href="/" onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label="LlamaChat home">
            <img src="/llama-logo.avif" alt="LlamaChat" />
          </a>
        </div>
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
            <span className="nav-icon-wrap">{ICONS[n.icon]}{n.to === "/notifications" ? <NotifBadge api={api} /> : null}</span>{n.label}
          </NavLink>
        ))}
        <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
          {ICONS.profile}Profile
        </NavLink>
        {me ? (
          <>
            <button type="button" className="bigpost" onClick={() => openComposeModal()}>Post</button>
          </>
        ) : (
          <button type="button" className="bigpost" onClick={() => navigate("/login")}>Log in</button>
        )}
        <button
          type="button"
          className="dice-btn"
          onClick={() => {
            navigate("/");
            window.dispatchEvent(new CustomEvent("feed-shuffle"));
          }}
          title="Shuffle the feed"
          aria-label="Shuffle the feed"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8.5" cy="8.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="15.5" cy="15.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="15.5" cy="8.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="8.5" cy="15.5" r="1.4" fill="currentColor" stroke="none"/></svg>
        </button>
      </div>
      {me ? (
        <div
          className="me-mini"
          onClick={() => navigate(`/profile/${me.handle}`)}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); navigate(`/profile/${me.handle}`); } }}
          role="link"
          tabIndex={0}
          aria-label={`View profile of ${me.display_name}`}
        >
          {resolveImageUrl(me.avatar_url) ? (
            <img src={resolveImageUrl(me.avatar_url)!} alt={me.display_name} />
          ) : (
            <img src="/llama-logo.avif" alt="LlamaChat" />
          )}
          <div><div className="n">{me.display_name}</div><div className="h">@{me.handle}</div></div>
        </div>
      ) : null}
      {/* Dave's call Oct 10 2026 (legal audit): persistent legal links. */}
      <div className="sidenav-legal" style={{ marginTop: "auto", padding: "16px 4px 4px", fontSize: 12 }}>
        <Link to="/terms" style={{ color: "#8e8e93", marginRight: 12 }}>Terms</Link>
        <Link to="/privacy" style={{ color: "#8e8e93" }}>Privacy</Link>
      </div>
    </nav>
  );
}

/** Persistent bottom-left footer: dev link + page generation time + version. */
function SideNavWrap({ me, api }: { me: Profile | null; api: any }) {
  const loc = useLocation();
  const mini = loc.pathname.startsWith("/messages");
  return <SideNav me={me} api={api} mini={mini} />;
}

function SideNavFoot() {
  const [loadTime, setLoadTime] = useState("");
  useEffect(() => {
    const onLoad = () => {
      // Modern Navigation Timing API (performance.timing is deprecated and
      // returns 0s in some browsers, producing negative garbage).
      const nav = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
      if (nav && nav.loadEventEnd > 0) {
        const secs = ((nav.loadEventEnd - nav.startTime) / 1000).toFixed(1);
        setLoadTime(secs + "s");
      }
      // If timing is unavailable, leave loadTime empty (nothing renders).
    };
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad);
    return () => window.removeEventListener("load", onLoad);
  }, []);
  // Dev footer hidden in production (Dave's call Oct 9 2026)
  if (typeof window !== 'undefined' && (window.location.hostname === 'llamachat.io' || window.location.hostname === 'llamachat.lol')) {
    return null;
  }
  return (
    <div className="sidenav-foot">
      <span className="gen-time">LlamaChat VONE</span>
      <span className="version-tag"> | V2</span>
      <a href="https://e2.life/map" target="_blank" rel="noopener" className="map-link" title="E2 map"> | 🗺️</a>
      {loadTime && <span className="load-time" style={{marginLeft: "auto", color: "#8e8e93", fontSize: "11px"}}>{loadTime}</span>}
    </div>
  );
}

function WhoRow({ api, n, h, img }: { api: ApiClient; n: string; h: string; img: string }) {
  const navigate = useNavigate();
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);

  // Load actual follow status on mount (Dave's call Oct 9 2026:
  // "doesn't remember who you're following")
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { profile } = await api.profile(h);
        if (alive) setFollowing(!!profile.following);
      } catch {
        /* keep default */
      }
    })();
    return () => { alive = false; };
  }, [api, h]);

  const toggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try {
      const { profile } = await api.profile(h);
      if (following) {
        await api.unfollow(profile.id);
        setFollowing(false);
      } else {
        await api.follow(profile.id);
        setFollowing(true);
      }
    } catch {
      // keep the button state; user can retry
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="who"
      onClick={() => navigate(`/profile/${h}`)}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); navigate(`/profile/${h}`); } }}
      role="link"
      tabIndex={0}
      aria-label={`View profile of ${n}`}
    >
      <img src={img} alt={n} loading="lazy" />
      <div><div className="n">{n}</div><div className="h">@{h}</div></div>
      <button type="button" onClick={toggle} disabled={busy} className={following ? "is-following" : ""}>
        {following ? "Following" : "Follow"}
      </button>
    </div>
  );
}

function RightBarWrap({ api }: { api: ApiClient }) {
  const loc = useLocation();
  if (loc.pathname.startsWith("/messages")) return null;
  return <RightBar api={api} />;
}

function RightBar({ api }: { api: ApiClient }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    if (query) navigate(`/search?q=${encodeURIComponent(query)}`);
  };
  return (
    <aside className="rightbar" aria-label="Trends">
      <div className="rsearch-wrap">
        <form className="rsearch real" onSubmit={submit}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search LlamaChat"
            aria-label="Search LlamaChat"
          />
        </form>
        <SearchAutocomplete api={api} query={q} onNavigate={() => setQ("")} />
      </div>
      <div className="rcard">
        <h2>Who to follow</h2>
        {[
          { n: "Sally", h: "sally", img: "/assets/avatars/sally.jpg" },
          { n: "Chadwick", h: "chadwick", img: "/assets/avatars/chadwickblaze.jpg" },
          { n: "Dinesh", h: "dinesh", img: "/assets/avatars/dinesh.webp" },
          { n: "Marty", h: "Marty", img: "/assets/avatars/martychaos.jpg" },
        ].map((w) => (
          <WhoRow key={w.h} api={api} n={w.n} h={w.h} img={w.img} />
        ))}
      </div>
    </aside>
  );
}

function BottomNav({ api }: { api: any }) {
  const loc = useLocation();
  const inDMs = loc.pathname.startsWith("/messages");
  const [hidden, setHidden] = useState(false);
  useEffect(() => {
    let lastY = window.scrollY;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        if (y > lastY && y > 80) setHidden(true);
        else if (y < lastY) setHidden(false);
        lastY = y;
        ticking = false;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <>
    <nav className={`bottomnav${hidden ? " hidden" : ""}`} aria-label="Primary">
      <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")} aria-label="Home">{ICONS.home}</NavLink>
      <NavLink to="/search" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Search">{ICONS.explore}</NavLink>
      <NavLink to="/explore" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Explore">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/></svg>
      </NavLink>
      <NavLink to="/notifications" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Notifications"><span className="nav-icon-wrap">{ICONS.notifications}<NotifBadge api={api} /></span></NavLink>
      <NavLink to="/messages" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Messages">{ICONS.messages}</NavLink>
    </nav>
    {/* Floating compose button, X style (Dave's call Oct 15 2026, screenshot
        checked against x.com): floats bottom right above the nav bar, never
        inside it. Hidden in DMs, where the thread has its own composer. */}
    {!inDMs && (
      <button
        type="button"
        className="compose-fab"
        aria-label="Compose new post"
        onClick={() => openComposeModal()}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg>
      </button>
    )}
    </>
  );
}


function MobileDrawer({ me, onClose }: { me: Profile; onClose: () => void }) {
  const navigate = useNavigate();
  const go = (path: string) => {
    onClose();
    navigate(path);
  };
  return (
    <>
      <button
        type="button"
        className="drawer-scrim"
        onClick={onClose}
        aria-label="Close menu"
        style={{ border: "none", padding: 0, cursor: "pointer" }}
      />
      <div className="mdrawer">
        <div className="mdrawer-head">
          <img
            src={resolveImageUrl(me.avatar_url) || "/llama-logo.avif"}
            alt={me.display_name}
            className="mdrawer-avatar"
          />
          <div className="mdrawer-name">{me.display_name}</div>
          <div className="mdrawer-handle">@{me.handle}</div>
          <button type="button" className="mdrawer-close" onClick={onClose} aria-label="Close menu">✕</button>
        </div>
        <nav className="mdrawer-nav">
          <button type="button" onClick={() => go(`/profile/${me.handle}`)}>
            <span className="mdrawer-icon">👤</span> Profile
          </button>
          <button type="button" onClick={() => go("/")}>
            <span className="mdrawer-icon">🏠</span> Home
          </button>
          <button type="button" onClick={() => go("/explore")}>
            <span className="mdrawer-icon">🔍</span> Explore
          </button>
          <button type="button" onClick={() => go("/notifications")}>
            <span className="mdrawer-icon">🔔</span> Notifications
          </button>
          <button type="button" onClick={() => go("/messages")}>
            <span className="mdrawer-icon">✉️</span> Messages
          </button>
        </nav>
      </div>
    </>
  );
}

// Unread notification badge: polls the unread-count endpoint
function NotifBadge({ api }: { api: any }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let alive = true;
    const fetchCount = async () => {
      try {
        const r = await api.unreadCount();
        if (alive) setCount(r.count || 0);
      } catch { /* not signed in */ }
    };
    fetchCount();
    const t = setInterval(fetchCount, 30000);
    const onFocus = () => fetchCount();
    window.addEventListener("focus", onFocus);
    // Refresh when notifications are marked read elsewhere
    const onRead = () => setCount(0);
    window.addEventListener("notif-read", onRead);
    return () => { alive = false; clearInterval(t); window.removeEventListener("focus", onFocus); window.removeEventListener("notif-read", onRead); };
  }, [api]);
  if (count <= 0) return null;
  return <span className="notif-badge">{count > 9 ? "9+" : count}</span>;
}

export function App() {
  const [me, setMe] = useState<Profile | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const api = useMemo(() => createClient(API_BASE, getCallerId), []);

  useEffect(() => {
    let alive = true;
    void ensureDevSession(api).then((p) => {
      if (alive && p) setMe(p);
    });
    return () => {
      alive = false;
    };
  }, [api]);

  const ctx: Ctx = { api, me };

  return (
    <BrowserRouter>
      <div className="app">
        <div className="mhead">
          {me ? (
            <button
              type="button"
              className="mhead-avatar"
              aria-label="Open menu"
              onClick={() => setDrawerOpen(true)}
            >
              <img
                src={resolveImageUrl(me.avatar_url) || "/llama-logo.avif"}
                alt={me.display_name}
              />
            </button>
          ) : null}
          <a href="/" onClick={(e) => { e.preventDefault(); window.location.href = "/"; }} aria-label="LlamaChat home" style={{display:"flex",alignItems:"center"}}>
            <img className="mhead-logo" src="/llama-logo.avif" alt="LlamaChat" />
          </a>
        </div>
        {drawerOpen && me ? (
          <MobileDrawer me={me} onClose={() => setDrawerOpen(false)} />
        ) : null}
        <div className="shell">
          <SideNavWrap me={me} api={api} />
          <main className="maincol feed-pad">
            <Suspense fallback={<div className="loading">Loading...</div>}>
            <Routes>
              <Route path="/" element={<ErrorBoundary label="home feed"><HomeView {...ctx} /></ErrorBoundary>} />
              <Route path="/profile/:handle" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="/tweet/:id" element={<ErrorBoundary label="post"><ThreadView {...ctx} /></ErrorBoundary>} />
              <Route path="/hashtag/:tag" element={<ErrorBoundary label="hashtag"><HashtagRoute {...ctx} /></ErrorBoundary>} />
              <Route path="/search" element={<ErrorBoundary label="search"><SearchView api={api} /></ErrorBoundary>} />
              <Route path="/messages" element={<ErrorBoundary label="messages"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/messages/:id" element={<ErrorBoundary label="conversation"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/explore" element={<ErrorBoundary label="explore"><ExploreView api={api} /></ErrorBoundary>} />
              <Route path="/notifications" element={<ErrorBoundary label="notifications"><NotificationsView api={api} /></ErrorBoundary>} />
              <Route path="/login" element={<ErrorBoundary label="login"><Login api={api} onDone={() => window.location.href = "/"} /></ErrorBoundary>} />
              {/* Dave's call Oct 10 2026 (legal audit): static legal pages. Must come before /:handle. */}
              <Route path="/terms" element={<ErrorBoundary label="terms"><TermsPage /></ErrorBoundary>} />
              <Route path="/privacy" element={<ErrorBoundary label="privacy"><PrivacyPage /></ErrorBoundary>} />
              {/* Dave's call Oct 9 2026: Twitter-style short profile URLs. /dave -> profile. Must come after all specific routes, before the catch-all. */}
              <Route path="/:handle" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="/:handle/:tab" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
            </Suspense>
          </main>
          <RightBarWrap api={api} />
        </div>
        <BottomNav api={api} />
        <SideNavFoot />
        <ReplyModalHost api={api} apiBase={API_BASE} me={me} />
        <ComposeModalHost api={api} apiBase={API_BASE} me={me} />
        <SignupModalHost />
        <Toast />
      </div>
    </BrowserRouter>
  );
}
