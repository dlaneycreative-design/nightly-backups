# LlamaChat Inspector: standing watchdog for llamachat.lol media + health.
# Dave's order Oct 13 2026, modeled on the Farm's Inspector.
# Full census, NO sampling. A URL passes only if ALL of these hold:
#   1. It resolves (exactly like web/src/lib/images.ts) to llamachat.lol itself.
#   2. The live server returns it with a 200/206.
#   3. The returned bytes sniff as a real image (not HTML, not an error page).
#   4. When the file exists in web/dist, the live byte count equals it.
#   5. The live byte count is at most 100 KB (the Llama Chat media cap,
#      Dave's law; rule name "oversize", added Oct 13 after a 1.4 MB PNG
#      was found by hand on the E2 homepage).
# Also audited: the live /seed-feed.json (every image inside it, same rules,
# plus a dead-host string scan), /api/v2/health, the site root, and that the
# live service worker cache version matches the source tree (stale-deploy
# tripwire). Writes inspector-reports/report-<ts>.json + inspector-state.json.
# Exit: 0 PASS, 1 FAIL, 2 INCOMPLETE (the inspector itself could not finish).
import fcntl, json, os, re, ssl, subprocess, sys, time
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor

BASE = "/home/hatch/workspace/llamachat-v2"
HOST = "https://llamachat.lol"
DIST = os.path.join(BASE, "web", "dist")
MAX_IMAGE_BYTES = 100 * 1024
REPORTS = os.path.join(BASE, "inspector-reports")

ABS_AVATAR_MAP = {
    "https://www.thestudio.io/casting/willa-portrait.webp": "/assets/avatars/willa.webp",
    "https://www.thestudio.io/casting/finn-portrait.webp": "/assets/avatars/finn.webp",
    "https://www.thestudio.io/daveos/img/chadwick-waving.png": "/assets/avatars/chadwick.webp",
    "https://www.thestudio.io/muse-avatar-final.webp": "/assets/avatars/muse.webp",
    "https://www.thestudio.io/e2/people/judgetootie/judgetootie.webp": "/assets/avatars/judge.webp",
    "https://www.thestudio.io/mike/assets/mike-gym-selfie.webp": "/assets/avatars/songify.webp",
    "https://e2.life/people/sam/sam.webp": "/assets/avatars/sam.webp",
}
LEGACY_AVATAR_MAP = {
    "/sloth/assets/llama-avatar.webp": "/assets/avatars/llama.webp",
    "/shortbus/assets/portraits/sally.jpg": "/assets/avatars/sally.jpg",
    "/shortbus/assets/portraits/marty-face.jpg": "/assets/avatars/martychaos.jpg",
    "/shortbus/assets/portraits/dinesh-solo.webp": "/assets/avatars/dinesh.webp",
    "/sloth/assets/ricky-avatar.webp": "/assets/avatars/memebot.webp",
    "/shortbus/assets/portraits/mateo.webp": "/assets/avatars/mateo.webp",
    "/shortbus/assets/portraits/haddie-face.jpg": "/assets/avatars/haddiesings.jpg",
    "/sloth/assets/harsh-avatar.jpg": "/assets/avatars/harsh.jpg",
    "/shortbus/assets/portraits/tex.jpg": "/assets/avatars/tex.webp",
    "/shortbus/assets/portraits/chadwick-face.jpg": "/assets/avatars/chadwickblaze.jpg",
    "/shortbus/assets/portraits/jaylen-bass.jpg": "/assets/avatars/jaylen.webp",
    "/shortbus/assets/portraits/jah-vibez.jpg": "/assets/avatars/jahvibez.webp",
    "/shortbus/assets/portraits/biscuit-face.jpg": "/assets/avatars/biscuit.jpg",
    "/shortbus/assets/portraits/gloria.jpg": "/assets/avatars/gloria.webp",
    "/sloth/assets/mike-static.png": "/assets/avatars/mike.png",
    "/plume/plume.webp": "/assets/avatars/plume.webp",
    "/henri/henri-hue.webp": "/assets/avatars/henri.webp",
    "/oldray/old-ray.webp": "/assets/avatars/oldray.webp",
    "/enrique/enrique.png": "/assets/avatars/enrique.webp",
    "/lemonHD/assets/leo-remake.webp": "/assets/avatars/leo.webp",
    "/dineshbot/dineshbot-avatar.webp": "/assets/avatars/dineshbot.webp",
    "/sally/doodle-bot.png": "/assets/avatars/doodle.webp",
    "/pixel/buster/buster-portrait.webp": "/assets/avatars/buster.webp",
    "/e2/map/sprite-mappy.webp": "/assets/avatars/mappy.webp",
    "/assets/hank.webp": "/assets/avatars/hank.webp",
    "/assets/ed.webp": "/assets/avatars/ed.webp",
    "/assets/avatars/dave-dlaney-face-400.webp": "/assets/avatars/dave.webp",
}
DEAD_HOSTS = ("thestudio.io", "blob.vercel-storage.com", "media.e2.life", "e2planet.com")

def resolve(url):
    if not url:
        return None
    if url in ABS_AVATAR_MAP:
        return ABS_AVATAR_MAP[url]
    if url.startswith("https://www.thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://www.thestudio.io/"):]
    if url.startswith("https://thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://thestudio.io/"):]
    if re.match(r"^(https?:|data:|blob:)", url, re.I):
        return url
    if url.startswith("//"):
        return "https:" + url
    if url in LEGACY_AVATAR_MAP:
        return LEGACY_AVATAR_MAP[url]
    if url.startswith("/assets/"):
        return url
    if url.startswith("/"):
        return HOST + url
    return url

def absolute(resolved):
    if resolved and resolved.startswith("/"):
        return HOST + resolved
    return resolved

def sniff(b):
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return "webp"
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if b[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if b[4:8] == b"ftyp":
        return "avif"
    if b[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if b"<svg" in b[:256]:
        return "svg"
    return None

ctx = ssl.create_default_context()

def fetch(url, want_body=True):
    """Return (status, body_bytes_or_None, error_str). 4 attempts with
    growing backoff (Oct 13: the VM egress collapses in waves lasting
    longer than the old 1s retry gaps, so every URL in a wave failed
    together; wider spacing lets a wave pass mid-run)."""
    last = (None, None, "no attempt")
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (LlamaChat Inspector)"})
            with urllib.request.urlopen(req, timeout=25, context=ctx) as r:
                body = r.read() if want_body else None
                return (r.status, body, None)
        except urllib.error.HTTPError as e:
            last = (e.code, None, f"HTTP {e.code}")
            if e.code in (404, 410, 403, 522):
                return last
        except Exception as e:
            last = (None, None, f"{type(e).__name__}")
        time.sleep((2, 5, 10)[min(attempt, 2)])
    return last

def check_media(url):
    """Return list of failure dicts for one resolved absolute URL (empty = pass)."""
    fails = []
    if url.startswith(("data:", "blob:")):
        return fails
    if not (url.startswith(HOST + "/") or url == HOST):
        return [{"url": url, "rule": "home", "detail": "resolves OFF llamachat.lol"}]
    status, body, err = fetch(url)
    if status not in (200, 206):
        return [{"url": url, "rule": "status", "detail": f"live status {status or err}"}]
    kind = sniff(body or b"")
    if not kind:
        return [{"url": url, "rule": "bytes", "detail": "live bytes are not an image (fallback page?)"}]
    if body is not None and len(body) > MAX_IMAGE_BYTES:
        fails.append({"url": url, "rule": "oversize",
                      "detail": f"live image is {len(body)}B, over the 100KB Llama Chat media cap"})
    path = url[len(HOST):]
    disk = os.path.join(DIST, path.lstrip("/"))
    if os.path.isfile(disk) and body is not None and len(body) != os.path.getsize(disk):
        fails.append({"url": url, "rule": "size", "detail": f"live {len(body)}B != dist {os.path.getsize(disk)}B"})
    return fails

def main():
    # Single-runner lock (Oct 13): dueling inspector processes saturate the
    # egress path and manufacture read-error failures. If another run holds
    # the lock, exit WITHOUT touching state; that run writes the verdict.
    lockf = open("/tmp/llamachat-inspector.lock", "w")
    try:
        fcntl.flock(lockf, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("INCOMPLETE: another inspector run is already in progress; skipping")
        return 2
    failures = []
    notes = []
    os.makedirs(REPORTS, exist_ok=True)
    # 1. Refresh the DB enumeration.
    try:
        r = subprocess.run(["node", os.path.join(BASE, "census-enumerate.js")],
                           capture_output=True, text=True, timeout=1200)
    except subprocess.TimeoutExpired:
        print("INCOMPLETE: enumeration timed out after 1200s")
        save_state("INCOMPLETE", [{"url": "(database)", "rule": "enumerate",
                                   "detail": "census-enumerate.js timed out after 1200 seconds"}])
        return 2
    if r.returncode != 0:
        print("INCOMPLETE: enumeration failed:", (r.stderr or r.stdout)[:300])
        save_state("INCOMPLETE", [{"url": "(database)", "rule": "enumerate", "detail": "census-enumerate.js failed"}])
        return 2
    raw = json.load(open(os.path.join(BASE, "census-raw.json")))
    refs = []
    for p in raw["profiles"]:
        if p.get("avatar_url"):
            refs.append(("avatar", p["handle"], p["avatar_url"]))
    for t in raw["tweets"]:
        refs.append(("tweet-image", t["id"], t["image_url"]))
    for m in raw["messages"]:
        refs.append(("message-image", m["id"], m["image_url"]))
    # 2. Home rule on STORED urls: a stored absolute URL on a dead host is a
    # failure even if the client map rescues it today.
    for kind, owner, stored in refs:
        for h in DEAD_HOSTS:
            if h in stored:
                failures.append({"url": stored, "rule": "stored-host",
                                 "detail": f"{kind} of {owner} is stored on {h}"})
    distinct = sorted({absolute(resolve(s)) for _, _, s in refs if resolve(s)})
    # 3. Byte-level live check of every distinct resolved URL.
    with ThreadPoolExecutor(max_workers=3) as ex:
        for url, fl in zip(distinct, ex.map(check_media, distinct)):
            for f in fl:
                f["refs"] = sum(1 for _, _, s in refs if absolute(resolve(s)) == url)
                failures.append(f)
    notes.append(f"media: {len(refs)} refs, {len(distinct)} distinct URLs checked")
    # 4. Seed audit: the live seed file browsers actually paint from.
    status, body, err = fetch(HOST + "/seed-feed.json")
    if status != 200 or not body:
        failures.append({"url": HOST + "/seed-feed.json", "rule": "seed",
                         "detail": f"live seed status {status or err}"})
    else:
        try:
            seed = json.loads(body.decode("utf-8"))
            text = body.decode("utf-8", "replace")
            for h in DEAD_HOSTS:
                if h in text:
                    failures.append({"url": HOST + "/seed-feed.json", "rule": "seed-host",
                                     "detail": f"seed contains {h}"})
            # e2.life in tweet TEXT links is approved (Dave, Oct 13: the
            # mikeblog links point at e2.life/mikeblog). It still fails as a
            # media host: no cross-site images, ever.
            seed_media = []
            for t in seed.get("tweets", []):
                if t.get("image_url"):
                    seed_media.append(t["image_url"])
                a = t.get("author") or {}
                if a.get("avatar_url"):
                    seed_media.append(a["avatar_url"])
            for p in seed.get("profiles", []):
                if isinstance(p, dict) and p.get("avatar_url"):
                    seed_media.append(p["avatar_url"])
            for u in seed_media:
                if "e2.life" in str(u):
                    failures.append({"url": HOST + "/seed-feed.json", "rule": "seed-host",
                                     "detail": "seed media hosted on e2.life"})
            seed_urls = set()
            for t in seed.get("tweets", []):
                if t.get("image_url"):
                    seed_urls.add(absolute(resolve(t["image_url"])))
                a = t.get("author") or {}
                if a.get("avatar_url"):
                    seed_urls.add(absolute(resolve(a["avatar_url"])))
            seed_urls.discard(None)
            with ThreadPoolExecutor(max_workers=3) as ex:
                for url, fl in zip(sorted(seed_urls), ex.map(check_media, sorted(seed_urls))):
                    for f in fl:
                        f["rule"] = "seed-" + f["rule"]
                        failures.append(f)
            notes.append(f"seed: {len(seed.get('tweets', []))} tweets, {len(seed_urls)} image URLs checked")
        except Exception as e:
            failures.append({"url": HOST + "/seed-feed.json", "rule": "seed",
                             "detail": f"unparseable: {type(e).__name__}"})
    # 5. Site + API health and the stale-deploy tripwire.
    status, body, err = fetch(HOST + "/")
    if status != 200 or not body or b"LlamaChat" not in body:
        failures.append({"url": HOST + "/", "rule": "health", "detail": f"root status {status or err}"})
    status, body, err = fetch(HOST + "/api/v2/health")
    if status != 200:
        failures.append({"url": HOST + "/api/v2/health", "rule": "health", "detail": f"api health {status or err}"})
    local_sw = open(os.path.join(BASE, "web", "public", "sw.js")).read()
    m = re.search(r"const CACHE = '([^']+)'", local_sw)
    status, body, err = fetch(HOST + "/sw.js")
    if status != 200 or not body:
        failures.append({"url": HOST + "/sw.js", "rule": "health", "detail": f"sw status {status or err}"})
    elif m and m.group(1).encode() not in body:
        failures.append({"url": HOST + "/sw.js", "rule": "stale-deploy",
                         "detail": f"live sw cache != source {m.group(1)} (deploy is behind the tree)"})
    # Transport honesty (Oct 13): when the census network path collapses
    # (VM egress under load, dueling runs), most "failures" are read errors
    # on files that are fine. A run dominated by transport errors proves
    # nothing about the site: verdict INCOMPLETE, real failures kept.
    TRANSPORT = ("IncompleteRead", "RemoteDisconnected", "TimeoutError",
                 "timed out", "URLError", "ConnectionResetError",
                 "Remote end closed", "EOF occurred")
    transport = [f for f in failures
                 if any(t in str(f.get("detail", "")) for t in TRANSPORT)]
    ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    if failures and len(transport) >= max(10, len(failures) // 2):
        real = [f for f in failures if f not in transport]
        failures = [{"url": HOST + "/", "rule": "transport",
                     "detail": f"census network collapsed: {len(transport)} read errors, {len(real)} real failures; verdict deferred to a clean run"}] + real
        report = {"verdict": "INCOMPLETE", "run_at": ts, "notes": notes, "failures": failures}
        json.dump(report, open(os.path.join(REPORTS, f"report-{ts}.json"), "w"), indent=1)
        save_state("INCOMPLETE", failures, ts)
        print(f"INCOMPLETE: {len(transport)} transport errors, {len(real)} real failures")
        return 2
    verdict = "PASS" if not failures else "FAIL"
    report = {"verdict": verdict, "run_at": ts, "notes": notes, "failures": failures}
    json.dump(report, open(os.path.join(REPORTS, f"report-{ts}.json"), "w"), indent=1)
    save_state(verdict, failures, ts)
    print(f"{verdict}: {len(failures)} failures | " + " | ".join(notes))
    for f in failures:
        print(" FAIL", f["rule"], f["url"], "-", f["detail"])
    return 0 if verdict == "PASS" else 1

def save_state(verdict, failures, ts=None):
    state = {"verdict": verdict, "run_at": ts or time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()),
             "failure_count": len(failures), "failures": failures[:50]}
    json.dump(state, open(os.path.join(BASE, "inspector-state.json"), "w"), indent=1)

if __name__ == "__main__":
    sys.exit(main())
