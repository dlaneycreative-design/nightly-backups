// About Llama Chat: what makes it different from X. Dave's call
// Oct 30 2026: a really clear page explaining the cool features,
// the money and game commands, with all the misspellings tucked
// under a chevron so the main commands stay clean.
import React from "react";
import { Link } from "react-router-dom";

const pageStyle: React.CSSProperties = {
  maxWidth: 720,
  margin: "0 auto",
  padding: "48px 20px 80px",
  lineHeight: 1.7,
  fontSize: 16,
};

const h1Style: React.CSSProperties = {
  fontSize: 34,
  fontWeight: 800,
  letterSpacing: "-0.02em",
  marginBottom: 8,
};

const h2Style: React.CSSProperties = {
  fontSize: 22,
  fontWeight: 800,
  marginTop: 44,
  marginBottom: 8,
};

const metaStyle: React.CSSProperties = {
  color: "#8e8e93",
  fontSize: 14,
  marginBottom: 8,
};

// Neutral translucent grays throughout: the app has light and dark
// themes, and these read correctly on both (hardcoded dark-theme
// colors made the code chips unreadable in light mode).
const cardStyle: React.CSSProperties = {
  border: "1px solid rgba(128,128,128,0.4)",
  borderRadius: 16,
  padding: "16px 18px",
  margin: "14px 0",
};

const cmdRowStyle: React.CSSProperties = {
  display: "flex",
  gap: 14,
  alignItems: "baseline",
  padding: "7px 0",
  borderBottom: "1px solid rgba(128,128,128,0.3)",
  flexWrap: "wrap",
};

const codeStyle: React.CSSProperties = {
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  fontSize: 14.5,
  background: "rgba(128,128,128,0.18)",
  border: "1px solid rgba(128,128,128,0.35)",
  borderRadius: 8,
  padding: "2px 8px",
  whiteSpace: "nowrap",
};

const descStyle: React.CSSProperties = { opacity: 0.78, fontSize: 15 };

const chevWrapStyle: React.CSSProperties = {
  border: "1px solid rgba(128,128,128,0.4)",
  borderRadius: 16,
  padding: "4px 18px",
  margin: "14px 0",
};

const summaryStyle: React.CSSProperties = {
  cursor: "pointer",
  fontWeight: 700,
  padding: "12px 0",
  listStyle: "none",
};

function Cmd({ code, children }: { code: string; children: React.ReactNode }) {
  return (
    <div style={cmdRowStyle}>
      <code style={codeStyle}>{code}</code>
      <span style={descStyle}>{children}</span>
    </div>
  );
}

function SpellGroup({ label, items }: { label: string; items: string[] }) {
  return (
    <p style={{ margin: "10px 0" }}>
      <strong>{label}:</strong>{" "}
      {items.map((s, i) => (
        <React.Fragment key={s}>
          {i > 0 ? ", " : ""}
          <code style={codeStyle}>{s}</code>
        </React.Fragment>
      ))}
    </p>
  );
}

export function AboutPage() {
  return (
    <div style={pageStyle}>
      <h1 style={h1Style}>About Llama Chat</h1>
      <p style={metaStyle}>The social app where a post can do things.</p>
      <p>
        Llama Chat looks familiar on purpose: posts, replies, likes, follows, messages.
        The difference is what a post can hold. On X, a post is words and pictures, and
        that is the end of it. Here, a post is a container. You can send real money in a
        post. You can drop a whole playable video game into a post. And we are just
        getting started with what fits inside one.
      </p>

      <h2 style={h2Style}>💛 Send money in a post</h2>
      <p>
        Tippy, our money bot, lives here just like in the E2 Discord, with the same bank
        and the same balances. Post a tip command and Tippy moves the money instantly
        and confirms it right in the thread. Amounts work in pesos, dollars, rupees, or
        SOL, and you can split one tip between up to 10 people.
      </p>
      <div style={cardStyle}>
        <Cmd code="$tip @harsh 5p">Send ₱5 to Harsh. Try 50 pesos, $.25, ₹100, or 0.1 SOL.</Cmd>
        <Cmd code="$tip @sam &amp; @harsh 20p">Split ₱20 between two people.</Cmd>
        <Cmd code="$bal">See your balance.</Cmd>
        <Cmd code="$bank">See the Tippy bank.</Cmd>
        <Cmd code="$dash">See the whole money network at a glance.</Cmd>
        <Cmd code="$deposit">How to put money in.</Cmd>
        <Cmd code="$help">Every Tippy command, from Tippy.</Cmd>
      </div>
      <p>
        Tips also work in direct messages when Tippy is in the conversation. Putting
        money in and taking it out runs through Tippy on Discord for now; tipping and
        balances here work right away.
      </p>

      <h2 style={h2Style}>🕹️ Drop a game into a post</h2>
      <p>
        Post a game command and the game appears inside your post, cover art and a big
        Play button included. Tap Play and it runs right in the feed, no download, no
        leaving the app. Our arcade bot, @arcade, confirms every game in the thread.
      </p>
      <div style={cardStyle}>
        <Cmd code="!games">See every game you can drop in a post.</Cmd>
        <Cmd code="!SuperE2">Super E2, the platformer. Pick a runner and race.</Cmd>
        <Cmd code="!play Super E2">The same game, the long way round.</Cmd>
        <Cmd code="!MURKH">MURKH: Disaster in the Sky, by Harsh.</Cmd>
        <Cmd code="!snake">The classic Snake. Eat apples, grow long, do not bite your tail.</Cmd>
        <Cmd code="!snakeduel">Snake Duel: two snakes, one keyboard, first to 5 rounds.</Cmd>
      </div>
      <p>
        Made a game yourself? Put it on{" "}
        <a href="https://openarcade.lol" target="_blank" rel="noopener">Open Arcade</a>{" "}
        and it can live in posts here too.
      </p>

      <details style={chevWrapStyle}>
        <summary style={summaryStyle}>▸ Spelling usually does not matter: most variations work</summary>
        <p>
          People type fast and spell creatively, so the commands are forgiving.
          Most variations work: if it looks like a game command, it will usually
          launch the game. These are some of the variations that work:
        </p>
        <SpellGroup
          label="Command words"
          items={["!lay snake", "!gmae snake", "!gaem murkh", "!playsnake", "!gamemurkh", "! MURKH", "!!MURKH", "!games list"]}
        />
        <SpellGroup
          label="Super E2"
          items={["!super E2", "!super", "!play super", "!Game SuperE2", "!Game SUPER-E2", "!play supper E2", "!Super E2 is the best"]}
        />
        <SpellGroup
          label="MURKH"
          items={["!M-U-R-K-H", "!merk", "!play merc", "!murch", "!play murk", "!play MURKH: Disaster in the Sky", "!MURKH is live"]}
        />
        <SpellGroup
          label="Snake"
          items={["!sanke", "!snaek", "!play Google Snake", "!googlesnake", "!snake!"]}
        />
        <p style={{ marginBottom: 12 }}>
          Trailing words are fine too: end your post with extra chatter and the game
          still lands. And plain talk never triggers anything, so nobody drops a game
          by accident.
        </p>
      </details>

      <h2 style={h2Style}>🧩 Apps, in beta</h2>
      <p>
        Llama Chat also has an <Link to="/apps">Apps</Link> section, down at the
        bottom of the sidebar. Apps are little extras you install on purpose: tap
        Install and the app pins itself into your sidebar, ready whenever you are.
        Our first app is <strong>Flashcards</strong>, a Spanish flashcard game with
        50 levels and 2,000 cards, so you can learn a little every day without
        leaving Llama Chat. Apps are brand new and firmly in beta: we are
        experimenting, trying things, and seeing what the vibe is like, so expect
        the shelf to change as we learn what people actually enjoy.
      </p>

      <h2 style={h2Style}>🔮 What is coming next</h2>
      <p>
        Money and games are only the first two things that fit in a post. Next up:
        whole VR worlds you can drop into a post and step inside, and whatever else
        we dream up. The idea underneath all of it stays the same: if you can post
        it, you should be able to drop it in a post and let people use it, play it,
        or walk around in it, right where they found it.
      </p>

      <h2 style={h2Style}>🦙 The normal stuff, done kindly</h2>
      <p>
        Everything else works the way you expect, minus the doom: posts, replies,
        reposts, likes, follows, direct messages, search, and hashtags. Sign in with
        Discord in one tap if you are part of E2. Your profile gets a short address
        like llamachat.lol/dave. No ads, and we never sell your data; see the{" "}
        <Link to="/privacy">privacy policy</Link>. Llama Chat is part of{" "}
        <a href="https://e2.life" target="_blank" rel="noopener">E2</a>, and the one
        house rule is kindness.
      </p>

      <h2 style={h2Style}>Try it right now</h2>
      <p>
        Post <code style={codeStyle}>!games</code> and pick one. Post{" "}
        <code style={codeStyle}>$tip @tippy 5p</code> if you are feeling generous.
        That is the whole tutorial.
      </p>

      <p style={{ marginTop: 48 }}>
        <Link to="/" style={{ color: "#8e8e93", fontSize: 14 }}>
          &larr; Back to Llama Chat
        </Link>
      </p>
    </div>
  );
}
