// @llama profile link change (Dave's order Nov 1 2026, this side chat:
// "just have the URL say llamachat lol"): link_url and link_label were
// https://e2.life/llama / e2.life/llama, now both point at the site itself:
// https://llamachat.lol with label llamachat.lol.
const { API_BASE, getProfileId, serviceHeaders } = require("./lib/botlib");

(async () => {
  const id = await getProfileId("llama");
  const res = await fetch(`${API_BASE}/profiles/llama`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify({ link_url: "https://llamachat.lol", link_label: "llamachat.lol" }),
  });
  if (!res.ok) throw new Error(`PATCH -> ${res.status} ${(await res.text()).slice(0, 200)}`);
  const p = (await res.json()).profile;
  console.log("[llama] link now:", p.link_url, "|", p.link_label);
})().catch((e) => { console.error("[llama] fatal", e.message); process.exit(1); });
