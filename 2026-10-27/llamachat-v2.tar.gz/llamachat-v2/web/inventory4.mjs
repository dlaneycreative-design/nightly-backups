// Read-only: tweets mentioning thestudio.io WITHOUT a www URL (bare prose mentions).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
const sql = neon(url);
const hits = await sql`
  SELECT t.id, p.handle, t.created_at, t.text
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE (t.text ILIKE '%thestudio.io%' OR t.html ILIKE '%thestudio.io%')
    AND t.text NOT ILIKE '%https://www.thestudio.io%'
  ORDER BY t.created_at`;
console.log(`BARE-MENTION (no www link in text): ${hits.length}`);
for (const r of hits) console.log('---', r.handle, '|', (r.text || '').replace(/\n/g, ' ').slice(0, 160));
console.log('DONE4');
