// Login: Discord first for linked accounts (Dave, Harsh, and E2
// members sign in through e2-auth, which returns with a token in the
// URL hash that App startup captures). Everyone else keeps the legacy
// handle login below: enter your handle, we look up the profile and
// store the user id in localStorage. The @dave and @harsh handles are
// locked to Discord and never sign in through the handle form.
// The signup success screen lands here with ?handle= prefilled.
// Dave's call Oct 28 2026: keep this page clean and simple, no Recent
// chips, no extra explanatory paragraphs.
import { useState } from "react";
import type { ApiClient } from "../lib/api.ts";
import { setCallerId } from "../lib/session.ts";
import { openSignupModal } from "../lib/signupModal.ts";
import { SITE_NAME } from "../lib/theme.ts";

export function Login({ api, onDone }: { api: ApiClient; onDone: () => void }) {
  const [handle, setHandle] = useState(() => {
    try {
      return new URLSearchParams(window.location.search).get("handle") || "";
    } catch {
      return "";
    }
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const DISCORD_LOGIN_URL = "https://e2-auth.dlaneycreative.workers.dev/auth/login?to=llamachat";

  const doLogin = async (rawHandle: string) => {
    const h = rawHandle.trim().replace(/^@/, "").toLowerCase();
    if (!h) return;
    if (h === "dave" || h === "harsh") {
      setError("@dave/@harsh now uses Discord login - tap Login with Discord above.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await api.profile(h);
      // Log the login (IP + country) server-side; fire-and-forget.
      void api.logLoginEvent(res.profile.handle, res.profile.id);
      setCallerId(res.profile.id, res.profile.handle);
      onDone();
    } catch {
      setError("We could not find that handle. If you just signed up, check the spelling. New here? Create your account first.");
    } finally {
      setBusy(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    await doLogin(handle);
  };

  return (
    <div style={{maxWidth:380,margin:"80px auto",padding:"0 20px",textAlign:"center"}}>
      <h1 style={{fontSize:28,marginBottom:8}}>Log in to {SITE_NAME}</h1>
      <p style={{color:"#536471",marginBottom:24}}>Dave, Harsh and E2 members sign in with Discord now.</p>
      <a
        href={DISCORD_LOGIN_URL}
        style={{display:"block",width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#5865F2",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",textDecoration:"none",boxSizing:"border-box"}}
      >
        Login with Discord
      </a>
      <p style={{color:"#8b98a5",fontSize:13,margin:"28px 0 16px"}}>or use your handle</p>
      <form onSubmit={submit}>
        <input
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          placeholder="@handle"
          aria-label={`Your ${SITE_NAME} handle`}
          style={{width:"100%",padding:"12px 16px",fontSize:16,border:"1px solid #cfd9de",borderRadius:9999,marginBottom:12,outline:"none",boxSizing:"border-box"}}
        />
        {error && <p style={{color:"#f4212e",fontSize:14,marginBottom:12}}>{error}</p>}
        <button
          type="submit"
          disabled={busy || !handle.trim()}
          style={{width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#1d9bf0",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",opacity:busy||!handle.trim()?0.5:1}}
        >
          {busy ? "Logging in..." : "Log in"}
        </button>
      </form>
      <p style={{fontSize:14,marginTop:24,color:"#536471"}}>
        New here?{" "}
        <button
          type="button"
          onClick={() => openSignupModal()}
          style={{color:"#1d9bf0",background:"none",border:"none",cursor:"pointer",fontSize:14,padding:0,fontWeight:700}}
        >
          Create your account
        </button>
      </p>
    </div>
  );
}
