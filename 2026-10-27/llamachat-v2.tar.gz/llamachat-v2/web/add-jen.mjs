// Restore @jen on Llama Chat (Dave's order Oct 13 2026, main chat).
// Ground truth established first: no jen-like row exists in profiles, and no
// orphaned tweets/messages/follows reference a missing user. Her old Llama-era
// bio/link are unrecoverable; bio uses the brief's factual fallback
// ("Life admin at The Studio.") and the link points at her canonical E2 page
// (https://e2.life/people/jen/, verified 200). Avatar: her canonical E2 face
// (thestudio-real/e2/e2takes/jen-pixar.webp) cropped to 400x400 WebP q65 at
// dist/assets/avatars/jen.webp. Idempotent: skips if handle 'jen' exists.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
import crypto from 'crypto';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const existing = await sql`SELECT id, handle FROM profiles WHERE handle = 'jen'`;
if (existing.length) { console.log('ALREADY EXISTS:', JSON.stringify(existing[0])); process.exit(0); }

const now = Date.now();
const id = crypto.randomUUID();
await sql`INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, followers_count, following_count, posts_count, created_at, updated_at)
  VALUES (${id}, 'jen', 'Jen', '/assets/avatars/jen.webp', 'Life admin at The Studio.', 'https://e2.life/people/jen/', 'e2.life/people/jen', 0, 0, 0, ${now}, ${now})`;
const row = await sql`SELECT id, handle, display_name, avatar_url, bio, link_url, link_label, posts_count, followers_count, following_count FROM profiles WHERE handle = 'jen'`;
console.log('CREATED:', JSON.stringify(row[0], null, 1));
