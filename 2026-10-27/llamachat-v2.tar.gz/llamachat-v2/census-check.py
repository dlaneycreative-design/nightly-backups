# Census phase 2: resolve every stored URL exactly like the client does
# (web/src/lib/images.ts resolveImageUrl) and live-check each distinct URL.
import json, re, ssl, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor

HOST = "https://llamachat.lol"
ABS_AVATAR_MAP = {
    "https://www.thestudio.io/casting/willa-portrait.webp": "/assets/avatars/willa.webp",
    "https://www.thestudio.io/casting/finn-portrait.webp": "/assets/avatars/finn.webp",
    "https://www.thestudio.io/daveos/img/chadwick-waving.png": "/assets/avatars/chadwick.webp",
    "https://www.thestudio.io/muse-avatar-final.webp": "/assets/avatars/muse.webp",
    "https://www.thestudio.io/e2/people/judgetootie/judgetootie.webp": "/assets/avatars/judge.webp",
    "https://www.thestudio.io/mike/assets/mike-gym-selfie.webp": "/assets/avatars/songify.webp",
    "https://e2.life/people/sam/sam.webp": "/assets/avatars/sam.webp",
}
LEGACY_AVATAR_MAP = {
    "/sloth/assets/llama-avatar.webp": "/assets/avatars/llama.webp",
    "/shortbus/assets/portraits/sally.jpg": "/assets/avatars/sally.jpg",
    "/shortbus/assets/portraits/marty-face.jpg": "/assets/avatars/martychaos.jpg",
    "/shortbus/assets/portraits/dinesh-solo.webp": "/assets/avatars/dinesh.webp",
    "/sloth/assets/ricky-avatar.webp": "/assets/avatars/memebot.webp",
    "/shortbus/assets/portraits/mateo.webp": "/assets/avatars/mateo.webp",
    "/shortbus/assets/portraits/haddie-face.jpg": "/assets/avatars/haddiesings.jpg",
    "/sloth/assets/harsh-avatar.jpg": "/assets/avatars/harsh.jpg",
    "/shortbus/assets/portraits/tex.jpg": "/assets/avatars/tex.webp",
    "/shortbus/assets/portraits/chadwick-face.jpg": "/assets/avatars/chadwickblaze.jpg",
    "/shortbus/assets/portraits/jaylen-bass.jpg": "/assets/avatars/jaylen.webp",
    "/shortbus/assets/portraits/jah-vibez.jpg": "/assets/avatars/jahvibez.webp",
    "/shortbus/assets/portraits/biscuit-face.jpg": "/assets/avatars/biscuit.jpg",
    "/shortbus/assets/portraits/gloria.jpg": "/assets/avatars/gloria.webp",
    "/sloth/assets/mike-static.png": "/assets/avatars/mike.png",
    "/plume/plume.webp": "/assets/avatars/plume.webp",
    "/henri/henri-hue.webp": "/assets/avatars/henri.webp",
    "/oldray/old-ray.webp": "/assets/avatars/oldray.webp",
    "/enrique/enrique.png": "/assets/avatars/enrique.webp",
    "/lemonHD/assets/leo-remake.webp": "/assets/avatars/leo.webp",
    "/dineshbot/dineshbot-avatar.webp": "/assets/avatars/dineshbot.webp",
    "/sally/doodle-bot.png": "/assets/avatars/doodle.webp",
    "/pixel/buster/buster-portrait.webp": "/assets/avatars/buster.webp",
    "/e2/map/sprite-mappy.webp": "/assets/avatars/mappy.webp",
    "/assets/hank.webp": "/assets/avatars/hank.webp",
    "/assets/ed.webp": "/assets/avatars/ed.webp",
    "/assets/avatars/dave-dlaney-face-400.webp": "/assets/avatars/dave.webp",
}

def resolve(url):
    if not url:
        return None
    if url in ABS_AVATAR_MAP:
        return ABS_AVATAR_MAP[url]
    if url.startswith("https://www.thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://www.thestudio.io/"):]
    if url.startswith("https://thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://thestudio.io/"):]
    if re.match(r"^(https?:|data:|blob:)", url, re.I):
        return url
    if url.startswith("//"):
        return "https:" + url
    if url in LEGACY_AVATAR_MAP:
        return LEGACY_AVATAR_MAP[url]
    if url.startswith("/assets/"):
        return url
    if url.startswith("/"):
        return HOST + url
    return url

def absolute(resolved):
    if resolved.startswith("/"):
        return HOST + resolved
    return resolved

ctx = ssl.create_default_context()

def check(url):
    if url.startswith("data:") or url.startswith("blob:"):
        return ("SKIP", url)
    last = None
    for _ in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Range": "bytes=0-0"})
            with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
                return (r.status, url)
        except urllib.error.HTTPError as e:
            last = e.code
            if e.code in (404, 410, 403, 522):
                return (e.code, url)
        except Exception as e:
            last = f"ERR {type(e).__name__}"
    return (last, url)

def main():
    raw = json.load(open("/home/hatch/workspace/llamachat-v2/census-raw.json"))
    refs = []  # (kind, owner, stored, resolved_abs)
    for p in raw["profiles"]:
        if p.get("avatar_url"):
            refs.append(("avatar", p["handle"], p["avatar_url"], absolute(resolve(p["avatar_url"]))))
    for t in raw["tweets"]:
        refs.append(("tweet", t["id"], t["image_url"], absolute(resolve(t["image_url"]))))
    for m in raw["messages"]:
        refs.append(("message", m["id"], m["image_url"], absolute(resolve(m["image_url"]))))
    distinct = sorted({r[3] for r in refs if r[3]})
    print(f"refs: {len(refs)} | distinct resolved URLs to check: {len(distinct)}")
    results = {}
    with ThreadPoolExecutor(max_workers=6) as ex:
        for status, url in ex.map(check, distinct):
            results[url] = status
    broken = {u: s for u, s in results.items() if s not in (200, 206)}
    ok = {u: s for u, s in results.items() if s in (200, 206)}
    print(f"OK: {len(ok)} | BROKEN: {len(broken)}")
    out = {"results": results, "refs": [list(r) for r in refs]}
    json.dump(out, open("/home/hatch/workspace/llamachat-v2/census-results.json", "w"), indent=1)
    print("\n== BROKEN (resolved URL, status, kinds, sample stored) ==")
    by_url = {}
    for kind, owner, stored, res in refs:
        if res in broken:
            by_url.setdefault(res, []).append((kind, stored))
    for u in sorted(by_url):
        kinds = sorted({k for k, _ in by_url[u]})
        sample = by_url[u][0][1]
        print(broken[u], u, "| refs:", len(by_url[u]), kinds, "| e.g. stored:", sample)

if __name__ == "__main__":
    main()
