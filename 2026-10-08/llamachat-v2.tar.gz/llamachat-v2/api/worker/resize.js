// Resize worker: RETIRED (Oct 7 2026).
//
// The R2 presigned-upload pipeline is gone. Uploads now go to Vercel Blob
// (5GB included on Pro) via POST /api/v2/uploads, and clients downscale to
// <=1600px WebP in-browser before upload (Dave's speed rules), so there is
// nothing left to resize server-side. Tweets store the blob URL directly.
//
// This file is kept as a stub so `npm run worker` fails loudly instead of
// running the old R2 code.
console.error(
  "[worker] retired: image uploads now go straight to Vercel Blob; " +
    "no server-side resize step exists."
);
process.exit(1);
