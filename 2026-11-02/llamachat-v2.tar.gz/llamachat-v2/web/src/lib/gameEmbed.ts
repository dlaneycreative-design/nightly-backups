// !Game detection for tweet rendering. MUST agree with the worker
// parser (llamachat-worker/src/lib/game.js): both are covered by
// tests using the same case list. Only a command triggers an embed —
// a plain mention of a game in a normal tweet does not. Dave's rules:
// ANY kind of command works — !game/!games/!play + name, the direct
// shout (!MURKH, !SuperE2), glued (!playmurkh), even "! MURKH"; a
// bare !games/!game is the games list (no embed, @arcade replies
// with the list); and misspellings of both the command word
// (!lay, !gmae) and the game name (!M-U-R-K-H, !merk, !sanke,
// !super E2) still launch the right game.

export interface GameInfo {
  id: string;
  name: string;
  playUrl: string;
  pageUrl: string;
  coverUrl: string;
}

export const SUPER_E2: GameInfo = {
  id: "super-e2",
  name: "Super E2",
  playUrl: "https://supere2.netlify.app",
  pageUrl: "https://openarcade.lol/supere2",
  coverUrl: "https://e2.life/games/img/e2world.webp",
};

export const MURKH: GameInfo = {
  id: "murkh-disaster-in-the-sky",
  name: "MURKH: Disaster in the Sky",
  playUrl: "https://openarcade-api.dlaneycreative.workers.dev/play/murkh-disaster-in-the-sky/",
  pageUrl: "https://openarcade.lol/murkh-disaster-in-the-sky",
  coverUrl: "https://openarcade-api.dlaneycreative.workers.dev/api/cover/murkh-disaster-in-the-sky",
};

export const SNAKE: GameInfo = {
  id: "google-snake",
  name: "Snake",
  playUrl: "https://doodlecricket.github.io/doodle-snake",
  pageUrl: "https://openarcade.lol/google-snake",
  coverUrl: "https://openarcade.lol/img/google-snake.webp",
};

export const SNAKE_DUEL: GameInfo = {
  id: "snake-duel",
  name: "Snake Duel",
  playUrl: "https://openarcade.lol/play/snake-duel/",
  pageUrl: "https://openarcade.lol/snake-duel",
  coverUrl: "https://openarcade.lol/img/snake-duel.webp",
};

export const ENIT_WALKS: GameInfo = {
  id: "enitwalks",
  name: "Enit Walks",
  playUrl: "https://openarcade.lol/play/enitwalks/",
  pageUrl: "https://openarcade.lol/enitwalks",
  coverUrl: "https://openarcade.lol/img/enitwalks.webp",
};

/** Every game playable in a tweet, in list order. */
export const GAMES: GameInfo[] = [SUPER_E2, MURKH, SNAKE, SNAKE_DUEL, ENIT_WALKS];

/** Lowercase, then strip every non-alphanumeric: "SUPER-E2" -> "supere2". */
export function normalizeGameName(raw: string): string {
  return String(raw || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

// Every name a game answers to, normalized: its real name, its
// full title, its Open Arcade slug, and the common misspellings
// people actually type. "M-U-R-K-H" needs no entry: normalization
// strips the hyphens and it lands on "murkh" by itself.
const GAME_ALIASES = new Map<string, GameInfo>([
  // Super E2
  [normalizeGameName(SUPER_E2.name), SUPER_E2],
  ["super", SUPER_E2],
  ["supere", SUPER_E2],
  ["super2", SUPER_E2],
  ["suppere2", SUPER_E2],
  ["soupere2", SUPER_E2],
  ["supere2game", SUPER_E2],
  // MURKH: Disaster in the Sky
  ["murkh", MURKH],
  [normalizeGameName(MURKH.name), MURKH],
  ["murk", MURKH],
  ["merk", MURKH],
  ["merc", MURKH],
  ["murch", MURKH],
  ["merkh", MURKH],
  ["disasterinthesky", MURKH],
  ["murkhgame", MURKH],
  // Snake
  ["snake", SNAKE],
  ["googlesnake", SNAKE],
  ["snakes", SNAKE],
  ["sanke", SNAKE],
  ["snak", SNAKE],
  ["snaek", SNAKE],
  ["snakegame", SNAKE],
  ["jssnake", SNAKE],
  // Snake Duel
  [normalizeGameName(SNAKE_DUEL.name), SNAKE_DUEL],
  ["snakeduels", SNAKE_DUEL],
  // Enit Walks
  [normalizeGameName(ENIT_WALKS.name), ENIT_WALKS],
  ["enitwalk", ENIT_WALKS],
  ["enit", ENIT_WALKS],
  ["enitwalksgame", ENIT_WALKS],
]);
const ALIAS_KEYS = [...GAME_ALIASES.keys()].sort((a, b) => b.length - a.length);

/**
 * Resolve a normalized requested name to a game, generously: an
 * exact alias, an alias plus trailing chatter, or a partial name
 * of 4+ chars ("murk", "super"). Null when nothing plausibly matches.
 */
export function resolveGame(normalized: string): GameInfo | null {
  if (!normalized) return null;
  const exact = GAME_ALIASES.get(normalized);
  if (exact) return exact;
  for (const key of ALIAS_KEYS) if (normalized.startsWith(key)) return GAME_ALIASES.get(key) ?? null;
  if (normalized.length >= 4) {
    for (const key of ALIAS_KEYS) if (key.startsWith(normalized)) return GAME_ALIASES.get(key) ?? null;
  }
  return null;
}

export interface GameCommand {
  game: GameInfo | null;
  known: boolean;
  list?: boolean;
  requested: string;
}

// Words that ask for the games list instead of a game: a bare
// command word, or one of these as the requested name.
const LIST_WORDS = new Set(["list", "all", "help", "menu", "catalog", "games", ""]);

/**
 * Parse a game command at the very start of the trimmed text:
 * !game / !games / !play + name, the direct shout (!MURKH,
 * !SuperE2), glued (!playmurkh), and "! MURKH" all work, so
 * "!gambling" never triggers (a glued tail must name a real game).
 * A bare command word is the games list. Returns null for
 * non-commands; a command naming an unknown game returns
 * { known: false, game: null } (the worker replies with the list;
 * the web renders no embed for it or for the list).
 */
export function parseGameCommand(text: string): GameCommand | null {
  let t = String(text || "").trim();
  if (!t.startsWith("!")) return null;
  t = t.replace(/^!+/, "!").replace(/^!\s+/, "!");
  if (t === "!") return null;

  const firstChunk = t.split(/\s+/)[0];
  const direct = resolveGame(normalizeGameName(firstChunk.slice(1)));
  if (direct) {
    return { game: direct, known: true, requested: t.slice(firstChunk.length).trim() };
  }

  const m = t.match(/^!(playing|launch|arcade|games|game|plays|play|start|gmae|gaem|lay|gam)/i);
  if (!m) return null;
  const after = t.slice(m[0].length);
  if (!after) return { game: null, known: false, list: true, requested: "" };
  if (/^[^a-z0-9]/i.test(after)) {
    const requested = after.trim();
    if (LIST_WORDS.has(normalizeGameName(requested))) {
      return { game: null, known: false, list: true, requested };
    }
    const game = resolveGame(normalizeGameName(requested));
    return { game, known: !!game, requested };
  }
  const gluedChunk = after.split(/\s+/)[0];
  let gluedGame = resolveGame(normalizeGameName(gluedChunk));
  // "!playsnake" reads as play+snake, not plays+nake: when the word
  // ends in s, retry with the s handed back to the game name.
  if (!gluedGame && /s$/i.test(m[1])) gluedGame = resolveGame(normalizeGameName("s" + gluedChunk));
  if (!gluedGame) return null;
  return { game: gluedGame, known: true, requested: gluedChunk };
}

/** The game to embed under this tweet's text, or null. */
export function detectGameEmbed(text: string): GameInfo | null {
  const parsed = parseGameCommand(text);
  return parsed && parsed.known ? parsed.game : null;
}

/**
 * The cover a tweet's game embed should show (Dave's call, Oct 31
 * 2026, on Harsh's game posts): when the poster attached an image to
 * a game tweet, that image IS the game's cover art, so it becomes
 * the play screen's cover. The catalog cover is only the fallback —
 * for MURKH it is a generic Open Arcade placeholder, not the real
 * art Harsh attached. Blank/absent image keeps the catalog cover.
 */
export function coverFromTweetImage(
  game: GameInfo,
  imageUrl: string | null | undefined
): GameInfo {
  const cover = String(imageUrl || "").trim();
  return cover ? { ...game, coverUrl: cover } : game;
}
