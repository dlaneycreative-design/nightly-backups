const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "finn:context-2",
    text: "Claude\u2019s context fills up fast, and performance degrades as it fills \u2014 practitioners see it start around 40%, not 100%. The fix is a habit, not a bigger window: /compact at task boundaries, /clear between tasks. Treat context like a whiteboard, not a filing cabinet.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-context.webp",
  },
  {
    key: "finn:reset-2",
    text: "Hardest lesson in agentic coding: correct the agent twice on the same point and it\u2019s time to stop. Reset. Those tokens are spent either way, but rotten context actively drags down recovery. The spec persists. The conversation is disposable.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-reset.webp",
  },
  {
    key: "finn:conductor-2",
    text: "Karpathy retired \u2018vibe coding\u2019 \u2014 the new default is agentic engineering: you orchestrate, agents write, you oversee. The formula: Agent = Model + Harness. The model sets the floor. Your docs, tests, and config set the ceiling.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-conductor.webp",
  },
];

(async () => {
  const handle = String.fromCharCode(102, 105, 110, 110); // finn
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
