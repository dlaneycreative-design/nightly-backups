// Census phase 1: enumerate EVERY stored image URL in the DB. Read-only.
const fs = require("fs");
const { neon } = require("@neondatabase/serverless");
const envText = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8");
const dbUrl = envText.match(/^DATABASE_URL=(.+)$/m)[1].trim().replace(/^"|"$/g, "");
const sql = neon(dbUrl);
(async () => {
  const profiles = await sql.query("SELECT id, handle, avatar_url FROM profiles ORDER BY handle");
  const tweets = await sql.query("SELECT id, image_url FROM tweets WHERE image_url IS NOT NULL AND image_url <> ''");
  const messages = await sql.query("SELECT id, image_url FROM messages WHERE image_url IS NOT NULL AND image_url <> ''");
  const tweetTotal = await sql.query("SELECT count(*)::int AS n FROM tweets");
  const imgInHtml = await sql.query("SELECT count(*)::int AS n FROM tweets WHERE html LIKE '%<img%' OR text LIKE '%<img%'");
  const out = {
    generated_at: new Date().toISOString(),
    profiles_total: profiles.length,
    tweets_total: tweetTotal[0].n,
    tweets_with_image: tweets.length,
    messages_with_image: messages.length,
    tweets_with_img_tag_in_text_or_html: imgInHtml[0].n,
    profiles, tweets, messages,
  };
  fs.writeFileSync("/home/hatch/workspace/llamachat-v2/census-raw.json", JSON.stringify(out, null, 1));
  console.log("profiles:", out.profiles_total, "| tweets:", out.tweets_total, "| tweets w/image:", out.tweets_with_image, "| msgs w/image:", out.messages_with_image, "| img tags in text/html:", out.tweets_with_img_tag_in_text_or_html);
  const hosts = {};
  const note = (u) => { if (!u) return; let h; try { h = u.startsWith("/") ? "(relative)" : new URL(u).host; } catch { h = "(unparsable)"; } hosts[h] = (hosts[h] || 0) + 1; };
  profiles.forEach(r => note(r.avatar_url));
  tweets.forEach(r => note(r.image_url));
  messages.forEach(r => note(r.image_url));
  console.log("stored URLs by host:", JSON.stringify(hosts, null, 1));
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
