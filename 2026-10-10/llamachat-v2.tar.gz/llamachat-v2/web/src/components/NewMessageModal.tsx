import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient } from "../lib/api.ts";
import { resolveImageUrl } from "../lib/images.ts";

/**
 * X-style "New message" modal. Matches X's DM flow exactly:
 * search bar, Create a group, suggested people with avatars.
 * Dave's call Oct 9 2026: "Let's do exactly this!"
 */
export function NewMessageModal({ api, onClose }: { api: ApiClient; onClose: () => void }) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Array<{ id: string; handle: string; display_name: string; avatar_url: string | null }>>([]);
  const [suggested, setSuggested] = useState<typeof results>([]);
  const [searching, setSearching] = useState(false);

  // Load suggested people on open: use the conversations list (people you DM)
  // plus a general user search as fallback.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { conversations } = await api.conversations();
        const seen = new Set<string>();
        const people: typeof results = [];
        for (const c of conversations || []) {
          for (const o of c.others || []) {
            if (!seen.has(o.id) && people.length < 8) {
              seen.add(o.id);
              people.push({ id: o.id, handle: o.handle, display_name: o.display_name, avatar_url: o.avatar_url });
            }
          }
        }
        if (alive && people.length > 0) {
          setSuggested(people);
          return; // Got real suggestions; skip the generic fallback below.
        }
      } catch {
        /* fall through to search */
      }
      // Fallback: general search if no conversations
      if (alive) {
        try {
          const { users } = await api.search("a", "users");
          if (alive) setSuggested((users || []).slice(0, 8));
        } catch {
          /* keep empty */
        }
      }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api]);

  // Search as you type (debounced)
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const { users } = await api.search(query.trim(), "users");
        setResults(users || []);
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 250);
    return () => clearTimeout(t);
  }, [query, api]);

  const startDM = async (profileId: string) => {
    try {
      const { conversation } = await api.createConversation([profileId]);
      onClose();
      navigate(`/messages/${conversation.id}`, { state: { conversation } });
    } catch {
      /* stay open on error */
    }
  };

  const list = query.trim() ? results : suggested;
  const showEmpty = !searching && list.length === 0;

  return (
    <div className="rm-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="nm-modal" role="dialog" aria-label="New message">
        <div className="nm-header">
          <h2>New message</h2>
          <button type="button" className="nm-close" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="nm-search">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          <input
            type="text"
            placeholder="Search name or username"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
        </div>
        <button type="button" className="nm-group" onClick={() => { /* groups later */ }}>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          Create a group
        </button>
        <div className="nm-list">
          {searching && <div className="nm-status">Searching...</div>}
          {showEmpty && (
            <div className="nm-status">{query.trim() ? "No people found." : "Try searching for people."}</div>
          )}
          {list.map((p) => {
            const avatar = resolveImageUrl(p.avatar_url);
            const initial = (p.display_name || p.handle || "?").slice(0, 1).toUpperCase();
            return (
              <button key={p.id} type="button" className="nm-row" onClick={() => startDM(p.id)}>
                {avatar ? (
                  <img src={avatar} alt="" loading="lazy" decoding="async" />
                ) : (
                  <div className="avatar-fallback" aria-hidden="true">{initial}</div>
                )}
                <div className="nm-txt">
                  <div className="nm-name">{p.display_name}</div>
                  <div className="nm-handle">@{p.handle}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

