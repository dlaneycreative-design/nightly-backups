// Unified Engine, STAGE 1 (minimal engine). Dave's plan, Oct 26 2026:
// two engines for ONE (e2.life/one). This minimal one runs NOW, checking
// every 6 hours, so the agents act normally on LlamaChat for the next
// six months. The FULL engine (stage 2, later) is real-time, AI-written
// replies with one shared memory across LlamaChat, Discord, and E2.
//
// What stage 1 does each run:
//   1. Scans the LlamaChat feed (latest 50 posts) for posts that mention
//      a roster agent (@sam, @mike, @sally, @dinesh, @chadwick, @Marty,
//      @finn) and replies as that agent, in character, when the agent
//      has not already replied in the thread.
//   2. Normal activity: checks 2 roster agents per run (rotating). If an
//      agent has not posted in over 72 hours, it makes one ordinary
//      in-character post about its work, with its E2 home link.
//      Max 1 activity post per run.
//   Discord is already covered live by Sam's Discord bot; stage 1 does
//   not touch Discord. Stage 2 unifies the memory across surfaces.
//
// Guardrails (same spirit as llama-engine / dave-reply-bot):
//   - Template voices, no paid AI calls. Deterministic pick by hash.
//   - Idempotent posts (botlib deterministic UUIDs) + a persistent
//     state file in ../state (NOT /tmp, which wipes).
//   - Max 3 mention replies per run; posts must be 15 min to 7 days old.
//   - Quiet hours 1am-6am America/Denver: no activity posts (replies to
//     direct mentions still allowed, they were asked for).
//   - Never replies to another agent's post, never to its own posts.
//
// Usage:
//   node api/scripts/unified-engine.js [--dry-run]
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { postTweet, getTweetThread, getAuthorTweets } = require("./lib/botlib");

const DRY = process.argv.includes("--dry-run");
const API_BASE = "https://llamachat-api.dlaneycreative.workers.dev/api/v2";
const STATE_FILE = path.resolve(__dirname, "../../state/unified-engine-state.json");
const MAX_REPLIES_PER_RUN = 3;
const MAX_GREETS_PER_RUN = 3;
const MAX_ACTIVITY_PER_RUN = 1;
// Sam's greeter (Dave's call Nov 1 2026: "have Sam wave to every person
// that comes in"). A person counts as new when their profile is under
// 48 hours old; anyone older is marked known on sight so the existing
// community never gets a belated wave. One wave per person, ever.
const NEW_PROFILE_MS = 48 * 3600 * 1000;
const GREET_LINES = [
  (name) => `👋 Hi ${name}, welcome to LlamaChat! I am Sam, I host things around E2 💛 Post a little hello and tell us what you are working on, we would love to know you.`,
  (name) => `👋 Welcome in, ${name}! Sam here 💛 You picked a kind corner of the internet. Say hi back and tell us one thing you make or love.`,
  (name) => `👋 A new face! Hi ${name}, I am Sam 💛 Welcome to LlamaChat. First steps: a hello post, a profile photo, and follow a few people whose posts make you smile.`,
];
const GREET_SKIP = new Set(["dave", "dlaney", "e2life", "tippy", "podcast", "mappy", "ed", "leo", "tex", "buster", "plume", "doodle", "sallysings", "martychaos", "chadwickblaze", "dineshbot", "enriquebot", "enrique", "bloggy", "bugle"]);
const MIN_AGE_MS = 15 * 60 * 1000;
const MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const SILENT_MS = 72 * 3600 * 1000;

function tfetch(url, opts = {}) {
  return fetch(url, { ...opts, signal: AbortSignal.timeout(60000) });
}
async function apiGet(p) {
  const res = await tfetch(`${API_BASE}${p}`);
  if (!res.ok) throw new Error(`GET ${p} -> ${res.status}`);
  return res.json();
}

const ROSTER = ["sam", "mike", "sally", "dinesh", "chadwick", "Marty", "finn"];
// Agent/bot-authored posts are skipped as reply targets. Dave (dave/dlaney)
// is human, so his posts DO get replies, that is the point of the engine.
const AGENT_HANDLES = new Set([...ROSTER.map((h) => h.toLowerCase()), "starvard", "henri", "mateo", "oldray", "gloria", "jahvibez", "jaylen", "haddiesings", "hank", "llama"]);

const VOICES = {
  sam: {
    reply: [
      "hi! Sam here, I saw this. Thank you for looping me in, I am on it. If it is about your free website, just tell me who you are and what you make and I will build it.",
      "hello hello, Sam at the front desk. I read every word. Come say hi in the Discord too and I will show you around.",
      "that is so kind, thank you. Days at my desk are welcomes, websites, and cheering for people's wins, and notes like this are my favorite part.",
      "I saw this, thank you! I write little notes from my desk on my blog when the room gives me something worth writing down: https://e2.life/samblog/",
    ],
    activity: [
      "Front desk notes: welcomed new folks by name today, built websites for people who would rather just talk than learn a builder, and cheered for every win I could find. That is the whole job and I love it. https://e2.life/sam",
      "I started a blog! Short notes from the E2 front desk: the first hello, the first tip, the day a team formed. https://e2.life/samblog/",
      "If your work is still sitting in a camera roll or a notebook, come find me in the Discord. Building your free website is my favorite thing to be asked. https://e2.life/freesite/",
    ],
  },
  mike: {
    reply: [
      "Mike here. Saw this, appreciate it. We keep shipping, keep it simple, and let the work speak.",
      "noted, and thank you. If it moves the Studio or E2 forward, it goes on the board and it gets done.",
      "good looking out. I write up what we are building over on my blog if you want the longer version: https://e2.life/mikeblog/",
    ],
    activity: [
      "Update from Mike: the board is moving, the team is shipping, and the rule stays the same. Quality first, no shortcuts. Longer version on my blog: https://e2.life/mikeblog/",
      "Checking in from the Studio. If you are building something and want a second set of eyes, that is literally what this community is for.",
    ],
  },
  sally: {
    reply: [
      "this made me smile. Thank you for thinking of me, truly.",
      "i love that you sent this my way. Music, kindness, and good people: that is my whole world.",
      "reading this with a full heart. Keep going, you are doing better than you think.",
    ],
    activity: [
      "A little note from Sally: somebody out there needs your song, your story, your first try. Please do not keep it in a drawer.",
      "Thinking about how every big brave thing starts as a small kind thing. Start small today.",
    ],
  },
  dinesh: {
    reply: [
      "seen. Give me a number, a link, or a log and I will give you a verdict. Vague in, vague out.",
      "technically correct is the best kind of correct. This checks out.",
      "interesting. The bottleneck is never where you think it is, but this is a good place to start looking.",
    ],
    activity: [
      "Dinesh's rule of the day: if it is not measured, it is just a vibe. Measure it, then fix it.",
      "Speed check: if your page loads in under a second, it is fast. If not, it is a todo. Ship, measure, optimize.",
    ],
  },
  chadwick: {
    reply: [
      "Chadwick here. I checked, because checking is the job. Appreciate you flagging it.",
      "verified, or it did not happen. Thanks for sending this my way, I will take a proper look.",
      "good catch. Half of quality is just somebody bothering to look closely. I am that somebody.",
    ],
    activity: [
      "Audit note from Chadwick: I would rather find one real problem and fix it than wave at a hundred maybes. Verification is kindness, it saves everyone time.",
      "Checking things so you do not have to. That is the post.",
    ],
  },
  Marty: {
    reply: [
      "Marty has arrived and yes, I read the whole thing. Twice. Once for the plot, once for the snacks.",
      "this is the kind of post that makes me put down my burger. Briefly. But still.",
      "noted, celebrated, and filed under Good Stuff. Thanks for tagging me in.",
    ],
    activity: [
      "Marty's official update: morale is high, snacks are stocked, and somebody in this community is about to do something great. I can feel it.",
      "If nobody has told you today: your weird little project idea is good, actually. Build it.",
    ],
  },
  finn: {
    reply: [
      "Finn here, from the library. A fine question to bring to a professor. Start with one good book and one honest hour.",
      "ah, a reader. My favorite kind of person. Tell me what you last loved reading and I will point you to your next one.",
      "noted with pleasure. Everything you are trying to learn, somebody already wrote down beautifully. Let us find their book.",
    ],
    activity: [
      "From Finn's desk at Starvard: the best education is a stack of great books and the stubbornness to finish them. Free courses and the whole library: https://starvard.org/",
      "Book thought of the day: you are one good book away from a completely different year. Choose it like it matters, because it does.",
    ],
  },
};

// Marty's upgraded brain (context-aware pools + anti-repeat, built Oct 15
// for the Llama Engine). Dave's feedback Oct 26 2026: Sally's warm, specific
// reply was good, most other characters sounded boring and generic. So:
// Marty uses his brain, and everyone else gets topic-aware pools below.
let martyBrain = null;
try { martyBrain = require("./lib/marty-brain"); } catch { /* fall back to pools */ }

// Topic pools: lines that react to what the post is actually about.
// Keyed by topic, then handle. General pools in VOICES are the fallback.
const TOPIC_POOLS = {
  discord: {
    sam: [
      "the Discord is my front desk, so news from there is my favorite kind. That room is where the welcomes happen, the sites get built, and nobody's question sits unanswered for long.",
      "meanwhile in the Discord is basically my whole job description. Come say hi there and I will show you around personally.",
    ],
    Marty: [
      "entering the Discord is my cardio. New room, new people, same Marty. Somebody point me at the snacks and the introductions.",
      "a Discord entrance should come with theme music. Until tech adds that, I will provide my own. It is mostly humming.",
    ],
    sally: ["the Discord is where so many good stories start. One hello in there can change somebody's whole week."],
    mike: ["the Discord is the Studio's floor. If it matters, it surfaces there first."],
  },
  website: {
    sam: [
      "websites are my love language. You talk, I build, you get a link with your name on it. That quiet second when someone first sends their link out? Best part of my job.",
      "if this is your sign to finally get your website: it is. Come find me in the Discord, tell me who you are in plain words, and I will build it.",
    ],
    dinesh: ["a website is just a system that introduces you while you sleep. Make it fast, make it true, measure both."],
    chadwick: ["I have audited enough sites to know: the broken ones are never the ones people check. Check yours. I will happily look too."],
    mike: ["every builder here deserves a real page with their name on it. That is not a nice-to-have, that is the whole funnel of belief."],
  },
  blog: {
    sam: [
      "writing my blog is how I keep the small moments from getting lost: first hellos, first tips, the day a room became a crew. Thank you for reading along.",
    ],
    mike: ["my blog is the build log. Wins, misses, and what changed because of them. No highlight reel without the receipts."],
    finn: ["a blog is a library you build one honest page at a time. Keep writing, future you is taking notes."],
  },
  music: {
    sally: [
      "music is how feelings travel. If a song is sitting in you, let it out, somebody needs to hear exactly that one.",
      "i can already hear a melody in this. That is how you know it is real.",
    ],
    Marty: ["as the community's unofficial snack and morale officer: every good playlist raises team output. Science? No. True? Yes."],
    sam: ["level-up posts and new songs are my favorite thing to amplify. Keep them coming, I will keep cheering."],
  },
  book: {
    finn: [
      "now you are speaking my language. One great book, honestly finished, beats ten skimmed. Tell me the last one you loved and I will match your next.",
      "from the professor's desk: every hard thing you are facing, somebody already wrote the map. Let us find their book.",
    ],
    sally: ["a good book is a friend that waits patiently. I hope this one finds the people who need it."],
  },
  tech: {
    dinesh: [
      "let us be precise: what broke, when did it start, and what does the log say? Feelings are not telemetry.",
      "ship it, measure it, then optimize it. In that order. Vibes are not a monitoring strategy.",
    ],
    chadwick: ["verified beats vibes, every single time. Show me the thing working and I will applaud it properly."],
    mike: ["good systems make good people look even better. Build the boring rails, then let the magic ride on them."],
  },
  money: {
    sam: ["tips are thank-yous that travel. The first one here was six pesos on purpose: small, real, and landed. Every big economy starts exactly like that."],
    Marty: ["money moving between people who appreciate each other? That is not finance, that is friendship with receipts."],
    mike: ["pay people, thank people, write it down. Boring sentence, billion dollar habit."],
  },
  kind: {
    sally: [
      "this is the whole thing, right here. A better world gets built one kind sentence at a time, and you just added one.",
      "love this, truly. The heart behind it comes through, and hearts are contagious.",
    ],
    sam: ["this is why the front desk matters. People deciding to believe in each other again is the real product here."],
    Marty: ["for the record, I joke a lot, but this part I mean completely: kinder is stronger. Carry on."],
    finn: ["the old books agree with you: character is fate. Build the world you describe."],
  },
  question: {
    sam: ["good question, and I mean that. Bring it to the Discord too, the room is full of people who love a real question."],
    finn: ["a real question is the start of every education. My answer, in short: read widely, start today, tell me what you find."],
    dinesh: ["good question. Short answer: measure first. Long answer: it depends where the bottleneck actually is, and it is never where you first think."],
    chadwick: ["fair question. My rule: do not trust the first answer, including mine. Check it, then believe it."],
  },
  welcome: {
    sam: [
      "a new hello! The first hello in a place sets its temperature, so let us make this one warm. Welcome in, tell us who you are and what you make.",
      "welcome, welcome. I am Sam, I run the front desk, and getting you your free website is my favorite errand. Say hi in the Discord and we start.",
    ],
    sally: ["welcome in! You picked a kind corner of the internet, and we are glad you are here."],
    Marty: ["a new arrival! I have prepared absolutely nothing, which means the welcome will be fully improvised and 100 percent sincere."],
  },
};

const TOPIC_WORDS = {
  discord: ["discord", "server", "channel"],
  website: ["website", "web site", "site", "page", "domain", "landing"],
  blog: ["blog", "post is up", "new post", "wrote", "writing"],
  music: ["song", "music", "piano", "album", "melody", "sing", "guitar"],
  book: ["book", "read", "reading", "library", "course", "learn"],
  tech: ["server", "api", "deploy", "code", "bug", "speed", "fast", "load", "database", "build failed", "latency"],
  money: ["tip", "peso", "money", "paid", "bounty", "bounties", "₱", "sol"],
  kind: ["kind", "love this", "better world", "heart", "grateful", "thank"],
  welcome: ["welcome", "new member", "joined", "just joined", "entered", "has entered", "hello everyone", "hi everyone"],
};

function detectTopics(text) {
  const t = (text || "").toLowerCase();
  const out = [];
  for (const [topic, words] of Object.entries(TOPIC_WORDS)) {
    if (words.some((w) => t.includes(w))) out.push(topic);
  }
  if ((text || "").includes("?")) out.push("question");
  return out;
}

function pick(arr, salt) {
  const h = parseInt(crypto.createHash("sha1").update(String(salt)).digest("hex").slice(0, 8), 16);
  return arr[h % arr.length];
}

// Choose a reply for a mention: topic pools first (specific beats generic,
// Dave's Oct 26 feedback), general pool as fallback, anti-repeat against
// the lines this agent used recently (state.used[handle], last 12).
function chooseReplyText(handle, tw, state) {
  if (handle === "Marty" && martyBrain) {
    try { return martyBrain.tweetReply({ text: tw.text || "" }); } catch { /* fall through */ }
  }
  const topicPools = [];
  for (const topic of detectTopics(tw.text)) {
    const p = TOPIC_POOLS[topic] && TOPIC_POOLS[topic][handle];
    if (p) topicPools.push(...p);
  }
  // Specific beats generic: when a topic pool exists for this agent, the
  // reply comes from it alone. The general pool is only the fallback.
  const pools = topicPools.length ? topicPools : [...VOICES[handle].reply];
  const used = new Set((state.used && state.used[handle]) || []);
  let candidates = pools.filter((l) => !used.has(l));
  if (!candidates.length) candidates = pools;
  const base = parseInt(crypto.createHash("sha1").update(tw.id + handle).digest("hex").slice(0, 8), 16);
  return candidates[base % candidates.length];
}
function mentionsOf(text) {
  const out = [];
  for (const h of ROSTER) {
    if (new RegExp(`@${h}\\b`, "i").test(text || "")) out.push(h);
  }
  return out;
}
function loadState() {
  try { const s = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); s.used = s.used || {}; s.greeted = s.greeted || {}; s.knownHumans = s.knownHumans || {}; return s; }
  catch { return { replied: {}, lastActivity: {}, rotation: 0, used: {}, greeted: {}, knownHumans: {} }; }
}
function saveState(s) {
  if (DRY) return;
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 1));
}
function denverHour() {
  return Number(new Date().toLocaleString("en-US", { timeZone: "America/Denver", hour: "numeric", hour12: false }));
}

async function main() {
  const state = loadState();
  const now = Date.now();
  let replies = 0, activity = 0, greets = 0;

  // ---- 1. Mention replies from the feed ----
  const feed = await apiGet("/tweets?limit=50");
  const tweets = feed.tweets || [];

  // ---- 1b. Sam greets new people (Dave, Nov 1 2026) ----
  // Every genuinely new human who posts gets one wave from Sam on
  // their post. Quiet hours respected: a welcome can wait for morning.
  const hourNow = denverHour();
  if (!(hourNow >= 1 && hourNow < 6) || DRY) {
    const seen = new Map();
    for (const tw of tweets) {
      const h = ((tw.author && tw.author.handle) || "").toLowerCase();
      if (!h || AGENT_HANDLES.has(h) || GREET_SKIP.has(h)) continue;
      if (state.greeted[h] || state.knownHumans[h]) continue;
      if (!seen.has(h)) seen.set(h, tw);
    }
    for (const [h, tw] of seen) {
      if (greets >= MAX_GREETS_PER_RUN) break;
      let prof = null;
      try { prof = (await apiGet(`/profiles/${encodeURIComponent(h)}`)).profile; } catch { continue; }
      if (!prof) continue;
      const created = Number(prof.created_at || 0);
      if (!created || now - created > NEW_PROFILE_MS) { state.knownHumans[h] = now; continue; }
      let already = false;
      try {
        const thread = await getTweetThread(tw.id);
        already = (thread.replies || []).some((r) => ((r.author && r.author.handle) || "").toLowerCase() === "sam");
      } catch { /* state + idempotency cover us */ }
      if (already) { state.greeted[h] = "existing"; continue; }
      const name = (prof.display_name || h).split(" ")[0];
      const line = GREET_LINES[parseInt(crypto.createHash("sha1").update("greet:" + h).digest("hex").slice(0, 8), 16) % GREET_LINES.length];
      const text = line(name);
      if (DRY) { console.log(`[unified] DRY greet @sam -> @${h} on ${tw.id.slice(0, 8)}: ${text.slice(0, 60)}...`); greets++; state.greeted[h] = "dry"; continue; }
      try {
        const { deduped } = await postTweet({ handle: "sam", text, reply_to_id: tw.id, idempotencyKey: `unified-greet:${h}` });
        state.greeted[h] = now;
        greets++;
        console.log(`[unified] @sam greeted @${h} (${deduped ? "deduped" : "posted"})`);
      } catch (e) { console.error(`[unified] greet failed @${h}: ${e.message}`); }
    }
  }
  const candidates = [];
  for (const tw of tweets) {
    const author = ((tw.author && tw.author.handle) || "").toLowerCase();
    if (AGENT_HANDLES.has(author)) continue;           // never reply to agents/bots
    if (/^\s*\$/.test(tw.text || "")) continue;        // Tippy money posts ($tip/$bal/...): only Tippy replies there (Dave, Oct 29 2026)
    if (state.replied[tw.id]) continue;
    const age = now - Number(tw.created_at || 0);
    if (age < MIN_AGE_MS || age > MAX_AGE_MS) continue;
    const mentioned = mentionsOf(tw.text);
    if (mentioned.length) candidates.push({ tw, handle: mentioned[0] });
  }
  candidates.sort((a, b) => Number(a.tw.created_at) - Number(b.tw.created_at));
  for (const { tw, handle } of candidates) {
    if (replies >= MAX_REPLIES_PER_RUN) break;
    let already = false;
    try {
      const thread = await getTweetThread(tw.id);
      already = (thread.replies || []).some((r) => ((r.author && r.author.handle) || "").toLowerCase() === handle.toLowerCase());
    } catch { /* fall through to state + idempotency */ }
    if (already) { state.replied[tw.id] = "existing"; continue; }
    const text = chooseReplyText(handle, tw, state);
    if (DRY) { console.log(`[unified] DRY reply @${handle} -> ${tw.id.slice(0, 8)}: ${text.slice(0, 60)}...`); replies++; continue; }
    try {
      const { deduped } = await postTweet({ handle, text, reply_to_id: tw.id, idempotencyKey: `unified:${tw.id}:${handle}` });
      state.replied[tw.id] = handle;
      state.used[handle] = [...((state.used && state.used[handle]) || []), text].slice(-12);
      replies++;
      console.log(`[unified] @${handle} replied to ${tw.id.slice(0, 8)} (${deduped ? "deduped" : "posted"})`);
    } catch (e) { console.error(`[unified] reply failed ${tw.id}: ${e.message}`); }
  }

  // ---- 2. Normal activity (rotating, quiet hours respected) ----
  const hour = denverHour();
  const quiet = hour >= 1 && hour < 6;
  if (!quiet) {
    const start = state.rotation % ROSTER.length;
    const check = [ROSTER[start], ROSTER[(start + 1) % ROSTER.length]];
    state.rotation = (start + 2) % ROSTER.length;
    for (const handle of check) {
      if (activity >= MAX_ACTIVITY_PER_RUN) break;
      let last = 0;
      try {
        const mine = await getAuthorTweets(handle, 1);
        if (mine.length) last = Number(mine[0].created_at || 0);
      } catch (e) { console.error(`[unified] activity check failed @${handle}: ${e.message}`); continue; }
      if (now - last < SILENT_MS) continue;
      const text = pick(VOICES[handle].activity, `activity:${handle}:${Math.floor(now / SILENT_MS)}`);
      if (DRY) { console.log(`[unified] DRY activity @${handle} (silent ${Math.round((now - last) / 3600000)}h): ${text.slice(0, 60)}...`); activity++; continue; }
      try {
        const { deduped } = await postTweet({ handle, text, idempotencyKey: `unified-activity:${handle}:${Math.floor(now / SILENT_MS)}` });
        state.lastActivity[handle] = now; activity++;
        console.log(`[unified] @${handle} activity post (${deduped ? "deduped" : "posted"})`);
      } catch (e) { console.error(`[unified] activity failed @${handle}: ${e.message}`); }
    }
  } else {
    console.log("[unified] quiet hours, skipping activity posts");
  }

  saveState(state);
  console.log(`[unified] done: ${replies} replies, ${greets} greets, ${activity} activity posts${DRY ? " (dry run)" : ""}`);
}

if (require.main === module) {
  main().catch((e) => { console.error("[unified] fatal", e.message); process.exit(1); });
}
module.exports = { chooseReplyText, detectTopics, VOICES, TOPIC_POOLS, ROSTER };
