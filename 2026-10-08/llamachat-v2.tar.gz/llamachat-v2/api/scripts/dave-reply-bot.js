// Bot 3: Dinesh and Sally auto-replies to Dave's tweets.
// Polls @dlaney's recent tweets, picks ones neither bot has replied to
// yet, and posts one in-character reply.
//
// Voices:
//   Dinesh (@dinesh): technical, precise, a little nerdy. Cares about
//     speed, systems, correctness. Short sentences.
//   Sally (@sally): warm, encouraging, kind, genuine. Big heart.
//
// Rules to avoid spam:
//   - Max 1 reply per Dave tweet, from ONE of them (picked by fit).
//   - Cooldown: no more than 3 replies per run, and never reply to a
//     tweet less than 10 minutes old (give Dave room).
//   - State file tracks replied tweet IDs: /tmp/dave-reply-state.json
//   - Template-based for now (no AI backend yet). Keyword matching picks
//     the voice; rotation within each voice keeps it fresh.
//
// TIMESTAMP LAW: API server-stamps created_at.
// Idempotent: deterministic UUID per (tweet, bot).
//
// Usage: node api/scripts/dave-reply-bot.js
//   Run every 15 min via cron.
const fs = require("fs");
const crypto = require("crypto");
const { postTweet, getAuthorTweets, getTweetThread } = require("./lib/botlib");

const STATE_FILE = "/tmp/dave-reply-state.json";
const COOLDOWN_MS = 10 * 60 * 1000;
const MAX_REPLIES_PER_RUN = 3;

// ---------- reply templates ----------
const DINESH_TECH = [
  "technically correct. which is the best kind of correct.",
  "have you measured it? if it's not measured it's just a vibe.",
  "this is a systems problem. everything is a systems problem if you squint.",
  "ship it. we can optimize later. (we will optimize later.)",
  "the bottleneck is never where you think it is. it's always the thing you didn't instrument.",
];
const DINESH_SPEED = [
  "how fast? numbers or it didn't happen.",
  "if it loads in under a second, it's fast. if not, it's a todo.",
  "speed is a feature. the best feature. ok one of the best.",
];
const SALLY_WARM = [
  "this made me smile. keep going, you're doing good work.",
  "i love this. the heart behind it comes through.",
  "yes! this is exactly the kind of thing the world needs more of.",
  "reading this with my morning coffee and it just made my day better.",
  "you've got a good heart, dave. don't ever lose that.",
];
const SALLY_MUSIC = [
  "this is giving me song ideas. piano is calling my name.",
  "i can already hear the melody for this one.",
  "felt this in my chest. that's how i know it's real.",
];

function pick(arr, salt) {
  const h = parseInt(crypto.createHash("sha1").update(String(salt)).digest("hex").slice(0, 8), 16);
  return arr[h % arr.length];
}

// Decide who replies and with what pool, based on Dave's text.
function chooseReply(text) {
  const t = text.toLowerCase();
  const techWords = ["server", "api", "deploy", "code", "bug", "speed", "fast", "load", "build", "data", "system", "latency", "v2", "vercel", "database"];
  const musicWords = ["song", "music", "piano", "sing", "melody", "album", "guitar", "vocals"];
  const kindWords = ["kind", "kindness", "love", "heart", "good person", "rgkp", "grateful", "thank"];
  const hasAny = (words) => words.some((w) => t.includes(w));

  if (hasAny(musicWords)) return { handle: "sally", pool: SALLY_MUSIC };
  if (hasAny(techWords)) {
    // Dinesh owns tech, but alternate pools for variety
    return { handle: "dinesh", pool: pick([DINESH_TECH, DINESH_SPEED], text) === DINESH_TECH ? DINESH_TECH : DINESH_SPEED };
  }
  if (hasAny(kindWords)) return { handle: "sally", pool: SALLY_WARM };
  // Default: alternate by hash so it doesn't always pick the same bot
  const h = parseInt(crypto.createHash("sha1").update("who:" + text).digest("hex").slice(0, 8), 16);
  return h % 2 === 0
    ? { handle: "dinesh", pool: DINESH_TECH }
    : { handle: "sally", pool: SALLY_WARM };
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return { replied: {} }; }
}
function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s)); }

async function main() {
  const state = loadState();
  const tweets = await getAuthorTweets("dlaney", 20);
  const now = Date.now();
  let replied = 0;

  // Oldest first so replies land in chronological order.
  for (const tw of [...tweets].reverse()) {
    if (replied >= MAX_REPLIES_PER_RUN) break;
    if (tw.reply_to_id) continue; // don't reply to Dave's own replies
    if (state.replied[tw.id]) continue;
    if (now - Number(tw.created_at) < COOLDOWN_MS) continue;

    // Check nobody (dinesh/sally) already replied via the API.
    let alreadyReplied = false;
    try {
      const thread = await getTweetThread(tw.id);
      const replies = thread.replies || [];
      alreadyReplied = replies.some((r) =>
        ["dinesh", "sally"].includes(((r.author && r.author.handle) || "").toLowerCase())
      );
    } catch { /* if thread fetch fails, fall through to state check */ }
    if (alreadyReplied) { state.replied[tw.id] = "existing"; continue; }

    const { handle, pool } = chooseReply(tw.text || "");
    const text = pick(pool, tw.id + handle);
    try {
      const { deduped } = await postTweet({
        handle,
        text,
        reply_to_id: tw.id,
        idempotencyKey: `dave-reply:${tw.id}:${handle}`,
      });
      state.replied[tw.id] = handle;
      replied++;
      console.log(`[dave-reply] @${handle} -> Dave's tweet ${tw.id.slice(0, 8)}: ${deduped ? "deduped" : "replied"}`);
    } catch (e) {
      console.error(`[dave-reply] failed on ${tw.id}: ${e.message}`);
    }
  }
  saveState(state);
  console.log(`[dave-reply] done: ${replied} replies this run`);
}

main().catch((e) => { console.error("[dave-reply] fatal", e.message); process.exit(1); });
