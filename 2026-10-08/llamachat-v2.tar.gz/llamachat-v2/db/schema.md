# LlamaChat V2 Database Schema

## Profiles
- id: UUID (primary key)
- handle: VARCHAR UNIQUE NOT NULL (e.g. "dlaney", "hank", "henri")
- display_name: VARCHAR NOT NULL
- avatar_url: VARCHAR
- bio: TEXT
- link_url: VARCHAR
- link_label: VARCHAR
- followers_count: INT DEFAULT 0
- following_count: INT DEFAULT 0
- posts_count: INT DEFAULT 0
- created_at: BIGINT NOT NULL (Unix ms, server-stamped)
- updated_at: BIGINT NOT NULL

## Tweets
- id: UUID PRIMARY KEY (client-generated for idempotency)
- author_id: UUID NOT NULL → profiles.id
- text: TEXT NOT NULL
- html: TEXT (rendered, links/hashtags)
- image_url: VARCHAR (nullable) — the MEDIUM (800px) variant URL; full variant
  derivable by convention (see Image Pipeline below)
- reply_to_id: UUID NULLABLE → tweets.id
- hashtags: TEXT[] (extracted server-side on write)
- likes_count: INT DEFAULT 0
- replies_count: INT DEFAULT 0
- reposts_count: INT DEFAULT 0
- created_at: BIGINT NOT NULL (Unix ms, server-stamped, NEVER null)
- updated_at: BIGINT NOT NULL

Indexes:
- (author_id, created_at DESC) for profile feeds
- (created_at DESC) for main feed
- GIN (hashtags) for hashtag pages
- (reply_to_id) for threads

## Follows
- follower_id: UUID → profiles.id
- following_id: UUID → profiles.id
- created_at: BIGINT NOT NULL
- PRIMARY KEY (follower_id, following_id)

## Likes
- user_id: UUID → profiles.id
- tweet_id: UUID → tweets.id
- created_at: BIGINT NOT NULL
- PRIMARY KEY (user_id, tweet_id)

## Conversations (DMs)
- id: UUID PRIMARY KEY
- created_at: BIGINT NOT NULL
- updated_at: BIGINT NOT NULL

## Conversation Participants
- conversation_id: UUID → conversations.id
- user_id: UUID → profiles.id
- last_read_at: BIGINT
- PRIMARY KEY (conversation_id, user_id)

## Messages
- id: UUID PRIMARY KEY (client-generated)
- conversation_id: UUID NOT NULL → conversations.id
- sender_id: UUID NOT NULL → profiles.id
- text: TEXT NOT NULL
- image_url: VARCHAR (nullable)
- created_at: BIGINT NOT NULL (server-stamped)
- Index: (conversation_id, created_at DESC)

---

## Timestamp Rules (Dave's P1, burned 3 times in V1)

1. Server stamps EVERY write with Date.now(). No exceptions.
2. Database enforces NOT NULL on created_at.
3. Client NEVER generates timestamps.
4. Client displays:
   - < 60s → "Xs"
   - < 60m → "Xm"
   - < 24h → "Xh"
   - < 7d → "Xd"
   - Else → "Oct 6" (or "Oct 6, 2026" if different year)
   - Invalid/null/0/negative → "" (empty, never "now")
   - Future (clock skew) → clamp to "now"
5. API always returns created_at. If missing, client shows "".

## Image Pipeline (Dave's call, Oct 7 2026: V2 must handle LOTS of images)

Uploads never touch the API server. Flow:

1. Client calls `POST /uploads/presign` with `{ content_type, byte_size }`.
   Server validates (image/* only, <= 25MB) and returns
   `{ upload_url, public_url, image_id }`. `upload_url` is a short-lived
   presigned PUT to R2/S3; `public_url` is the CDN URL of the ORIGINAL slot.
2. Client PUTs bytes directly to `upload_url` (no server bandwidth).
3. R2/S3 event triggers the resize worker, which generates three variants
   from the original and writes them next to it:
   - `thumb` — 200px longest edge, WebP q75 — feed list, avatars-in-DM, search
   - `medium` — 800px longest edge, WebP q75 — default tweet view, `image_url` in DB
   - `full` — 1600px longest edge, WebP q75 — lightbox / tap-to-expand
   Variant URL convention: `<public_url without ext>-thumb.webp`,
   `-medium.webp`, `-full.webp` (e.g. `https://cdn.llamachat.io/img/abc-medium.webp`).
4. **100KB rule enforced in code, not by hand:** after encode, if a variant
   exceeds 100KB the worker re-encodes at descending quality (70, 65, 60)
   and, if still over, steps the longest edge down 10% until under 100KB.
   The `full` variant is exempt ONLY for the lightbox and gets the same
   treatment with a 500KB cap.
5. **Originals are deleted** after variants are written (save space).
   The DB stores only the medium URL; variants are derived by convention.
6. Tweets reference `image_url` (medium). Clients build `srcset`:
   `thumb 200w, medium 800w, full 1600w` and let the browser pick.

Failure handling: if the worker fails, the tweet still posts with the
original `public_url` and a `POST /uploads/retry` re-queues processing.
A nightly janitor deletes originals older than 24h with no variants.
