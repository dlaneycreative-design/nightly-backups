// Simple login: enter your handle, we look up the profile and store
// the user id in localStorage. No password (dev launch, Dave's call).
// The signup success screen lands here with ?handle= prefilled.
import { useState } from "react";
import type { ApiClient } from "../lib/api.ts";
import { setCallerId } from "../lib/session.ts";
import { openSignupModal } from "../lib/signupModal.ts";
import { SITE_NAME } from "../lib/theme.ts";

export function Login({ api, onDone }: { api: ApiClient; onDone: () => void }) {
  const [handle, setHandle] = useState(() => {
    try {
      return new URLSearchParams(window.location.search).get("handle") || "";
    } catch {
      return "";
    }
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [recent, setRecent] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("llama_recent_users") || "[]");
    } catch {
      return [];
    }
  });

  const doLogin = async (rawHandle: string) => {
    const h = rawHandle.trim().replace(/^@/, "").toLowerCase();
    if (!h) return;
    setBusy(true);
    setError("");
    try {
      const res = await api.profile(h);
      // Log the login (IP + country) server-side; fire-and-forget.
      void api.logLoginEvent(res.profile.handle, res.profile.id);
      setCallerId(res.profile.id, res.profile.handle);
      const updated = [res.profile.handle, ...recent.filter((x) => x !== res.profile.handle)].slice(0, 5);
      setRecent(updated);
      try {
        localStorage.setItem("llama_recent_users", JSON.stringify(updated));
      } catch {}
      onDone();
    } catch {
      setError("We could not find that handle. If you just signed up, check the spelling. New here? Create your account first.");
    } finally {
      setBusy(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    await doLogin(handle);
  };

  return (
    <div style={{maxWidth:380,margin:"80px auto",padding:"0 20px",textAlign:"center"}}>
      <h1 style={{fontSize:28,marginBottom:8}}>Log in to {SITE_NAME}</h1>
      <p style={{color:"#536471",marginBottom:8}}>Enter your handle to post, reply, like, and DM.</p>
      <p style={{color:"#8b98a5",fontSize:14,marginBottom:24}}>No password needed: your handle is your key for now.</p>
      {recent.length > 0 && (
        <div style={{marginBottom:16}}>
          <p style={{color:"#8b98a5",fontSize:13,marginBottom:8}}>Recent</p>
          <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
            {recent.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => doLogin(r)}
                disabled={busy}
                style={{padding:"6px 14px",fontSize:14,border:"1px solid #cfd9de",borderRadius:9999,background:"#fff",cursor:"pointer",color:"#536471"}}
              >
                @{r}
              </button>
            ))}
          </div>
        </div>
      )}
      <form onSubmit={submit}>
        <input
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          placeholder="@handle"
          aria-label={`Your ${SITE_NAME} handle`}
          style={{width:"100%",padding:"12px 16px",fontSize:16,border:"1px solid #cfd9de",borderRadius:9999,marginBottom:12,outline:"none"}}
        />
        {error && <p style={{color:"#f4212e",fontSize:14,marginBottom:12}}>{error}</p>}
        <button
          type="submit"
          disabled={busy || !handle.trim()}
          style={{width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#1d9bf0",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",opacity:busy||!handle.trim()?0.5:1}}
        >
          {busy ? "Logging in..." : "Log in"}
        </button>
      </form>
      <p style={{fontSize:14,marginTop:20,color:"#536471"}}>
        New here?{" "}
        <button
          type="button"
          onClick={() => openSignupModal()}
          style={{color:"#1d9bf0",background:"none",border:"none",cursor:"pointer",fontSize:14,padding:0,fontWeight:700}}
        >
          Create your account
        </button>
      </p>
    </div>
  );
}
