// Marty's reply to Tippy's intro tweet (Dave's call, Oct 30 2026).
// Tippy's tweet ends "Try it: $tip @harsh 5p" — Marty declines.
// Run: node api/scripts/marty-harsh-tips.js
const { postTweet, getTweetThread } = require("./lib/botlib");

const TARGET = "ce50fa76-b248-4862-8d66-2b370d9e5d86";
const TEXT = "Nah, @Harsh has enough tips already";

(async () => {
  const r = await postTweet({
    handle: "Marty",
    text: TEXT,
    reply_to_id: TARGET,
    idempotencyKey: "marty-harsh-tips-1",
  });
  console.log("tweet:", r.tweet.id, r.deduped ? "(deduped)" : "");
  console.log("URL=https://llamachat.lol/tweet/" + r.tweet.id);

  const d = await getTweetThread(TARGET);
  const replies = d.replies || [];
  const mine = replies.find((x) => x.id === r.tweet.id);
  if (!mine) throw new Error("reply not found in thread read-back");
  const author = (mine.author && (mine.author.handle || mine.author.username)) || "";
  console.log("readback author:", author);
  console.log("readback text:", JSON.stringify(mine.text));
  if (mine.text !== TEXT) throw new Error("text mismatch");
  console.log("VERIFIED in thread");
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
