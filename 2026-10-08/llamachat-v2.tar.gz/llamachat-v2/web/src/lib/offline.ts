// Offline queue for posts. V1's "POOF" bug: the API timed out and the
// optimistic reply was rolled back, silently dropping Dave's post.
// V2: a failed post is persisted to localStorage and retried with
// backoff until the server confirms it. Nothing the user wrote is
// ever silently dropped.

export interface QueuedPost {
  id: string; // client-generated UUID, matches the tweet id (idempotent)
  text: string;
  image_url: string | null;
  reply_to_id: string | null;
  attempts: number;
  enqueued_at: number;
  last_error: string | null;
}

const KEY = "llamachat-v2:offline-queue";
const MAX_ATTEMPTS = 12;

function load(): QueuedPost[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function save(items: QueuedPost[]): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(items));
  } catch {
    /* storage full: drop oldest */
    try {
      localStorage.setItem(KEY, JSON.stringify(items.slice(-20)));
    } catch { /* give up */ }
  }
}

export function enqueue(post: Omit<QueuedPost, "attempts" | "enqueued_at" | "last_error">): void {
  const items = load();
  if (!items.some((p) => p.id === post.id)) {
    items.push({ ...post, attempts: 0, enqueued_at: Date.now(), last_error: null });
    save(items);
  }
}

export function dequeue(id: string): void {
  save(load().filter((p) => p.id !== id));
}

export function peek(): QueuedPost[] {
  return load();
}

/**
 * Drain the queue: try each post oldest-first. Calls postFn for each;
 * on success the item is removed, on failure attempts++ and last_error
 * is recorded. Stops retrying an item after MAX_ATTEMPTS.
 */
export async function drain(
  postFn: (p: QueuedPost) => Promise<unknown>,
  onChange?: (remaining: number) => void
): Promise<void> {
  const items = load().sort((a, b) => a.enqueued_at - b.enqueued_at);
  for (const item of items) {
    if (item.attempts >= MAX_ATTEMPTS) continue;
    try {
      await postFn(item);
      dequeue(item.id);
    } catch (e) {
      const rest = load();
      const cur = rest.find((p) => p.id === item.id);
      if (cur) {
        cur.attempts += 1;
        cur.last_error = e instanceof Error ? e.message : String(e);
        save(rest);
      }
      // Back off before the next item; don't hammer a struggling server.
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
  onChange?.(load().length);
}

export function backoffMs(attempts: number): number {
  return Math.min(30000, 1000 * 2 ** attempts);
}
