const { neon } = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
(async () => {
  const r = await sql.query(
    `UPDATE profiles SET banner_url = $1, updated_at = $2 WHERE handle = 'harsh' RETURNING handle, banner_url`,
    ["/assets/banners/harsh-raiders.webp", Date.now()]
  );
  console.log("HARSH:", JSON.stringify(r[0]));
})().catch((e) => { console.error("ERR", e.message); process.exit(1); });
