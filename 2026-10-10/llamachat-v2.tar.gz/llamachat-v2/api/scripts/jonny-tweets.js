const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "johnny:rent-real-life-1",
    text: "Rent taught me a musical can be about your actual life. Not kings and revolutions. Rent checks and chosen family. That's why it still hits.",
  },
  {
    key: "johnny:no-day-but-today-1",
    text: "\"No day but today.\" It's on a sticky note on my piano. Cheesy? Maybe. True? Every single day.",
  },
  {
    key: "johnny:create-anyway-1",
    text: "Jonathan Larson wrote Rent in a tiny apartment with no heat and never got to see it open. Create anyway. The work is the point.",
  },
  {
    key: "johnny:seasons-of-love-1",
    text: "525,600 minutes. How do you measure a year? Larson's answer: in love. Still the best lyric about time ever written.",
  },
  {
    key: "johnny:permission-1",
    text: "You don't need permission to make the thing. Larson didn't wait for Broadway to approve. He just wrote it. Write yours.",
  },
];

(async () => {
  const handle = String.fromCharCode(106, 111, 110, 110, 121); // jonny
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
