import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { upsertTweets, getTweet, removeTweet } from "../lib/store.ts";
import { prefetch } from "../lib/lazyload.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { getCallerId } from "../lib/session.ts";
import { Tweet } from "./Tweet.tsx";
import { tempToPending, type PendingViewTweet, type TweetLike } from "../lib/tweetView.ts";
import { Composer, type TempTweet } from "./Composer.tsx";
import { openSignupModal } from "../lib/signupModal.ts";

interface Props {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
  sort?: "chron" | "foryou" | "shuffle";
}

/**
 * Virtualized feed: only ~30 rows in the DOM (visible + overscan), cursor
 * pagination 20/page, IntersectionObserver infinite scroll, pull-to-refresh
 * on mobile. Row positioning uses an imperative transform in a layout effect
 * (dynamic per-row geometry lives in the DOM, not in JSX style attributes).
 * STATIC (Dave's call Oct 8 2026): no realtime polling. The feed loads once;
 * the user pulls to refresh or taps "Load more" for new posts.
 */
/**
 * Feed data layer: cursor pagination, seed-first initial load, optimistic
 * posting, and delete handling. Returns state + callbacks for the Feed
 * component to render.
 */
function useFeedData(api: ApiClient, me: Profile | null, sort: "chron" | "foryou" | "shuffle") {
  const [order, setOrder] = useState<string[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const cursorRef = useRef<string | null>(null);
  const hasMoreRef = useRef(true);
  const loadingRef = useRef(false);
  const pendingRef = useRef(new Map<string, PendingViewTweet>());
  const orderRef = useRef<string[]>([]);

  useEffect(() => {
    orderRef.current = order;
  }, [order]);

  const resolveItem = useCallback((id: string): TweetLike | undefined => {
    if (id.startsWith("temp:")) return pendingRef.current.get(id.slice(5));
    return getTweet(id);
  }, []);

  const loadMore = useCallback(async () => {
    if (loadingRef.current || !hasMoreRef.current) return;
    const cursor = cursorRef.current;
    loadingRef.current = true;
    setLoadingMore(true);
    setError(null);
    try {
      if (sort === "shuffle") return; // no pagination for shuffle
      const { tweets, next_cursor } = await api.feed(cursor, 20, sort);
      upsertTweets(tweets);
      const ids = tweets.map((t) => t.id);
      setOrder((prev) => {
        const seen = new Set(prev);
        return [...prev, ...ids.filter((id) => !seen.has(id))];
      });
      cursorRef.current = next_cursor;
      hasMoreRef.current = next_cursor !== null;
      setHasMore(next_cursor !== null);
      for (const t of tweets) {
        if (t.image_url) prefetch(resolveImageUrl(t.image_url) ?? t.image_url);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load posts.");
    } finally {
      loadingRef.current = false;
      setLoadingMore(false);
      setInitialLoading(false);
    }
  }, [api, sort]);

  const refresh = useCallback(async () => {
    cursorRef.current = null;
    hasMoreRef.current = true;
    setHasMore(true);
    pendingRef.current.clear();
    if (loadingRef.current) return;
    loadingRef.current = true;
    setError(null);
    try {
      if (sort === "shuffle") {
        const { tweets } = await api.randomFeed(30);
        upsertTweets(tweets);
        setOrder(tweets.map((t) => t.id));
        setHasMore(false);
        hasMoreRef.current = false;
      } else {
        const { tweets, next_cursor } = await api.feed(null, 20, sort);
        upsertTweets(tweets);
        setOrder(tweets.map((t) => t.id));
        cursorRef.current = next_cursor;
        hasMoreRef.current = next_cursor !== null;
        setHasMore(next_cursor !== null);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load posts.");
    } finally {
      loadingRef.current = false;
      setInitialLoading(false);
    }
  }, [api, sort]);

  // Initial load: STATIC seed (Dave's call Oct 8 2026). The first batch of
  // tweets is baked into /seed-feed.json at build time and served from the
  // edge cache (~50ms), so the homepage paints instantly with zero API
  // calls. The API is only hit when the user scrolls for more (loadMore)
  // or pulls to refresh.
  const loadSeed = useCallback(async () => {
    setError(null);
    // The seed snapshot is chronological; on the For You tab it would show
    // the wrong order, so skip it and go straight to a live sorted refresh.
    if (sort !== "chron") {
      await refresh();
      return;
    }
    try {
      const res = await fetch("/seed-feed.json", { cache: "force-cache" });
      if (!res.ok) throw new Error(`seed ${res.status}`);
      const seed: { tweets: TweetT[]; next_cursor: string | null } = await res.json();
      upsertTweets(seed.tweets);
      setOrder(seed.tweets.map((t) => t.id));
      cursorRef.current = seed.next_cursor;
      hasMoreRef.current = seed.next_cursor !== null;
      setHasMore(seed.next_cursor !== null);
    } catch (e) {
      // Seed missing or stale build: fall back to a live refresh.
      await refresh();
      return;
    } finally {
      setInitialLoading(false);
    }
  }, [refresh, sort]);

  // Initial load: paint seed instantly, then live-refresh in background.
  // (P1 fix Oct 9 2026: seed alone left users staring at stale build-time
  // content. Seed still paints first for speed, but a live refresh follows
  // immediately to pull fresh tweets.)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      await loadSeed();
      if (cancelled) return;
      // Background live refresh: fetch fresh tweets and merge them in.
      // If the seed already painted, a refresh failure should not surface
      // an error; the seed remains visible and the user can pull to retry.
      const hadSeed = orderRef.current.length > 0;
      try {
        await refresh();
      } catch {
        // refresh() handles its own errors; nothing to do here.
      }
      if (cancelled) return;
      if (hadSeed) setError(null);
    })();
    return () => {
      cancelled = true;
    };
  }, [loadSeed, refresh]);

  // Posts from the sidebar compose modal (mounted outside the Feed tree).
  useEffect(() => {
    const onPosted = (e: Event) => {
      const tweet = (e as CustomEvent).detail as TweetT | undefined;
      if (!tweet || !tweet.id) return;
      upsertTweets([tweet]);
      setOrder((prev) => (prev.includes(tweet.id) ? prev : [tweet.id, ...prev]));
    };
    window.addEventListener("llama:posted", onPosted);
    return () => window.removeEventListener("llama:posted", onPosted);
  }, []);

  // ---- optimistic posting ----
  const onOptimistic = useCallback(
    (temp: TempTweet) => {
      const author = me
        ? { display_name: me.display_name, handle: me.handle, avatar_url: me.avatar_url }
        : { display_name: "You", handle: "you", avatar_url: null };
      pendingRef.current.set(temp.tempId, tempToPending(temp, author));
      setOrder((prev) => [`temp:${temp.tempId}`, ...prev]);
    },
    [me]
  );

  const onSettled = useCallback((tempId: string, tweet: TweetT | null) => {
    if (!tweet) {
      // Post failed and was queued for retry: the optimistic row stays up
      // showing "sending..." until the retry confirms it. Never poof.
      return;
    }
    pendingRef.current.delete(tempId);
    upsertTweets([tweet]);
    setOrder((prev) => prev.map((id) => (id === `temp:${tempId}` ? tweet.id : id)));
  }, []);

  const onPosted = useCallback((_t: TweetT) => {
    // Settled via onSettled; nothing extra needed.
  }, []);

  const onDeleted = useCallback((id: string) => {
    removeTweet(id);
    setOrder((prev) => prev.filter((x) => x !== id));
  }, []);

  return {
    order, hasMore, loadingMore, initialLoading, error,
    resolveItem, loadMore, onOptimistic, onSettled, onPosted, onDeleted,
  };
}

export function Feed({ api, apiBase, me, sort = "chron" }: Props) {
  const {
    order, hasMore, loadingMore, initialLoading, error,
    resolveItem, loadMore, onOptimistic, onSettled, onPosted, onDeleted,
  } = useFeedData(api, me, sort);

  const showComposer = !!getCallerId();
  const showSkeletons = initialLoading;
  const showTweets = !initialLoading;
  const showSentinel = !initialLoading && order.length > 0;
  const showEmpty = !initialLoading && order.length === 0 && !error;

  return (
    <div className="feed">
      {/* Pull-to-shuffle handled by App.tsx on feedtabs (Dave's call Oct 10 2026) */}
      {!showComposer ? <LoggedOutHero /> : null}
      {showComposer ? (
        <Composer
          api={api}
          apiBase={apiBase}
          getCallerId={getCallerId}
          avatarUrl={me?.avatar_url ?? null}
          onOptimistic={onOptimistic}
          onPosted={onPosted}
          onSettled={onSettled}
        />
      ) : null}
      {showSkeletons ? <FeedSkeletons /> : null}
      {showTweets ? (
        <div className="feed-simple">
          {order.map((id) => {
            const tweet = resolveItem(id);
            if (!tweet) return null;
            return <Tweet key={id} tweet={tweet} api={api} onDeleted={onDeleted} />;
          })}
        </div>
      ) : null}
      {error ? <FeedErrorBox error={error} onRetry={() => void loadMore()} /> : null}
      {showSentinel ? (
        <div className="feed-sentinel" aria-hidden={hasMore ? "true" : "false"}>
          {hasMore ? (
            <button
              type="button"
              className="loadmore"
              onClick={() => void loadMore()}
              disabled={loadingMore}
            >
              {loadingMore ? "Loading..." : "Load more"}
            </button>
          ) : null}
          {!hasMore ? "You are all caught up" : null}
        </div>
      ) : null}
      {showEmpty ? <FeedEmptyState /> : null}
    </div>
  );
}

/** Shown to logged-out visitors at the top of the feed. */
function LoggedOutHero() {
  return (
    <div className="loggedout-hero">
      <h2>New to LlamaChat?</h2>
      <p>Follow the E2 crew, join the conversation, post your own updates.</p>
      <button type="button" className="bigpost" style={{ width: "auto", minWidth: 200 }} onClick={() => openSignupModal()}>Log in to join</button>
    </div>
  );
}

/** Skeleton rows shown while the first batch loads. */
function FeedSkeletons() {
  return (
    <div aria-label="Loading feed">
      {[0, 1, 2, 3, 4].map((i) => (
        <div className="skel-tweet" key={i}>
          <div className="skel skel-avatar" />
          <div className="skel-lines">
            <div className="skel skel-line short" />
            <div className="skel skel-line" />
            <div className="skel skel-line" />
          </div>
        </div>
      ))}
    </div>
  );
}

/** Error box with a retry button when the feed fails to load. */
function FeedErrorBox({ error, onRetry }: { error: string; onRetry: () => void }) {
  return (
    <div className="errorbox" role="alert">
      <h2>Feed hiccup</h2>
      <p>{error}</p>
      <button type="button" className="ghost" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}

/** Empty state when the feed has no tweets and no error. */
function FeedEmptyState() {
  return (
    <div className="empty">
      <h2>Nothing here yet</h2>
      <p>Be the first to post. The feed is waiting.</p>
    </div>
  );
}

// TweetImage and other helpers below
