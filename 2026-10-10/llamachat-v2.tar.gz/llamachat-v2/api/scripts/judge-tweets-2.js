const { postTweet } = require("./lib/botlib");

const BLOB = "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/judge-tweets/";

const TWEETS = [
  {
    key: "judge2:read-twice-1",
    text: "Your signature is your word on paper. Never give your word to something you haven't read. Slow down. Read it twice.",
    image_url: BLOB + "judge2-read.webp",
  },
  {
    key: "judge2:honest-people-1",
    text: "The best contract is the one you never need to enforce, because both sides were honest on day one. Choose honest people. It's the only clause that matters.",
  },
  {
    key: "judge2:fence-1",
    text: "Boundaries are not walls. They're the fence around the garden. Everything inside grows better when the line is clear.",
    image_url: BLOB + "judge2-fence.webp",
  },
  {
    key: "judge2:angry-boundaries-1",
    text: "If someone gets angry at your boundaries, that's information. Thank them for showing you exactly why the boundary exists.",
  },
  {
    key: "judge2:document-1",
    text: "Document everything. Memories fade, screenshots don't. A paper trail is just kindness to your future self.",
  },
  {
    key: "judge2:pause-1",
    text: "'Let me think about it' is a complete sentence too. You never have to answer on the spot. Pressure is a tactic. Pause is a right.",
    image_url: BLOB + "judge2-pause.webp",
  },
  {
    key: "judge2:respect-no-1",
    text: "The people who respect your no are the ones who deserved your yes.",
  },
  {
    key: "judge2:writing-1",
    text: "A verbal promise is worth the paper it's printed on. Get it in writing. Every time. No exceptions. This isn't distrust, it's diligence.",
  },
  {
    key: "judge2:fair-1",
    text: "Fair doesn't mean equal. Fair means honest. Treat people honestly and you'll sleep fine, win or lose.",
    image_url: BLOB + "judge2-scales.webp",
  },
  {
    key: "judge2:peace-1",
    text: "Protect your peace like it's property. Because it is. Lock the doors, set the terms, and don't apologize for the fence.",
  },
];

(async () => {
  const handle = String.fromCharCode(106, 117, 100, 103, 101); // judge
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
