-- Quote tweets (Dave's order Oct 19 2026): a tweet can quote another
-- tweet, X-style. The quoter writes their own post; the original is
-- embedded one level deep at read time.
--
-- quote_of_id is deliberately NOT a foreign key: when the quoted tweet
-- is deleted, the quote survives and the API emits quoted_tweet: null
-- with quote_of_id intact, so clients render X's "This post is
-- unavailable" card instead of the quote vanishing with its target.
ALTER TABLE tweets ADD COLUMN IF NOT EXISTS quote_of_id UUID;
CREATE INDEX IF NOT EXISTS idx_tweets_quote_of ON tweets (quote_of_id) WHERE quote_of_id IS NOT NULL;

-- X allows quoting with no added comment: an empty text is valid when
-- the post carries a quote (previously only an image excused empty text).
ALTER TABLE tweets DROP CONSTRAINT IF EXISTS tweets_text_check;
ALTER TABLE tweets ADD CONSTRAINT tweets_text_check
  CHECK (char_length(text) BETWEEN 0 AND 2000
         AND (char_length(text) > 0 OR image_url IS NOT NULL OR quote_of_id IS NOT NULL));

-- 'quote' becomes a notification type (the quoted author is notified).
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_type_check
  CHECK (type IN ('reply','like','repost','follow','mention','quote'));
