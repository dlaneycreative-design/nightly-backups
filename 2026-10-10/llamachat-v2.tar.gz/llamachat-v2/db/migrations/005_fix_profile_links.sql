-- Fix profile links to e2.life/<name> (Dave's call Oct 9 2026, "very very important").
-- All profiles must link to https://e2.life/<name> with label e2.life/<name>.

UPDATE profiles SET link_url = 'https://e2.life/dave', link_label = 'e2.life/dave' WHERE handle = 'dave';
UPDATE profiles SET link_url = 'https://e2.life/llama', link_label = 'e2.life/llama' WHERE handle = 'llama';
UPDATE profiles SET link_url = 'https://e2.life/marty', link_label = 'e2.life/marty' WHERE handle = 'martychaos';
UPDATE profiles SET link_url = 'https://e2.life/sally', link_label = 'e2.life/sally' WHERE handle = 'sally';
UPDATE profiles SET link_url = 'https://e2.life/dinesh', link_label = 'e2.life/dinesh' WHERE handle = 'dinesh';
UPDATE profiles SET link_url = 'https://e2.life/hank', link_label = 'e2.life/hank' WHERE handle = 'hank';
UPDATE profiles SET link_url = 'https://e2.life/haddie', link_label = 'e2.life/haddie' WHERE handle = 'haddiesings';
UPDATE profiles SET link_url = 'https://e2.life/harsh', link_label = 'e2.life/harsh' WHERE handle = 'harsh';
UPDATE profiles SET link_url = 'https://e2.life/oldray', link_label = 'e2.life/oldray' WHERE handle = 'oldray';
UPDATE profiles SET link_url = 'https://e2.life/chadwick', link_label = 'e2.life/chadwick' WHERE handle = 'chadwickblaze';
UPDATE profiles SET link_url = 'https://e2.life/jaylen', link_label = 'e2.life/jaylen' WHERE handle = 'jaylen';
UPDATE profiles SET link_url = 'https://e2.life/jahvibez', link_label = 'e2.life/jahvibez' WHERE handle = 'jahvibez';
UPDATE profiles SET link_url = 'https://e2.life/gloria', link_label = 'e2.life/gloria' WHERE handle = 'gloria';
UPDATE profiles SET link_url = 'https://e2.life/biscuit', link_label = 'e2.life/biscuit' WHERE handle = 'biscuit';
UPDATE profiles SET link_url = 'https://e2.life/enrique', link_label = 'e2.life/enrique' WHERE handle = 'enrique';
UPDATE profiles SET link_url = 'https://e2.life/leo', link_label = 'e2.life/leo' WHERE handle = 'leo';
UPDATE profiles SET link_url = 'https://e2.life/plume', link_label = 'e2.life/plume' WHERE handle = 'plume';
UPDATE profiles SET link_url = 'https://e2.life/mike', link_label = 'e2.life/mike' WHERE handle = 'mike';
UPDATE profiles SET link_url = 'https://e2.life/buster', link_label = 'e2.life/buster' WHERE handle = 'buster';
UPDATE profiles SET link_url = 'https://e2.life/ed', link_label = 'e2.life/ed' WHERE handle = 'ed';
UPDATE profiles SET link_url = 'https://e2.life/mateo', link_label = 'e2.life/mateo' WHERE handle = 'mateo';
UPDATE profiles SET link_url = 'https://e2.life/john', link_label = 'e2.life/john' WHERE handle = 'john';
UPDATE profiles SET link_url = 'https://e2.life/serversteve', link_label = 'e2.life/serversteve' WHERE handle = 'serversteve';
UPDATE profiles SET link_url = 'https://e2.life/memebot', link_label = 'e2.life/memebot' WHERE handle = 'memebot';
UPDATE profiles SET link_url = 'https://e2.life/dineshbot', link_label = 'e2.life/dineshbot' WHERE handle = 'dineshbot';
UPDATE profiles SET link_url = 'https://e2.life/doodle', link_label = 'e2.life/doodle' WHERE handle = 'doodle';
UPDATE profiles SET link_url = 'https://e2.life/tex', link_label = 'e2.life/tex' WHERE handle = 'tex';
UPDATE profiles SET link_url = 'https://e2.life/finn', link_label = 'e2.life/finn' WHERE handle = 'finn';
UPDATE profiles SET link_url = 'https://e2.life/judgetootie', link_label = 'e2.life/judgetootie' WHERE handle = 'judge';
UPDATE profiles SET link_url = 'https://e2.life/henri', link_label = 'e2.life/henri' WHERE handle = 'henri';
UPDATE profiles SET link_url = 'https://e2.life/mappy', link_label = 'e2.life/mappy' WHERE handle = 'mappy';
