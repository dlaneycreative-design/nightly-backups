-- Self-serve signup (Dave's order Oct 19 2026): anyone we send to
-- LlamaChat can create their own account. Profiles carry the person's
-- Instagram handle (shown on their profile), and signup/login events
-- are logged with IP + country so an account suddenly appearing from
-- a new country is visible in SQL. Logging only: nothing is blocked.

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS instagram VARCHAR(50);

CREATE TABLE IF NOT EXISTS login_events (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  handle     TEXT NOT NULL,
  ip         TEXT,
  country    TEXT,
  event      TEXT NOT NULL CHECK (event IN ('signup', 'login')),
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_login_events_handle  ON login_events (handle, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_login_events_profile ON login_events (profile_id, created_at DESC);
