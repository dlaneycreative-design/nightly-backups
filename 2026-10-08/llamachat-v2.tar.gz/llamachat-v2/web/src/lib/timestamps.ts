// Client-side timestamp DISPLAY. Never generates timestamps; it only
// formats the server-stamped created_at (Unix ms).
//
// Rules (Dave's P1, broken 3 times in V1 — hence the tests):
//   invalid (null/undefined/NaN/<=0/non-integer) -> "" (never "now")
//   future (clock skew, >60s ahead)              -> "now" (clamped)
//   < 60s  -> "Xs"    < 60m -> "Xm"    < 24h -> "Xh"    < 7d -> "Xd"
//   older  -> "Oct 6" (or "Oct 6, 2026" when the year differs)

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
] as const;

const SKEW_ALLOWANCE_MS = 60 * 1000;

export function isValidTs(ts: unknown): ts is number {
  return typeof ts === "number" && Number.isInteger(ts) && ts > 0;
}

/** Format a server-stamped Unix-ms timestamp. `now` is injectable for tests. */
export function relTime(ts: unknown, now: number = Date.now()): string {
  if (!isValidTs(ts)) return "";
  if (ts > now + SKEW_ALLOWANCE_MS) return "now"; // clock skew: clamp
  const diff = Math.max(0, now - ts);

  if (diff < 60 * 1000) return `${Math.floor(diff / 1000)}s`;
  if (diff < 60 * 60 * 1000) return `${Math.floor(diff / (60 * 1000))}m`;
  if (diff < 24 * 60 * 60 * 1000) return `${Math.floor(diff / (60 * 60 * 1000))}h`;
  if (diff < 7 * 24 * 60 * 60 * 1000) return `${Math.floor(diff / (24 * 60 * 60 * 1000))}d`;

  const d = new Date(ts);
  const label = `${MONTHS[d.getMonth()]} ${d.getDate()}`;
  return d.getFullYear() === new Date(now).getFullYear() ? label : `${label}, ${d.getFullYear()}`;
}

/** Absolute date for tweet detail pages, e.g. "Oct 6, 2026 · 8:04 AM". */
export function absTime(ts: unknown): string {
  if (!isValidTs(ts)) return "";
  const d = new Date(ts);
  let h = d.getHours();
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  const min = String(d.getMinutes()).padStart(2, "0");
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()} · ${h}:${min} ${ampm}`;
}

/** Date only, no time (for "Joined" dates). */
export function absDate(ts: unknown): string {
  if (!isValidTs(ts)) return "";
  const d = new Date(ts);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

/**
 * THE tweet-card timestamp path (Dave's #1 rule, Oct 7 2026).
 * Every timestamp shown in the UI goes through this or relTime()/absTime().
 *   pending tweet (optimistic, no server stamp yet) -> "sending..."
 *     (NEVER a fake "just now", NEVER a client-generated created_at)
 *   invalid created_at (null/0/negative/"now"/...)     -> "" (render nothing)
 *   otherwise                                          -> relTime()
 */
export function tweetTime(tweet: { created_at?: unknown; pending?: boolean }, now: number = Date.now()): string {
  if (tweet.pending) return "sending...";
  return relTime(tweet.created_at, now);
}

/**
 * Numeric-only newest-first comparator. Sorting NEVER uses string
 * comparison: invalid stamps sink to the bottom instead of poisoning order.
 */
export function newestFirst(a: { created_at: unknown }, b: { created_at: unknown }): number {
  const ta = isValidTs(a.created_at) ? a.created_at : -Infinity;
  const tb = isValidTs(b.created_at) ? b.created_at : -Infinity;
  return tb - ta;
}
