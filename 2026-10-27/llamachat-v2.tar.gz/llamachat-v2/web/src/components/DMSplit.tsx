import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import type { ApiClient, Conversation } from "../lib/api.ts";
import { relTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { DMThread } from "./DMThread.tsx";
import { NewMessageModal } from "./NewMessageModal.tsx";

/**
 * X-style split DM view: conversation list on the left, active thread on the right.
 * Dave's call Oct 8 2026.
 */
export function DMSplit({ api }: { api: ApiClient }) {
  const navigate = useNavigate();
  const { id: selectedId } = useParams<{ id: string }>();
  const location = useLocation();
  const stateConvo = (location.state as { conversation?: Conversation } | null)?.conversation || null;
  const [convos, setConvos] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewMessage, setShowNewMessage] = useState(false);
  const splitRef = useRef<HTMLDivElement>(null);

  // Pin the split view to the VISUAL viewport, sized exactly, so the
  // composer can neither float nor jump (Dave's pinned priority, Oct 14).
  // Round 1 (vv height alone) still floated on his iPhone because:
  //  - the mobile header (.mhead) is in flow ABOVE the split (~52px), so
  //    a full-vv split made the document taller than the visible area and
  //    iOS scroll-offset the page on input focus;
  //  - the document was never scroll-locked on this screen.
  // Now: split height = vv.height minus the visible header height, and
  // html/body are scroll-locked (dm-lock) while this view is mounted, so
  // there is no page scroll for iOS to offset with. kb-open drops the
  // bottom-nav clearance lifts while the keyboard covers the nav.
  useEffect(() => {
    const el = splitRef.current;
    const vv = window.visualViewport;
    if (!el || !vv) return;
    const root = document.documentElement;
    root.classList.add("dm-lock");
    // kb-open detection: the software keyboard is up when the composer
    // input is the active element AND the visual viewport has shrunk
    // well below the height it has while unfocused. Focus is read fresh
    // from document.activeElement on every update: a tracked flag
    // desynced during viewport transitions in device testing (Oct 14),
    // leaving kb-open off and the nav lifts in place above the keyboard.
    let fullH = vv.height;
    const update = () => {
      const head = document.querySelector(".mhead");
      const headH =
        head && getComputedStyle(head).display !== "none"
          ? head.getBoundingClientRect().height
          : 0;
      // min-height must be set too: the stylesheet's min-height:100dvh
      // silently clamped the height alone, leaving the split a full
      // viewport tall below the header (measured on device, Oct 14).
      el.style.height = `${Math.max(0, vv.height - headH)}px`;
      el.style.minHeight = el.style.height;
      el.style.transform = vv.offsetTop ? `translateY(${vv.offsetTop}px)` : "";
      const ae = document.activeElement;
      const focused = !!(
        ae &&
        el.contains(ae) &&
        (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA")
      );
      if (!focused) fullH = vv.height;
      el.classList.toggle("kb-open", focused && vv.height < fullH - 80);
    };
    update();
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    el.addEventListener("focusin", update);
    el.addEventListener("focusout", update);
    return () => {
      vv.removeEventListener("resize", update);
      vv.removeEventListener("scroll", update);
      el.removeEventListener("focusin", update);
      el.removeEventListener("focusout", update);
      root.classList.remove("dm-lock");
      el.style.height = "";
      el.style.minHeight = "";
      el.style.transform = "";
      el.classList.remove("kb-open");
    };
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { conversations } = await api.conversations(null, 20);
        if (alive) setConvos(conversations);
      } catch {
        /* keep empty */
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [api]);

  // Hide orphan conversations with no messages at all: empty shells left
  // behind by abandoned starts (opened a thread, never wrote). A shell
  // still has its participant in others[], so the old filter let 1:1
  // shells like Dave/Old Ray render as blank rows (Dave, Oct 14). A real
  // thread appears the moment its first message lands (last_text set);
  // an in-progress new thread renders from the route id, not this list.
  const visibleConvos = convos.filter((c) => !!c.last_text);

  return (
    <div ref={splitRef} className={`dm-split${selectedId ? " has-selection" : ""}`}>
      <div className="dm-split-list">
        <div className="dm-split-header">
          <h2>Messages</h2>
        </div>
        {loading ? (
          <div aria-label="Loading conversations">
            {[0, 1, 2].map((i) => (
              <div className="skel-tweet" key={i}>
                <div className="skel skel-avatar" />
                <div className="skel-lines">
                  <div className="skel skel-line short" />
                  <div className="skel skel-line" />
                </div>
              </div>
            ))}
          </div>
        ) : visibleConvos.length === 0 ? (
          <div className="empty">
            <h2>No conversations yet</h2>
            <p>Visit someone's profile and tap Message to say hi.</p>
          </div>
        ) : (
          visibleConvos.map((c) => {
            const names = (c.others || []).map((p) => p.display_name).join(", ") || "Conversation";
            const avatar = resolveImageUrl((c.others || [])[0]?.avatar_url || null);
            const initial = (names || "?").slice(0, 1).toUpperCase();
            const when = relTime(c.updated_at);
            const active = c.id === selectedId;
            const unread = c.unread;
            return (
              <button
                key={c.id}
                type="button"
                className={`convo-row${active ? " active" : ""}${unread ? " unread" : ""}`}
                onClick={() => navigate(`/messages/${c.id}`)}
              >
                {avatar ? (
                  <img src={avatar} alt="" loading="lazy" decoding="async" />
                ) : (
                  <div className="avatar-fallback" aria-hidden="true">{initial}</div>
                )}
                <div className="convo-txt">
                  <div className="convo-top">
                    <span className="convo-name">{names}</span>
                    <span className="convo-when">{when}</span>
                  </div>
                  <div className="convo-preview">{c.last_text || ""}</div>
                </div>
              </button>
            );
          })
        )}
      </div>
      <div className="dm-split-thread">
        {selectedId ? (
          <DMThread
            key={selectedId}
            api={api}
            conversationId={selectedId}
            conversation={convos.find((c) => c.id === selectedId) || (stateConvo?.id === selectedId ? stateConvo : null)}
          />
        ) : (
          <div className="dm-split-empty">
            <div className="dm-empty-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/>
              </svg>
            </div>
            <h2>Start Conversation</h2>
            <p>Choose from your existing conversations, or start a new one.</p>
            <button type="button" className="dm-new-chat-btn" onClick={() => setShowNewMessage(true)}>
              New chat
            </button>
          </div>
        )}
      </div>
      {showNewMessage && (
        <NewMessageModal api={api} onClose={() => setShowNewMessage(false)} />
      )}
    </div>
  );
}
