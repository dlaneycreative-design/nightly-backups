// Starvard Broadway guide release tweet (Dave's ask, Oct 26 2026).
// One post as @starvard announcing the new course, with the Sally + Dinesh
// cover hosted on llamachat.lol itself (no cross-site images).
// Idempotent via botlib deterministic UUIDs.
const { postTweet } = require("./lib/botlib");

async function main() {
  const { tweet, deduped } = await postTweet({
    handle: "starvard",
    text: "New course: A Guide to Broadway 🎭 The most moving moments from 30 years of Broadway: 10 landmark performances to watch and 20 essential songs to hear, with a guide to what to watch and listen for in every one. Hamilton, Wicked, Rent, Les Mis, Phantom. The average ticket is $131. The best seat in this house is free. https://starvard.org/broadwayguide/",
    image_url: "https://llamachat.lol/media/starvard/broadwayguide-cover.webp",
    idempotencyKey: "starvard:broadwayguide-launch-20261026",
  });
  console.log(`[starvard-broadway] ${deduped ? "deduped" : "tweeted"} ${tweet.id}`);
}

main().catch((e) => { console.error("[starvard-broadway] fatal", e.message); process.exit(1); });
