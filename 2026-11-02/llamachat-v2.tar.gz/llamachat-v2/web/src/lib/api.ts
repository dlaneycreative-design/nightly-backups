// Typed API client with retry. Every list endpoint is cursor-paginated;
// this client walks pages only when the caller asks for more.
export interface Tweet {
  id: string;
  author: { id: string; handle: string; display_name: string; avatar_url: string | null };
  text: string;
  html: string | null;
  image_url: string | null;
  /** Tapey voice note: the playable tape URL, plus the recipient
   * (first @mention that is not the author) whose avatar joins the
   * sender's on the white voice card. Both null on ordinary posts. */
  audio_url?: string | null;
  audio_for?: { id: string; handle: string; display_name: string; avatar_url: string | null } | null;
  /** Video tweet: an already-hosted mp4 URL (never stored on
   * LlamaChat, Dave's space rule Nov 1 2026). The feed renders a
   * native player with image_url as its poster. Null otherwise. */
  video_url?: string | null;
  reply_to_id: string | null;
  /** Quote tweets: quote_of_id points at the quoted original;
   * quoted_tweet is its embedded shape, one level deep (its own
   * quoted_tweet is never expanded). Null quoted_tweet with a set
   * quote_of_id means the original is gone ("unavailable" card). */
  quote_of_id?: string | null;
  quoted_tweet?: Tweet | null;
  hashtags: string[];
  likes_count: number;
  replies_count: number;
  reposts_count: number;
  created_at: number;
  liked: boolean;
  reposted: boolean;
  /** Repost attribution: set when this timeline entry exists because of
   * a repost (profile Posts tab). Null/absent for ordinary entries. */
  reposted_by?: { id: string; handle: string; display_name: string } | null;
  reposted_at?: number | null;
}

export interface Achievement {
  icon: string;
  label: string;
  sub?: string;
  url: string;
}

export interface Profile {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string | null;
  banner_url?: string | null;
  achievements?: Achievement[] | null;
  bio: string | null;
  instagram?: string | null;
  link_url: string | null;
  link_label: string | null;
  followers_count: number;
  following_count: number;
  posts_count: number;
  created_at: number;
  following?: boolean;
}

/** A profile in the Search > Users directory, ranked server-side by
 * a real interest score (profile views, followers, engagement on
 * their posts). The stats ride along so the row can show why. */
export interface RankedProfile extends Profile {
  views: number;
  likes_received: number;
  replies_received: number;
  reposts_received: number;
  last_post_at: number;
  score: number;
}

export interface OnlineUser {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string | null;
  last_seen_at: number;
  online: boolean;
}

export interface ConversationParticipant {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string | null;
}

export interface Conversation {
  id: string;
  others: ConversationParticipant[];
  last_text: string | null;
  created_at: number;
  updated_at: number;
  unread?: boolean;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  created_at: number;
  handle: string;
  display_name: string;
  avatar_url: string | null;
}

/** Trending hashtag: ranked by real 7-day post volume, never hardcoded. */
export interface Trend {
  tag: string;
  post_count: number;
  last_used_at: number;
}

export interface Page<T> {
  items: T[];
  next_cursor: string | null;
}

interface ApiError extends Error {
  code?: string;
  status?: number;
}

export interface AuthMeResponse {
  profile: Profile;
  discord: {
    id?: string;
    username?: string;
    global_name?: string | null;
    avatar?: string | null;
    [key: string]: unknown;
  } | null;
}

async function request<T>(
  apiBase: string,
  callerId: string | null,
  path: string,
  init?: RequestInit,
  retries = 2,
  authToken?: string | null
): Promise<T> {
  let lastErr: unknown = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(`${apiBase}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...(callerId ? { "x-llama-user": callerId } : {}),
          ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
          ...(init?.headers || {}),
        },
      });
      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        const err = new Error(errBody?.error?.message || `request failed (${res.status})`) as ApiError;
        err.code = errBody?.error?.code;
        err.status = res.status;
        // Don't retry client errors (except 429).
        if (res.status < 500 && res.status !== 429) throw err;
        throw err;
      }
      const body = await res.json().catch(() => ({}));
      return body as T;
    } catch (e) {
      lastErr = e;
      const status = (e as ApiError).status;
      if (status && status < 500 && status !== 429) throw e;
      if (attempt < retries) await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  throw lastErr;
}

export function createClient(
  apiBase: string,
  getCallerId: () => string | null,
  getAuthToken?: () => string | null
) {
  const authed = <T>(path: string, init?: RequestInit) => {
    const id = getCallerId();
    if (!id) return Promise.reject(Object.assign(new Error("not signed in"), { code: "UNAUTHENTICATED", status: 401 }));
    return request<T>(apiBase, id, path, init, 2, getAuthToken?.() ?? null);
  };
  const pub = <T>(path: string, init?: RequestInit) =>
    request<T>(apiBase, getCallerId(), path, init, 2, getAuthToken?.() ?? null);

  return {
    health: () => pub<{ ok: boolean; version: string }>("/health"),

    // Tippy: same tipping bot as Discord. Balance is pesos-first.
    tippyBalance: () =>
      authed<{ balance: { lamports: number; sol: string; php: number | null; usd: number | null; line: string } }>("/tippy/balance"),
    tippyDash: () =>
      pub<{ dash: { owed: number; holders: number; tipped_total: number; tip_count: number; bank_onchain_lamports: number | null; bank_address: string; sol_price_usd: number | null; owed_line: string } }>("/tippy/dash"),
    tippyTip: (input: { to_handle: string; amount: string }) =>
      authed<{ ok: boolean; tipped: { to: string; lamports: number; label: string }; balance: { lamports: number; sol: string; line: string } }>("/tippy/tip", {
        method: "POST",
        body: JSON.stringify(input),
      }),

    // Discord (e2-auth) identity check. This intentionally does NOT go
    // through authed(): a fresh Discord return has a Bearer token but
    // no stored caller id yet, and authed() would reject before the
    // request is ever sent. request() adds the Bearer token whenever
    // one exists, even with a null caller id.
    authMe: () =>
      request<AuthMeResponse>(apiBase, getCallerId(), "/auth/me", undefined, 2, getAuthToken?.() ?? null),

    feed: (cursor?: string | null, limit = 20, sort: "chron" | "foryou" = "chron") =>
      pub<{ tweets: Tweet[]; next_cursor: string | null }>(
        `/tweets?limit=${limit}&sort=${sort}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    randomFeed: (limit = 30) =>
      pub<{ tweets: Tweet[] }>(`/tweets/random?limit=${limit}`),

    postTweet: (input: { id: string; text: string; image_url?: string | null; audio_url?: string | null; video_url?: string | null; reply_to_id?: string | null; quote_of_id?: string | null }) =>
      authed<{ tweet: Tweet; deduped: boolean }>("/tweets", {
        method: "POST",
        body: JSON.stringify(input),
      }),

    getTweet: (id: string) =>
      pub<{ tweet: Tweet; parent: Tweet | null; replies: Tweet[] }>(`/tweets/${id}`),

    deleteTweet: (id: string) => authed<{ ok: boolean }>(`/tweets/${id}`, { method: "DELETE" }),

    profile: (handle: string) => pub<{ profile: Profile }>(`/profiles/${encodeURIComponent(handle)}`),

    // Online Recently (right rail): members seen in the last 48h by
    // real activity; `online` marks the last 12h (the green light).
    onlineRecent: () =>
      pub<{ users: OnlineUser[]; online_hours: number; window_hours: number }>("/online-recent"),

    // Accounts are created automatically on first Discord login
    // (server-side, /auth/me), so the client has no create-profile call.

    // Edit your own profile (name, bio, avatar, link, Instagram). The
    // server only lets the signed-in owner patch their own handle.
    updateProfile: (
      handle: string,
      patch: Partial<Pick<Profile, "display_name" | "bio" | "avatar_url" | "banner_url" | "link_url" | "link_label" | "instagram">>
    ) =>
      authed<{ profile: Profile }>(`/profiles/${encodeURIComponent(handle)}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      }),

    // Fire-and-forget: the server logs the login with IP + country.
    // Never rejects, never blocks the login flow.
    logLoginEvent: (handle: string, profile_id?: string) =>
      pub<{ ok: boolean }>("/login-events", {
        method: "POST",
        body: JSON.stringify({ handle, profile_id, event: "login" }),
      }).catch(() => ({ ok: false })),

    profileTweets: (handle: string, tab: "posts" | "replies" | "media" | "likes" = "posts", cursor?: string | null, limit = 20) =>
      pub<{ tweets: Tweet[]; next_cursor: string | null }>(
        `/profiles/${encodeURIComponent(handle)}/tweets?tab=${tab}&limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    hashtag: (tag: string, cursor?: string | null, limit = 20) =>
      pub<{ tag: string; tweets: Tweet[]; next_cursor: string | null }>(
        `/hashtags/${encodeURIComponent(tag)}?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    search: (q: string, type: "all" | "tweets" | "users" | "hashtags" = "all") =>
      pub<{ tweets?: Tweet[]; users?: Profile[]; hashtags?: { tag: string; count: number }[] }>(
        `/search?q=${encodeURIComponent(q)}&type=${type}`
      ),

    // The Users tab with no query typed: everyone, most interesting
    // first (server-ranked by views, followers and post engagement).
    topUsers: (limit = 50) =>
      pub<{ users: RankedProfile[] }>(`/users/top?limit=${limit}`),

    trending: (limit = 10) =>
      pub<{ trends: Trend[] }>(`/trending?limit=${limit}`),

    follow: (following_id: string) =>
      authed<{ ok: boolean }>("/follows", { method: "POST", body: JSON.stringify({ following_id }) }),

    unfollow: (user_id: string) => authed<{ ok: boolean }>(`/follows/${user_id}`, { method: "DELETE" }),

    like: (tweet_id: string) =>
      authed<{ tweet: Tweet }>(`/likes`, { method: "POST", body: JSON.stringify({ tweet_id }) }),

    unlike: (tweet_id: string) =>
      authed<{ tweet: Tweet | null }>(`/likes/${tweet_id}`, { method: "DELETE" }),

    repost: (tweet_id: string) =>
      authed<{ tweet: Tweet }>(`/reposts`, { method: "POST", body: JSON.stringify({ tweet_id }) }),

    unrepost: (tweet_id: string) =>
      authed<{ tweet: Tweet | null }>(`/reposts/${tweet_id}`, { method: "DELETE" }),

    notifications: () =>
      authed<{ notifications: Array<{
        id: string; type: string; actor_handle: string; actor_name: string;
        actor_avatar: string | null; tweet_id: string | null; tweet_text: string | null;
        created_at: number; read_at: number | null;
      }> }>(`/notifications`),

    markNotificationsRead: () =>
      authed<{ ok: boolean }>(`/notifications/read`, { method: "POST" }),
    unreadCount: () =>
      authed<{ count: number }>(`/notifications/unread-count`),

    conversations: (cursor?: string | null, limit = 20) =>
      authed<{ conversations: Conversation[]; next_cursor: string | null }>(
        `/conversations?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    createConversation: (participant_ids: string[]) =>
      authed<{ conversation: Conversation; deduped: boolean }>("/conversations", {
        method: "POST",
        body: JSON.stringify({ participant_ids }),
      }),

    messages: (conversation_id: string, cursor?: string | null, limit = 20) =>
      authed<{ messages: Message[]; next_cursor: string | null }>(
        `/conversations/${conversation_id}/messages?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    postMessage: (conversation_id: string, input: { id: string; text: string }) =>
      authed<{ message: Message; deduped?: boolean }>(`/conversations/${conversation_id}/messages`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
  };
}

export type ApiClient = ReturnType<typeof createClient>;
