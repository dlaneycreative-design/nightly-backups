// Trending hashtags against the real seeded DB: ranked by real post
// volume (last 7 days), never hardcoded. Needs DATABASE_URL pointing at
// a seeded DB. Mirrors the exact SQL in server.js GET /api/v2/trending.
const { test } = require("node:test");
const assert = require("node:assert/strict");

const hasDb = !!process.env.DATABASE_URL;
let query;
if (hasDb) ({ query } = require("../lib/db"));

const WINDOW_MS = 7 * 24 * 3600 * 1000;

async function trending(limit) {
  const r = await query(
    `SELECT tag, count(*)::int AS post_count, max(t.created_at)::bigint AS last_used_at
     FROM tweets t, LATERAL unnest(t.hashtags) AS tag
     WHERE t.created_at >= $1
     GROUP BY tag
     ORDER BY post_count DESC, last_used_at DESC
     LIMIT $2`,
    [Date.now() - WINDOW_MS, limit]
  );
  return r.rows;
}

test("trending returns a ranked list with counts", { skip: !hasDb && "DATABASE_URL not set" }, async ()=> {
  const trends = await trending(10);
  assert.ok(Array.isArray(trends), "must be an array");
  assert.ok(trends.length > 0, "seeded DB should have hashtag volume");
  for (const t of trends) {
    assert.match(t.tag, /^[a-z0-9_]{1,64}$/, "tag is normalized");
    assert.ok(Number.isInteger(t.post_count) && t.post_count > 0, "positive count");
    assert.ok(Number.isSafeInteger(Number(t.last_used_at)) && Number(t.last_used_at) > 0, "positive last_used_at");
  }
});

test("trending is sorted by volume descending", { skip: !hasDb && "DATABASE_URL not set" }, async ()=> {
  const trends = await trending(10);
  const counts = trends.map((t) => t.post_count);
  const sorted = [...counts].sort((a, b) => b - a);
  assert.deepEqual(counts, sorted, "counts must be descending");
});

test("trending respects the limit clamp", { skip: !hasDb && "DATABASE_URL not set" }, async ()=> {
  const five = await trending(5);
  assert.ok(five.length <= 5, "must not exceed limit");
});

test("trending only counts posts inside the 7-day window", { skip: !hasDb && "DATABASE_URL not set" }, async ()=> {
  const trends = await trending(25);
  const cutoff = Date.now() - WINDOW_MS;
  for (const t of trends) {
    assert.ok(Number(t.last_used_at) >= cutoff, "last_used_at inside window");
  }
});

test("every trending tag exists in the hashtags index (no ghosts)", { skip: !hasDb && "DATABASE_URL not set" }, async ()=> {
  const trends = await trending(25);
  const r = await query(
    `SELECT DISTINCT unnest(hashtags) AS tag FROM tweets WHERE created_at >= $1`,
    [Date.now() - WINDOW_MS]
  );
  const live = new Set(r.rows.map((x) => x.tag));
  for (const t of trends) {
    assert.ok(live.has(t.tag), `trending tag #${t.tag} must exist in index`);
  }
});
