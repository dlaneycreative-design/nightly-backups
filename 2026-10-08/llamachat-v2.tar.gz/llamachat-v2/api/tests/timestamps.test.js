// Timestamps: the server stamps every write; the client never does.
// Dave's #1 bug (burned 3x in V1). These tests pin the contract.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { nowMs, parseClientTs } = require("../lib/timestamps");

test("nowMs returns sane Unix ms", () => {
  const before = Date.now();
  const ts = nowMs();
  const after = Date.now();
  assert.ok(Number.isInteger(ts), "must be an integer");
  assert.ok(ts > 0, "must be positive");
  assert.ok(ts >= before && ts <= after, "must be within the call window");
  assert.ok(ts > 1_700_000_000_000, "must be plausible Unix ms, not seconds");
});

test("parseClientTs accepts valid values", () => {
  const good = Date.now() - 1000;
  assert.equal(parseClientTs(String(good)), good);
  assert.equal(parseClientTs(good), good);
});

test("parseClientTs returns null for empty input", () => {
  assert.equal(parseClientTs(undefined), null);
  assert.equal(parseClientTs(null), null);
  assert.equal(parseClientTs(""), null);
});

test("parseClientTs rejects invalid values with 400", () => {
  const bad = [
    "0", 0, "-5", -1, "abc", "12.5", 12.5, "NaN",
    String(Date.now() + 48 * 3600 * 1000), // >24h in the future
  ];
  for (const v of bad) {
    assert.throws(() => parseClientTs(v), (e) => {
      assert.equal(e.status, 400);
      assert.equal(e.code, "INVALID_TIMESTAMP");
      return true;
    }, `should reject ${JSON.stringify(v)}`);
  }
});

test("parseClientTs never defaults to now", () => {
  // The V1 bug: relTime() defaulted garbage to Date.now(), producing
  // false "now" labels. Garbage must throw, never return a timestamp.
  const before = Date.now();
  assert.throws(() => parseClientTs("now"), /invalid timestamp/);
  assert.throws(() => parseClientTs("not-a-time"), /invalid timestamp/);
  assert.ok(Date.now() - before < 5000); // sanity: test itself is fast
});
