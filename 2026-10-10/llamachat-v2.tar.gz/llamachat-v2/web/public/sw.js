// LlamaChat service worker: cache app shell for instant repeat visits.
// Dave's call Oct 9 2026. P1 fix Oct 9: network-first for HTML so deploys
// always reach users; cache-first only for hashed assets.
const CACHE = 'llamachat-v2';
const SHELL = ['/seed-feed.json', '/llama-logo.avif'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  // Hashed static assets: cache-first (immutable).
  if (url.pathname.startsWith('/assets/') || SHELL.some((p) => url.pathname === p)) {
    e.respondWith(
      caches.match(e.request).then((hit) => hit || fetch(e.request).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      }))
    );
    return;
  }
  // HTML shell: network-first, fall back to cache offline.
  if (e.request.mode === 'navigate' || url.pathname === '/') {
    e.respondWith(
      fetch(e.request).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      }).catch(() => caches.match(e.request))
    );
  }
});
