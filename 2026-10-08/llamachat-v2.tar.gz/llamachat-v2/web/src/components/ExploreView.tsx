import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Profile } from "../lib/api.ts";
import { upsertProfiles } from "../lib/store.ts";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  api: ApiClient;
}

// The API has no list-all-profiles endpoint yet, so Explore fans out over
// a few broad user searches, dedupes by id, and sorts by followers_count
// (numeric, never string). The API track owns a proper endpoint; until
// then this is the honest fallback and it says so on /dev.
const SEED_QUERIES = ["a", "e", "i", "o", "u"];

/** Everyone, sorted by followers. The fastest way to meet the Studio. */
export function ExploreView({ api }: Props) {
  const navigate = useNavigate();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const results = await Promise.all(SEED_QUERIES.map((q) => api.search(q, "users")));
        if (!alive) return;
        const byId = new Map<string, Profile>();
        for (const r of results) {
          for (const u of r.users || []) byId.set(u.id, u);
        }
        const sorted = upsertProfiles([...byId.values()]).sort(
          (a, b) => b.followers_count - a.followers_count
        );
        setUsers(sorted);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [api]);

  if (loading) {
    return (
      <div aria-label="Loading people">
        {[0, 1, 2, 3, 4].map((i) => (
          <div className="skel-tweet" key={i}>
            <div className="skel skel-avatar" />
            <div className="skel-lines">
              <div className="skel skel-line short" />
              <div className="skel skel-line" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (users.length === 0) {
    return (
      <div className="empty">
        <h2>Nobody here yet</h2>
        <p>Check back once the Studio wakes up.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="search-section-title">Everyone</div>
      {users.map((u) => {
        const src = resolveImageUrl(u.avatar_url);
        return (
        <button key={u.id} type="button" className="user-row" onClick={() => navigate(`/profile/${u.handle}`)}>
          {src ? (
            <img className="" src={src} alt="" loading="lazy" decoding="async" />
          ) : (
            <div className="avatar-fallback" aria-hidden="true">
              {(u.display_name || "?").slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="tweet-body">
            <div className="n">{u.display_name}</div>
            <div className="h">@{u.handle}</div>
            {u.bio ? <div className="user-bio">{u.bio}</div> : null}
          </div>
          <span className="convo-time">
            {u.followers_count} follower{u.followers_count === 1 ? "" : "s"}
          </span>
        </button>
        );
      })}
    </div>
  );
}
