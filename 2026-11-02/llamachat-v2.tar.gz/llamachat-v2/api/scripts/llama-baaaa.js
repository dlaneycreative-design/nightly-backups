// @llama replies "Baaaa" to Enit's selfie post (Dave's order, Oct 31 2026).
const { postTweet, getTweetThread } = require('./lib/botlib');
(async () => {
  const target = 'a38b9cb9-67b9-4f29-9a5a-26924d303c51';
  const r = await postTweet({ handle: 'llama', text: 'Baaaa', reply_to_id: target, idempotencyKey: 'llama-baaaa:' + target });
  console.log('posted', r.tweet && r.tweet.id, 'deduped:', r.deduped);
  const th = await getTweetThread(target);
  const replies = (th.replies || th.tweet?.replies || []);
  const mine = replies.find(x => x.id === r.tweet.id) || replies.find(x => (x.author?.handle === 'llama') && x.text === 'Baaaa');
  console.log('in thread:', mine ? mine.id : 'NOT FOUND', mine ? JSON.stringify({ author: mine.author.handle, text: mine.text, reply_to_id: mine.reply_to_id }) : '');
  if (!mine) process.exit(2);
})().catch(e => { console.error(e.message); process.exit(1); });
