import { neon } from '@neondatabase/serverless';
import fs from 'node:fs';
const env = fs.readFileSync(new URL('../.env.local', import.meta.url), 'utf8');
const url = env.match(/DATABASE_URL\s*=\s*"?([^"\n]+)"?/)[1].trim();
const sql = neon(url);
const before = await sql`SELECT handle, link_url, link_label, instagram FROM profiles WHERE handle='dave'`;
console.log('BEFORE:', JSON.stringify(before));
if (!before.length) { console.error('no dave profile'); process.exit(1); }
await sql`UPDATE profiles SET link_label='HiDave.lol', instagram='Dlaney__', updated_at=${Date.now()} WHERE handle='dave'`;
const after = await sql`SELECT handle, link_url, link_label, instagram FROM profiles WHERE handle='dave'`;
console.log('AFTER:', JSON.stringify(after));
