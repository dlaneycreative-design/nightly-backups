// E2 official LlamaChat account, round 2 (Dave's feedback, Oct 31 2026):
// - Avatar becomes JUST the official E2 logo (navy circle, "E2." + gold dot,
//   the one on the flag), banner becomes a new high-quality 3D Pixar-style
//   map of the whole E2 island.
// - The 7 numbered story posts are deleted and replaced with unnumbered
//   posts pulled from Sam's E2 blog letter (e2.life/blog): the night the
//   doors opened, the Helpers Wall, Tippy arriving, the building spree,
//   bounties + Points, the music, and Sam's welcome as the crown post.
// Idempotent: uploads cached in /tmp/e2-llama-uploads-v2.json, tweets use
// deterministic idempotency keys (e2-blog:*), deletes skip 404s.
// Usage: node api/scripts/e2-account-v2.js
const fs = require("fs");
const { API_BASE, postTweet, getProfileId, getAuthorTweets, serviceHeaders, botServiceSecret } = require("./lib/botlib");

const handle = String.fromCharCode(101, 50, 108, 105, 102, 101); // e2life
const UPLOAD_STATE = "/tmp/e2-llama-uploads-v2.json";
const OLD_UPLOAD_STATE = "/tmp/e2-llama-uploads.json"; // round 1 uploads

const LOCAL_IMAGES = {
  pixarmap: [
    "/home/hatch/workspace/imagine_media/media-generation-e2-island-pixar-map-0-bd09fff6-624b-47b4-8ae4-225f06cc0916.webp",
    "image/webp",
    "e2-island-pixar-map.webp",
  ],
  logo: [
    "/home/hatch/workspace/e2-carve/brand/img/logo-circle.png",
    "image/png",
    "e2-logo.png",
  ],
  samroom: [
    "/home/hatch/workspace/e2-carve/people/sam/img/sam-in-the-room.webp",
    "image/webp",
    "sam-in-the-room.webp",
  ],
  samcoins: [
    "/home/hatch/workspace/e2-carve/people/sam/img/sam-coins.webp",
    "image/webp",
    "sam-coins.webp",
  ],
  tippy: ["/tmp/e2blog/tippy.webp", "image/webp", "tippy.webp"],
};

function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return {};
  }
}

async function uploadAll(e2Id) {
  const saved = readJson(UPLOAD_STATE);
  const old = readJson(OLD_UPLOAD_STATE);
  const urls = { ...old }; // reuse round-1 uploads (little, game, music, map)
  for (const [key, [path, type, name]] of Object.entries(LOCAL_IMAGES)) {
    if (saved[key]) {
      urls[key] = saved[key];
      console.log(`[e2v2] reusing upload ${key}`);
      continue;
    }
    const bytes = fs.readFileSync(path);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type }), name);
    form.append("kind", "tweet");
    const up = await fetch(`${API_BASE}/uploads`, {
      method: "POST",
      headers: serviceHeaders(e2Id),
      body: form,
    });
    if (!up.ok) throw new Error(`upload ${key} -> ${up.status} ${(await up.text()).slice(0, 200)}`);
    const { image_url } = await up.json();
    console.log(`[e2v2] uploaded ${key}: ${image_url}`);
    urls[key] = image_url;
    saved[key] = image_url;
    fs.writeFileSync(UPLOAD_STATE, JSON.stringify(saved, null, 2));
  }
  return urls;
}

async function patchProfile(id, urls) {
  const fields = {
    display_name: "E2",
    avatar_url: urls.logo,
    bio: "🏝️ The official account of E2: a little island universe of games, music, free learning and kind people. Built in public, one good day at a time. Welcome to the island.",
    link_url: "https://e2.life",
    link_label: "e2.life",
    banner_url: urls.pixarmap,
  };
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify(fields),
  });
  if (!res.ok) throw new Error(`PATCH -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[e2v2] profile set: avatar=logo, banner=pixar map");
  return d.profile;
}

async function deleteOldPosts(id) {
  const tweets = await getAuthorTweets(handle, 30);
  const posts = tweets.filter((t) => !t.reply_to_id);
  console.log(`[e2v2] found ${posts.length} existing posts to delete`);
  for (const t of posts) {
    const res = await fetch(`${API_BASE}/tweets/${t.id}`, {
      method: "DELETE",
      headers: serviceHeaders(id),
    });
    console.log(`[e2v2] delete ${t.id.slice(0, 8)} -> ${res.status}`);
    await new Promise((r) => setTimeout(r, 600));
  }
}

function tweets(urls) {
  return [
    {
      key: "e2-blog:doors",
      image_url: urls.little,
      text: "🚪 It started in the middle of the night.\n\nWe opened the doors to our friendly Discord on October 19 at 2:04 in the morning, because apparently that is when the best ideas happen around here. A handful of people wandered in, half asleep.\n\nBy the next night there were more than a hundred. Inside the first week, nearly five hundred. Today there are more than 900 of you in the room. Nine hundred hellos. 🏝️",
    },
    {
      key: "e2-blog:helpers",
      image_url: urls.samroom,
      text: "💛 And you did not just join. You helped.\n\nIn the last two weeks alone, nearly 300 of you have earned a face on our Helpers Wall: welcoming strangers, testing games, fixing pages, cheering on first drafts at hours when nobody reasonable is awake.\n\nHarsh, Moon, Ermalieh, Quibs, Koko, and so many more. That wall is a promise, not a finished list. https://e2.life/blog/",
    },
    {
      key: "e2-blog:tippy",
      image_url: urls.samcoins,
      text: "🪙 Then our smallest coworker with one of the biggest jobs arrived: Tippy, our cheerful gold coin tip bot.\n\nSuddenly good work around here comes with a thank you attached. Help somebody, ship something, claim one of the bounties, and Tippy rains pesos on you right there in the chat.\n\nIt sounds like a game, and it is a game, and it is also real people getting thanked in a way they can actually feel.",
    },
    {
      key: "e2-blog:built",
      image_url: urls.game,
      text: "🛠️ While all of that was happening, we built like crazy.\n\nThe games kept landing on Open Arcade. YouBoob grew past 600 videos. Starvard opened its courses and its big free library. Clear Recipe kept cooking, hundreds of dishes in 15 languages now.\n\nLlamaChat, Llamagram, a hackathon for our Filipino builders at Pinoy Hack, and well over a hundred brand new free sites for members who needed a home on the web. https://openarcade.lol",
    },
    {
      key: "e2-blog:points",
      image_url: urls.tippy,
      text: "🏆 The Bounties board never really sleeps.\n\nAnd the Points Scoreboard became one silver pile for the whole world: play a game, watch a video, finish a course, it all counts in the same place.\n\nJust this week we got to write about Ermalieh earning her very first Points. First points, first pages, first songs, first brave drafts of everything. This month was made of firsts.",
    },
    {
      key: "e2-blog:music",
      image_url: urls.music,
      text: "🎵 The island got a soundtrack, too.\n\nFind Your Island. Sally's songs. Dlaney learning music in public: 5 instruments, 50 songs, one year.\n\nThere is a stage on the beach on the island map. It is there because the music is real.",
    },
    {
      key: "e2-blog:welcome",
      image_url: urls.pixarmap,
      text: "🏝️ Welcome to E2, the official home of our little island universe on LlamaChat.\n\nSam said it best in this month's blog: \"If you just found us tonight, come on in. The kettle is on, the welcome desk is open, and I saved you a chair.\"\n\nHere is to month two. Read the whole story: https://e2.life/blog/",
    },
  ];
}

(async () => {
  const id = await getProfileId(handle);
  const urls = await uploadAll(id);
  await patchProfile(id, urls);
  await deleteOldPosts(id);
  for (const t of tweets(urls)) {
    const { tweet, deduped } = await postTweet({
      handle,
      text: t.text,
      image_url: t.image_url,
      idempotencyKey: t.key,
    });
    console.log(`[e2v2] ${deduped ? "deduped" : "posted"} ${t.key} -> ${tweet.id}`);
    await new Promise((res) => setTimeout(res, 1500));
  }
  console.log("[e2v2] done");
})().catch((e) => {
  console.error("[e2v2] fatal", e.message);
  process.exit(1);
});
