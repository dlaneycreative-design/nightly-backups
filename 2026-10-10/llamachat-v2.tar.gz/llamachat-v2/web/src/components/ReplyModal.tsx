// X-style reply modal. Clicking any tweet's reply button opens this instead
// of navigating: original tweet on top, "Replying to @handle", then the
// reply composer. Posts via the API, bumps the parent's reply count in the
// store, and closes.
import { useCallback, useEffect, useState } from "react";
import { showToast } from "../lib/toast.ts";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { tweetTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { upsertTweets } from "../lib/store.ts";
import { getCallerId } from "../lib/session.ts";
import {
  subscribeReplyModal,
  closeReplyModal,
  currentReplyTarget,
} from "../lib/replyModal.ts";
import { Composer } from "./Composer.tsx";

interface ModalProps {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
  target: TweetT;
  onClose: () => void;
}

function ReplyModal({ api, apiBase, me, target, onClose }: ModalProps) {
  const now = Date.now();
  const avatarSrc = resolveImageUrl(target.author.avatar_url);

  // Lock body scroll + close on Escape while the modal is open.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const onPosted = useCallback(
    (reply: TweetT) => {
      // New reply in the store + bump the parent's reply count everywhere
      // the store is read (feed, profile, thread header).
      upsertTweets([
        reply,
        { ...target, replies_count: target.replies_count + 1 },
      ]);
      onClose();
      showToast("Your reply was sent");
    },
    [target, onClose]
  );

  return (
    <div className="rm-backdrop" onClick={onClose} role="presentation">
      <div
        className="rm-modal"
        role="dialog"
        aria-modal="true"
        aria-label={`Reply to ${target.author.display_name}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="rm-top">
          <button type="button" className="rm-close" onClick={onClose} aria-label="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
          <button type="button" className="rm-drafts" onClick={onClose}>
            Drafts
          </button>
        </div>

        <div className="rm-orig">
          <div className="rm-orig-row">
            {avatarSrc ? (
              <img className="avatar" src={avatarSrc} alt={`${target.author.display_name}'s avatar`} />
            ) : (
              <div className="avatar avatar-fallback" aria-hidden="true">
                {(target.author.display_name || "?").slice(0, 1).toUpperCase()}
              </div>
            )}
            <div className="rm-orig-body">
              <div className="tweet-head">
                <span className="name">{target.author.display_name}</span>
                <span className="meta">
                  @{target.author.handle} · {tweetTime(target, now)}
                </span>
              </div>
              {target.html ? (
                <div className="tweet-text" dangerouslySetInnerHTML={{ __html: target.html }} />
              ) : (
                <p className="tweet-text">{target.text}</p>
              )}
              <div className="rm-replying">
                Replying to <span className="rm-replying-handle">@{target.author.handle}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="rm-composer">
          <Composer
            api={api}
            apiBase={apiBase}
            getCallerId={getCallerId}
            avatarUrl={me?.avatar_url ?? null}
            replyToId={target.id}
            placeholder="Post your reply"
            autofocus
            hideReplyingLabel
            onPosted={onPosted}
          />
        </div>
      </div>
    </div>
  );
}

interface HostProps {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
}

/** Mounted once in App. Shows the modal whenever openReplyModal() fires. */
export function ReplyModalHost({ api, apiBase, me }: HostProps) {
  const [target, setTarget] = useState<TweetT | null>(() => currentReplyTarget());

  useEffect(() => subscribeReplyModal(setTarget), []);

  const onClose = useCallback(() => closeReplyModal(), []);

  if (!target) return null;
  if (!getCallerId()) {
    // Not signed in: nothing to reply with. Close quietly.
    closeReplyModal();
    return null;
  }
  return <ReplyModal api={api} apiBase={apiBase} me={me} target={target} onClose={onClose} />;
}
