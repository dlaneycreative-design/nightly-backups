import { neon } from '@neondatabase/serverless';
import fs from 'node:fs';
const env = fs.readFileSync('../.env.local', 'utf8');
const url = env.match(/DATABASE_URL\s*=\s*"?([^"\n]+)"?/)[1].trim();
const sql = neon(url);
const rows = await sql`SELECT id, image_url FROM tweets WHERE image_url LIKE '%e2.life%' OR image_url LIKE '%thestudio.io%'`;
console.log('offsite rows:', JSON.stringify(rows));
for (const r of rows) {
  if (r.image_url.includes('sally-and-doodle')) {
    await sql`UPDATE tweets SET image_url='/media/local/doodle/sally-and-doodle.webp' WHERE id=${r.id}`;
    console.log('rewrote tweet', r.id);
  }
}
const after = await sql`SELECT count(*) AS n FROM tweets WHERE image_url LIKE '%e2.life%' OR image_url LIKE '%thestudio.io%'`;
console.log('offsite remaining:', JSON.stringify(after));
console.log('DOODLE FIX DONE');
