import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import { upsertTweets, removeTweet } from "../lib/store.ts";
import { Tweet } from "./Tweet.tsx";

interface Props {
  api: ApiClient;
  tag: string;
}

/** Hashtag page: server-side index, paginated. */
export function HashtagView({ api, tag }: Props) {
  const [tweets, setTweets] = useState<TweetT[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const cursorRef = useRef<string | null>(null);
  const hasMoreRef = useRef(true);
  const loadingRef = useRef(false);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const loadMore = useCallback(async () => {
    if (loadingRef.current || !hasMoreRef.current) return;
    loadingRef.current = true;
    setLoadingMore(true);
    try {
      const res = await api.hashtag(tag, cursorRef.current, 20);
      upsertTweets(res.tweets);
      setTweets((prev) => {
        const seen = new Set(prev.map((t) => t.id));
        return [...prev, ...res.tweets.filter((t) => !seen.has(t.id))];
      });
      cursorRef.current = res.next_cursor;
      hasMoreRef.current = res.next_cursor !== null;
    } finally {
      loadingRef.current = false;
      setLoading(false);
      setLoadingMore(false);
    }
  }, [api, tag]);

  useEffect(() => {
    setTweets([]);
    cursorRef.current = null;
    hasMoreRef.current = true;
    setLoading(true);
    void loadMore();
  }, [tag, loadMore]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) void loadMore();
      },
      { rootMargin: "1200px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [loadMore]);

  const onDeleted = useCallback((id: string) => {
    removeTweet(id);
    setTweets((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <div>
      <div className="hashtag-head">
        <h1>#{tag}</h1>
        <p>Every post tagged #{tag}, newest first.</p>
      </div>
      {loading ? (
        <div aria-label="Loading tag">
          {[0, 1, 2].map((i) => (
            <div className="skel-tweet" key={i}>
              <div className="skel skel-avatar" />
              <div className="skel-lines">
                <div className="skel skel-line short" />
                <div className="skel skel-line" />
              </div>
            </div>
          ))}
        </div>
      ) : tweets.length === 0 ? (
        <div className="empty">
          <h2>No posts yet</h2>
          <p>Be the first to post #{tag}.</p>
        </div>
      ) : (
        tweets.map((t) => <Tweet key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
      )}
      <div ref={sentinelRef} className="feed-sentinel" aria-hidden="true">
        {loadingMore ? "Loading more..." : ""}
      </div>
    </div>
  );
}
