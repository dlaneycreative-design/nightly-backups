// Read-only: the full c4ba3a00 tweet row (Mike log #114).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
const sql = neon(url);
const rows = await sql`SELECT id, text, html, image_url, created_at FROM tweets WHERE id = 'c4ba3a00-cefd-571c-ab7c-ac4b5e5335b2'`;
for (const r of rows) { console.log('text:', r.text); console.log('html:', r.html); console.log('image_url:', r.image_url); console.log('created_at:', r.created_at); }
const anyOther = await sql`SELECT count(*)::int AS n FROM tweets WHERE image_url ILIKE '%thestudio.io%'`;
console.log('tweets with thestudio.io image_url:', anyOther[0].n);
