import { neon } from '@neondatabase/serverless';
import fs from 'node:fs';
const env = fs.readFileSync('../.env.local', 'utf8');
const url = env.match(/DATABASE_URL\s*=\s*"?([^"\n]+)"?/)[1].trim();
const sql = neon(url);
const rows = await sql`SELECT id, handle, image_url FROM tweets WHERE image_url LIKE '%e2.life%' OR image_url LIKE '%thestudio.io%'`;
console.log('offsite rows:', JSON.stringify(rows, null, 1));
