import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import type { TempTweet } from "./Composer.tsx";
import { tweetTime, absTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { TweetImage } from "./TweetImage.tsx";
import { getCallerId } from "../lib/session.ts";
import { openReplyModal } from "../lib/replyModal.ts";

/** A tweet still waiting on the server. Renders "sending...", never a time. */
export interface PendingViewTweet {
  pending: true;
  tempId: string;
  text: string;
  image_url: string | null;
  author: { display_name: string; handle: string; avatar_url: string | null };
}

export type TweetLike = TweetT | PendingViewTweet;

/** Type guard: optimistic (server-unconfirmed) tweets carry pending: true. */
export function isPendingTweet(t: TweetLike): t is PendingViewTweet {
  return (t as PendingViewTweet).pending === true;
}

export function tempToPending(temp: TempTweet, author: PendingViewTweet["author"]): PendingViewTweet {
  return {
    pending: true,
    tempId: temp.tempId,
    text: temp.text,
    image_url: temp.image_url,
    author,
  };
}

/** Re-render on a slow tick so "5s" becomes "6s" without new data. */
function useNow(intervalMs = 30_000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function Avatar({ name, url }: { name: string; url: string | null }) {
  const src = resolveImageUrl(url);
  if (src) {
    return <img className="avatar" src={src} alt={`${name}'s avatar`} loading="lazy" decoding="async" />;
  }
  const initial = (name || "?").slice(0, 1).toUpperCase();
  return (
    <div className="avatar avatar-fallback" aria-hidden="true">
      {initial}
    </div>
  );
}

interface Props {
  tweet: TweetLike;
  api: ApiClient;
  onDeleted?: (id: string) => void;
  detail?: boolean;
  onReplyOverride?: (tweet: TweetT) => void;
}

/** Like toggle: optimistic UI, persists via /api/v2/likes. Reverts on failure. */
function LikeToggle({ tweetId, initial, initialLiked, api }: {
  tweetId: string;
  initial: number;
  initialLiked: boolean;
  api: ApiClient;
}) {
  const [on, setOn] = useState(initialLiked);
  const [count, setCount] = useState(initial);
  const busy = useRef(false);
  const toggle = async () => {
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.like(tweetId) : await api.unlike(tweetId);
      if (r.tweet) {
        setOn(r.tweet.liked);
        setCount(r.tweet.likes_count);
      }
    } catch {
      // Not signed in or network failed: revert the optimistic toggle.
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };
  return (
    <button
      type="button"
      className={`act like${on ? " on" : ""}`}
      aria-label={`${count} likes`}
      onClick={toggle}
    >
      <span className="ic">
        <svg viewBox="0 0 24 24" fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
      </span>
      <span className="n">{count > 0 ? count : null}</span>
    </button>
  );
}

/** Repost toggle: optimistic UI, persists via /api/v2/reposts. Reverts on failure. */
function RepostToggle({ tweetId, initial, initialReposted, api }: {
  tweetId: string;
  initial: number;
  initialReposted: boolean;
  api: ApiClient;
}) {
  const [on, setOn] = useState(initialReposted);
  const [count, setCount] = useState(initial);
  const busy = useRef(false);
  const toggle = async () => {
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.repost(tweetId) : await api.unrepost(tweetId);
      if (r.tweet) {
        setOn(r.tweet.reposted);
        setCount(r.tweet.reposts_count);
      }
    } catch {
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };
  return (
    <button
      type="button"
      className={`act rt${on ? " on" : ""}`}
      aria-label={`${count} reposts`}
      onClick={toggle}
    >
      <span className="ic">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
      </span>
      <span className="n">{count > 0 ? count : null}</span>
    </button>
  );
}

/**
 * Tweet card. THE timestamp path: tweetTime() only. Invalid stamps render
 * nothing; pending tweets render "sending...". No ad-hoc date formatting.
 */
export function Tweet({ tweet, api, onDeleted, detail = false, onReplyOverride }: Props) {
  const navigate = useNavigate();
  const now = useNow();
  const [deleting, setDeleting] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [shared, setShared] = useState(false);

  // Normalize the union into one view model. The timestamp ALWAYS goes
  // through tweetTime(): pending -> "sending...", invalid -> "".
  const pending = isPendingTweet(tweet);
  const view = pending
    ? {
        key: tweet.tempId,
        name: tweet.author.display_name,
        handle: tweet.author.handle,
        avatar: tweet.author.avatar_url,
        time: tweetTime({ pending: true }, now),
        text: tweet.text,
        html: null as string | null,
        image_url: tweet.image_url,
        replies_count: 0,
        likes_count: 0,
        real: null as TweetT | null,
      }
    : {
        key: tweet.id,
        name: tweet.author.display_name,
        handle: tweet.author.handle,
        avatar: tweet.author.avatar_url,
        time: tweetTime(tweet, now),
        text: tweet.text,
        html: tweet.html,
        image_url: tweet.image_url,
        replies_count: tweet.replies_count,
        likes_count: tweet.likes_count,
        real: tweet as TweetT,
      };
  const mine = view.real !== null && view.real.author.id === getCallerId();

  // Server-rendered html already linkifies #tags and @mentions; route
  // those through the SPA instead of a full page load.
  const onBodyClick = (e: React.MouseEvent) => {
    const a = (e.target as HTMLElement).closest("a");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (href.startsWith("/hashtag/") || href.startsWith("/profile/")) {
      e.preventDefault();
      e.stopPropagation();
      navigate(href);
    }
  };

  const openThread = () => {
    if (view.real) navigate(`/tweet/${view.real.id}`);
  };

  // X behavior: the reply icon opens the reply modal, not the thread.
  const onReply = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    if (onReplyOverride) {
      onReplyOverride(view.real);
    } else {
      openReplyModal(view.real);
    }
  };

  const onDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real || deleting) return;
    if (!window.confirm("Delete this post?")) return;
    setDeleting(true);
    setMenuOpen(false);
    try {
      await api.deleteTweet(view.real.id);
      onDeleted?.(view.real.id);
    } catch {
      setDeleting(false);
    }
  };

  const onShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    const url = `${window.location.origin}/tweet/${view.real.id}`;
    const text = `${view.name} (@${view.handle}): ${view.text}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "LlamaChat post", text, url });
      } else {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      }
    } catch {
      // user cancelled share or clipboard failed; try clipboard as fallback
      try {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch { /* ignore */ }
    }
  };

  return (
    <article
      className={`tweet${pending ? " pending" : ""}`}
      onClick={openThread}
      aria-label={pending ? "Sending post" : `Post by ${view.name}`}
    >
      <a
        className="avatar-link"
        href={`/profile/${view.handle}`}
        onClick={(e) => {
          e.stopPropagation();
          navigate(`/profile/${view.handle}`);
        }}
      >
        <Avatar name={view.name} url={view.avatar} />
      </a>
      <div className="tweet-body">
        <div className="tweet-head">
          <a
            className="name"
            href={`/profile/${view.handle}`}
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/profile/${view.handle}`);
            }}
          >
            {view.name}
          </a>
          <span className="meta">
            <a
              className="tw-handle"
              href={`/profile/${view.handle}`}
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/profile/${view.handle}`);
              }}
            >
              @{view.handle}
            </a>
            {" · "}
            {view.real ? (
              <a
                className="tw-time"
                href={`/tweet/${view.real.id}`}
                title="View tweet"
                onClick={(e) => {
                  e.stopPropagation();
                  openThread();
                }}
              >
                {view.time}
              </a>
            ) : (
              <span className="tw-time sending">{view.time}</span>
            )}
          </span>
          {view.real ? (
            <div className="tw-menu-wrap">
              <button
                type="button"
                className="tw-menu-btn"
                aria-label="More options"
                onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}
              >
                <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>
              </button>
              {menuOpen ? (
                <>
                  <div className="tw-menu-backdrop" onClick={(e) => { e.stopPropagation(); setMenuOpen(false); }} />
                  <div className="tw-menu" onClick={(e) => e.stopPropagation()}>
                    {mine ? (
                      <button type="button" className="tw-menu-item danger" onClick={onDelete} disabled={deleting}>
                        {deleting ? "Deleting..." : "Delete post"}
                      </button>
                    ) : null}
                    <button type="button" className="tw-menu-item" onClick={(e) => { setMenuOpen(false); onShare(e); }}>
                      Share post
                    </button>
                  </div>
                </>
              ) : null}
            </div>
          ) : null}
        </div>
        {view.html ? (
          <div className="tweet-text" onClick={onBodyClick} dangerouslySetInnerHTML={{ __html: view.html }} />
        ) : (
          <p className="tweet-text">{view.text}</p>
        )}
        {view.image_url ? <TweetImage imageUrl={view.image_url} /> : null}
        {detail && view.real ? (
          <div className="tw-detail-time">{absTime(view.real.created_at)}</div>
        ) : null}
        {view.real && (
          <div className="tweet-actions" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="act reply" aria-label={`${view.replies_count} replies`} onClick={onReply}>
              <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-3-.4-4.2-1.1L3 20l1.1-5.3A8.5 8.5 0 1 1 21 11.5z"/></svg></span>
              <span className="n">{view.replies_count > 0 ? view.replies_count : null}</span>
            </button>
            <RepostToggle tweetId={view.real.id} initial={view.real.reposts_count} initialReposted={!!view.real.reposted} api={api} />
            <LikeToggle tweetId={view.real.id} initial={view.likes_count} initialLiked={!!view.real.liked} api={api} />
            <span className="act views" aria-label="Views">
              <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </span>
            <button type="button" className={`act share${shared ? " on" : ""}`} aria-label="Share post" onClick={onShare} title={shared ? "Link copied!" : "Share"}>
              <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12"/><path d="M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 002 2h10a2 2 0 002-2v-6"/></svg></span>
            </button>
            {detail && mine ? (
              <button type="button" className="act ghost-act" onClick={onDelete} disabled={deleting}>
                {deleting ? "Deleting..." : "Delete"}
              </button>
            ) : null}
          </div>
        )}
      </div>
    </article>
  );
}
