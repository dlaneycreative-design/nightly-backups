import { neon } from '@neondatabase/serverless';
import fs from 'fs';
import crypto from 'crypto';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
const now = Date.now();
const MUSE = '287f91ac-1fb2-4505-a489-77256fb35404';
const DAVE = '8d754e46-a2af-4318-a3d8-9b47e5473abb';
const TWEET = '1f07bbb6-1e51-4dc1-9630-7bc72c0174ed';

// 1. Chadwick bio + link (Dave's pick: the Blaze bio, e2.life link)
await sql`UPDATE profiles SET bio = 'Youth pastor. Big smile. Believe.', link_url = 'https://e2.life/chadwick/', link_label = 'e2.life/chadwick', updated_at = ${now} WHERE handle = 'chadwick'`;
const c = await sql`SELECT handle, bio, link_url, link_label FROM profiles WHERE handle = 'chadwick'`;
console.log('CHADWICK NOW:', JSON.stringify(c[0]));

// 2. Like Dave's tweet as @muse (same writes the API performs)
const ins = await sql`INSERT INTO likes (user_id, tweet_id, created_at) VALUES (${MUSE}, ${TWEET}, ${now}) ON CONFLICT DO NOTHING RETURNING user_id`;
console.log('LIKE INSERTED:', ins.length === 1);
await sql`UPDATE tweets SET likes_count = (SELECT COUNT(*) FROM likes WHERE tweet_id = ${TWEET}) WHERE id = ${TWEET}`;
if (ins.length === 1) {
  await sql`INSERT INTO notifications (id, user_id, actor_id, type, tweet_id, created_at) VALUES (${crypto.randomUUID()}, ${DAVE}, ${MUSE}, 'like', ${TWEET}, ${now})`;
}
const t = await sql`SELECT likes_count FROM tweets WHERE id = ${TWEET}`;
console.log('TWEET LIKES_COUNT:', t[0].likes_count);

// 3. New post as @muse: just the sparkles
const id = crypto.randomUUID();
await sql`INSERT INTO tweets (id, author_id, text, html, image_url, reply_to_id, hashtags, created_at, updated_at) VALUES (${id}, ${MUSE}, '✨', '✨', ${null}, ${null}, '{}', ${now}, ${now}) ON CONFLICT (id) DO NOTHING`;
await sql`UPDATE profiles SET posts_count = (SELECT COUNT(*) FROM tweets WHERE author_id = ${MUSE}) WHERE id = ${MUSE}`;
console.log('NEW POST ID:', id);
