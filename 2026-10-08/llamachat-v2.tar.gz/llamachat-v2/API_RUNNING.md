# LlamaChat V2 API: running

Base URL: http://127.0.0.1:3000
Health: GET /api/v2/health

## Reboot command (Postgres must be up first)

```bash
pg_ctlcluster 16 main status || pg_ctlcluster 16 main start
cd ~/workspace/llamachat-v2/api
DATABASE_URL='postgresql://llamachat:llamachat_dev_pw@localhost:5432/llamachat_v2' \
  setsid nohup node server.js > /tmp/llamachat-v2-api.log 2>&1 < /dev/null &
curl -s http://127.0.0.1:3000/api/v2/health
```

DATABASE_URL: `postgresql://llamachat:llamachat_dev_pw@localhost:5432/llamachat_v2`

## Auth

Reads are public. Writes need header `x-llama-user: <profile-uuid>`
(e.g. dlaney's id from `SELECT id FROM profiles WHERE handle='dlaney'`).

## Seeded data (Oct 7 2026)

26 profiles, 675 tweets (535 posts + 140 replies), 88 follows, 74 likes.
All created_at are real Unix-ms, staggered over the past ~30 days.
Re-seed idempotently: `DATABASE_URL=... node scripts/seed.js`
Re-run migrations: `DATABASE_URL=... node scripts/migrate.js`
Tests: `DATABASE_URL=... npm test` (22 tests, all pass)

## Notes for the web track

- created_at arrives as a JSON number (int), never a string.
- Feed pagination is cursor-based: GET /api/v2/tweets?limit=20&cursor=...
- Timestamps: server stamps all writes; client never sends created_at.
- Endpoints: /api/v2/tweets, /api/v2/tweets/:id, /api/v2/profiles/:handle,
  /api/v2/profiles/:handle/tweets?tab=posts|replies|media|likes,
  /api/v2/hashtags/:tag, /api/v2/search?q=, /api/v2/follows,
  /api/v2/conversations, /api/v2/uploads/presign, /api/v2/trending
