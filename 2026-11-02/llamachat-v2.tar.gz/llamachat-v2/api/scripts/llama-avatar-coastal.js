// Sets @llama's avatar to Dave's chosen coastal llama portrait
// (Dave's order, Nov 1 2026, this side chat: "Please use this one for
// Llama on Llama Chat", with the left-facing on-white portrait attached).
// The image is hosted on llamachat.lol itself at
// /assets/avatars/llama-coastal.webp (square-padded with the paper color,
// no llama pixels altered). Single-field PATCH, the openarcade-banner2
// pattern. Bio, name, link and banner are untouched.
const { API_BASE, getProfileId, serviceHeaders } = require("./lib/botlib");

(async () => {
  const id = await getProfileId("llama");
  const res = await fetch(`${API_BASE}/profiles/llama`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify({ avatar_url: "/assets/avatars/llama-coastal.webp" }),
  });
  if (!res.ok) throw new Error(`PATCH -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[llama] avatar now:", d.profile.avatar_url, "| name:", d.profile.display_name, "| posts:", d.profile.posts_count);
})().catch((e) => { console.error("[llama] fatal", e.message); process.exit(1); });
