// Session restore for Discord-locked accounts (Dave @dave, Harsh
// @harsh, Oct 28-29 2026): a protected profile must never be restored
// from the bare legacy stored id alone (the API refuses every write
// for it with DISCORD_LOGIN_REQUIRED, so the app would look logged in
// while posting always fails), and a transient auth failure must
// never discard a valid Discord token.
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  _setStorage, ensureDevSession, captureDiscordLogin,
  getAuthToken, getCallerId, setCallerId, setAuthToken, clearCallerId,
} from "../src/lib/session.ts";
import type { Profile } from "../src/lib/api.ts";

const HARSH_ID = "cac2d6dc-df51-526a-942a-ca8c229f6c56";
const SAM_ID = "11111111-2222-4333-8444-555555555555";

function mem() {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => (m.has(k) ? m.get(k)! : null),
    setItem: (k: string, v: string) => { m.set(k, v); },
    removeItem: (k: string) => { m.delete(k); },
  };
}

function profile(id: string, handle: string): Profile {
  return {
    id, handle, display_name: handle, avatar_url: null, bio: null,
    link_url: null, link_label: null, followers_count: 0,
    following_count: 0, posts_count: 0, created_at: 1700000000000,
  };
}

function apiWith(authMeImpl: () => Promise<unknown>, profileImpl?: (h: string) => Promise<unknown>) {
  return {
    authMe: authMeImpl,
    profile: profileImpl || (async (h: string) => ({ profile: profile(h === "harsh" ? HARSH_ID : SAM_ID, h) })),
  } as never;
}

function errWith(status: number) {
  return Object.assign(new Error(`http ${status}`), { status });
}

test("legacy @harsh session with no Discord token is NOT restored, and is cleared", async () => {
  _setStorage(mem());
  clearCallerId();
  setCallerId(HARSH_ID, "harsh");
  const p = await ensureDevSession(apiWith(async () => { throw errWith(401); }));
  assert.equal(p, null);
  assert.equal(getCallerId(), null);
});

test("legacy non-protected session still restores by handle", async () => {
  _setStorage(mem());
  clearCallerId();
  setCallerId(SAM_ID, "sam");
  const p = await ensureDevSession(apiWith(async () => { throw errWith(401); }));
  assert.equal(p?.handle, "sam");
});

test("@harsh with a token whose auth check fails transiently (500): logged out, token KEPT", async () => {
  _setStorage(mem());
  clearCallerId();
  setCallerId(HARSH_ID, "harsh");
  setAuthToken("tok-valid-but-server-flaky");
  const p = await ensureDevSession(apiWith(async () => { throw errWith(500); }));
  assert.equal(p, null);
  assert.equal(getAuthToken(), "tok-valid-but-server-flaky");
});

test("captureDiscordLogin keeps the token when auth/me fails transiently", async () => {
  _setStorage(mem());
  clearCallerId();
  (globalThis as Record<string, unknown>).window = {
    location: { hash: "#t=tok-fresh", pathname: "/", search: "" },
    history: { replaceState: () => {} },
  };
  const p = await captureDiscordLogin(apiWith(async () => { throw errWith(500); }));
  assert.equal(p, null);
  assert.equal(getAuthToken(), "tok-fresh");
});

test("captureDiscordLogin discards the token on a definitive 401", async () => {
  _setStorage(mem());
  clearCallerId();
  (globalThis as Record<string, unknown>).window = {
    location: { hash: "#t=tok-bad", pathname: "/", search: "" },
    history: { replaceState: () => {} },
  };
  const p = await captureDiscordLogin(apiWith(async () => { throw errWith(401); }));
  assert.equal(p, null);
  assert.equal(getAuthToken(), null);
});

test("@harsh with a valid Discord token restores as @harsh", async () => {
  _setStorage(mem());
  clearCallerId();
  setCallerId(HARSH_ID, "harsh");
  setAuthToken("tok-good");
  const p = await ensureDevSession(apiWith(async () => ({ profile: profile(HARSH_ID, "harsh") })));
  assert.equal(p?.handle, "harsh");
  assert.equal(getAuthToken(), "tok-good");
});
