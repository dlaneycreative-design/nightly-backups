import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Conversation, Message } from "../lib/api.ts";
import { newestFirst } from "../lib/timestamps.ts";
import { getCallerId } from "../lib/session.ts";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  api: ApiClient;
  conversationId: string;
  conversation?: Conversation | null;
}

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

/**
 * Conversation view. Messages sorted by numeric created_at (oldest at
 * the bottom). Optimistic bubbles show "sending...", never a fake time.
 */
export function DMThread({ api, conversationId, conversation = null }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const me = getCallerId();
  const bottomRef = useRef<HTMLDivElement>(null);

  const merge = useCallback((incoming: Message[]) => {
    setMessages((prev) => {
      const byId = new Map(prev.map((m) => [m.id, m]));
      for (const m of incoming) byId.set(m.id, m);
      // Numeric sort, oldest first for chat layout.
      return [...byId.values()].sort((a, b) => newestFirst(b, a));
    });
  }, []);

  const load = useCallback(async () => {
    setError(null);
    try {
      const { messages: list } = await api.messages(conversationId, null, 50);
      merge(list);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load messages.");
    } finally {
      setLoading(false);
    }
  }, [api, conversationId, merge]);

  useEffect(() => {
    setMessages([]);
    setLoading(true);
    void load();
  }, [load]);

  // Lightweight poll while the thread is open (no WebSocket endpoint).
  useEffect(() => {
    const t = setInterval(() => {
      void load();
    }, 15000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  const send = useCallback(async () => {
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    const id = newId();
    const optimistic: Message = {
      id,
      conversation_id: conversationId,
      sender_id: me || "",
      text: body,
      created_at: NaN, // invalid on purpose: renders as "sending...", never a fake time
      handle: "",
      display_name: "",
      avatar_url: null,
    };
    merge([optimistic]);
    setText("");
    try {
      const { message } = await api.postMessage(conversationId, { id, text: body });
      merge([message]);
    } catch {
      // Keep the bubble; a retry tap could go here (V2.5).
    } finally {
      setSending(false);
    }
  }, [text, sending, api, conversationId, me, merge]);

  if (loading) {
    return (
      <div className="dm-messages" aria-label="Loading messages">
        {[0, 1, 2].map((i) => (
          <div className="skel skel-line" key={i} />
        ))}
      </div>
    );
  }

  return (
    <div className="dm-thread">
      {conversation && conversation.others.length > 0 ? (
        <div className="dm-thread-header">
          <button
            type="button"
            className="dm-back-btn"
            aria-label="Back to messages"
            onClick={() => window.history.back()}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          {(() => {
            const other = conversation.others[0];
            const avatar = resolveImageUrl(other.avatar_url);
            return (
              <>
                {avatar ? (
                  <img src={avatar} alt="" className="dm-thread-avatar" />
                ) : (
                  <div className="avatar-fallback" aria-hidden="true">
                    {(other.display_name || "?").slice(0, 1).toUpperCase()}
                  </div>
                )}
                <div className="dm-thread-info">
                  <div className="dm-thread-name">{other.display_name}</div>
                  <div className="dm-thread-handle">@{other.handle}</div>
                </div>
              </>
            );
          })()}
        </div>
      ) : null}
      {error ? (
        <div className="errorbox" role="alert">
          <p>{error}</p>
          <button type="button" className="ghost" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : null}
      <div className="dm-messages">
        {messages.length === 0 ? (
          <div className="empty">
            <h2>No messages yet</h2>
            <p>Say hi to start the conversation.</p>
          </div>
        ) : (
          messages.map((m) => {
            const mine = m.sender_id === me;
            return (
              <div key={m.id} className={`dm-bubble${mine ? " me" : " them"}`}>
                <div>{m.text}</div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>
      <div className="dm-inputbar">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write a message"
          aria-label="Write a message"
          maxLength={2000}
          onKeyDown={(e) => {
            if (e.key === "Enter") void send();
          }}
        />
        <button type="button" onClick={() => void send()} disabled={!text.trim() || sending} aria-label="Send message">
          {sending ? "..." : "Send"}
        </button>
      </div>
    </div>
  );
}
