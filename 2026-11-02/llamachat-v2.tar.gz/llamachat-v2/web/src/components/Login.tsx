// Login: Discord is the ONLY door (Dave's call Nov 1 2026: "The
// honor system login is no more. Take it off of everywhere."). Anyone
// logs in with Discord through e2-auth, which returns with a token in
// the URL hash that App startup captures, and the API creates their
// LlamaChat account automatically on the first login. There is no
// signup form and no handle login anywhere anymore.
import type { ApiClient } from "../lib/api.ts";
import { DISCORD_LOGIN_URL, SITE_NAME } from "../lib/theme.ts";

export function Login(_props: { api: ApiClient; onDone: () => void }) {
  return (
    <div style={{maxWidth:380,margin:"80px auto",padding:"0 20px",textAlign:"center"}}>
      <h1 style={{fontSize:28,marginBottom:8}}>Log in to {SITE_NAME}</h1>
      <p style={{color:"#536471",marginBottom:24}}>Log in with Discord and you are in. New accounts are created automatically.</p>
      <a
        href={DISCORD_LOGIN_URL}
        style={{display:"block",width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#5865F2",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",textDecoration:"none",boxSizing:"border-box"}}
      >
        Login with Discord
      </a>
      <p style={{fontSize:14,marginTop:24,color:"#536471"}}>
        That is the whole login. One button, no form, no password.
      </p>
    </div>
  );
}
