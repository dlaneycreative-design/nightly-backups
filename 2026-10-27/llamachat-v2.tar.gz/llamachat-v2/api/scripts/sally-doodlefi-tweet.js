const { postTweet } = require("./lib/botlib");

const TEXT = "we built doodle a safe place tonight. doodlefi: she draws at her desk, her music plays soft, her battery never runs low, and nobody ever rushes her. turn it on and just chill.\n\nhttps://e2.life/doodlefi/\n\ncc @doodle";

(async () => {
  const handle = String.fromCharCode(115, 97, 108, 108, 121); // sally
  const { tweet, deduped } = await postTweet({
    handle,
    text: TEXT,
    image_url: "https://e2.life/people/doodle/sally-and-doodle.webp",
    idempotencyKey: "sally:doodlefi-launch-1",
  });
  console.log(deduped ? "deduped" : "posted", "sally tweet:", tweet.id);
  console.log("TWEET_URL=https://llamachat.lol/tweet/" + tweet.id);
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
