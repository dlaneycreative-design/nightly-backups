// Dave's #1 rule (Oct 7 2026): timestamps go through ONE path, and a
// missing/invalid stamp renders NOTHING, never "now", never a fake time.
// This tests the exact path the Tweet component uses (tweetTime), plus the
// numeric-only sort comparator. Run: node --test web/tests/
import { test } from "node:test";
import assert from "node:assert/strict";
import { tweetTime, newestFirst } from "../src/lib/timestamps.ts";

const NOW = new Date("2026-10-07T14:00:00").getTime();
const s = 1000;
const m = 60 * s;

test("invalid created_at renders empty string, never 'now'", () => {
  for (const bad of [null, 0, -5, "now", undefined, NaN, 1.5, {}, []]) {
    assert.equal(tweetTime({ created_at: bad }, NOW), "", `expected "" for ${JSON.stringify(bad)}`);
  }
});

test("future created_at clamps to 'now' (clock skew)", () => {
  assert.equal(tweetTime({ created_at: NOW + 5 * m }, NOW), "now");
});

test("pending optimistic tweet shows 'sending...', never a fake timestamp", () => {
  assert.equal(tweetTime({ created_at: null, pending: true }, NOW), "sending...");
  // Even a plausible-looking client stamp must not leak through as a time.
  assert.equal(tweetTime({ created_at: NOW - 2 * s, pending: true }, NOW), "sending...");
});

test("valid created_at still formats relatively", () => {
  assert.equal(tweetTime({ created_at: NOW - 42 * s }, NOW), "42s");
  assert.equal(tweetTime({ created_at: NOW - 3 * m }, NOW), "3m");
});

test("sort comparator is numeric-only; invalid stamps sink to the bottom", () => {
  const items = [
    { created_at: 5 },
    { created_at: 100 },
    { created_at: null },
    { created_at: 50 },
    { created_at: "now" },
  ];
  const sorted = [...items].sort(newestFirst);
  assert.deepEqual(
    sorted.map((i) => i.created_at),
    [100, 50, 5, null, "now"]
  );
  // String comparison would put "now" first; numeric must not.
  assert.ok(newestFirst({ created_at: "9" }, { created_at: 1000 }) > 0);
});
