// Batch-repoint the 19 proof-grid-failing profiles whose avatar image exists as a
// Pages-served file in dist, away from dead /media/ URLs.
// Owner: main chat (Dave's P1 part 2 order Oct 13 2026). Idempotent. Follows set-avatars.mjs pattern.
// NOT repointed (no non-/media/ dist copy exists): jonny, podcast, thestudio.
// john -> /John-avatar.webp: same file as its current /media/oldchat/John-avatar.webp target,
//   present at dist root and verified live (200 image/webp) before this run.
// enriquebot -> enrique.webp: its current DB target IS enrique.webp (same image).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const MAP = {
  buster: '/assets/avatars/buster.webp',
  doodle: '/assets/avatars/doodle.webp',
  enrique: '/assets/avatars/enrique.webp',
  enriquebot: '/assets/avatars/enrique.webp',
  gloria: '/assets/avatars/gloria.webp',
  haddiesings: '/assets/avatars/haddiesings.jpg',
  harsh: '/assets/avatars/harsh.jpg',
  jahvibez: '/assets/avatars/jahvibez.webp',
  jaylen: '/assets/avatars/jaylen.webp',
  john: '/John-avatar.webp',
  judge: '/assets/avatars/judge.webp',
  leo: '/assets/avatars/leo.webp',
  llama: '/assets/avatars/llama.webp',
  mateo: '/assets/avatars/mateo.webp',
  memebot: '/assets/avatars/memebot.webp',
  oldray: '/assets/avatars/oldray.webp',
  sam: '/assets/avatars/sam.webp',
  tex: '/assets/avatars/tex.webp',
  willa: '/assets/avatars/willa.webp',
};
const HANDLES = Object.keys(MAP);

const before = await sql`SELECT handle, avatar_url FROM profiles WHERE handle = ANY(${HANDLES}) ORDER BY handle`;
console.log('BEFORE:');
for (const r of before) console.log(`  ${r.handle} -> ${r.avatar_url}`);

for (const [handle, target] of Object.entries(MAP)) {
  const u = await sql`UPDATE profiles SET avatar_url = ${target} WHERE handle = ${handle}`;
  console.log(`update ${handle}: count=${u.count}`);
}

const after = await sql`SELECT handle, avatar_url FROM profiles WHERE handle = ANY(${HANDLES}) ORDER BY handle`;
console.log('AFTER:');
let bad = 0;
for (const r of after) {
  const ok = r.avatar_url === MAP[r.handle];
  if (!ok) bad++;
  console.log(`  ${r.handle} -> ${r.avatar_url} ${ok ? 'OK' : 'MISMATCH'}`);
}
console.log(`ROWS: ${after.length} of ${HANDLES.length}, mismatches: ${bad}`);
console.log('BATCH AVATAR UPDATE DONE');
