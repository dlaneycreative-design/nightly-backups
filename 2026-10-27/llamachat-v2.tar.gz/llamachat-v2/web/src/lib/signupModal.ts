// Signup modal open/close bus. The modal hosts the self-serve
// SignupForm (Dave's order Oct 19 2026): account creation is instant,
// no vetting queue.
type Listener = (open: boolean) => void;
let isOpen = false;
const listeners = new Set<Listener>();

export function openSignupModal(): void {
  isOpen = true;
  listeners.forEach((l) => l(true));
}

export function closeSignupModal(): void {
  isOpen = false;
  listeners.forEach((l) => l(false));
}

export function subscribeSignupModal(l: Listener): () => void {
  listeners.add(l);
  return () => { listeners.delete(l); };
}

export function isSignupOpen(): boolean {
  return isOpen;
}
