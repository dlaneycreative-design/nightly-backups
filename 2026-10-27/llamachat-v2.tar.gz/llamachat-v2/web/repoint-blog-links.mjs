// Repoint blog links in DB tweets from thestudio.io to their E2 homes.
// Dave approved this exact change in main chat (Oct 13 2026): Mike blog links
// -> e2.life/mikeblog; Sally/Dinesh blogs -> their e2.life blog homes
// (ALL BLOGS IN E2 rule). Anchored Mike links keep their #mike-log-NN anchor,
// which exists verbatim as an id on e2.life/mikeblog/archive/.
// Out of scope (inventory only): cardboard/podcast product links, bare prose
// mentions of thestudio.io. Idempotent: rerunning matches zero rows.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const MAPS = [
  ['https://www.thestudio.io/mike/#mike-log-', 'https://e2.life/mikeblog/archive/#mike-log-'],
  ['https://www.thestudio.io/mike/', 'https://e2.life/mikeblog/archive/'],
  ['https://www.thestudio.io/sallyblog/', 'https://e2.life/sallyblog/'],
  ['https://www.thestudio.io/dineshblog/', 'https://e2.life/dineshblog/'],
];

for (const [oldU, newU] of MAPS) {
  const before = await sql`
    SELECT count(*)::int AS n FROM tweets
    WHERE text LIKE ${'%' + oldU + '%'} OR html LIKE ${'%' + oldU + '%'}`;
  const upd = await sql`
    UPDATE tweets
    SET text = replace(text, ${oldU}, ${newU}),
        html = replace(html, ${oldU}, ${newU})
    WHERE text LIKE ${'%' + oldU + '%'} OR html LIKE ${'%' + oldU + '%'}`;
  console.log(`${oldU} -> ${newU} : matched ${before[0].n}, updated ${upd.count}`);
}

const remain = await sql`
  SELECT t.id, p.handle FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE (t.text LIKE '%thestudio.io/mike/%' OR t.html LIKE '%thestudio.io/mike/%'
      OR t.text LIKE '%thestudio.io/sallyblog/%' OR t.html LIKE '%thestudio.io/sallyblog/%'
      OR t.text LIKE '%thestudio.io/dineshblog/%' OR t.html LIKE '%thestudio.io/dineshblog/%')`;
console.log('blog-pattern rows still on thestudio.io:', remain.length);

const sample = await sql`
  SELECT t.id, t.text FROM tweets t
  WHERE t.text LIKE '%e2.life/mikeblog%' ORDER BY t.created_at DESC LIMIT 4`;
for (const r of sample) console.log('SAMPLE', r.id, '|', r.text);
console.log('REPOINT DONE');
