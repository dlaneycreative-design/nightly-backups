// Read-only inspection before wiping @llama's tweets (Dave's order Nov 1
// 2026: delete all the other tweets, post five new aloof ones).
// The API delete path caps at 3 deletes per 10 min and then locks the
// account (safety.js DELETE_LIMIT), so bulk removal goes direct to the
// DB like other LlamaChat admin work (add-jen.mjs pattern).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync(new URL('../../.env.local', import.meta.url), 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const prof = await sql`SELECT id, handle, posts_count FROM profiles WHERE handle = 'llama'`;
console.log('profile:', JSON.stringify(prof[0]));
const pid = prof[0].id;
const tweets = await sql`SELECT id, text, reply_to_id, created_at FROM tweets WHERE author_id = ${pid} ORDER BY created_at`;
console.log('authored tweets:', tweets.length);
for (const t of tweets) console.log(' ', t.id, t.reply_to_id ? '(reply)' : '', JSON.stringify((t.text || '').slice(0, 60)));
fs.writeFileSync('/home/hatch/workspace/llama-tweets-db-backup-20261101.json', JSON.stringify(tweets, null, 2));
console.log('db backup written');

const fks = await sql`
  SELECT tc.table_name, kcu.column_name, rc.delete_rule
  FROM information_schema.referential_constraints rc
  JOIN information_schema.table_constraints tc ON tc.constraint_name = rc.constraint_name
  JOIN information_schema.key_column_usage kcu ON kcu.constraint_name = rc.constraint_name
  JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = rc.constraint_name
  WHERE ccu.table_name = 'tweets'`;
console.log('FKs referencing tweets:');
for (const f of fks) console.log(' ', JSON.stringify(f));
const tables = await sql`SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY 1`;
console.log('tables:', tables.map(t => t.table_name).join(', '));
