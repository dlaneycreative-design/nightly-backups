// Creates the @bugle profile (The E2 Bugle) and posts one synopsis tweet per
// Bugle issue, oldest first so the newest issue crowns the profile.
// Idempotent: profile insert is ON CONFLICT DO NOTHING; tweets use
// deterministic idempotency keys via botlib.
// Usage: node api/scripts/bugle-account.js
const { neon } = require("@neondatabase/serverless");
const fs = require("fs");
const { postTweet } = require("./lib/botlib");

let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);

const handle = String.fromCharCode(98, 117, 103, 108, 101); // bugle

const TWEETS = [
  {
    key: "bugle:issue-1",
    image_url: "https://llamachat.lol/media/bugle/issue1.webp",
    text: "📯 The first Bugle is out! Mike climbed on a crate in the town square: Chadwick's 6am gym, a rooftop sunset with Sally and Dinesh, Cardboard shipped before breakfast, and e2.life has a new front door. Read it: https://e2.life/bugle/#bugle-1",
  },
  {
    key: "bugle:issue-2",
    image_url: "https://llamachat.lol/media/bugle/issue2.webp",
    text: "📯 Bugle #2: LAKE DAY. The crew took the Short Bus out of town. Mike wiped out water skiing, Dinesh coded from a hammock and then actually closed the laptop, and Sally wrote a song about the water. Read it: https://e2.life/bugle/#bugle-2",
  },
  {
    key: "bugle:issue-3",
    image_url: "https://llamachat.lol/media/bugle/issue3.webp",
    text: "📯 Bugle #3: Romula, the city before the city. Our reporter went 2,000 years back: the founding carving, the fountain that never stopped, baths kept at the temperature of a good soup, and one very confident historian. Read it: https://e2.life/bugle/#bugle-3",
  },
  {
    key: "bugle:issue-4",
    image_url: "https://llamachat.lol/media/bugle/issue4.webp",
    text: "📯 Bugle #4: STARVARD UNIVERSITY IS OPEN 🎓 Dave cut the ribbon yesterday. 102 books that read aloud, 115 free courses, 5 languages, and a piano challenge that pays you $100. Read it: https://e2.life/bugle/#bugle-4",
  },
];

(async () => {
  const ts = Date.now();
  const r = await sql.query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(), $1, 'The E2 Bugle', 'https://llamachat.lol/assets/avatars/bugle.webp', '📯 The E2 Bugle. Every update from around E2, delivered loud and clear. Town square news, lake reports, and now a university.', 'https://e2.life/bugle/', 'e2.life/bugle', $2, $2)
     ON CONFLICT (handle) DO NOTHING RETURNING id`,
    [handle, ts]
  );
  if (r.length) console.log("created @bugle:", r[0].id);
  else {
    const e = await sql`SELECT id, display_name FROM profiles WHERE handle = ${handle}`;
    console.log("@bugle already exists:", e[0].id, e[0].display_name);
  }
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", t.key, tweet.id);
    await new Promise((res) => setTimeout(res, 1500));
  }
})().catch((e) => { console.error("ERR", e.message); process.exit(1); });
