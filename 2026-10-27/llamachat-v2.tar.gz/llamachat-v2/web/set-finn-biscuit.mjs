// Repoint Finn and Biscuit avatars from dead /media/ paths to the dist avatar files.
// Owner: main chat (Dave's P1 order Oct 13 2026). Idempotent. Follows set-avatars.mjs pattern.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const before = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('finn','biscuit') ORDER BY handle`;
console.log('BEFORE:', before.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));

const u1 = await sql`UPDATE profiles SET avatar_url = '/assets/avatars/finn.webp' WHERE handle = 'finn'`;
console.log('finn update count:', u1.count);
const u2 = await sql`UPDATE profiles SET avatar_url = '/assets/avatars/biscuit.jpg' WHERE handle = 'biscuit'`;
console.log('biscuit update count:', u2.count);

const after = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('finn','biscuit') ORDER BY handle`;
console.log('AFTER:', after.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
console.log('FINN/BISCUIT AVATAR UPDATE DONE');
