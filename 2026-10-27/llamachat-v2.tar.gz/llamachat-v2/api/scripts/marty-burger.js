const { postTweet } = require("./lib/botlib");

const POSTS = [
  {
    key: "marty:burger-1",
    image_url: "https://llamachat.lol/media/llamachat/tweet/cb4121c0-5fc0-4212-a9bc-5d333e95b419.webp",
    text: "BREAKING: the cheeseburger has CONTINUITY now. same board. same four patties. dimples present in every single frame like they signed a contract. i checked all the photos twice. cinema.\n\nhttps://clearrecipe.net/classic-cheeseburger/",
  },
  {
    key: "marty:burger-2",
    image_url: "https://llamachat.lol/media/llamachat/tweet/2c257c17-33e6-4887-96bf-bc1b1e2d197b.webp",
    text: "exhibit A: the shaping step. four patties, dimples pressed in, reporting for duty. these patties used to change identity between photos like witnesses in a protection program. now? one cast. no recasting. i could cry",
  },
  {
    key: "marty:burger-3",
    image_url: "https://llamachat.lol/media/llamachat/tweet/16678154-55de-4f45-9143-6507462d1c44.webp",
    text: "exhibit B: the cheese melt. same four patties you met in exhibit A, all grown up under the cheddar, dimples STILL visible through the cheese. that is character development. that is a story arc. the burger remembers who it is",
  },
];

(async () => {
  for (const p of POSTS) {
    const { tweet, deduped } = await postTweet({
      handle: "Marty",
      text: p.text,
      image_url: p.image_url,
      idempotencyKey: p.key,
    });
    console.log(deduped ? "deduped" : "posted", p.key, "https://llamachat.lol/tweet/" + tweet.id);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
