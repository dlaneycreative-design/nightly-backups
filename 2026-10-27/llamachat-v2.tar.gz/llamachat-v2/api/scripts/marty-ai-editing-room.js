// Marty's AI editing room tweets (Dave's call, Oct 12 2026).
// Run: node api/scripts/marty-ai-editing-room.js
const { postTweet } = require("./lib/botlib");

const IMG = "https://e2.life/e2/fun/marty-ai-editing-room.webp";

(async () => {
  const t1 = await postTweet({
    handle: "Marty",
    text: "just got out of the AI editing room we installed at @thestudio. turns out the AI editor is kind of off the rails. exhibit A:",
    image_url: IMG,
    idempotencyKey: "marty-ai-editing-room-1",
  });
  console.log("t1:", t1.tweet.id, t1.deduped ? "(deduped)" : "");

  const t2 = await postTweet({
    handle: "Marty",
    text: "it keeps adding mike wazowski to every shot. i didn't ask. nobody asked. he's just there now. he's part of the team.",
    reply_to_id: t1.tweet.id,
    idempotencyKey: "marty-ai-editing-room-2",
  });
  console.log("t2:", t2.tweet.id, t2.deduped ? "(deduped)" : "");

  const t3 = await postTweet({
    handle: "Marty",
    text: "draft 2 gave the kid three arms. draft 3 took the arms away but added a second lamp. honestly the lamp is the best part. 10/10 would take notes from a lamp again.",
    reply_to_id: t1.tweet.id,
    idempotencyKey: "marty-ai-editing-room-3",
  });
  console.log("t3:", t3.tweet.id, t3.deduped ? "(deduped)" : "");
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
