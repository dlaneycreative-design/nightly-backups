// Tapey voice notes for LlamaChat: the recorder + upload half.
// The player half is the VoiceCard in components/Tweet.tsx.
//
// Recording uses the same recipe as the Tapey recorder on e2.life:
// MediaRecorder with the mime type picked MP4 FIRST, because tapes
// recorded as Chrome WebM/Opus will not play in Safari (Dave hit
// exactly that on Oct 31 2026 and every Tapey tape had to be
// transcoded). MP4/AAC plays everywhere; WebM is the fallback for
// browsers with no MP4 recorder (Firefox).
import { getAuthToken } from "./session.ts";

const MIME_CANDIDATES = [
  "audio/mp4",
  "audio/webm;codecs=opus",
  "audio/webm",
  "audio/ogg;codecs=opus",
  "audio/ogg",
];

/** The MediaRecorder mime type to record with on THIS browser. */
export function pickRecorderMime(): string {
  if (typeof MediaRecorder === "undefined") return "";
  for (const m of MIME_CANDIDATES) {
    try {
      if (MediaRecorder.isTypeSupported(m)) return m;
    } catch {
      /* try the next one */
    }
  }
  return "";
}

export function recorderSupported(): boolean {
  return (
    typeof navigator !== "undefined" &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.getUserMedia === "function" &&
    typeof MediaRecorder !== "undefined"
  );
}

/** File extension that matches a recorder mime type (server names the R2 key with it). */
export function extForMime(mime: string): string {
  if (mime.startsWith("audio/mp4")) return "m4a";
  if (mime.startsWith("audio/webm")) return "webm";
  if (mime.startsWith("audio/ogg")) return "ogg";
  return "webm";
}

/**
 * Upload a recorded tape via the normal uploads route (kind=voice).
 * The API stores it in the same R2 bucket Tapey uses and returns the
 * playable media URL the tweet then carries as audio_url.
 */
export async function uploadVoice(
  apiBase: string,
  callerId: string,
  blob: Blob,
  mime: string
): Promise<string> {
  const form = new FormData();
  form.append("file", blob, `tapey-voice.${extForMime(mime)}`);
  form.append("kind", "voice");
  const authToken = getAuthToken();
  const res = await fetch(`${apiBase}/uploads`, {
    method: "POST",
    headers: {
      "x-llama-user": callerId,
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
    },
    body: form,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `voice upload failed (${res.status})`);
  }
  const data = await res.json();
  const url = data?.audio_url || data?.image_url;
  if (!url) throw new Error("voice upload returned no url");
  return url as string;
}

/** "0:07" style timer for the recorder and the player. */
export function fmtClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds || 0));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
