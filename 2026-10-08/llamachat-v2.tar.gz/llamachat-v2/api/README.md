# LlamaChat V2 API

Stateless Express API. All state lives in PostgreSQL; any number of
instances can run behind a load balancer.

## Setup

```bash
npm install
# env (see below), then:
npm run migrate   # applies db/migrations/*.sql in order
npm run dev       # watch mode on :3000
```

## Env

| Var | Required | Purpose |
|---|---|---|
| `DATABASE_URL` | yes | Postgres connection string |
| `PORT` | no | default 3000 |
| `PG_POOL_MAX` | no | default 20 |
| `R2_ENDPOINT` | no | REMOVED Oct 7 2026: uploads moved to Vercel Blob |
| `R2_ACCESS_KEY_ID` | no | REMOVED Oct 7 2026: uploads moved to Vercel Blob |
| `R2_SECRET_ACCESS_KEY` | no | REMOVED Oct 7 2026: uploads moved to Vercel Blob |
| `R2_BUCKET` | no | REMOVED Oct 7 2026: uploads moved to Vercel Blob |
| `CDN_BASE_URL` | no | REMOVED Oct 7 2026: uploads moved to Vercel Blob |
| `BLOB_READ_WRITE_TOKEN` | for uploads | Vercel Blob store token (auto-set when the store is connected) |

## Conventions

- **Timestamps:** server-stamped `Date.now()` on every write (`lib/timestamps.js`).
  `created_at` is `BIGINT NOT NULL` everywhere. Client values are ignored.
- **Pagination:** cursor = `base64url("<created_at>:<id>")`, keyset over
  `(created_at DESC, id DESC)`. `?cursor=&limit=` (default 20, max 50).
  Never `OFFSET`.
- **Idempotent writes:** tweets/messages take client-generated UUIDs;
  `ON CONFLICT (id) DO NOTHING` + return existing. Retries never duplicate.
- **Auth (pragmatic V2):** `x-llama-user` header = caller profile id.
  V2.5 replaces this with signed session tokens.
- **Errors:** `{ "error": { "code": "SNAKE_CASE", "message": "..." } }`
  with the matching HTTP status.

## Worker

RETIRED Oct 7 2026. Uploads go straight to Vercel Blob and clients
downscale to <=1600px WebP in-browser, so no server-side resize step exists.
`npm run worker` exits with a note.
