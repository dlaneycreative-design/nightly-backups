// Build public/seed-feed.json straight from the database (Neon), mirroring
// api/server.js shapeTweet + the chron feed query exactly. Fallback for when
// the live API is unreachable from the build box; fetch-seed.js (API route)
// remains the primary. Oct 13 2026.
const fs = require("fs");
const path = require("path");
const { neon } = require("@neondatabase/serverless");

const envText = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8");
const dbUrl = envText.match(/^DATABASE_URL=(.+)$/m)[1].trim().replace(/^"|"$/g, "");
const sql = neon(dbUrl);

const WEBP_REWRITES = {
  "avatars/chadwick.png": "avatars/chadwick.webp",
  "avatars/doodle.png": "avatars/doodle.webp",
  "avatars/enrique.png": "avatars/enrique.webp",
  "avatars/gloria.jpg": "avatars/gloria.webp",
  "avatars/jahvibez.jpg": "avatars/jahvibez.webp",
  "avatars/jaylen.jpg": "avatars/jaylen.webp",
  "avatars/tex.jpg": "avatars/tex.webp",
  "assets/studio-world-hero.jpg": "assets/studio-world-hero.webp",
  "cardboard/cardboard-images-tweet.png": "cardboard/cardboard-images-tweet.webp",
  "e2/podcast/dumb-ideas-ep1-poster.jpg": "e2/podcast/dumb-ideas-ep1-poster.webp",
  "sally/doodle-bot.png": "sally/doodle-bot.webp",
  "shortbus/assets/portraits/chadwick.jpg": "shortbus/assets/portraits/chadwick.webp",
  "starvard/starvard-campus.jpg": "starvard/starvard-campus.webp",
};
function fixImageUrl(url) {
  if (!url || typeof url !== "string") return url;
  if (url.startsWith("https://www.thestudio.io/")) {
    const p = url.slice("https://www.thestudio.io/".length);
    return "https://llamachat.lol/assets/" + (WEBP_REWRITES[p] || p);
  }
  return url;
}
function hashtags(v) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string") {
    const s = v.replace(/^\{|\}$/g, "").trim();
    return s ? s.split(",").map((x) => x.replace(/^"|"$/g, "")) : [];
  }
  return [];
}
function shapeTweet(row) {
  return {
    id: row.id,
    author: { id: row.author_id, handle: row.handle, display_name: row.display_name, avatar_url: row.avatar_url },
    text: row.text,
    html: row.html,
    image_url: fixImageUrl(row.image_url),
    reply_to_id: row.reply_to_id,
    hashtags: hashtags(row.hashtags),
    likes_count: Number(row.likes_count) || 0,
    replies_count: Number(row.replies_count) || 0,
    reposts_count: Number(row.reposts_count) || 0,
    created_at: Number(row.created_at),
    liked: false,
    reposted: false,
  };
}

(async () => {
  const rows = await sql.query(
    `SELECT t.*, p.handle, p.display_name, p.avatar_url
     FROM tweets t JOIN profiles p ON p.id = t.author_id
     WHERE t.reply_to_id IS NULL
     ORDER BY t.created_at DESC, t.id DESC
     LIMIT 9`
  );
  const page = rows.slice(0, 8);
  const last = page[page.length - 1];
  const next_cursor = rows.length > 8 && last
    ? Buffer.from(`${Number(last.created_at)}:${last.id}`).toString("base64url")
    : null;
  const seed = { built_at: new Date().toISOString(), tweets: page.map(shapeTweet), next_cursor };
  const out = path.join(__dirname, "..", "public", "seed-feed.json");
  fs.writeFileSync(out, JSON.stringify(seed));
  console.log(`[seed-db] wrote ${seed.tweets.length} tweets -> ${out}`);
})().catch((e) => { console.error("[seed-db] FAILED:", e.message); process.exit(1); });
