// Client-side HTML sanitizer for server-rendered tweet HTML.
// The API's renderHtml() escapes user text server-side, but we sanitize
// again here as defense-in-depth before dangerouslySetInnerHTML.
import DOMPurify from "dompurify";

const ALLOWED_TAGS = [
  "a",
  "b",
  "strong",
  "i",
  "em",
  "br",
  "p",
  "div",
  "span",
  "iframe",
];
const ALLOWED_ATTR = [
  "href",
  "target",
  "rel",
  "class",
  "data-tag",
  "data-handle",
  "title",
  "src",
  "frameborder",
  "allow",
  "allowfullscreen",
  "loading",
];

export function sanitizeTweetHtml(dirty: string): string {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS,
    ALLOWED_ATTR,
    ALLOW_DATA_ATTR: false,
  });
}
