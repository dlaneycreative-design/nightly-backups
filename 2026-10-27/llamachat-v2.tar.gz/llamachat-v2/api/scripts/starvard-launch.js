const { postTweet } = require("./lib/botlib");

// Starvard launch tweets, Dave's order Oct 14 2026. Posted in array order;
// the feed is newest-first, so the announcement (launch-1) is posted LAST
// and crowns the profile. Idempotent via deterministic keys.
const POSTS = [
  {
    key: "starvard:launch-2",
    image_url: "https://llamachat.lol/media/starvard/courses.webp",
    text: "New covers just dropped: The Money Index Card, Artificial Intelligence 101, Positive Psychology, Law 101, and Habits 101. Every course free, so we made the covers feel like movie posters. Which one are you taking first?",
  },
  {
    key: "starvard:launch-3",
    image_url: "https://llamachat.lol/media/starvard/library.webp",
    text: "The Masters Library is open. 19 classics you can read right in your browser, 5 with full human audio: Frankenstein, Dracula, Pride and Prejudice, Moby-Dick, and more. Next stop, 100 books. starvard.org/books",
  },
  {
    key: "starvard:launch-4",
    image_url: "https://llamachat.lol/media/starvard/piano.webp",
    text: "We pay you to learn. The 99 Days of Piano Challenge is live: practice daily, post your videos, finish all 99 days and Starvard pays you $100. Sally teaches the free course. starvard.org/challenges",
  },
  {
    key: "starvard:launch-5",
    image_url: "https://llamachat.lol/media/starvard/campuses.webp",
    text: "One face, one name, two campuses. Your Starvard profile is your Llama Chat profile, same name, same face. Dave is studying piano and Spanish. What are you studying?",
  },
  {
    key: "starvard:launch-1",
    image_url: "https://llamachat.lol/media/starvard/seal.webp",
    text: "Starvard University is officially open. 114 free courses, a library of the great books, and tuition of exactly $0. No applications. No debt. No catch. Just learn. starvard.org",
  },
];

(async () => {
  for (const p of POSTS) {
    const { tweet, deduped } = await postTweet({
      handle: "starvard",
      text: p.text,
      image_url: p.image_url,
      idempotencyKey: p.key,
    });
    console.log(deduped ? "deduped" : "posted", p.key, "https://llamachat.lol/tweet/" + tweet.id);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
