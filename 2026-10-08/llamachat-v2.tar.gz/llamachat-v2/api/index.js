// Vercel serverless entry: re-export the Express app.
// server.js only calls app.listen() when run directly (require.main check),
// so requiring it here is safe. Vercel preserves the original request path
// through the /api/v2/* rewrite, so all /api/v2/... routes keep working.
module.exports = require('./server.js');
