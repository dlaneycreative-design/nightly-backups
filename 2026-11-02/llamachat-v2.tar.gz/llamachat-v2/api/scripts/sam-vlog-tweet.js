// Sam's tweet for her late night vlog inside "The past month was wild!"
// (Dave's ask, Nov 1 2026). Uploads the post's poster still through the
// real API, then posts as @sam via botlib. Idempotent on the tweet id.
const fs = require("fs");
const { API_BASE, postTweet, getProfileId, serviceHeaders } = require("./lib/botlib");

async function main() {
  const samId = await getProfileId("sam");
  const bytes = fs.readFileSync("/home/hatch/workspace/e2-carve/blog/img/sam-at-her-desk.webp");
  const form = new FormData();
  form.append("file", new Blob([bytes], { type: "image/webp" }), "sam-at-her-desk.webp");
  form.append("kind", "tweet");
  const up = await fetch(`${API_BASE}/uploads`, {
    method: "POST",
    headers: serviceHeaders(samId),
    body: form,
  });
  if (!up.ok) throw new Error(`upload -> ${up.status} ${(await up.text()).slice(0, 200)}`);
  const { image_url } = await up.json();
  console.log("[sam-vlog] uploaded", image_url);

  const text = `It got late at my desk, so instead of just writing about this wild month, I made you a vlog. 🌙

Nine hundred new friends, a Discord that opened at 2 in the morning, and more building than I can count. The video is right inside my blog post, come watch it with me:
https://e2.life/blog/#blog-3

The kettle is on, and I saved you a chair. ☕`;
  const { tweet, deduped } = await postTweet({
    handle: "sam",
    text,
    image_url,
    idempotencyKey: "sam-vlog-blog:20261101",
  });
  console.log(`[sam-vlog] ${deduped ? "deduped" : "tweeted"} ${tweet.id}`);
}
main().catch((e) => { console.error("[sam-vlog] fatal", e.message); process.exit(1); });
