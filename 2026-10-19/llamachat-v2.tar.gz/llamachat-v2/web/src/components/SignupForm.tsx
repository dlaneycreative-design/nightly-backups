// Self-serve signup form (Dave's order Oct 19 2026): a cold visitor
// creates a REAL account, no hand-vetting queue. Used by the join modal
// and by the /approved page we send invited people to.
// Fields (Dave's final word): display name, username they choose, and
// their Instagram. Account creation is POST /api/v2/profiles; the old
// /signups store still gets a copy as Dave's notification record.
import { useState } from "react";
import type { Profile } from "../lib/api.ts";

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "12px 16px",
  fontSize: 16,
  border: "1px solid #cfd9de",
  borderRadius: 9999,
  marginBottom: 6,
  outline: "none",
  boxSizing: "border-box",
};
const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 14,
  fontWeight: 700,
  margin: "14px 0 6px",
  textAlign: "left",
};
const hintStyle: React.CSSProperties = { fontSize: 13, color: "#536471", margin: "0 0 6px", textAlign: "left" };

export function SignupForm({ apiBase, onCreated }: { apiBase: string; onCreated?: () => void }) {
  const [displayName, setDisplayName] = useState("");
  const [handleRaw, setHandleRaw] = useState("");
  const [instagram, setInstagram] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Profile | null>(null);

  const handle = handleRaw.trim().replace(/^@/, "").toLowerCase();
  const handleValid = /^[a-z0-9_]{3,20}$/.test(handle);
  const handleHint = !handleRaw.trim()
    ? "Pick the name people will know you by."
    : handleValid
      ? `This will be your @${handle}`
      : "3-20 characters: lowercase letters, numbers, or underscores only.";
  const ig = instagram.trim().replace(/^@/, "");
  const canSubmit = !busy && displayName.trim().length > 0 && handleValid && ig.length > 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`${apiBase}/profiles`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ handle, display_name: displayName.trim(), instagram: ig }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(body?.error?.message || "Something went wrong. Try again?");
      }
      const profile = body.profile as Profile;
      // Notification record for Dave (the old /signups store), best effort.
      void fetch(`${apiBase}/signups`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: displayName.trim(), instagram: ig }),
      }).catch(() => {});
      try {
        localStorage.setItem("llama_signup_instagram", ig);
      } catch { /* non-fatal */ }
      setCreated(profile);
      onCreated?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again?");
    } finally {
      setBusy(false);
    }
  };

  if (created) {
    return (
      <div style={{ textAlign: "center" }}>
        <h2 style={{ fontSize: 24, margin: "0 0 8px" }}>You're in! 🎉</h2>
        <p style={{ color: "#536471", margin: "0 0 8px", fontSize: 15 }}>
          Welcome to the honor roll, <b>@{created.handle}</b>. Your account is live.
        </p>
        <p style={{ color: "#536471", margin: "0 0 24px", fontSize: 15 }}>
          Log in with your username. No password needed: your handle is your key for now.
        </p>
        <button
          type="button"
          onClick={() => { window.location.href = `/login?handle=${encodeURIComponent(created.handle)}`; }}
          style={{ width: "100%", padding: "12px", fontSize: 16, fontWeight: 700, background: "#1d9bf0", color: "#fff", border: "none", borderRadius: 9999, cursor: "pointer" }}
        >
          Log in now
        </button>
        <p style={{ fontSize: 13, marginTop: 16 }}>
          <a href={`/${created.handle}`} style={{ color: "#1d9bf0" }}>See my profile</a>
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit}>
      <label style={labelStyle} htmlFor="su-name">Your name</label>
      <input
        id="su-name"
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
        placeholder="e.g. Maria Santos"
        aria-label="Your name"
        autoFocus
        style={inputStyle}
      />
      <label style={labelStyle} htmlFor="su-handle">Choose your username</label>
      <input
        id="su-handle"
        value={handleRaw}
        onChange={(e) => setHandleRaw(e.target.value.toLowerCase())}
        placeholder="@yourname"
        aria-label="Choose your username"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        style={inputStyle}
      />
      <p style={{ ...hintStyle, color: handleRaw.trim() && !handleValid ? "#f4212e" : "#536471" }}>{handleHint}</p>
      <label style={labelStyle} htmlFor="su-ig">Instagram</label>
      <input
        id="su-ig"
        value={instagram}
        onChange={(e) => setInstagram(e.target.value)}
        placeholder="@yourhandle"
        aria-label="Your Instagram handle"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        style={inputStyle}
      />
      <p style={hintStyle}>So we can find you and say hi.</p>
      {error && <p style={{ color: "#f4212e", fontSize: 14, margin: "8px 0" }}>{error}</p>}
      <button
        type="submit"
        disabled={!canSubmit}
        style={{ width: "100%", padding: "12px", fontSize: 16, fontWeight: 700, background: "#1d9bf0", color: "#fff", border: "none", borderRadius: 9999, cursor: "pointer", opacity: canSubmit ? 1 : 0.5, marginTop: 10 }}
      >
        {busy ? "Creating..." : "Create my account"}
      </button>
    </form>
  );
}
