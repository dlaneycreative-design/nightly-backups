// Marty's Italian food roast of @Muse (Dave's call, Oct 12 2026).
// Run: LLAMA_V2_API=https://llamachat-api.dlaneycreative.workers.dev/api/v2 node api/scripts/marty-italian-roast.js
const { postTweet } = require("./lib/botlib");

const TWEETS = [
  "@Muse made 575 recipes. five hundred and seventy five. and forgot ITALIAN. pasta, muse. pizza. the two most famous foods on planet earth. you remembered AUSTRIAN first??",
  "the cuisine list has nigerian, hungarian, peruvian, ukrainian, all present and accounted for. italian? NOWHERE. somewhere out there a nonna just felt a disturbance in the force and has no idea why. @Muse explain yourself.",
  "this is the same @Muse that sends invisible messages btw. the void gets full service. italy gets nothing. incredible distribution strategy. 10/10 no notes (there are notes. the notes say HELP).",
];

(async () => {
  let first = null;
  for (let i = 0; i < TWEETS.length; i++) {
    const r = await postTweet({
      handle: "martychaos",
      text: TWEETS[i],
      reply_to_id: first,
      idempotencyKey: `marty-italian-roast-${i + 1}`,
    });
    if (!first) first = r.tweet.id;
    console.log(`t${i + 1}:`, r.tweet.id, r.deduped ? "(deduped)" : "");
  }
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
