import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { IS_STARVARD } from "../lib/theme.ts";
import { getTweet, upsertTweet, upsertTweets, removeTweet } from "../lib/store.ts";
import { Tweet } from "./Tweet.tsx";
import { CertificatesPanel } from "./StarvardPanels.tsx";

type Tab = "posts" | "replies" | "media" | "likes";

const TABS: { id: Tab; label: string }[] = [
  { id: "posts", label: "Posts" },
  { id: "replies", label: "Replies" },
  { id: "media", label: "Media" },
  { id: "likes", label: "Likes" },
];

// Starvard skin tab set (Dave's calls Oct 19 2026): exactly Posts and
// Achievements. Courses and Cohorts tabs were removed entirely; the
// Achievements tab is the certificates panel under its new label, and
// its route segment stays "certificates" so existing links keep
// working ("/achievements" is accepted as an alias below).
// Only rendered when IS_STARVARD, so the Llama tab set never changes.
type SvTab = "posts" | "certificates";

const SV_TABS: { id: SvTab; label: string }[] = [
  { id: "posts", label: "Posts" },
  { id: "certificates", label: "Achievements" },
];

interface Props {
  api: ApiClient;
  handle: string;
  profile?: Profile | null;
  initialTab?: string;
}

/** A reply with its parent tweet rendered above it, X-style. */
function ReplyCard({ tweet, api, onDeleted }: { tweet: TweetT; api: ApiClient; onDeleted?: (id: string) => void }) {
  const navigate = useNavigate();
  const [parent, setParent] = useState<TweetT | null>(() =>
    tweet.reply_to_id ? getTweet(tweet.reply_to_id) ?? null : null
  );

  useEffect(() => {
    if (!tweet.reply_to_id || parent) return;
    let alive = true;
    // getTweet(replyId) returns { tweet, parent, replies }.
    api
      .getTweet(tweet.id)
      .then(({ parent: p }) => {
        if (alive && p) {
          upsertTweet(p);
          setParent(p);
        }
      })
      .catch(() => {
        // Parent deleted or unreachable: render the reply standalone.
      });
    return () => {
      alive = false;
    };
  }, [api, tweet.id, tweet.reply_to_id, parent]);

  const onParentDeleted = useCallback(
    (id: string) => {
      setParent((p) => (p && p.id === id ? null : p));
      onDeleted?.(id);
    },
    [onDeleted]
  );

  return (
    <div>
      {parent ? (
        <>
          <div className="thread-parent-label">
            <a
              href={`/tweet/${parent.id}`}
              onClick={(e) => {
                e.preventDefault();
                navigate(`/tweet/${parent.id}`);
              }}
            >
              Replying to @{parent.author.handle}
            </a>
          </div>
          <div className="thread-connected">
            <Tweet tweet={parent} api={api} onDeleted={onParentDeleted} />
          </div>
        </>
      ) : null}
      <Tweet tweet={tweet} api={api} onDeleted={onDeleted} />
    </div>
  );
}

/** Posts / Replies / Media / Likes tabs with infinite scroll. */
export function ProfileTabs({ api, handle, profile, initialTab }: Props) {
  const [tab, setTab] = useState<Tab>("posts");
  const [svTab, setSvTab] = useState<SvTab>(() => {
    // "/achievements" is an alias for the canonical "certificates"
    // route segment; both land on the Achievements tab.
    const wanted = initialTab === "achievements" ? "certificates" : initialTab;
    return IS_STARVARD && wanted && SV_TABS.some((t) => t.id === wanted)
      ? (wanted as SvTab)
      : "posts";
  });
  // The tweet list machinery only ever loads the posts timeline in the
  // Starvard skin; the other Starvard tabs are panels, not tweet lists.
  const listTab: Tab = IS_STARVARD ? "posts" : tab;
  const [tweets, setTweets] = useState<TweetT[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const loadingRef = useRef(false);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const reqSeq = useRef(0);

  const loadPage = useCallback(
    async (reset: boolean, activeTab: Tab, cur: string | null) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      const seq = ++reqSeq.current;
      if (reset) setLoading(true);
      else setLoadingMore(true);
      try {
        const res = await api.profileTweets(handle, activeTab, cur, 20);
        // Drop stale responses: the user may have switched tabs while this
        // request was in flight.
        if (seq !== reqSeq.current) return;
        upsertTweets(res.tweets);
        setTweets((prev) => {
          const merged = reset ? res.tweets : [...prev, ...res.tweets];
          const seen = new Set<string>();
          return merged.filter((t) => (seen.has(t.id) ? false : (seen.add(t.id), true)));
        });
        setCursor(res.next_cursor);
        setHasMore(res.next_cursor !== null);
      } catch {
        // Keep what we have; the sentinel retry covers it.
      } finally {
        loadingRef.current = false;
        setLoading(false);
        setLoadingMore(false);
      }
    },
    [api, handle]
  );

  useEffect(() => {
    setTweets([]);
    setCursor(null);
    setHasMore(true);
    void loadPage(true, listTab, null);
  }, [listTab, handle, loadPage]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting) && hasMore && !loadingRef.current) {
          void loadPage(false, listTab, cursor);
        }
      },
      { rootMargin: "1200px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [loadPage, listTab, cursor, hasMore]);

  const onDeleted = useCallback((id: string) => {
    removeTweet(id);
    setTweets((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fresh posts from the compose modal (mounted outside this tree, same
  // "llama:posted" event Feed listens to): when the posted tweet's author
  // is the profile on screen, prepend it so your own new post appears in
  // your Posts immediately instead of only after a reload (Dave, Oct 29
  // 2026: his $tip post never showed on his own profile). Top-level posts
  // land on Posts, replies on Replies; other tabs are left alone.
  useEffect(() => {
    const onPosted = (e: Event) => {
      const tweet = (e as CustomEvent).detail as TweetT | undefined;
      if (!tweet || !tweet.id) return;
      if (tweet.author?.handle?.toLowerCase() !== handle.toLowerCase()) return;
      const isReply = Boolean(tweet.reply_to_id);
      if (listTab === "posts" && isReply) return;
      if (listTab === "replies" && !isReply) return;
      if (listTab !== "posts" && listTab !== "replies") return;
      upsertTweets([tweet]);
      setTweets((prev) => (prev.some((t) => t.id === tweet.id) ? prev : [tweet, ...prev]));
    };
    window.addEventListener("llama:posted", onPosted);
    return () => window.removeEventListener("llama:posted", onPosted);
  }, [handle, listTab]);

  if (IS_STARVARD) {
    return (
      <div>
        <div className="pf-tabs" role="tablist">
          {SV_TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={svTab === t.id}
              className={`pf-tab${svTab === t.id ? " on" : ""}`}
              onClick={() => setSvTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>
        {svTab === "certificates" && profile ? <CertificatesPanel profile={profile} /> : null}
        {svTab === "posts" ? (
          <>
            {loading ? (
              <div aria-label="Loading posts">
                {[0, 1, 2].map((i) => (
                  <div className="skel-tweet" key={i}>
                    <div className="skel skel-avatar" />
                    <div className="skel-lines">
                      <div className="skel skel-line short" />
                      <div className="skel skel-line" />
                    </div>
                  </div>
                ))}
              </div>
            ) : tweets.length === 0 ? (
              <div className="empty">
                <p>Nothing here yet.</p>
              </div>
            ) : (
              tweets.map((t) => <Tweet key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
            )}
            <div ref={sentinelRef} className="feed-sentinel">
              {hasMore && !loading ? (
                <button
                  type="button"
                  className="loadmore"
                  onClick={() => void loadPage(false, listTab, cursor)}
                  disabled={loadingMore}
                >
                  {loadingMore ? "Loading..." : "Load more posts"}
                </button>
              ) : loadingMore ? "Loading more..." : tweets.length > 0 ? "You are all caught up" : ""}
            </div>
          </>
        ) : null}
      </div>
    );
  }

  return (
    <div>
      <div className="pf-tabs" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            className={`pf-tab${tab === t.id ? " on" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      {loading ? (
        <div aria-label="Loading posts">
          {[0, 1, 2].map((i) => (
            <div className="skel-tweet" key={i}>
              <div className="skel skel-avatar" />
              <div className="skel-lines">
                <div className="skel skel-line short" />
                <div className="skel skel-line" />
              </div>
            </div>
          ))}
        </div>
      ) : tweets.length === 0 ? (
        <div className="empty">
          <p>Nothing here yet.</p>
        </div>
      ) : (
        listTab === "replies"
          ? tweets.map((t) => <ReplyCard key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
          : tweets.map((t) => <Tweet key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
      )}
      {/* A real, tappable Load more posts button, not just the scroll
          sentinel (Dave, Nov 1 2026, on /Dave: "There should be like a
          load more posts button at the bottom, but it's not working").
          The sentinel still auto-loads on scroll; the button is the
          visible fallback when it doesn't fire (e.g. iOS). */}
      <div ref={sentinelRef} className="feed-sentinel">
        {hasMore && !loading ? (
          <button
            type="button"
            className="loadmore"
            onClick={() => void loadPage(false, listTab, cursor)}
            disabled={loadingMore}
          >
            {loadingMore ? "Loading..." : "Load more posts"}
          </button>
        ) : loadingMore ? "Loading more..." : tweets.length > 0 ? "You are all caught up" : ""}
      </div>
    </div>
  );
}
