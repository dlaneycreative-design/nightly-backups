// Caller identity: localStorage "llama_user_id" sent as the x-llama-user
// header. Dev default: look up the seeded Dave profile once and cache it;
// until then the app works read-only (public reads need no auth).
import type { ApiClient, Profile } from "./api.ts";

const KEY = "llama_user_id";
const HANDLE_KEY = "llama_user_handle";
const AUTH_TOKEN_KEY = "llama_auth_token";

type StorageLike = {
  getItem: (k: string) => string | null;
  setItem: (k: string, v: string) => void;
  removeItem: (k: string) => void;
};

function memStorage(): StorageLike {
  const m = new Map<string, string>();
  return {
    getItem: (k) => (m.has(k) ? m.get(k)! : null),
    setItem: (k, v) => {
      m.set(k, v);
    },
    removeItem: (k) => {
      m.delete(k);
    },
  };
}

let backing: StorageLike | null = null;
function storage(): StorageLike {
  if (!backing) {
    try {
      backing = typeof localStorage !== "undefined" ? localStorage : memStorage();
    } catch {
      backing = memStorage();
    }
  }
  return backing;
}

/** For tests: swap the backing store. */
export function _setStorage(s: StorageLike): void {
  backing = s;
}

export function getCallerId(): string | null {
  try {
    return storage().getItem(KEY);
  } catch {
    return null;
  }
}

export function setCallerId(id: string, handle?: string): void {
  try {
    storage().setItem(KEY, id);
    if (handle) storage().setItem(HANDLE_KEY, handle);
  } catch {
    /* non-fatal */
  }
}

export function getCallerHandle(): string | null {
  try {
    return storage().getItem(HANDLE_KEY);
  } catch {
    return null;
  }
}

export function getAuthToken(): string | null {
  try {
    return storage().getItem(AUTH_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string | null): void {
  try {
    if (token) storage().setItem(AUTH_TOKEN_KEY, token);
    else storage().removeItem(AUTH_TOKEN_KEY);
  } catch {
    /* non-fatal */
  }
}

export function clearCallerId(): void {
  cachedProfile = null;
  try {
    storage().removeItem(KEY);
    storage().removeItem(HANDLE_KEY);
    storage().removeItem(AUTH_TOKEN_KEY);
  } catch {
    /* non-fatal */
  }
}

/**
 * Session restore: if a caller id is stored (user logged in before),
 * fetch their profile. Otherwise stay logged out.
 * Dave's call Oct 9 2026: new visitors start LOGGED OUT. No more
 * auto-login as Dave. The app works read-only until they log in.
 */
let cachedProfile: Profile | null = null;

function isAuthError(e: unknown): boolean {
  const status = (e as { status?: unknown } | null)?.status;
  return status === 401 || status === 403;
}

/**
 * Discord login return: e2-auth redirects back with the token in the
 * URL hash ("#t=<token>"). Store it, scrub the hash from the address
 * bar (preserving the path and query), then resolve the token to a
 * LlamaChat profile via /auth/me and sign in as that profile.
 * Returns the profile on success, null when there is no token in the
 * hash or the token does not validate.
 */
export async function captureDiscordLogin(api: ApiClient): Promise<Profile | null> {
  let hash = "";
  try {
    hash = typeof window !== "undefined" ? window.location.hash : "";
  } catch {
    return null;
  }
  if (!hash.startsWith("#t=")) return null;
  const token = decodeURIComponent(hash.slice("#t=".length)).trim();
  // Clean the URL either way so the token never lingers in the bar,
  // history, or a copied link.
  try {
    const { pathname, search } = window.location;
    window.history.replaceState(null, "", `${pathname}${search}`);
  } catch {
    /* non-fatal */
  }
  if (!token) return null;
  setAuthToken(token);
  try {
    const { profile } = await api.authMe();
    if (!profile?.id) throw new Error("auth/me returned no profile");
    setCallerId(profile.id, profile.handle);
    cachedProfile = profile;
    return profile;
  } catch {
    setAuthToken(null);
    return null;
  }
}

export async function ensureDevSession(api: ApiClient): Promise<Profile | null> {
  if (cachedProfile) return cachedProfile;
  // Discord-backed session: a stored e2-auth token is the source of
  // truth. Validate it and refresh the cached profile and stored
  // caller id/handle from whatever the server returns.
  if (getAuthToken()) {
    try {
      const { profile } = await api.authMe();
      if (profile?.id) {
        setCallerId(profile.id, profile.handle);
        cachedProfile = profile;
        return profile;
      }
      // No usable profile came back: drop the Discord session.
      clearCallerId();
      return null;
    } catch (e) {
      if (isAuthError(e)) {
        clearCallerId();
        return null;
      }
      // Transient failure (offline, 5xx): fall through to the legacy
      // stored-id path below rather than signing the user out.
    }
  }
  const existing = getCallerId();
  if (!existing) return null; // logged out: stay logged out
  // ID is known (user logged in). Fetch the profile by stored handle
  // so `me` is populated correctly after a fresh page load.
  const handle = getCallerHandle();
  if (handle) {
    try {
      const { profile } = await api.profile(handle);
      if (profile?.id) {
        cachedProfile = profile;
        return profile;
      }
    } catch {
      /* fall through */
    }
  }
  return null;
}
