// Bot 2: Server status bot ("Server Steve").
// Watches the V2 API and the main site. Tweets when things go down and
// when they come back. Personality: vulgar, blunt, funny. Not hateful,
// just a grumpy sysadmin who swears at servers.
//
// State: /tmp/server-steve-state.json (last known status per check).
//   { "v2api": {"up": true, "since": 123}, "site": {...} }
// Run every 5 min via cron. Only tweets on TRANSITIONS (up->down, down->up),
// never on steady state, so it stays quiet when things are fine.
//
// TIMESTAMP LAW: API server-stamps created_at.
// Idempotent: deterministic UUID per transition event.
//
// Usage: node api/scripts/server-status-bot.js
//   Needs DATABASE_URL (to ensure the profile exists).
//   LLAMA_V2_API env overrides the default API URL.
const fs = require("fs");
const crypto = require("crypto");
const { postTweet, detUuid } = require("./lib/botlib");
// Neon HTTP driver: the VM cannot do direct Postgres SSL, so profile
// creation goes over Neon's HTTPS API instead of the pg wire protocol.
const { neon } = require("@neondatabase/serverless");
const _neonSql = neon(process.env.DATABASE_URL);
async function query(text, params) {
  return _neonSql.query(text, params);
}
const pool = { end: async () => {} };

const STATE_FILE = "/tmp/server-steve-state.json";
const V2_API = process.env.LLAMA_V2_API || "https://llamachat-v2-q0xugwbpe-the-studio3.vercel.app/api/v2";

const CHECKS = [
  { name: "v2api", url: `${V2_API}/health`, label: "LlamaChat V2 API" },
  { name: "site", url: "https://www.thestudio.io/", label: "thestudio.io" },
  { name: "e2", url: "https://e2planet.com/", label: "E2 Planet" },
];

const DOWN_TWEETS = [
  (l) => `oh shit, ${l} just went down. somebody kick it.`,
  (l) => `welp. ${l} is down. this is fine. everything is fine.`,
  (l) => `fuck. ${l} just shit the bed. looking into it.`,
  (l) => `${l} down. i swear to god if it's DNS again...`,
  (l) => `aaaaand ${l} is gone. pour one out. fixing it.`,
];
const UP_TWEETS = [
  (l) => `we're back, bitches. ${l} is up.`,
  (l) => `${l} is alive again. you're welcome.`,
  (l) => `ok ${l} is back up. turns out it just needed a nap.`,
  (l) => `${l} recovered. i fixed it by staring at it menacingly.`,
];

function pick(arr, salt) {
  const h = parseInt(crypto.createHash("sha1").update(salt).digest("hex").slice(0, 8), 16);
  return arr[h % arr.length];
}

async function checkUrl(url) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch(url, { signal: ctrl.signal, redirect: "follow" });
    clearTimeout(t);
    return res.status < 500;
  } catch {
    return false;
  }
}

async function ensureProfile() {
  // Direct DB: no public profile-create endpoint.
  // Note: detUuid("llamachat-v2:profile","serversteve") collides with an
  // existing profile id, so use a random UUID with ON CONFLICT (handle).
  const now = Date.now();
  await query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(),'serversteve','Server Steve',NULL,'I watch the servers. When they die, you will hear about it.',NULL,NULL,$1,$1)
     ON CONFLICT (handle) DO NOTHING`,
    [now]
  );
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return {}; }
}
function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s)); }

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required (to ensure the bot profile exists)");
  await ensureProfile();
  const state = loadState();
  let changed = false;

  for (const c of CHECKS) {
    const up = await checkUrl(c.url);
    const prev = state[c.name];
    const wasUp = prev ? prev.up : true; // assume up on first run (no false alarm)
    state[c.name] = { up, since: wasUp === up && prev ? prev.since : Date.now() };
    if (wasUp !== up) {
      changed = true;
      const salt = `${c.name}:${up ? "up" : "down"}:${Date.now()}`;
      const text = up ? pick(UP_TWEETS, salt)(c.label) : pick(DOWN_TWEETS, salt)(c.label);
      try {
        const { deduped } = await postTweet({
          handle: "serversteve",
          text,
          idempotencyKey: `serversteve:${c.name}:${up ? "up" : "down"}:${state[c.name].since}`,
        });
        console.log(`[server-steve] ${c.name} ${wasUp ? "UP->DOWN" : "DOWN->UP"}: ${deduped ? "deduped" : "tweeted"}`);
      } catch (e) {
        console.error(`[server-steve] tweet failed for ${c.name}: ${e.message}`);
      }
    } else {
      console.log(`[server-steve] ${c.name}: still ${up ? "up" : "down"}, quiet`);
    }
  }
  saveState(state);
  if (!changed) console.log("[server-steve] no transitions, stayed quiet");
  await pool.end();
}

main().catch((e) => { console.error("[server-steve] fatal", e.message); process.exit(1); });
