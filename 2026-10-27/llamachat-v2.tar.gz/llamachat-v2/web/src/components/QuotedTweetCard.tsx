// The embedded card for a quoted tweet (X pattern). Two variants:
//   compact — inside timelines: author row, text, small media thumb.
//   full    — inside the quote composer: author row, full text, media
//             shown large, with a remove (x) control.
// Clicking the compact card opens the original tweet's thread; clicks
// on links inside its text route through the SPA like normal tweets.
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import type { Tweet as TweetT } from "../lib/api.ts";
import { tweetTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { sanitizeTweetHtml } from "../lib/sanitize.ts";
import { getProfileById } from "../lib/store.ts";

interface Props {
  tweet: TweetT;
  variant?: "compact" | "full";
  now?: number;
  /** Composer only: detach the quote (the post then sends as normal). */
  onRemove?: () => void;
}

export function QuotedTweetCard({ tweet, variant = "compact", now, onRemove }: Props) {
  const navigate = useNavigate();
  const [imgFailed, setImgFailed] = useState(false);
  const full = variant === "full";

  // Prefer the store's live profile for the author, like Tweet.tsx does:
  // the embedded snapshot goes stale when the author edits their profile.
  const live = getProfileById(tweet.author.id);
  const name = live?.display_name ?? tweet.author.display_name;
  const handle = live?.handle ?? tweet.author.handle;
  const avatarSrc = resolveImageUrl(live ? live.avatar_url : tweet.author.avatar_url);
  const imgSrc = tweet.image_url ? resolveImageUrl(tweet.image_url) || tweet.image_url : null;

  const openThread = () => {
    if (full) return;
    navigate(`/tweet/${tweet.id}`);
  };

  // #tag / @mention links inside the quoted text route via the SPA
  // instead of opening the thread (same rule as Tweet.tsx's body).
  const onTextClick = (e: React.MouseEvent) => {
    const a = (e.target as HTMLElement).closest("a");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (href.startsWith("/hashtag/") || href.startsWith("/profile/")) {
      e.preventDefault();
      e.stopPropagation();
      navigate(href);
    }
  };

  return (
    <div
      className={`quoted-card${full ? " full" : ""}`}
      onClick={(e) => {
        e.stopPropagation();
        openThread();
      }}
      role={full ? undefined : "link"}
      aria-label={full ? undefined : `Quoted post by ${name}`}
    >
      {onRemove ? (
        <button
          type="button"
          className="quoted-card-remove"
          aria-label="Remove quoted post"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
        </button>
      ) : null}
      <div className="quoted-card-head">
        {avatarSrc ? (
          <img className="avatar quoted-avatar" src={avatarSrc} alt="" loading="lazy" decoding="async" />
        ) : (
          <div className="avatar avatar-fallback quoted-avatar" aria-hidden="true">
            {(name || "?").slice(0, 1).toUpperCase()}
          </div>
        )}
        <span className="quoted-card-name">{name}</span>
        <span className="quoted-card-meta">
          @{handle} · {tweetTime(tweet, now ?? Date.now())}
        </span>
      </div>
      {tweet.html ? (
        <div
          className="quoted-card-text"
          onClick={onTextClick}
          dangerouslySetInnerHTML={{ __html: sanitizeTweetHtml(tweet.html) }}
        />
      ) : tweet.text ? (
        <p className="quoted-card-text">{tweet.text}</p>
      ) : null}
      {imgSrc && !imgFailed ? (
        <img
          className="quoted-card-img"
          src={imgSrc}
          alt="Quoted post image"
          loading="lazy"
          decoding="async"
          onError={() => setImgFailed(true)}
        />
      ) : null}
    </div>
  );
}

/** quote_of_id is set but the original is gone (deleted before read). */
export function QuotedUnavailableCard() {
  return <div className="quoted-unavailable">This post is unavailable.</div>;
}
