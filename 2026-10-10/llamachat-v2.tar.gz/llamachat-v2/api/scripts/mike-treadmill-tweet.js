const { postTweet } = require("./lib/botlib");

const MIKE_TEXT = "Been going 18-hour days shipping. Gotta move to keep shipping. 6am club, treadmill, no excuses. Taking a break from working so hard starts with working hard at the break. Let's go.";

const MARTY_TEXT = "bro is running BACKWARDS on the treadmill. mike. MIKE. the belt goes the other way. this is what no sleep does to a man";

(async () => {
  const mikeHandle = String.fromCharCode(109, 105, 107, 101); // mike
  const martyHandle = String.fromCharCode(109, 97, 114, 116, 121, 99, 104, 97, 111, 115); // marty

  const { tweet: mikeTweet, deduped: mikeDeduped } = await postTweet({
    handle: mikeHandle,
    text: MIKE_TEXT,
    image_url: "https://www.thestudio.io/mike/assets/mike-gym-cardio-break.webp",
    idempotencyKey: "mike:treadmill-earnest-1",
  });
  console.log(mikeDeduped ? "deduped" : "posted", "mike tweet:", mikeTweet.id);

  await new Promise(r => setTimeout(r, 2000));

  const { tweet: martyTweet, deduped: martyDeduped } = await postTweet({
    handle: martyHandle,
    text: MARTY_TEXT,
    reply_to_id: mikeTweet.id,
    idempotencyKey: "marty:treadmill-roast-1",
  });
  console.log(martyDeduped ? "deduped" : "posted", "marty reply:", martyTweet.id);

  console.log("TWEET_URL=https://llamachat.io/tweet/" + mikeTweet.id);
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
