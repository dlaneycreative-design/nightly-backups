// Read-only inventory: every DB tweet/profile field containing thestudio.io,
// plus the latest top-level tweets (what a seed regen would produce).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const hits = await sql`
  SELECT t.id, p.handle, t.created_at, t.reply_to_id, t.text, t.html
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE t.text ILIKE '%thestudio.io%' OR t.html ILIKE '%thestudio.io%'
  ORDER BY t.created_at`;
console.log(`TWEETS WITH thestudio.io: ${hits.length}`);
for (const r of hits) {
  console.log('---');
  console.log('id:', r.id, '| author:', r.handle, '| created_at:', r.created_at, '| reply_to:', r.reply_to_id);
  console.log('text:', r.text);
  console.log('html:', r.html);
}

const profs = await sql`
  SELECT handle, bio, link FROM profiles
  WHERE bio ILIKE '%thestudio.io%' OR link ILIKE '%thestudio.io%' OR avatar_url ILIKE '%thestudio.io%'`;
console.log(`\nPROFILES WITH thestudio.io (bio/link/avatar): ${profs.length}`);
for (const r of profs) console.log(r.handle, '| bio:', r.bio, '| link:', r.link);

const latest = await sql`
  SELECT t.id, p.handle, t.created_at, left(t.text, 70) AS text
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE t.reply_to_id IS NULL
  ORDER BY t.created_at DESC, t.id DESC
  LIMIT 14`;
console.log('\nLATEST 14 TOP-LEVEL TWEETS:');
for (const r of latest) console.log(r.created_at, r.handle, '|', (r.text || '').replace(/\n/g, ' '));
console.log('\nINVENTORY DONE');
