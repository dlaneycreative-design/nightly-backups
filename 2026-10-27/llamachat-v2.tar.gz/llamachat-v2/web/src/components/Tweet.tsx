import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import { tweetTime, absTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { TweetImage } from "./TweetImage.tsx";
import { getCallerId } from "../lib/session.ts";
import { openReplyModal } from "../lib/replyModal.ts";
import { openQuoteComposer } from "../lib/composeModal.ts";
import { QuotedTweetCard, QuotedUnavailableCard } from "./QuotedTweetCard.tsx";
import { sanitizeTweetHtml } from "../lib/sanitize.ts";
import { isPendingTweet, type TweetLike } from "../lib/tweetView.ts";
import { getProfileById } from "../lib/store.ts";

/** A tweet still waiting on the server. Renders "sending...", never a time. */
export type { PendingViewTweet, TweetLike } from "../lib/tweetView.ts";

/** Re-render on a slow tick so "5s" becomes "6s" without new data. */
function useNow(intervalMs = 30_000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function Avatar({ name, url }: { name: string; url: string | null }) {
  const src = resolveImageUrl(url);
  if (src) {
    return <img className="avatar" src={src} alt={`${name}'s avatar`} loading="lazy" decoding="async" />;
  }
  const initial = (name || "?").slice(0, 1).toUpperCase();
  return (
    <div className="avatar avatar-fallback" aria-hidden="true">
      {initial}
    </div>
  );
}

interface Props {
  tweet: TweetLike;
  api: ApiClient;
  onDeleted?: (id: string) => void;
  detail?: boolean;
  onReplyOverride?: (tweet: TweetT) => void;
}

/** Like toggle: optimistic UI, persists via /api/v2/likes. Reverts on failure. */
function LikeToggle({ tweetId, initial, initialLiked, api }: {
  tweetId: string;
  initial: number;
  initialLiked: boolean;
  api: ApiClient;
}) {
  const [on, setOn] = useState(initialLiked);
  const [count, setCount] = useState(initial);
  const busy = useRef(false);
  const toggle = async () => {
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.like(tweetId) : await api.unlike(tweetId);
      if (r.tweet) {
        setOn(r.tweet.liked);
        setCount(r.tweet.likes_count);
      }
    } catch {
      // Not signed in or network failed: revert the optimistic toggle.
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };
  return (
    <button
      type="button"
      className={`act like${on ? " on" : ""}`}
      aria-label={`${count} likes`}
      onClick={toggle}
    >
      <span className="ic">
        <svg viewBox="0 0 24 24" fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
      </span>
      <span className="n">{count > 0 ? count : null}</span>
    </button>
  );
}

/**
 * Repost button, X pattern: tapping it opens a small menu with two
 * rows — "Repost" (or "Undo repost" when already reposted) and
 * "Quote". Reposting itself is the same optimistic toggle as before,
 * persisted via /api/v2/reposts and reverted on failure. Quote opens
 * the compose modal with this tweet attached (lib/composeModal).
 */
function RepostMenu({ tweet, api }: { tweet: TweetT; api: ApiClient }) {
  const tweetId = tweet.id;
  const [on, setOn] = useState(!!tweet.reposted);
  const [count, setCount] = useState(tweet.reposts_count);
  const [menuOpen, setMenuOpen] = useState(false);
  const busy = useRef(false);

  // Close the menu on Escape (backdrop click also closes), mirroring
  // the TweetMenu pattern so no stuck overlay can block clicks.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const toggle = async () => {
    setMenuOpen(false);
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.repost(tweetId) : await api.unrepost(tweetId);
      if (r.tweet) {
        setOn(r.tweet.reposted);
        setCount(r.tweet.reposts_count);
      }
    } catch {
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };

  const quote = () => {
    setMenuOpen(false);
    openQuoteComposer(tweet);
  };

  return (
    <span className="rt-wrap">
      <button
        type="button"
        className={`act rt${on ? " on" : ""}`}
        aria-label={`${count} reposts`}
        aria-haspopup="menu"
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen((o) => !o)}
      >
        <span className="ic">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
        </span>
        <span className="n">{count > 0 ? count : null}</span>
      </button>
      {menuOpen ? (
        <>
          <button type="button" className="tw-menu-backdrop" aria-label="Close menu" onClick={() => setMenuOpen(false)} style={{ border: "none", padding: 0, background: "transparent" }} />
          <div className="tw-menu rt-menu" role="menu" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="tw-menu-item rt-menu-item" role="menuitem" aria-label={on ? "Undo repost" : "Repost"} onClick={() => void toggle()}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
              <span>{on ? "Undo repost" : "Repost"}</span>
            </button>
            <button type="button" className="tw-menu-item rt-menu-item" role="menuitem" aria-label="Quote post" onClick={quote}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
              <span>Quote</span>
            </button>
          </div>
        </>
      ) : null}
    </span>
  );
}

/**
 * Tweet card. THE timestamp path: tweetTime() only. Invalid stamps render
 * nothing; pending tweets render "sending...". No ad-hoc date formatting.
 */
interface TweetView {
  key: string;
  name: string;
  handle: string;
  avatar: string | null;
  time: string;
  text: string;
  html: string | null;
  image_url: string | null;
  quote_of_id: string | null;
  quoted_tweet: TweetT | null;
  replies_count: number;
  likes_count: number;
  real: TweetT | null;
}

/** Normalize the TweetLike union into one view model for rendering. */
function toTweetView(tweet: TweetLike, now: number): TweetView {
  // The timestamp ALWAYS goes through tweetTime(): pending -> "sending...",
  // invalid -> "".
  if (isPendingTweet(tweet)) {
    return {
      key: tweet.tempId,
      name: tweet.author.display_name,
      handle: tweet.author.handle,
      avatar: tweet.author.avatar_url,
      time: tweetTime({ pending: true }, now),
      text: tweet.text,
      html: null,
      image_url: tweet.image_url,
      quote_of_id: tweet.quote_of_id,
      quoted_tweet: tweet.quoted_tweet,
      replies_count: 0,
      likes_count: 0,
      real: null,
    };
  }
  // Prefer the store's current profile for the author: the snapshot
  // embedded in the tweet goes stale when the author edits their
  // profile (e.g. saves a new avatar), while the store copy is kept
  // fresh by the edit flow and profile fetches.
  const liveAuthor = getProfileById(tweet.author.id);
  return {
    key: tweet.id,
    name: liveAuthor?.display_name ?? tweet.author.display_name,
    handle: liveAuthor?.handle ?? tweet.author.handle,
    avatar: liveAuthor ? liveAuthor.avatar_url : tweet.author.avatar_url,
    time: tweetTime(tweet, now),
    text: tweet.text,
    html: tweet.html,
    image_url: tweet.image_url,
    quote_of_id: tweet.quote_of_id ?? null,
    quoted_tweet: tweet.quoted_tweet ?? null,
    replies_count: tweet.replies_count,
    likes_count: tweet.likes_count,
    real: tweet as TweetT,
  };
}

/** Options (⋯) menu for a real tweet: delete (own tweets) + share. */
function TweetMenu({
  mine,
  deleting,
  onDelete,
  onShare,
}: {
  mine: boolean;
  deleting: boolean;
  onDelete: (e: React.MouseEvent) => void;
  onShare: (e: React.MouseEvent) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  // Close the options menu on Escape; without this a stuck backdrop can
  // block all clicks until reload.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  return (
    <div className="tw-menu-wrap">
      <button
        type="button"
        className="tw-menu-btn"
        aria-label="More options"
        onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}
      >
        <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>
      </button>
      {menuOpen ? (
        <>
          <button type="button" className="tw-menu-backdrop" aria-label="Close menu" onClick={(e) => { e.stopPropagation(); setMenuOpen(false); }} style={{ border: "none", padding: 0, background: "transparent" }} />
          <div className="tw-menu" onClick={(e) => e.stopPropagation()}>
            {mine ? (
              <button type="button" className="tw-menu-item danger" onClick={onDelete} disabled={deleting}>
                {deleting ? "Deleting..." : "Delete post"}
              </button>
            ) : null}
            <button type="button" className="tw-menu-item" onClick={(e) => { setMenuOpen(false); onShare(e); }}>
              Share post
            </button>
          </div>
        </>
      ) : null}
    </div>
  );
}

export function Tweet({ tweet, api, onDeleted, detail = false, onReplyOverride }: Props) {
  const navigate = useNavigate();
  const now = useNow();
  const [deleting, setDeleting] = useState(false);
  const [shared, setShared] = useState(false);

  const pending = isPendingTweet(tweet);
  const view = toTweetView(tweet, now);
  const mine = view.real !== null && view.real.author.id === getCallerId();

  // X-style repost attribution ("Name reposted", "You reposted" for the
  // viewer): only on timeline entries that exist because of a repost.
  // Prefer the store's live profile for the reposter, like the author.
  const repostedBy = view.real?.reposted_by ?? null;
  const reposterProfile = repostedBy ? getProfileById(repostedBy.id) : undefined;
  const reposterHandle = reposterProfile?.handle ?? repostedBy?.handle ?? "";
  const reposterLabel = repostedBy
    ? repostedBy.id === getCallerId()
      ? "You"
      : (reposterProfile?.display_name ?? repostedBy.display_name)
    : null;

  // Server-rendered html already linkifies #tags and @mentions; route
  // those through the SPA instead of a full page load.
  const onBodyClick = (e: React.MouseEvent) => {
    const a = (e.target as HTMLElement).closest("a");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (href.startsWith("/hashtag/") || href.startsWith("/profile/")) {
      e.preventDefault();
      e.stopPropagation();
      navigate(href);
    }
  };

  const openThread = () => {
    if (view.real) navigate(`/tweet/${view.real.id}`);
  };

  // X behavior: the reply icon opens the reply modal, not the thread.
  const onReply = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    if (onReplyOverride) {
      onReplyOverride(view.real);
    } else {
      openReplyModal(view.real);
    }
  };

  const onDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real || deleting) return;
    if (!window.confirm("Delete this post?")) return;
    setDeleting(true);
    try {
      await api.deleteTweet(view.real.id);
      onDeleted?.(view.real.id);
    } catch {
      setDeleting(false);
    }
  };

  const onShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    const url = `${window.location.origin}/tweet/${view.real.id}`;
    const text = `${view.name} (@${view.handle}): ${view.text}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "LlamaChat post", text, url });
      } else {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      }
    } catch {
      // user cancelled share or clipboard failed; try clipboard as fallback
      try {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch { /* ignore */ }
    }
  };

  return (
    <article
      className={`tweet${pending ? " pending" : ""}`}
      onClick={openThread}
      aria-label={pending ? "Sending post" : `Post by ${view.name}`}
    >
      <a
        className="avatar-link"
        href={`/profile/${view.handle}`}
        onClick={(e) => {
          e.stopPropagation();
          navigate(`/profile/${view.handle}`);
        }}
      >
        <Avatar name={view.name} url={view.avatar} />
      </a>
      <div className="tweet-body">
        {repostedBy ? (
          <a
            className="tweet-repost-note"
            href={`/profile/${reposterHandle}`}
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/profile/${reposterHandle}`);
            }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
            <span>{reposterLabel} reposted</span>
          </a>
        ) : null}
        <div className="tweet-head">
          <a
            className="name"
            href={`/profile/${view.handle}`}
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/profile/${view.handle}`);
            }}
          >
            {view.name}
          </a>
          <span className="meta">
            <a
              className="tw-handle"
              href={`/profile/${view.handle}`}
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/profile/${view.handle}`);
              }}
            >
              @{view.handle}
            </a>
            {" · "}
            {view.real ? (
              <a
                className="tw-time"
                href={`/tweet/${view.real.id}`}
                title="View tweet"
                onClick={(e) => {
                  e.stopPropagation();
                  openThread();
                }}
              >
                {view.time}
              </a>
            ) : (
              <span className="tw-time sending">{view.time}</span>
            )}
          </span>
          {view.real ? (
            <TweetMenu mine={mine} deleting={deleting} onDelete={onDelete} onShare={onShare} />
          ) : null}
        </div>
        {view.html ? (
          <div className="tweet-text" onClick={onBodyClick} dangerouslySetInnerHTML={{ __html: sanitizeTweetHtml(view.html) }} />
        ) : view.text ? (
          <p className="tweet-text">{view.text}</p>
        ) : null}
        {/* X order: own text, quoted card, own image, actions. A bare
            quote has no text of its own; a deleted original renders the
            unavailable card (quote_of_id set, quoted_tweet null). */}
        {view.quote_of_id ? (
          view.quoted_tweet ? (
            <QuotedTweetCard tweet={view.quoted_tweet} now={now} />
          ) : (
            <QuotedUnavailableCard />
          )
        ) : null}
        {view.image_url ? <TweetImage imageUrl={view.image_url} /> : null}
        {detail && view.real ? (
          <div className="tw-detail-time">{absTime(view.real.created_at)}</div>
        ) : null}
        {view.real && (
          <TweetActions
            view={view}
            api={api}
            detail={detail}
            mine={mine}
            deleting={deleting}
            shared={shared}
            onReply={onReply}
            onShare={onShare}
            onDelete={onDelete}
          />
        )}
      </div>
    </article>
  );
}

/** Reply / repost / like / views / share action row under a tweet. */
function TweetActions({
  view,
  api,
  detail,
  mine,
  deleting,
  shared,
  onReply,
  onShare,
  onDelete,
}: {
  view: TweetView;
  api: ApiClient;
  detail: boolean;
  mine: boolean;
  deleting: boolean;
  shared: boolean;
  onReply: (e: React.MouseEvent) => void;
  onShare: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
}) {
  if (!view.real) return null;
  const real = view.real;
  return (
    <div className="tweet-actions" onClick={(e) => e.stopPropagation()}>
      <button type="button" className="act reply" aria-label={`${view.replies_count} replies`} onClick={onReply}>
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-3-.4-4.2-1.1L3 20l1.1-5.3A8.5 8.5 0 1 1 21 11.5z"/></svg></span>
        <span className="n">{view.replies_count > 0 ? view.replies_count : null}</span>
      </button>
      <RepostMenu tweet={real} api={api} />
      <LikeToggle tweetId={real.id} initial={view.likes_count} initialLiked={!!real.liked} api={api} />
      <span className="act views" aria-label="Views">
        <span className="ic"><svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="10" width="3.5" height="10" rx="1"/><rect x="8" y="4" width="3.5" height="16" rx="1"/><rect x="13" y="12" width="3.5" height="8" rx="1"/><rect x="18" y="7" width="3.5" height="13" rx="1"/></svg></span>
      </span>
      <button type="button" className={`act share${shared ? " on" : ""}`} aria-label="Share post" onClick={onShare} title={shared ? "Link copied!" : "Share"}>
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12"/><path d="M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 002 2h10a2 2 0 002-2v-6"/></svg></span>
      </button>
      <a href={`https://e2-prod.pages.dev/songify/?url=${encodeURIComponent(`https://llamachat.lol/tweet/${real.id}`)}`} target="_blank" rel="noopener" className="act songify" aria-label="Songify this tweet" title="Songify">
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span>
      </a>
      {detail && mine ? (
        <button type="button" className="act ghost-act" onClick={onDelete} disabled={deleting}>
          {deleting ? "Deleting..." : "Delete"}
        </button>
      ) : null}
    </div>
  );
}
