// Dave's profile upgrade (his call Oct 16 2026): personal night-sky banner,
// new bio, and achievement chips (Style 1) that link to the Starvard class
// each one celebrates. Harsh gets the shared First Film chip too.
// Applies migration 006's schema via the neon driver (the pg pool cannot
// reach Neon from this VM) and records it in schema_migrations so the
// regular migrate.js stays consistent. Idempotent.
const { neon } = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);

const DAVE_ACH = [
  { icon: "🎹", label: "99-Day Piano Streak", sub: "99 days in a row", url: "https://starvard.org/learnpiano/" },
  { icon: "🎤", label: "25 Stand-Up Sets", sub: "sets performed live", url: "https://starvard.org/comedy101/" },
  { icon: "🇪🇸", label: "Spanish Level 6", sub: "course complete", url: "https://starvard.org/learnspanish/" },
  { icon: "🎬", label: "First Film", sub: "completed with Harsh", url: "https://starvard.org/learnvideo/" },
];
const HARSH_ACH = [
  { icon: "🎬", label: "First Film", sub: "completed with Dave", url: "https://starvard.org/learnvideo/" },
];

(async () => {
  // --- schema (migration 006) ---
  await sql.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at BIGINT NOT NULL)`);
  const done = await sql.query(`SELECT name FROM schema_migrations WHERE name = '006_profile_banner_achievements.sql'`);
  if (!done.length) {
    await sql.query(`ALTER TABLE profiles ADD COLUMN IF NOT EXISTS banner_url TEXT`);
    await sql.query(`ALTER TABLE profiles ADD COLUMN IF NOT EXISTS achievements JSONB`);
    await sql.query(`INSERT INTO schema_migrations (name, applied_at) VALUES ('006_profile_banner_achievements.sql', $1)`, [Date.now()]);
    console.log("migration 006 applied");
  } else {
    console.log("migration 006 already recorded");
  }

  // --- Dave ---
  const dave = await sql.query(
    `UPDATE profiles SET bio = $1, banner_url = $2, achievements = $3::jsonb, updated_at = $4 WHERE handle = 'dave' RETURNING handle, bio, banner_url, achievements`,
    ["I love building stuff and learning about stuff.", "/assets/banners/dave-nightsky.webp", JSON.stringify(DAVE_ACH), Date.now()]
  );
  console.log("DAVE:", JSON.stringify(dave[0], null, 1));

  // --- Harsh ---
  const harsh = await sql.query(
    `UPDATE profiles SET achievements = $1::jsonb, updated_at = $2 WHERE handle = 'harsh' RETURNING handle, achievements`,
    [JSON.stringify(HARSH_ACH), Date.now()]
  );
  console.log("HARSH:", JSON.stringify(harsh[0], null, 1));
})().catch((e) => { console.error("ERR", e.message); process.exit(1); });
