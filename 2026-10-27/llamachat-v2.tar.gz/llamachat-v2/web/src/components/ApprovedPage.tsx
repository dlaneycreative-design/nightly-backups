// /approved: the link we hand to invited people (Dave's order Oct 19
// 2026). "We invite a person, send them to llamachat.lol/approved, and
// there they claim their account." Same self-serve form as the join
// modal, on its own page so the link works cold from any message app.
import { useState } from "react";
import type { Profile } from "../lib/api.ts";
import { SignupForm } from "./SignupForm.tsx";
import { HOME_URL, IS_STARVARD, SITE_NAME } from "../lib/theme.ts";
import { clearCallerId } from "../lib/session.ts";
import { clearStore } from "../lib/store.ts";

const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "/api/v2";

export function ApprovedPage({ me }: { me: Profile | null }) {
  const [created, setCreated] = useState(false);
  return (
    <div style={{ maxWidth: 420, margin: "48px auto", padding: "0 20px" }}>
      {!created ? (
        <>
          <h1 style={{ fontSize: 28, margin: "0 0 8px", textAlign: "center" }}>Welcome to {SITE_NAME}{IS_STARVARD ? "" : " 🦙"}</h1>
          <p style={{ color: "#536471", margin: "0 0 8px", fontSize: 15, textAlign: "center" }}>
            You were invited. Claim your account below and you are in: pick your username, add your name and Instagram, done.
          </p>
        </>
      ) : null}
      {me && !created ? (
        // Clear logged-in notice (Dave's call Oct 20 2026): the old faint
        // one-line note was easy to miss, so a logged-in visitor could not
        // tell why a signup form was in front of them. Now it is a card
        // with their face, the plain fact, and the two ways out.
        <div style={{ display: "flex", gap: 12, alignItems: "center", background: "#f7f9f9", border: "1px solid #e3e8ea", borderRadius: 16, padding: "12px 14px", margin: "14px 0 18px", textAlign: "left" }}>
          {me.avatar_url ? (
            <img src={me.avatar_url} alt="" style={{ width: 42, height: 42, borderRadius: "50%", objectFit: "cover", flex: "none" }} />
          ) : (
            <span style={{ width: 42, height: 42, borderRadius: "50%", background: "#1d9bf0", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 17, flex: "none" }}>{(me.display_name || me.handle || "?").slice(0, 1).toUpperCase()}</span>
          )}
          <div style={{ minWidth: 0 }}>
            <p style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#0f1419" }}>You are already logged in as @{me.handle}</p>
            <p style={{ margin: "2px 0 0", fontSize: 13.5, color: "#536471" }}>This form would create a new account.</p>
            <p style={{ margin: "8px 0 0", fontSize: 14 }}>
              <a href={HOME_URL} style={{ color: "#1d9bf0", fontWeight: 700 }}>Continue as @{me.handle}</a>
              <span style={{ color: "#aab8c2", margin: "0 8px" }}>·</span>
              <button type="button" onClick={() => { clearCallerId(); clearStore(); window.location.href = HOME_URL; }} style={{ background: "none", border: "none", padding: 0, font: "inherit", color: "#536471", fontWeight: 600, cursor: "pointer" }}>Log out</button>
            </p>
          </div>
        </div>
      ) : null}
      <SignupForm apiBase={API_BASE} onCreated={() => setCreated(true)} />
      {!created ? (
        <p style={{ fontSize: 13, marginTop: 16, textAlign: "center" }}>
          <a href="/login" style={{ color: "#1d9bf0" }}>Already have an account? Log in</a>
        </p>
      ) : null}
    </div>
  );
}
