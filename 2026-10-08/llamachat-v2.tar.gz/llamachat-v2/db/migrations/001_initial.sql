-- LlamaChat V2: initial schema
-- PostgreSQL. Designed for 100k users: keyset pagination, GIN indexes,
-- server-stamped Unix-ms timestamps enforced NOT NULL everywhere.
--
-- Timestamp rule (Dave's P1, burned 3x in V1):
--   The SERVER stamps every write with extract(epoch from now())*1000.
--   The client NEVER generates timestamps. created_at is NOT NULL on
--   every table. Invalid input is rejected, never defaulted to "now".

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================= PROFILES =============================
-- One canonical profile per person. No duplicates, no JS-file profiles.
CREATE TABLE profiles (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  handle        VARCHAR(32)  NOT NULL UNIQUE,
  display_name  VARCHAR(80)  NOT NULL,
  avatar_url    VARCHAR(512),
  bio           TEXT,
  link_url      VARCHAR(512),
  link_label    VARCHAR(120),
  followers_count INT NOT NULL DEFAULT 0 CHECK (followers_count >= 0),
  following_count INT NOT NULL DEFAULT 0 CHECK (following_count >= 0),
  posts_count     INT NOT NULL DEFAULT 0 CHECK (posts_count >= 0),
  created_at    BIGINT NOT NULL,
  updated_at    BIGINT NOT NULL,
  CONSTRAINT handle_format CHECK (handle ~ '^[a-z0-9_]{1,32}$')
);
CREATE INDEX idx_profiles_handle_lower ON profiles (lower(handle));
CREATE INDEX idx_profiles_search_trgm ON profiles USING GIN (handle gin_trgm_ops, display_name gin_trgm_ops);

-- ============================= TWEETS =============================
-- id is CLIENT-GENERATED (UUID v4) so retries are idempotent:
-- re-POSTing the same id returns the existing row, never a duplicate.
CREATE TABLE tweets (
  id           UUID PRIMARY KEY,
  author_id    UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  text         TEXT NOT NULL CHECK (char_length(text) BETWEEN 1 AND 2000),
  html         TEXT,                       -- server-rendered (links, #tags, @mentions)
  image_url    VARCHAR(512),
  reply_to_id  UUID REFERENCES tweets(id) ON DELETE CASCADE,
  hashtags     TEXT[] NOT NULL DEFAULT '{}',  -- lowercased, no '#', extracted server-side
  likes_count    INT NOT NULL DEFAULT 0 CHECK (likes_count >= 0),
  replies_count  INT NOT NULL DEFAULT 0 CHECK (replies_count >= 0),
  reposts_count  INT NOT NULL DEFAULT 0 CHECK (reposts_count >= 0),
  created_at   BIGINT NOT NULL,            -- server-stamped Unix ms, NEVER null
  updated_at   BIGINT NOT NULL,
  search_vector tsvector GENERATED ALWAYS AS (
    to_tsvector('english', coalesce(text, ''))
  ) STORED
);

-- Keyset pagination: (created_at DESC, id DESC) is a total order.
CREATE INDEX idx_tweets_feed        ON tweets (created_at DESC, id DESC);
CREATE INDEX idx_tweets_author_feed ON tweets (author_id, created_at DESC, id DESC);
CREATE INDEX idx_tweets_reply_to    ON tweets (reply_to_id, created_at DESC) WHERE reply_to_id IS NOT NULL;
CREATE INDEX idx_tweets_hashtags    ON tweets USING GIN (hashtags);
CREATE INDEX idx_tweets_search      ON tweets USING GIN (search_vector);
CREATE INDEX idx_tweets_media       ON tweets (author_id, created_at DESC) WHERE image_url IS NOT NULL;

-- ============================= FOLLOWS =============================
CREATE TABLE follows (
  follower_id  UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at   BIGINT NOT NULL,
  PRIMARY KEY (follower_id, following_id),
  CONSTRAINT no_self_follow CHECK (follower_id <> following_id)
);
CREATE INDEX idx_follows_following ON follows (following_id, follower_id);

-- ============================= LIKES =============================
CREATE TABLE likes (
  user_id    UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tweet_id   UUID NOT NULL REFERENCES tweets(id) ON DELETE CASCADE,
  created_at BIGINT NOT NULL,
  PRIMARY KEY (user_id, tweet_id)
);
CREATE INDEX idx_likes_tweet ON likes (tweet_id);

-- ============================= CONVERSATIONS (DMs) =============================
CREATE TABLE conversations (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE conversation_participants (
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id         UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  last_read_at    BIGINT,
  PRIMARY KEY (conversation_id, user_id)
);
CREATE INDEX idx_participants_user ON conversation_participants (user_id, conversation_id);

CREATE TABLE messages (
  id              UUID PRIMARY KEY,   -- client-generated, idempotent like tweets
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id       UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  text            TEXT NOT NULL CHECK (char_length(text) BETWEEN 1 AND 2000),
  image_url       VARCHAR(512),
  created_at      BIGINT NOT NULL,    -- server-stamped, NEVER null
  CONSTRAINT sender_in_conversation CHECK (true) -- enforced in app layer
);
CREATE INDEX idx_messages_conv ON messages (conversation_id, created_at DESC, id DESC);

-- ============================= COUNTER TRIGGERS =============================
-- Keep denormalized counts correct without app-layer races.
CREATE OR REPLACE FUNCTION bump_tweet_replies() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.reply_to_id IS NOT NULL THEN
    UPDATE tweets SET replies_count = replies_count + 1 WHERE id = NEW.reply_to_id;
  ELSIF TG_OP = 'DELETE' AND OLD.reply_to_id IS NOT NULL THEN
    UPDATE tweets SET replies_count = GREATEST(replies_count - 1, 0) WHERE id = OLD.reply_to_id;
  END IF;
  RETURN NULL;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tweet_replies
AFTER INSERT OR DELETE ON tweets
FOR EACH ROW EXECUTE FUNCTION bump_tweet_replies();

CREATE OR REPLACE FUNCTION bump_follow_counts() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE profiles SET following_count = following_count + 1 WHERE id = NEW.follower_id;
    UPDATE profiles SET followers_count = followers_count + 1 WHERE id = NEW.following_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE profiles SET following_count = GREATEST(following_count - 1, 0) WHERE id = OLD.follower_id;
    UPDATE profiles SET followers_count = GREATEST(followers_count - 1, 0) WHERE id = OLD.following_id;
  END IF;
  RETURN NULL;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_follow_counts
AFTER INSERT OR DELETE ON follows
FOR EACH ROW EXECUTE FUNCTION bump_follow_counts();

CREATE OR REPLACE FUNCTION bump_post_counts() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE profiles SET posts_count = posts_count + 1 WHERE id = NEW.author_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE profiles SET posts_count = GREATEST(posts_count - 1, 0) WHERE id = OLD.author_id;
  END IF;
  RETURN NULL;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_post_counts
AFTER INSERT OR DELETE ON tweets
FOR EACH ROW EXECUTE FUNCTION bump_post_counts();

CREATE OR REPLACE FUNCTION touch_conversation() RETURNS trigger AS $$
BEGIN
  UPDATE conversations SET updated_at = NEW.created_at WHERE id = NEW.conversation_id;
  RETURN NULL;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_touch_conversation
AFTER INSERT ON messages
FOR EACH ROW EXECUTE FUNCTION touch_conversation();
