// Llama Engine v1: makes LlamaChat feel real and alive.
// Dave's call Oct 9 2026: "We want Llama Chat to feel real. Let's make it real!"
//
// When Dave posts, characters like and reply naturally:
// - Likes: 2-4 characters, staggered 5-15 min, not everyone, not instant
// - Replies: 0-2 per post, character voice matched to content, 10-30 min delay
// - Never spammy, never generic, respects quiet hours (1am-6am MT = no activity)
//
// Characters (phase 1): dinesh, sally, mike, marty, chadwick
//
// Usage: node api/scripts/llama-engine.js
//   Run every 10 min via cron.

const fs = require("fs");
const crypto = require("crypto");
const { postTweet, getAuthorTweets, getTweetThread, getProfileId } = require("./lib/botlib");
// Marty's upgraded reply brain (Dave's call Oct 15 2026): context-aware
// categories, big voice pools, persistent anti-repeat memory. Loaded in a
// try/catch so a broken brain file can never kill the engine; Marty just
// falls back to the old template picker below.
let martyBrain = null;
try { martyBrain = require("./lib/marty-brain"); } catch (e) {
  console.error("[llama-engine] marty-brain failed to load, using fallback picker:", e.message);
}
const API_BASE = "https://llamachat-api.dlaneycreative.workers.dev/api/v2";
// Every call gets a hard 25s timeout (Oct 13): on a degraded network a
// bare fetch hangs for minutes on a half-open connection, and three runs
// in a row died mid-flight without saving state. Fail fast, save state,
// let the next run pick up where this one stopped.
function tfetch(url, opts = {}) {
  return fetch(url, { ...opts, signal: AbortSignal.timeout(25000) });
}

const STATE_FILE = "/tmp/llama-engine-state.json";
const LIKE_COOLDOWN_MS = 5 * 60 * 1000;      // don't like tweets < 5 min old
const REPLY_COOLDOWN_MS = 10 * 60 * 1000;    // don't reply to tweets < 10 min old
const MAX_LIKES_PER_RUN = 12;
const MAX_REPLIES_PER_RUN = 5;

// Character roster with their handles (verified live)
const CHARACTERS = ["dinesh", "sally", "mike", "Marty", "chadwick", "henri"];

// Dave's call Oct 10 2026: mentioned characters should respond naturally.
// Extract @mentions from tweet text, map to character handles.
function getMentionedCharacters(text) {
  const t = (text || "").toLowerCase();
  const mentioned = [];
  // Map mention patterns to handles (handles without @)
  const mentionMap = {
    "dinesh": "dinesh",
    "sally": "sally",
    "mike": "mike",
    "marty": "Marty",
    "chadwick": "chadwick",
    "chadwick": "chadwick",
    "henri": "henri",
  };
  for (const [pattern, handle] of Object.entries(mentionMap)) {
    // Match @pattern as a word boundary
    const re = new RegExp(`@${pattern}\b`, 'i');
    if (re.test(t) && !mentioned.includes(handle)) {
      mentioned.push(handle);
    }
  }
  return mentioned;
}

// Reply templates by character voice (from personality docs)
const VOICES = {
  dinesh: {
    tech: [
      "technically correct. which is the best kind of correct.",
      "have you measured it? if it's not measured it's just a vibe.",
      "this is a systems problem. everything is a systems problem if you squint.",
      "ship it. we can optimize later. (we will optimize later.)",
      "the bottleneck is never where you think it is.",
    ],
    general: [
      "interesting. let me think about the edge cases.",
      "this checks out. nice work.",
      "nerd approved. which is the highest approval.",
    ],
  },
  sally: {
    warm: [
      "this made me smile. keep going, you're doing good work.",
      "i love this. the heart behind it comes through.",
      "yes! this is exactly the kind of thing the world needs more of.",
      "you've got a good heart, dave. don't ever lose that.",
      "thank you for sharing this. it means a lot.",
    ],
    music: [
      "this is giving me song ideas. piano is calling my name.",
      "felt this in my chest. that's how i know it's real.",
    ],
  },
  mike: {
    // Mike: plainspoken, warm, short sentences, no fluff. Leads with answer.
    ops: [
      "on it. this is getting done today.",
      "love it. adding to the board.",
      "shipped. what's next?",
      "got it. handled.",
    ],
    general: [
      "let's go. this is the good stuff.",
      "cranking. this is becoming the real deal.",
      "done. you'll see it live in the morning.",
    ],
  },
  Marty: {
    // Marty: funny, memes, loving roast, never mean, never punching down
    funny: [
      "lol this is so good. stealing this for /fun/.",
      "i'm crying. this is perfect meme material.",
      "ok but why is this actually funny though.",
      "marty approves. that's the highest honor.",
    ],
    general: [
      "this slaps. no notes.",
      "adding this to the list of things that actually work.",
    ],
  },
  chadwick: {
    // Chadwick: finds broken websites, verifies with human eyes
    web: [
      "found 3 broken sites while reading this. multitasking.",
      "chadwick has verified this post is 100% not broken.",
    ],
    general: [
      "adding this to the list of things that actually work.",
      "verified with human eyes. this is good.",
    ],
  },
  henri: {
    // Henri: designer, Lyon to Denver. White space is a moral position.
    design: [
      "the negative space here is doing the heavy lifting. beautiful.",
      "navy and gold. classic. this has restraint, which is rare.",
      "i would kern the letters slightly tighter, but the feeling is right.",
      "design is how it works, but also how it makes you feel. this feels right.",
    ],
    general: [
      "c'est magnifique. the craft shows.",
      "less, but better. you understand.",
      "this has soul. keep the soul.",
    ],
  },
};

function pick(arr, salt) {
  const h = parseInt(crypto.createHash("sha1").update(String(salt)).digest("hex").slice(0, 8), 16);
  return arr[h % arr.length];
}

function isQuietHours() {
  // 1am-6am MT = quiet. No likes/replies.
  const mtHour = parseInt(new Date().toLocaleString("en-US", { timeZone: "America/Denver", hour: "numeric", hour12: false }));
  return mtHour >= 1 && mtHour < 6;
}

// Decide which characters like this tweet (2-4, deterministic but varied)
function chooseLikers(tweetId, text) {
  const h = parseInt(crypto.createHash("sha1").update("like:" + tweetId).digest("hex").slice(0, 8), 16);
  const count = 2 + (h % 3); // 2-4 likers
  // Mentioned characters always like first (feels natural)
  const mentioned = getMentionedCharacters(text).filter((m) => CHARACTERS.includes(m));
  // Shuffle remaining characters deterministically by tweet ID
  const rest = CHARACTERS.filter((c) => !mentioned.includes(c));
  const shuffled = [...rest].sort((a, b) => {
    const ha = parseInt(crypto.createHash("sha1").update(tweetId + a).digest("hex").slice(0, 8), 16);
    const hb = parseInt(crypto.createHash("sha1").update(tweetId + b).digest("hex").slice(0, 8), 16);
    return ha - hb;
  });
  // Mentioned first, then fill up to count
  const likers = [...mentioned, ...shuffled].slice(0, Math.max(count, mentioned.length));
  return likers;
}

// Decide who replies and with what voice
function chooseReply(text) {
  const t = (text || "").toLowerCase();
  // Mentioned characters reply first (Dave's call: feel natural)
  const mentioned = getMentionedCharacters(text).filter((m) => CHARACTERS.includes(m) && VOICES[m]);
  if (mentioned.length > 0) {
    // Pick deterministically by text hash so it's stable
    const h = parseInt(crypto.createHash("sha1").update("mention-reply:" + text).digest("hex").slice(0, 8), 16);
    const handle = mentioned[h % mentioned.length];
    const pools = Object.values(VOICES[handle]);
    return { handle, pool: pools[h % pools.length] };
  }
  const techWords = ["server", "api", "deploy", "code", "bug", "speed", "fast", "load", "build", "data", "system", "latency", "vercel", "database"];
  const musicWords = ["song", "music", "piano", "sing", "melody", "album", "guitar"];
  const kindWords = ["kind", "kindness", "love", "heart", "grateful", "thank"];
  const funnyWords = ["lol", "funny", "meme", "haha", "😂", "🤣"];
  const webWords = ["website", "site", "web", "broken", "audit"];
  const shipWords = ["ship", "done", "launch", "deploy", "build"];
  const hasAny = (words) => words.some((w) => t.includes(w));

  if (hasAny(musicWords)) return { handle: "sally", pool: VOICES.sally.music };
  if (hasAny(techWords)) return { handle: "dinesh", pool: VOICES.dinesh.tech };
  if (hasAny(funnyWords)) return { handle: "Marty", pool: VOICES.Marty.funny };
  if (hasAny(webWords)) return { handle: "chadwick", pool: VOICES.chadwick.web };
  if (hasAny(shipWords)) return { handle: "mike", pool: VOICES.mike.ops };
  if (hasAny(kindWords)) return { handle: "sally", pool: VOICES.sally.warm };

  // Default: rotate by hash
  const h = parseInt(crypto.createHash("sha1").update("reply:" + text).digest("hex").slice(0, 8), 16);
  const char = CHARACTERS[h % CHARACTERS.length];
  const pools = Object.values(VOICES[char]);
  return { handle: char, pool: pools[h % pools.length] };
}

async function apiPost(path, body, handle) {
  const profileId = await getProfileId(handle);
  const res = await tfetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-user": profileId },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  return res.json();
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return { liked: {}, replied: {}, dmReplied: {} }; }
}
function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s)); }


// --- DM AUTO-REPLIES (Dave's call Oct 10 2026) ---
// Check each character's DMs for unread messages from Dave, reply in their voice.

async function getConversations(handle) {
  const profileId = await getProfileId(handle);
  const res = await tfetch(`${API_BASE}/conversations`, {
    headers: { "x-llama-user": profileId },
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.conversations || [];
}

async function getMessages(handle, convId) {
  const profileId = await getProfileId(handle);
  const res = await tfetch(`${API_BASE}/conversations/${convId}/messages?limit=10`, {
    headers: { "x-llama-user": profileId },
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.messages || [];
}

async function sendDM(handle, convId, text) {
  const profileId = await getProfileId(handle);
  const msgId = require("crypto").randomUUID();
  const res = await tfetch(`${API_BASE}/conversations/${convId}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-user": profileId },
    body: JSON.stringify({ id: msgId, text }),
  });
  if (!res.ok) throw new Error(`DM send failed: ${res.status}`);
  return res.json();
}

// Pick a DM reply in the character's voice based on the incoming text
// Avoids repeating the same reply twice in a row for a given character.
const lastDMReply = {};
function chooseDMReply(handle, text, convKey) {
  // Marty has her own brain now (Oct 15 2026): it classifies the message
  // (praise, laughter, question, greeting, ...), echoes the topic, and
  // remembers her recent replies per conversation on disk. Any failure
  // falls through to the generic picker so she never goes silent.
  if (handle === "Marty" && martyBrain) {
    try {
      return martyBrain.dmReply({ text, convKey: convKey || "dm:unknown" });
    } catch (e) {
      console.error("[llama-engine] marty-brain DM reply failed, falling back:", e.message);
    }
  }
  const t = (text || "").toLowerCase();
  const pools = VOICES[handle] ? Object.values(VOICES[handle]).flat() : null;
  if (!pools || !pools.length) return null;

  // Simple keyword matching for more natural responses
  if (t.includes("?")) {
    // Questions get a thoughtful response
    const q = [
      "good question. let me think about that for a sec.",
      "hmm, that's interesting. here's what i think.",
      "oh i've got thoughts on this.",
    ];
    // Use character voice for the rest
    const h = parseInt(require("crypto").createHash("sha1").update("dmq:" + text).digest("hex").slice(0, 8), 16);
    return q[h % q.length] + " " + pools[h % pools.length];
  }

  const h = parseInt(require("crypto").createHash("sha1").update("dm:" + text + handle).digest("hex").slice(0, 8), 16);
  let idx = h % pools.length;
  // Don't repeat the last reply for this character
  if (pools.length > 1 && lastDMReply[handle] === pools[idx]) {
    idx = (idx + 1) % pools.length;
  }
  lastDMReply[handle] = pools[idx];
  return pools[idx];
}

async function checkDMs(state) {
  const daveId = await getProfileId("dave");
  for (const handle of CHARACTERS) {
    try {
      const convs = await getConversations(handle);
      for (const conv of convs) {
        // Only care about 1:1 DMs with Dave
        const others = conv.others || [];
        if (others.length !== 1) continue;
        if (others[0].id !== daveId) continue;
        if (!conv.unread) continue;

        const messages = await getMessages(handle, conv.id);
        // Find the latest unread message from Dave
        const daveMsgs = messages.filter((m) => m.sender_id === daveId);
        if (!daveMsgs.length) continue;

        const latest = daveMsgs[daveMsgs.length - 1];
        const replyKey = `dm:${conv.id}:${latest.id}`;
        if (state.dmReplied[replyKey]) continue;

        const replyText = chooseDMReply(handle, latest.text, "dm:" + conv.id);
        if (!replyText) continue;

        await sendDM(handle, conv.id, replyText);
        state.dmReplied[replyKey] = Date.now();
        console.log(`[llama-engine] @${handle} DM-replied to Dave`);
      }
    } catch (e) {
      console.error(`[llama-engine] DM check failed @${handle}: ${e.message}`);
    }
  }
}

async function main() {
  if (isQuietHours()) {
    console.log("[llama-engine] quiet hours, skipping");
    return;
  }

  const state = loadState();
  const tweets = await getAuthorTweets("dave", 20);
  const now = Date.now();
  let likes = 0, replies = 0;

  // Process oldest first for natural chronological feel
  for (const tw of [...tweets].reverse()) {
    if (tw.reply_to_id) continue; // don't engage with Dave's own replies
    const age = now - Number(tw.created_at);

    // --- LIKES ---
    if (age >= LIKE_COOLDOWN_MS && likes < MAX_LIKES_PER_RUN) {
      const likers = chooseLikers(tw.id, tw.text || "");
      for (const handle of likers) {
        const key = `${tw.id}:${handle}`;
        if (state.liked[key]) continue;
        try {
          await apiPost("/likes", { tweet_id: tw.id }, handle);
          state.liked[key] = Date.now();
          likes++;
          console.log(`[llama-engine] @${handle} liked Dave's tweet ${tw.id.slice(0, 8)}`);
        } catch (e) {
          console.error(`[llama-engine] like failed @${handle}: ${e.message}`);
        }
        if (likes >= MAX_LIKES_PER_RUN) break;
      }
    }

    // --- REPLIES ---
    if (age >= REPLY_COOLDOWN_MS && replies < MAX_REPLIES_PER_RUN && !state.replied[tw.id]) {
      // Check if anyone already replied
      let alreadyReplied = false;
      try {
        const thread = await getTweetThread(tw.id);
        const threadReplies = thread.replies || [];
        alreadyReplied = threadReplies.some((r) =>
          CHARACTERS.includes(((r.author && r.author.handle) || "").toLowerCase())
        );
      } catch { /* fall through */ }
      if (alreadyReplied) { state.replied[tw.id] = "existing"; continue; }

      // Dave's call: everybody comments. 90% of posts get a reply.
      const h = parseInt(crypto.createHash("sha1").update("should-reply:" + tw.id).digest("hex").slice(0, 8), 16);
      if (h % 10 >= 9) { state.replied[tw.id] = "skipped"; continue; }

      const { handle, pool } = chooseReply(tw.text || "");
      // When Marty wins the reply slot, her brain writes the reply
      // (topic-aware, never repeats her recent lines). Everyone else
      // keeps the classic template pick, unchanged.
      let text = null;
      if (handle === "Marty" && martyBrain) {
        try { text = martyBrain.tweetReply({ text: tw.text || "", convKey: "tweets" }); }
        catch (e) { console.error("[llama-engine] marty-brain tweet reply failed, falling back:", e.message); }
      }
      if (!text) text = pick(pool, tw.id + handle);
      try {
        const { deduped } = await postTweet({
          handle,
          text,
          reply_to_id: tw.id,
          idempotencyKey: `llama-engine:${tw.id}:${handle}`,
        });
        state.replied[tw.id] = handle;
        replies++;
        console.log(`[llama-engine] @${handle} -> Dave's tweet ${tw.id.slice(0, 8)}: ${deduped ? "deduped" : "replied"}`);
      } catch (e) {
        console.error(`[llama-engine] reply failed: ${e.message}`);
      }
    }
  }

  // Check DMs for each character
  await checkDMs(state);

  saveState(state);
  console.log(`[llama-engine] done: ${likes} likes, ${replies} replies this run`);
}

main().catch((e) => { console.error("[llama-engine] fatal", e.message); process.exit(1); });
