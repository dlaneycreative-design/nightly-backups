import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import type { ApiClient, Conversation } from "../lib/api.ts";
import { relTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { DMThread } from "./DMThread.tsx";

/**
 * X-style split DM view: conversation list on the left, active thread on the right.
 * Dave's call Oct 8 2026.
 */
export function DMSplit({ api }: { api: ApiClient }) {
  const navigate = useNavigate();
  const { id: selectedId } = useParams<{ id: string }>();
  const [convos, setConvos] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { conversations } = await api.conversations(null, 20);
        if (alive) setConvos(conversations);
      } catch {
        /* keep empty */
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [api]);

  return (
    <div className={`dm-split${selectedId ? " has-selection" : ""}`}>
      <div className="dm-split-list">
        <div className="dm-split-header">
          <h2>Messages</h2>
        </div>
        {loading ? (
          <div aria-label="Loading conversations">
            {[0, 1, 2].map((i) => (
              <div className="skel-tweet" key={i}>
                <div className="skel skel-avatar" />
                <div className="skel-lines">
                  <div className="skel skel-line short" />
                  <div className="skel skel-line" />
                </div>
              </div>
            ))}
          </div>
        ) : convos.length === 0 ? (
          <div className="empty">
            <h2>No conversations yet</h2>
            <p>Visit someone's profile and tap Message to say hi.</p>
          </div>
        ) : (
          convos.map((c) => {
            const names = (c.others || []).map((p) => p.display_name).join(", ") || "Conversation";
            const avatar = resolveImageUrl((c.others || [])[0]?.avatar_url || null);
            const initial = (names || "?").slice(0, 1).toUpperCase();
            const when = relTime(c.updated_at);
            const active = c.id === selectedId;
            const unread = c.unread;
            return (
              <button
                key={c.id}
                type="button"
                className={`convo-row${active ? " active" : ""}${unread ? " unread" : ""}`}
                onClick={() => navigate(`/messages/${c.id}`)}
              >
                {avatar ? (
                  <img src={avatar} alt="" loading="lazy" decoding="async" />
                ) : (
                  <div className="avatar-fallback" aria-hidden="true">{initial}</div>
                )}
                <div className="convo-txt">
                  <div className="convo-top">
                    <span className="convo-name">{names}</span>
                    <span className="convo-when">{when}</span>
                  </div>
                  <div className="convo-preview">{c.last_text || ""}</div>
                </div>
              </button>
            );
          })
        )}
      </div>
      <div className="dm-split-thread">
        {selectedId ? (
          <DMThread
            key={selectedId}
            api={api}
            conversationId={selectedId}
            conversation={convos.find((c) => c.id === selectedId) || null}
          />
        ) : (
          <div className="dm-split-empty">
            <div className="dm-empty-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/>
              </svg>
            </div>
            <h2>Start Conversation</h2>
            <p>Choose from your existing conversations, or start a new one.</p>
            <button type="button" className="dm-new-chat-btn" onClick={() => navigate("/search")}>
              New chat
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
