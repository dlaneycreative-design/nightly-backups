# LlamaChat V2 Frontend

## Structure

```
web/
├── src/
│   ├── components/
│   │   ├── Composer.tsx       # ONE composer, used everywhere
│   │   ├── Tweet.tsx          # Tweet card
│   │   ├── TweetImage.tsx     # Lazy image: thumb in feed, srcset, tap for full
│   │   ├── TweetThread.tsx    # Tweet + replies with parent context
│   │   ├── ProfileHeader.tsx  # Avatar, bio, follow button
│   │   ├── ProfileTabs.tsx    # Posts / Replies / Media / Likes
│   │   ├── Feed.tsx           # Virtualized feed list (never 500 <img> in DOM)
│   │   ├── DMThread.tsx       # Conversation view
│   │   ├── DMInbox.tsx        # Conversation list
│   │   ├── HashtagView.tsx    # Hashtag page
│   │   ├── SearchView.tsx     # Search with highlighting
│   │   ├── ExploreView.tsx    # All users sorted by followers
│   │   └── ErrorBoundary.tsx  # One bad tweet doesn't kill the feed
│   ├── lib/
│   │   ├── api.ts             # Typed API client, retry logic
│   │   ├── timestamps.ts      # THE timestamp formatter (tested!)
│   │   ├── images.ts          # Variant URLs, presign upload, srcset builder
│   │   ├── lazyload.ts        # IntersectionObserver helper
│   │   ├── store.ts           # Normalized cache (by ID)
│   │   ├── offline.ts         # Offline queue for posts
│   │   └── realtime.ts        # WebSocket with polling fallback
│   ├── styles/
│   │   ├── tokens.css         # Colors, spacing, type scale
│   │   └── components.css     # Component styles (no inline!)
│   └── App.tsx
├── tests/
│   ├── timestamps.test.ts     # We ship this bug 3 times, never again
│   ├── hashtags.test.ts
│   ├── api.test.ts
│   └── composer.test.ts
└── package.json
```

## Key Decisions

**TypeScript everywhere.** The `undefined.profile` bugs die here.

**One Composer.** V1 had three (modal, home inline, reply). V2 has one component with props.

**Normalized store.** One tweet object by ID. Feed, profile, hashtag all reference the same object. No duplicates.

**Timestamps tested.** `timestamps.ts` has unit tests for every case: seconds, minutes, hours, days, dates, invalid, future, zero. We broke this 3 times in V1.

**No inline styles.** All in CSS files. The banner bug was inline styles.

**Error boundaries.** Every view wrapped. A broken tweet shows "Couldn't load this post" not a white screen.

## Performance Targets (Dave's rules)

- Total page weight: < 1MB
- Time to first paint: < 1s
- Time to interactive: < 2s
- Lighthouse score: 95+ on mobile

## Feed Image Performance (Dave's call, Oct 7 2026: feed must handle 500+ images)

The feed paginates 20 tweets at a time (cursor-based, server-side). Images
must never blow up the DOM or the bandwidth budget:

**Lazy-load everything (IntersectionObserver).** `TweetImage` renders a
placeholder (aspect-ratio box, blurred thumb background) and only sets the
real `src` when the tweet scrolls within ~800px of the viewport. Images far
below the fold cost zero bytes until approached. `lib/lazyload.ts` wraps
IntersectionObserver with a fallback for old browsers (load on scroll idle).

**Thumbnails in feed, full on tap.** The feed shows the 200px `thumb`
variant (usually < 20KB). Tapping opens the lightbox with the 1600px `full`
variant. `srcset` (`thumb 200w, medium 800w, full 1600w`) lets the browser
pick on high-DPI screens, but the default feed request is the thumb.

**Virtualized list.** `Feed.tsx` uses windowing: only ~30 tweet rows exist
in the DOM at once (visible + overscan). Scrolling recycles rows. The DOM
never holds 500 `<img>` elements even after loading 25 pages. Row heights
are estimated then measured (dynamic virtualization) so variable text
lengths don't break scroll position.

**Preload next page.** When the user is within 2 screens of the feed end,
the next cursor page is fetched in the background AND its thumbnail URLs
are prefetched (`<link rel="prefetch">` or `new Image().src`). By the time
the user scrolls there, thumbs are in the HTTP cache.

**Never decode offscreen.** `decoding="async"` and `loading="lazy"` on every
`<img>`. The browser skips decode work for offscreen images.

**Bandwidth math (100k users):** 20 tweets/page x ~15KB avg thumb =
~300KB per page of images, loaded progressively. A full 500-image session
stays under ~8MB only if the user actually scrolls through all of it, and
the DOM stays at ~30 rows the whole time.

## Image Upload Flow (client side)

1. User picks/pastes/drops an image in `Composer`.
2. Client downscales a preview locally (canvas, 800px max) for instant feedback.
3. On Post: `POST /uploads/presign` -> PUT bytes direct to R2 -> create tweet
   with returned `public_url` as `image_url`. The composer shows "uploading..."
   state; if the PUT fails, the post is queued in the offline queue and
   retried (never POOF).
4. `lib/images.ts` builds variant URLs by convention and `srcset` strings;
   no extra API call needed to discover variants.

## Mobile First

- 44px touch targets
- No horizontal scroll (tested on real iPhones)
- Safe area insets
- Pull to refresh
- Swipe back gesture
