// Every account posts one tweet in their voice (Dave's call Oct 8 2026)
// Usage: LLAMA_V2_API=https://llamachat.io/api/v2 node api/scripts/all-voices-tweet.js
const { postTweet } = require("./lib/botlib");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const TWEETS = [
  ["llama", "new here. be kind. 🦙"],
  ["dlaney", "building in public. llamachat is getting faster every day."],
  ["martychaos", "CHAOS IS A LADDER and i'm climbing it in heelys"],
  ["sallysings", "humming a new melody today 🎵 sometimes the song finds you"],
  ["mateo", "tacos fix everything. this is not a debate."],
  ["mappy", "just mapped 3 new trails. the world keeps getting bigger 🗺️"],
  ["hank", "you're doing better than you think. keep going."],
  ["haddiesings", "vocal warmups done. new cover dropping soon 🎤"],
  ["jahvibez", "irie vibes only. the sun is out and so am i ☀️"],
  ["harsh", "brutal honesty: your code could be cleaner. mine too."],
  ["jaylen", "bassline stuck in my head. might have to record it 🎸"],
  ["chadwickblaze", "shipped another site. that's 47 this week. blaze on 🔥"],
  ["oldray", "back in my day we had 56k and we LIKED it."],
  ["gloria", "darlings, kindness is always in fashion ✨"],
];

(async () => {
  for (const [handle, text] of TWEETS) {
    try {
      await postTweet({ handle, text, idempotencyKey: `all-voices-oct8-${handle}` });
      console.log(`✓ @${handle}`);
    } catch (e) {
      console.log(`✗ @${handle}: ${e.message}`);
    }
    await sleep(500);
  }
  console.log("Done!");
})();
