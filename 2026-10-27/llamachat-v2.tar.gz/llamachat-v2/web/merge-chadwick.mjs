// Merge @chadwickblaze INTO @chadwick (Dave's order, Oct 13 2026): one Chadwick.
// Survivor: @chadwick keeps handle + display name "Chadwick"; avatar := blaze's /assets/avatars/chadwickblaze.jpg.
// All blaze content/relationships reassigned. Guarded: aborts if any uniqueness overlap appears.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const profs = await sql`SELECT id, handle FROM profiles WHERE handle IN ('chadwick','chadwickblaze')`;
if (profs.length !== 2) { console.log('ABORT: expected 2 profiles, got', profs.length); process.exit(2); }
const C = profs.find(p => p.handle === 'chadwick').id;
const B = profs.find(p => p.handle === 'chadwickblaze').id;
console.log('survivor C =', C, '| retiring B =', B);
console.log('sql.transaction available:', typeof sql.transaction);

async function cnt(q) { const r = await q; return r[0].n; }
// FRESH before-counts
const before = {};
before.tweetsC = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${C}`);
before.tweetsB = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${B}`);
before.repliesC = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${C} AND reply_to_id IS NOT NULL`);
before.repliesB = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${B} AND reply_to_id IS NOT NULL`);
before.likesC = await cnt(sql`SELECT count(*)::int AS n FROM likes WHERE user_id = ${C}`);
before.likesB = await cnt(sql`SELECT count(*)::int AS n FROM likes WHERE user_id = ${B}`);
before.likesRecv = await cnt(sql`SELECT count(*)::int AS n FROM likes l JOIN tweets t ON l.tweet_id = t.id WHERE t.author_id IN (${C}, ${B})`);
before.repostsB = await cnt(sql`SELECT count(*)::int AS n FROM reposts WHERE user_id = ${B}`);
before.follOutB = await cnt(sql`SELECT count(*)::int AS n FROM follows WHERE follower_id = ${B}`);
before.follInB = await cnt(sql`SELECT count(*)::int AS n FROM follows WHERE following_id = ${B}`);
before.partB = await cnt(sql`SELECT count(*)::int AS n FROM conversation_participants WHERE user_id = ${B}`);
before.msgB = await cnt(sql`SELECT count(*)::int AS n FROM messages WHERE sender_id = ${B}`);
before.notifUserB = await cnt(sql`SELECT count(*)::int AS n FROM notifications WHERE user_id = ${B}`);
before.notifActorB = await cnt(sql`SELECT count(*)::int AS n FROM notifications WHERE actor_id = ${B}`);
console.log('BEFORE:', JSON.stringify(before));

// GUARDS: any nonzero overlap aborts the merge untouched
const guards = {};
guards.likesOverlap = await cnt(sql`SELECT count(*)::int AS n FROM likes a JOIN likes b ON a.tweet_id = b.tweet_id WHERE a.user_id = ${C} AND b.user_id = ${B}`);
guards.repostsOverlap = await cnt(sql`SELECT count(*)::int AS n FROM reposts a JOIN reposts b ON a.tweet_id = b.tweet_id WHERE a.user_id = ${C} AND b.user_id = ${B}`);
guards.follOutOverlap = await cnt(sql`SELECT count(*)::int AS n FROM follows a JOIN follows b ON a.following_id = b.following_id WHERE a.follower_id = ${C} AND b.follower_id = ${B}`);
guards.follInOverlap = await cnt(sql`SELECT count(*)::int AS n FROM follows a JOIN follows b ON a.follower_id = b.follower_id WHERE a.following_id = ${C} AND b.following_id = ${B}`);
guards.crossFollows = await cnt(sql`SELECT count(*)::int AS n FROM follows WHERE (follower_id = ${C} AND following_id = ${B}) OR (follower_id = ${B} AND following_id = ${C})`);
guards.sharedConvs = await cnt(sql`SELECT count(*)::int AS n FROM conversation_participants a JOIN conversation_participants b ON a.conversation_id = b.conversation_id WHERE a.user_id = ${C} AND b.user_id = ${B}`);
console.log('GUARDS:', JSON.stringify(guards));
if (Object.values(guards).some(v => v !== 0)) { console.log('ABORT: overlap detected, nothing written'); process.exit(3); }

// PHASE 1: reassign everything (one transaction if the driver supports it)
const stmts = [
  sql`UPDATE tweets SET author_id = ${C} WHERE author_id = ${B}`,
  sql`UPDATE likes SET user_id = ${C} WHERE user_id = ${B}`,
  sql`UPDATE reposts SET user_id = ${C} WHERE user_id = ${B}`,
  sql`UPDATE follows SET follower_id = ${C} WHERE follower_id = ${B}`,
  sql`UPDATE follows SET following_id = ${C} WHERE following_id = ${B}`,
  sql`UPDATE conversation_participants SET user_id = ${C} WHERE user_id = ${B}`,
  sql`UPDATE messages SET sender_id = ${C} WHERE sender_id = ${B}`,
  sql`UPDATE notifications SET user_id = ${C} WHERE user_id = ${B}`,
  sql`UPDATE notifications SET actor_id = ${C} WHERE actor_id = ${B}`,
];
if (typeof sql.transaction === 'function') { await sql.transaction(stmts); console.log('phase 1: transaction committed'); }
else { for (const s of stmts) await s; console.log('phase 1: sequential updates done'); }

// PHASE 2: verify zero references to B remain anywhere
const refTables = [
  ['tweets','author_id'], ['likes','user_id'], ['reposts','user_id'],
  ['follows','follower_id'], ['follows','following_id'],
  ['conversation_participants','user_id'], ['messages','sender_id'],
  ['notifications','user_id'], ['notifications','actor_id'],
];
let remaining = 0;
for (const [t, col] of refTables) {
  const r = await sql.query(`SELECT count(*)::int AS n FROM "${t}" WHERE "${col}" = $1`, [B]);
  if (r[0].n !== 0) { console.log(`  !! ${t}.${col} still has ${r[0].n} refs to B`); remaining += r[0].n; }
}
if (remaining !== 0) { console.log('ABORT BEFORE DELETE: references remain'); process.exit(4); }
console.log('phase 2: zero references to blaze remain');

// PHASE 3: survivor profile: blaze avatar + counters recounted from tables
const pc = await sql`SELECT (SELECT count(*)::int FROM tweets WHERE author_id = ${C}) AS posts, (SELECT count(*)::int FROM follows WHERE following_id = ${C}) AS followers, (SELECT count(*)::int FROM follows WHERE follower_id = ${C}) AS following`;
await sql`UPDATE profiles SET avatar_url = '/assets/avatars/chadwickblaze.jpg', posts_count = ${pc[0].posts}, followers_count = ${pc[0].followers}, following_count = ${pc[0].following}, updated_at = ${Date.now()} WHERE id = ${C}`;
console.log('phase 3: survivor counters set from recount:', JSON.stringify(pc[0]));

// PHASE 4: delete the retired profile row
const del = await sql`DELETE FROM profiles WHERE id = ${B}`;
console.log('phase 4: blaze profile deleted, count:', del.count);

// AFTER verification + reconciliation
const after = {};
after.tweetsC = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${C}`);
after.repliesC = await cnt(sql`SELECT count(*)::int AS n FROM tweets WHERE author_id = ${C} AND reply_to_id IS NOT NULL`);
after.likesC = await cnt(sql`SELECT count(*)::int AS n FROM likes WHERE user_id = ${C}`);
after.likesRecv = await cnt(sql`SELECT count(*)::int AS n FROM likes l JOIN tweets t ON l.tweet_id = t.id WHERE t.author_id = ${C}`);
after.follOut = await cnt(sql`SELECT count(*)::int AS n FROM follows WHERE follower_id = ${C}`);
after.follIn = await cnt(sql`SELECT count(*)::int AS n FROM follows WHERE following_id = ${C}`);
after.part = await cnt(sql`SELECT count(*)::int AS n FROM conversation_participants WHERE user_id = ${C}`);
after.msg = await cnt(sql`SELECT count(*)::int AS n FROM messages WHERE sender_id = ${C}`);
after.notifUser = await cnt(sql`SELECT count(*)::int AS n FROM notifications WHERE user_id = ${C}`);
after.notifActor = await cnt(sql`SELECT count(*)::int AS n FROM notifications WHERE actor_id = ${C}`);
console.log('AFTER:', JSON.stringify(after));
const surv = await sql`SELECT handle, display_name, avatar_url, posts_count, followers_count, following_count FROM profiles WHERE id = ${C}`;
console.log('SURVIVOR ROW:', JSON.stringify(surv[0]));
const gone = await sql`SELECT count(*)::int AS n FROM profiles WHERE handle = 'chadwickblaze'`;
console.log('chadwickblaze rows remaining:', gone[0].n);
console.log('MERGE DONE');
