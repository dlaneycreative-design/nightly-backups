// LlamaChat V2 API server.
//
// Architecture principles (Dave's calls):
//   - Stateless: every instance is identical; scale horizontally.
//   - No endpoint returns "all" anything. Everything is cursor-paginated.
//   - The server stamps ALL timestamps (lib/timestamps.js). The client
//     NEVER generates them.
//   - Writes are idempotent: tweets/messages use client-generated UUIDs;
//     re-POSTing the same id returns the existing row, never a duplicate.
//
// Auth (pragmatic V2): the caller is identified by the `x-llama-user`
// header carrying the caller's profile id. In production this MUST be a
// verified token (V2.5: replace with signed session tokens). For now the
// header is trusted so Dave can post from day one.
const express = require("express");
const compression = require("compression");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const { query, pool } = require("./lib/db");
const { nowMs, parseClientTs } = require("./lib/timestamps");
const { extractHashtags, renderHtml } = require("./lib/render");
const { uploadToBlob, MAX_UPLOAD_BYTES } = require("./lib/images");

// Run pending DB migrations on cold start (Vercel serverless).
// Idempotent: tracks applied migrations in schema_migrations.
let migrationsDone = false;
async function runMigrations() {
  if (migrationsDone) return;
  migrationsDone = true;
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      name TEXT PRIMARY KEY, applied_at BIGINT NOT NULL
    )`);
    const applied = new Set(
      (await pool.query("SELECT name FROM schema_migrations")).rows.map((r) => r.name)
    );
    const dir = path.join(__dirname, "..", "db", "migrations");
    const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
    for (const f of files) {
      if (applied.has(f)) continue;
      const sql = fs.readFileSync(path.join(dir, f), "utf8");
      console.log(`[migrate] applying ${f}...`);
      await pool.query("BEGIN");
      try {
        await pool.query(sql);
        await pool.query("INSERT INTO schema_migrations (name, applied_at) VALUES ($1, $2)", [f, Date.now()]);
        await pool.query("COMMIT");
        console.log(`[migrate] applied ${f}`);
      } catch (e) {
        await pool.query("ROLLBACK");
        console.error(`[migrate] failed ${f}:`, e.message);
      }
    }
  } catch (e) {
    console.error("[migrate] startup error:", e.message);
  }
}
void runMigrations();

// Multer: hold the upload in memory (serverless has no disk), then put()
// it straight to Vercel Blob. Clients downscale to <=1600px WebP first,
// so real uploads are far under the 4.5MB function body cap.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_BYTES },
});

const app = express();

// Gzip compress API responses (Pingdom: "Compress components with gzip")
// Threshold 0: even tiny JSON payloads compress (Dave's call Oct 8 2026).
app.use(compression({ threshold: 0 }));

// CORS: the web app runs on a different origin in dev (and may be
// served separately in prod). Pragmatic V2: allow the configured origin,
// defaulting to * for dev. Credentials are not used (x-llama-user header).
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-llama-user");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: "1mb" }));

// ---------------- helpers ----------------

function httpError(status, code, message) {
  const err = new Error(message);
  err.status = status;
  err.code = code;
  return err;
}

// Cursor = base64url("<created_at>:<id>"). Keyset pagination over the
// total order (created_at DESC, id DESC): stable, no skipped/dupe rows,
// O(log n) via the composite indexes. Never OFFSET (slow at 100k+ rows).
function encodeCursor(created_at, id) {
  return Buffer.from(`${created_at}:${id}`).toString("base64url");
}

function decodeCursor(cursor) {
  try {
    const raw = Buffer.from(String(cursor), "base64url").toString("utf8");
    const [ts, id] = raw.split(":");
    const created_at = Number(ts);
    if (!Number.isInteger(created_at) || created_at <= 0 || !id) throw new Error("bad cursor");
    return { created_at, id };
  } catch {
    throw httpError(400, "INVALID_CURSOR", "cursor is malformed");
  }
}

function pageParams(req) {
  const limit = Math.min(Math.max(parseInt(req.query.limit || "20", 10) || 20, 1), 50);
  const cursor = req.query.cursor ? decodeCursor(req.query.cursor) : null;
  return { limit, cursor };
}

// Caller identity. V2 pragmatic: trusted header. V2.5: signed tokens.
function callerId(req) {
  const id = req.header("x-llama-user");
  if (!id) throw httpError(401, "UNAUTHENTICATED", "missing x-llama-user");
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw httpError(401, "UNAUTHENTICATED", "malformed caller id");
  return id.toLowerCase();
}

// Optional caller (public reads don't require auth).
function maybeCallerId(req) {
  try {
    return callerId(req);
  } catch {
    return null;
  }
}

function validateUuid(id, name = "id") {
  if (!/^[0-9a-f-]{36}$/i.test(String(id))) throw httpError(400, "INVALID_ID", `invalid ${name}`);
  return String(id).toLowerCase();
}

async function getProfileById(id) {
  const r = await query("SELECT * FROM profiles WHERE id = $1", [id]);
  return r.rows[0] || null;
}

async function getProfileByHandle(handle) {
  const r = await query("SELECT * FROM profiles WHERE lower(handle) = lower($1)", [handle]);
  return r.rows[0] || null;
}

// Shape a tweet row for the API: always includes created_at (never null),
// author embedded, counts as numbers. `liked` = whether the caller liked it.
function shapeTweet(row, liked = false, reposted = false) {
  return {
    id: row.id,
    author: {
      id: row.author_id,
      handle: row.handle,
      display_name: row.display_name,
      avatar_url: row.avatar_url,
    },
    text: row.text,
    html: row.html,
    image_url: row.image_url,
    reply_to_id: row.reply_to_id,
    hashtags: row.hashtags || [],
    likes_count: row.likes_count,
    replies_count: row.replies_count,
    reposts_count: row.reposts_count,
    created_at: row.created_at,
    liked: !!liked,
    reposted: !!reposted,
  };
}

// Attach per-caller liked/reposted state to tweet rows with single queries.
// No SQL changes: keeps every existing SELECT untouched.
async function withLiked(rows, caller) {
  if (!caller || rows.length === 0) return rows.map((r) => shapeTweet(r));
  const ids = rows.map((r) => r.id);
  const lr = await query(
    "SELECT tweet_id FROM likes WHERE user_id = $1 AND tweet_id = ANY($2::uuid[])",
    [caller, ids]
  );
  const liked = new Set(lr.rows.map((r) => r.tweet_id));
  let reposted = new Set();
  try {
    const rr = await query(
      "SELECT tweet_id FROM reposts WHERE user_id = $1 AND tweet_id = ANY($2::uuid[])",
      [caller, ids]
    );
    reposted = new Set(rr.rows.map((r) => r.tweet_id));
  } catch {
    // reposts table may not exist yet on old DBs; treat as none reposted
  }
  return rows.map((r) => shapeTweet(r, liked.has(r.id), reposted.has(r.id)));
}

const TWEET_SELECT = `
  SELECT t.*, p.handle, p.display_name, p.avatar_url
  FROM tweets t JOIN profiles p ON p.id = t.author_id`;

// ---------------- health ----------------

app.get("/api/v2/health", (req, res) => {
  res.json({ ok: true, version: "2.0.0" });
});

// ---------------- tweets ----------------

// GET /api/v2/tweets?cursor=&limit=&sort= — main feed.
// sort=chron (default): newest first.
// sort=foryou: engagement-weighted mix of recent tweets, shuffled with a
//   daily seed so it feels fresh each day but stable within a day.
//   (Dave's call Oct 8 2026: "make it interesting for people that sign in")
app.get("/api/v2/tweets", async (req, res, next) => {
  try {
    const { limit, cursor } = pageParams(req);
    const sort = req.query.sort === "foryou" ? "foryou" : "chron";

    const params = [];
    let where = "WHERE t.reply_to_id IS NULL";
    if (cursor) {
      where += " AND (t.created_at, t.id) < ($1, $2)";
      params.push(cursor.created_at, cursor.id);
    }
    params.push(limit + 1);
    // Dave's call Oct 9 2026: pure chronological, no algorithmic sorting.
    // Both "For you" and "Following" show newest first.
    let orderBy = "ORDER BY t.created_at DESC, t.id DESC";
    const r = await query(
      `${TWEET_SELECT} ${where} ${orderBy} LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit
        ? encodeCursor(rows[rows.length - 1].created_at, rows[rows.length - 1].id)
        : null;
    res.json({ tweets: await withLiked(rows, maybeCallerId(req)), next_cursor });
  } catch (e) {
    next(e);
  }
});

// GET /api/v2/tweets/random — 30 random tweets for the shuffle button.
// Dave's call Oct 9 2026: "a little random button... randomly grabbed 30 tweets."
app.get("/api/v2/tweets/random", async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(parseInt(String(req.query.limit || "30"), 10) || 30, 1), 50);
    const r = await query(
      `${TWEET_SELECT} WHERE t.reply_to_id IS NULL ORDER BY RANDOM() LIMIT $1`,
      [limit]
    );
    res.json({ tweets: await withLiked(r.rows, maybeCallerId(req)) });
  } catch (e) {
    next(e);
  }
});

// POST /api/v2/tweets — idempotent create. Server stamps created_at.
app.post("/api/v2/tweets", async (req, res, next) => {
  try {
    const author_id = callerId(req);
    const id = validateUuid(req.body.id, "tweet id");
    const text = String(req.body.text || "").trim();
    const reply_to_id = req.body.reply_to_id ? validateUuid(req.body.reply_to_id, "reply_to_id") : null;
    let image_url = null;
    if (req.body.image_url) {
      const u = String(req.body.image_url);
      if (!/^https:\/\//.test(u) || u.length > 512) throw httpError(400, "INVALID_IMAGE_URL", "bad image_url");
      image_url = u;
    }
    if (!text && !image_url) throw httpError(400, "EMPTY_TEXT", "text or image is required");
    if (text.length > 2000) throw httpError(400, "TEXT_TOO_LONG", "max 2000 chars");

    const author = await getProfileById(author_id);
    if (!author) throw httpError(404, "AUTHOR_NOT_FOUND", "caller profile does not exist");

    if (reply_to_id) {
      const parent = await query("SELECT id FROM tweets WHERE id = $1", [reply_to_id]);
      if (!parent.rows[0]) throw httpError(404, "PARENT_NOT_FOUND", "reply target does not exist");
    }

    const ts = nowMs(); // THE stamp. Client value ignored entirely.
    const hashtags = extractHashtags(text);
    const html = renderHtml(text);

    // Idempotent: same id -> return existing row, never a duplicate.
    // (This is what kills the V1 "POOF then double post" bug.)
    const r = await query(
      `INSERT INTO tweets (id, author_id, text, html, image_url, reply_to_id, hashtags, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)
       ON CONFLICT (id) DO NOTHING
       RETURNING id`,
      [id, author_id, text, html, image_url, reply_to_id, hashtags, ts]
    );
    const existing = r.rows[0]
      ? null
      : (await query(`${TWEET_SELECT} WHERE t.id = $1`, [id])).rows[0];
    if (existing && existing.author_id !== author_id) {
      throw httpError(409, "ID_CONFLICT", "tweet id already used by another author");
    }
    const row = r.rows[0]
      ? (await query(`${TWEET_SELECT} WHERE t.id = $1`, [id])).rows[0]
      : existing;
    // Notifications: reply → notify parent author
    if (r.rows[0] && reply_to_id) {
      const parent = await query("SELECT author_id FROM tweets WHERE id = $1", [reply_to_id]);
      if (parent.rows[0]) {
        await notify({ user_id: parent.rows[0].author_id, actor_id: author_id, type: "reply", tweet_id: id }).catch(() => {});
      }
    }
    res.status(r.rows[0] ? 201 : 200).json({ tweet: shapeTweet(row), deduped: !r.rows[0] });
  } catch (e) {
    next(e);
  }
});

// GET /api/v2/tweets/:id — tweet + parent + replies (thread context).
app.get("/api/v2/tweets/:id", async (req, res, next) => {
  try {
    const id = validateUuid(req.params.id, "tweet id");
    const t = await query(`${TWEET_SELECT} WHERE t.id = $1`, [id]);
    if (!t.rows[0]) throw httpError(404, "NOT_FOUND", "tweet not found");
    const tweet = t.rows[0];
    let parentRow = null;
    if (tweet.reply_to_id) {
      const p = await query(`${TWEET_SELECT} WHERE t.id = $1`, [tweet.reply_to_id]);
      if (p.rows[0]) parentRow = p.rows[0];
    }
    // Get all descendant replies (not just direct) for proper threading
    const replies = await query(
      `WITH RECURSIVE thread AS (
         SELECT t.* FROM tweets t WHERE t.reply_to_id = $1
         UNION ALL
         SELECT t.* FROM tweets t JOIN thread th ON t.reply_to_id = th.id
       )
       ${TWEET_SELECT.replace("FROM tweets t JOIN profiles p", "FROM thread t JOIN profiles p")}
       ORDER BY t.created_at ASC, t.id ASC LIMIT 100`,
      [id]
    );
    const caller = maybeCallerId(req);
    const shaped = await withLiked([tweet, ...(parentRow ? [parentRow] : []), ...replies.rows], caller);
    res.json({
      tweet: shaped[0],
      parent: parentRow ? shaped[1] : null,
      replies: shaped.slice(parentRow ? 2 : 1),
    });
  } catch (e) {
    next(e);
  }
});

// DELETE /api/v2/tweets/:id — author only.
app.delete("/api/v2/tweets/:id", async (req, res, next) => {
  try {
    const me = callerId(req);
    const id = validateUuid(req.params.id, "tweet id");
    const r = await query("DELETE FROM tweets WHERE id = $1 AND author_id = $2", [id, me]);
    if (r.rowCount === 0) throw httpError(404, "NOT_FOUND", "tweet not found or not yours");
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

// PATCH /api/v2/tweets/:id — author only, image_url only. Used to repair
// broken media without touching the server-stamped created_at (Dave's
// timestamp law: the stamp never moves).
app.patch("/api/v2/tweets/:id", async (req, res, next) => {
  try {
    const me = callerId(req);
    const id = validateUuid(req.params.id, "tweet id");
    if (!("image_url" in req.body) && !("text" in req.body)) throw httpError(400, "NOTHING_TO_UPDATE", "image_url or text required");
    let image_url = null;
    let text = null;
    if (req.body.image_url !== undefined) {
      if (req.body.image_url) {
        const u = String(req.body.image_url);
        if (!/^https:\/\//.test(u) || u.length > 512) throw httpError(400, "INVALID_IMAGE_URL", "bad image_url");
        image_url = u;
      }
    }
    if (req.body.text !== undefined) {
      text = String(req.body.text).slice(0, 500);
    }
    const r = await query(
      `${TWEET_SELECT} WHERE t.id = $1 AND t.author_id = $2`,
      [id, me]
    );
    if (!r.rows[0]) throw httpError(404, "NOT_FOUND", "tweet not found or not yours");
    const sets = [];
    const params = [];
    if (image_url !== null || "image_url" in req.body) { params.push(image_url); sets.push(`image_url = $${params.length}`); }
    if (text !== null) { params.push(text); sets.push(`text = $${params.length}`); }
    params.push(nowMs()); sets.push(`updated_at = $${params.length}`);
    params.push(id);
    await query(`UPDATE tweets SET ${sets.join(", ")} WHERE id = $${params.length}`, params);
    const t = await query(`${TWEET_SELECT} WHERE t.id = $1`, [id]);
    res.json({ tweet: (await withLiked(t.rows, me))[0] });
  } catch (e) {
    next(e);
  }
});

// ---------------- profiles ----------------

app.get("/api/v2/profiles/:handle", async (req, res, next) => {
  try {
    const p = await getProfileByHandle(req.params.handle);
    if (!p) throw httpError(404, "NOT_FOUND", "profile not found");
    const me = maybeCallerId(req);
    let following = false;
    if (me && me !== p.id) {
      const f = await query("SELECT 1 FROM follows WHERE follower_id = $1 AND following_id = $2", [me, p.id]);
      following = !!f.rows[0];
    }
    res.json({ profile: { ...p, following } });
  } catch (e) {
    next(e);
  }
});


app.patch("/api/v2/profiles/:handle", async (req, res, next) => {
  try {
    const me = callerId(req);
    const p = await getProfileByHandle(req.params.handle);
    if (!p) throw httpError(404, "NOT_FOUND", "profile not found");
    if (p.id !== me) throw httpError(403, "FORBIDDEN", "you can only edit your own profile");
    const allowed = ["display_name", "bio", "avatar_url", "banner_url", "link_url", "link_label"];
    const sets = [];
    const params = [];
    for (const k of allowed) {
      if (req.body[k] !== undefined) {
        const v = req.body[k] === null ? null : String(req.body[k]).slice(0, 512);
        params.push(v);
        sets.push(`${k} = $${params.length}`);
      }
    }
    if (!sets.length) throw httpError(400, "EMPTY_PATCH", "nothing to update");
    params.push(nowMs(), p.id);
    sets.push(`updated_at = $${params.length - 1}`);
    const r = await query(
      `UPDATE profiles SET ${sets.join(", ")} WHERE id = $${params.length} RETURNING *`,
      params
    );
    res.json({ profile: r.rows[0] });
  } catch (e) {
    next(e);
  }
});

// GET /api/v2/profiles/:handle/tweets?tab=posts|replies|media|likes
app.get("/api/v2/profiles/:handle/tweets", async (req, res, next) => {
  try {
    const p = await getProfileByHandle(req.params.handle);
    if (!p) throw httpError(404, "NOT_FOUND", "profile not found");
    const { limit, cursor } = pageParams(req);
    const tab = req.query.tab || "posts";
    if (!["posts", "replies", "media", "likes"].includes(tab)) {
      throw httpError(400, "INVALID_TAB", "tab must be posts|replies|media|likes");
    }
    const params = [p.id];
    let where = "t.author_id = $1";
    let join = "";
    if (tab === "replies") where += " AND t.reply_to_id IS NOT NULL";
    else if (tab === "posts") where += " AND t.reply_to_id IS NULL";
    else if (tab === "media") where += " AND t.image_url IS NOT NULL";
    else if (tab === "likes") {
      join = "JOIN likes l ON l.tweet_id = t.id";
      where = "l.user_id = $1";
    }
    if (cursor) {
      params.push(cursor.created_at, cursor.id);
      where += ` AND (t.created_at, t.id) < ($${params.length - 1}, $${params.length})`;
    }
    params.push(limit + 1);
    const r = await query(
      `${TWEET_SELECT} ${join} WHERE ${where} ORDER BY t.created_at DESC, t.id DESC LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit
        ? encodeCursor(rows[rows.length - 1].created_at, rows[rows.length - 1].id)
        : null;
    res.json({ tweets: await withLiked(rows, maybeCallerId(req)), next_cursor });
  } catch (e) {
    next(e);
  }
});

// ---------------- hashtags ----------------

// GET /api/v2/hashtags/:tag — server-side index, paginated. (V1 did this
// client-side and broke when userPosts hadn't loaded.)
app.get("/api/v2/hashtags/:tag", async (req, res, next) => {
  try {
    const tag = String(req.params.tag).toLowerCase().replace(/^#/, "");
    if (!/^[a-z0-9_]{1,64}$/.test(tag)) throw httpError(400, "INVALID_TAG", "bad hashtag");
    const { limit, cursor } = pageParams(req);
    const params = [tag];
    let where = "$1 = ANY(t.hashtags)";
    if (cursor) {
      params.push(cursor.created_at, cursor.id);
      where += ` AND (t.created_at, t.id) < ($${params.length - 1}, $${params.length})`;
    }
    params.push(limit + 1);
    const r = await query(
      `${TWEET_SELECT} WHERE ${where} ORDER BY t.created_at DESC, t.id DESC LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit
        ? encodeCursor(rows[rows.length - 1].created_at, rows[rows.length - 1].id)
        : null;
    res.json({ tag, tweets: await withLiked(rows, maybeCallerId(req)), next_cursor });
  } catch (e) {
    next(e);
  }
});

// GET /api/v2/trending — trending hashtags by REAL post volume (last 7
// days). Spec section 7: computed from actual volume, never hardcoded.
// Public, no cursor: a short ranked list.
app.get("/api/v2/trending", async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit || "10", 10) || 10, 1), 25);
    const r = await query(
      `SELECT tag, count(*)::int AS post_count, max(t.created_at)::bigint AS last_used_at
       FROM tweets t, LATERAL unnest(t.hashtags) AS tag
       WHERE t.created_at >= $1
       GROUP BY tag
       ORDER BY post_count DESC, last_used_at DESC
       LIMIT $2`,
      [Date.now() - 7 * 24 * 3600 * 1000, limit]
    );
    res.json({ trends: r.rows });
  } catch (e) {
    next(e);
  }
});

// ---------------- search ----------------

app.get("/api/v2/search", async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim().slice(0, 120);
    if (!q) throw httpError(400, "EMPTY_QUERY", "q is required");
    const type = req.query.type || "all";
    if (!["all", "tweets", "users", "hashtags"].includes(type)) {
      throw httpError(400, "INVALID_TYPE", "type must be all|tweets|users|hashtags");
    }
    const limit = Math.min(Math.max(parseInt(req.query.limit || "20", 10) || 20, 1), 50);
    const out = {};
    if (type === "all" || type === "tweets") {
      const r = await query(
        `${TWEET_SELECT} WHERE t.search_vector @@ plainto_tsquery('english', $1)
         OR $1 = ANY(t.hashtags)
         OR EXISTS (SELECT 1 FROM unnest(t.hashtags) h WHERE h ILIKE $1)
         ORDER BY t.created_at DESC LIMIT $2`,
        [q, limit]
      );
      out.tweets = await withLiked(r.rows, maybeCallerId(req));
    }
    if (type === "all" || type === "users") {
      const r = await query(
        `SELECT * FROM profiles
         WHERE handle ILIKE $1 OR display_name ILIKE $1
         ORDER BY followers_count DESC LIMIT $2`,
        [`%${q}%`, limit]
      );
      out.users = r.rows;
    }
    if (type === "all" || type === "hashtags") {
      const r = await query(
        `SELECT tag, count(*)::int AS count FROM (
           SELECT unnest(hashtags) AS tag FROM tweets
         ) s WHERE tag ILIKE $1 GROUP BY tag ORDER BY count DESC LIMIT $2`,
        [`%${q.toLowerCase()}%`, limit]
      );
      out.hashtags = r.rows;
    }
    res.json(out);
  } catch (e) {
    next(e);
  }
});

// ---------------- follows ----------------

app.post("/api/v2/follows", async (req, res, next) => {
  try {
    const me = callerId(req);
    const following_id = validateUuid(req.body.following_id, "following_id");
    if (following_id === me) throw httpError(400, "SELF_FOLLOW", "you cannot follow yourself");
    const target = await getProfileById(following_id);
    if (!target) throw httpError(404, "NOT_FOUND", "profile not found");
    await query(
      "INSERT INTO follows (follower_id, following_id, created_at) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING",
      [me, following_id, nowMs()]
    );
    res.status(201).json({ ok: true });
  } catch (e) {
    next(e);
  }
});

app.delete("/api/v2/follows/:user_id", async (req, res, next) => {
  try {
    const me = callerId(req);
    const following_id = validateUuid(req.params.user_id, "user id");
    await query("DELETE FROM follows WHERE follower_id = $1 AND following_id = $2", [me, following_id]);
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

async function followList(req, res, next, dir) {
  try {
    const p = await getProfileByHandle(req.params.handle);
    if (!p) throw httpError(404, "NOT_FOUND", "profile not found");
    const { limit, cursor } = pageParams(req);
    // Cursor over follows.created_at for stable pagination.
    const params = [p.id];
    let where = dir === "followers" ? "f.following_id = $1" : "f.follower_id = $1";
    const joinCol = dir === "followers" ? "f.follower_id" : "f.following_id";
    if (cursor) {
      params.push(cursor.created_at, cursor.id);
      where += ` AND (f.created_at, p2.id) < ($${params.length - 1}, $${params.length})`;
    }
    params.push(limit + 1);
    const r = await query(
      `SELECT p2.*, f.created_at AS fc FROM follows f
       JOIN profiles p2 ON p2.id = ${joinCol}
       WHERE ${where} ORDER BY f.created_at DESC, p2.id DESC LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit ? encodeCursor(rows[rows.length - 1].fc, rows[rows.length - 1].id) : null;
    res.json({ users: rows, next_cursor });
  } catch (e) {
    next(e);
  }
}

app.get("/api/v2/profiles/:handle/followers", (req, res, next) => followList(req, res, next, "followers"));
app.get("/api/v2/profiles/:handle/following", (req, res, next) => followList(req, res, next, "following"));

// ---------------- likes ----------------

// POST /api/v2/likes — like a tweet. Idempotent: liking twice is one like.
app.post("/api/v2/likes", async (req, res, next) => {
  try {
    const me = callerId(req);
    const tweet_id = validateUuid(req.body.tweet_id, "tweet_id");
    const t = await query("SELECT id FROM tweets WHERE id = $1", [tweet_id]);
    if (!t.rows[0]) throw httpError(404, "NOT_FOUND", "tweet not found");
    await query(
      "INSERT INTO likes (user_id, tweet_id, created_at) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING",
      [me, tweet_id, nowMs()]
    );
    await query(
      "UPDATE tweets SET likes_count = (SELECT COUNT(*) FROM likes WHERE tweet_id = $1) WHERE id = $1",
      [tweet_id]
    );
    // Notify tweet author
    const author = await query("SELECT author_id FROM tweets WHERE id = $1", [tweet_id]);
    if (author.rows[0]) {
      await notify({ user_id: author.rows[0].author_id, actor_id: me, type: "like", tweet_id }).catch(() => {});
    }
    const row = await query(`${TWEET_SELECT} WHERE t.id = $1`, [tweet_id]);
    res.status(201).json({ tweet: shapeTweet(row.rows[0], true) });
  } catch (e) {
    next(e);
  }
});

// POST /api/v2/reposts — repost a tweet. Idempotent.
app.post("/api/v2/reposts", async (req, res, next) => {
  try {
    const me = callerId(req);
    const tweet_id = validateUuid(req.body.tweet_id, "tweet_id");
    const t = await query("SELECT id FROM tweets WHERE id = $1", [tweet_id]);
    if (!t.rows[0]) throw httpError(404, "NOT_FOUND", "tweet not found");
    await query(
      "INSERT INTO reposts (user_id, tweet_id, created_at) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING",
      [me, tweet_id, nowMs()]
    );
    await query(
      "UPDATE tweets SET reposts_count = (SELECT COUNT(*) FROM reposts WHERE tweet_id = $1) WHERE id = $1",
      [tweet_id]
    );
    // Notify tweet author
    const author = await query("SELECT author_id FROM tweets WHERE id = $1", [tweet_id]);
    if (author.rows[0]) {
      await notify({ user_id: author.rows[0].author_id, actor_id: me, type: "repost", tweet_id }).catch(() => {});
    }
    const row = await query(`${TWEET_SELECT} WHERE t.id = $1`, [tweet_id]);
    res.status(201).json({ tweet: shapeTweet(row.rows[0], false, true) });
  } catch (e) {
    next(e);
  }
});

// DELETE /api/v2/reposts/:tweet_id — un-repost. Idempotent.
app.delete("/api/v2/reposts/:tweet_id", async (req, res, next) => {
  try {
    const me = callerId(req);
    const tweet_id = validateUuid(req.params.tweet_id, "tweet id");
    await query("DELETE FROM reposts WHERE user_id = $1 AND tweet_id = $2", [me, tweet_id]);
    await query(
      "UPDATE tweets SET reposts_count = (SELECT COUNT(*) FROM reposts WHERE tweet_id = $1) WHERE id = $1",
      [tweet_id]
    );
    const row = await query(`${TWEET_SELECT} WHERE t.id = $1`, [tweet_id]);
    res.json({ tweet: row.rows[0] ? shapeTweet(row.rows[0], false, false) : null });
  } catch (e) {
    next(e);
  }
});

// DELETE /api/v2/likes/:tweet_id — unlike. Idempotent.
app.delete("/api/v2/likes/:tweet_id", async (req, res, next) => {
  try {
    const me = callerId(req);
    const tweet_id = validateUuid(req.params.tweet_id, "tweet id");
    await query("DELETE FROM likes WHERE user_id = $1 AND tweet_id = $2", [me, tweet_id]);
    await query(
      "UPDATE tweets SET likes_count = (SELECT COUNT(*) FROM likes WHERE tweet_id = $1) WHERE id = $1",
      [tweet_id]
    );
    const row = await query(`${TWEET_SELECT} WHERE t.id = $1`, [tweet_id]);
    res.json({ tweet: row.rows[0] ? shapeTweet(row.rows[0], false) : null });
  } catch (e) {
    next(e);
  }
});

// ---------------- DMs ----------------

app.get("/api/v2/conversations", async (req, res, next) => {
  try {
    const me = callerId(req);
    const { limit, cursor } = pageParams(req);
    const params = [me];
    let where = "cp.user_id = $1";
    if (cursor) {
      params.push(cursor.created_at, cursor.id);
      where += ` AND (c.updated_at, c.id) < ($${params.length - 1}, $${params.length})`;
    }
    params.push(limit + 1);
    const r = await query(
      `SELECT c.*, (
         SELECT json_agg(json_build_object('id', p.id, 'handle', p.handle,
           'display_name', p.display_name, 'avatar_url', p.avatar_url))
         FROM conversation_participants cp2 JOIN profiles p ON p.id = cp2.user_id
         WHERE cp2.conversation_id = c.id AND cp2.user_id <> $1
       ) AS others,
       (SELECT m.text FROM messages m WHERE m.conversation_id = c.id
        ORDER BY m.created_at DESC LIMIT 1) AS last_text,
       (cp.last_read_at IS NULL OR c.updated_at > cp.last_read_at) AS unread
       FROM conversations c JOIN conversation_participants cp ON cp.conversation_id = c.id
       WHERE ${where} ORDER BY c.updated_at DESC, c.id DESC LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit
        ? encodeCursor(rows[rows.length - 1].updated_at, rows[rows.length - 1].id)
        : null;
    res.json({ conversations: rows, next_cursor });
  } catch (e) {
    next(e);
  }
});

// POST /api/v2/conversations — find-or-create by exact participant set.
app.post("/api/v2/conversations", async (req, res, next) => {
  try {
    const me = callerId(req);
    const ids = [...new Set([me, ...(req.body.participant_ids || []).map((x) => validateUuid(x, "participant"))])];
    if (ids.length < 2) throw httpError(400, "TOO_FEW", "need at least 2 participants");
    if (ids.length > 20) throw httpError(400, "TOO_MANY", "max 20 participants");
    for (const id of ids) {
      if (!(await getProfileById(id))) throw httpError(404, "NOT_FOUND", `profile ${id} not found`);
    }
    // Find existing conversation with EXACTLY this participant set.
    const existing = await query(
      `SELECT c.id FROM conversations c
       WHERE NOT EXISTS (
         SELECT 1 FROM conversation_participants cp
         WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY($1))
       ) AND (SELECT count(*) FROM conversation_participants cp2
              WHERE cp2.conversation_id = c.id) = $2
       LIMIT 1`,
      [ids, ids.length]
    );
    if (existing.rows[0]) return res.json({ conversation: existing.rows[0], deduped: true });
    const ts = nowMs();
    const c = await query("INSERT INTO conversations (created_at, updated_at) VALUES ($1,$1) RETURNING *", [ts]);
    for (const id of ids) {
      await query(
        "INSERT INTO conversation_participants (conversation_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
        [c.rows[0].id, id]
      );
    }
    res.status(201).json({ conversation: c.rows[0], deduped: false });
  } catch (e) {
    next(e);
  }
});

app.get("/api/v2/conversations/:id/messages", async (req, res, next) => {
  try {
    const me = callerId(req);
    const conv_id = validateUuid(req.params.id, "conversation id");
    const part = await query(
      "SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2",
      [conv_id, me]
    );
    if (!part.rows[0]) throw httpError(403, "FORBIDDEN", "not a participant");
    const { limit, cursor } = pageParams(req);
    const params = [conv_id];
    let where = "m.conversation_id = $1";
    if (cursor) {
      params.push(cursor.created_at, cursor.id);
      where += ` AND (m.created_at, m.id) < ($${params.length - 1}, $${params.length})`;
    }
    params.push(limit + 1);
    const r = await query(
      `SELECT m.*, p.handle, p.display_name, p.avatar_url FROM messages m
       JOIN profiles p ON p.id = m.sender_id
       WHERE ${where} ORDER BY m.created_at DESC, m.id DESC LIMIT $${params.length}`,
      params
    );
    const rows = r.rows.slice(0, limit);
    const next_cursor =
      r.rows.length > limit
        ? encodeCursor(rows[rows.length - 1].created_at, rows[rows.length - 1].id)
        : null;
    // Mark read (best-effort).
    query("UPDATE conversation_participants SET last_read_at = $1 WHERE conversation_id = $2 AND user_id = $3", [
      nowMs(),
      conv_id,
      me,
    ]).catch(() => {});
    res.json({ messages: rows, next_cursor });
  } catch (e) {
    next(e);
  }
});

app.post("/api/v2/conversations/:id/messages", async (req, res, next) => {
  try {
    const me = callerId(req);
    const conv_id = validateUuid(req.params.id, "conversation id");
    const part = await query(
      "SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2",
      [conv_id, me]
    );
    if (!part.rows[0]) throw httpError(403, "FORBIDDEN", "not a participant");
    const id = validateUuid(req.body.id, "message id");
    const text = String(req.body.text || "").trim();
    if (!text) throw httpError(400, "EMPTY_TEXT", "text is required");
    if (text.length > 2000) throw httpError(400, "TEXT_TOO_LONG", "max 2000 chars");
    const ts = nowMs();
    const r = await query(
      `INSERT INTO messages (id, conversation_id, sender_id, text, created_at)
       VALUES ($1,$2,$3,$4,$5) ON CONFLICT (id) DO NOTHING RETURNING id`,
      [id, conv_id, me, text, ts]
    );
    const row = (
      await query(
        `SELECT m.*, p.handle, p.display_name, p.avatar_url FROM messages m
         JOIN profiles p ON p.id = m.sender_id WHERE m.id = $1`,
        [id]
      )
    ).rows[0];
    res.status(r.rows[0] ? 201 : 200).json({ message: row, deduped: !r.rows[0] });
  } catch (e) {
    next(e);
  }
});

// ---------------- uploads ----------------

// Image upload via Vercel Blob. Client downscales to <=1600px WebP first,
// then POSTs multipart form: `file` (the bytes) + `kind` (tweet|avatar|dm).
// Response: `{ image_url }` — the public blob URL, stored on the tweet.
app.post("/api/v2/uploads", upload.single("file"), async (req, res, next) => {
  try {
    callerId(req); // must be signed in to upload
    if (!req.file) {
      const err = new Error("missing file field");
      err.status = 400;
      err.code = "MISSING_FILE";
      throw err;
    }
    const { image_url } = await uploadToBlob({
      buffer: req.file.buffer,
      content_type: req.file.mimetype,
      kind: req.body.kind || "tweet",
    });
    res.status(201).json({ image_url });
  } catch (e) {
    next(e);
  }
});

// ---------------- notifications ----------------

// Helper: create a notification (no-op if actor == target)
async function notify({ user_id, actor_id, type, tweet_id = null }) {
  if (!user_id || !actor_id || user_id === actor_id) return;
  const id = require("crypto").randomUUID();
  await query(
    "INSERT INTO notifications (id, user_id, actor_id, type, tweet_id, created_at) VALUES ($1,$2,$3,$4,$5,$6)",
    [id, user_id, actor_id, type, tweet_id, Date.now()]
  );
}

// GET /api/v2/notifications — list my notifications, newest first
app.get("/api/v2/notifications", async (req, res, next) => {
  try {
    const me = callerId(req);
    const limit = Math.min(Math.max(parseInt(req.query.limit || "20", 10) || 20, 1), 50);
    const r = await query(
      `SELECT n.*, p.handle AS actor_handle, p.display_name AS actor_name, p.avatar_url AS actor_avatar,
              t.text AS tweet_text
       FROM notifications n
       JOIN profiles p ON p.id = n.actor_id
       LEFT JOIN tweets t ON t.id = n.tweet_id
       WHERE n.user_id = $1
       ORDER BY n.created_at DESC LIMIT $2`,
      [me, limit]
    );
    res.json({ notifications: r.rows });
  } catch (e) { next(e); }
});

// POST /api/v2/notifications/read — mark all as read
app.post("/api/v2/notifications/read", async (req, res, next) => {
  try {
    const me = callerId(req);
    await query("UPDATE notifications SET read_at = $1 WHERE user_id = $2 AND read_at IS NULL", [Date.now(), me]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// GET /api/v2/notifications/unread-count — badge count
app.get("/api/v2/notifications/unread-count", async (req, res, next) => {
  try {
    const me = callerId(req);
    const r = await query("SELECT COUNT(*)::int AS c FROM notifications WHERE user_id = $1 AND read_at IS NULL", [me]);
    res.json({ count: r.rows[0].c });
  } catch (e) { next(e); }
});

// ---------------- errors ----------------

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || 500;
  const code = err.code || "INTERNAL";
  if (status >= 500) console.error("[api]", err);
  res.status(status).json({ error: { code, message: err.message || "internal error" } });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  

app.listen(PORT, () => console.log(`[api] llamachat v2 listening on :${PORT}`));
}

module.exports = app;
