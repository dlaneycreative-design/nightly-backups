import { useEffect, useState } from "react";
import {
  baseYouBoobInfo,
  extractYouBoobId,
  resolveYouBoobInfo,
  type YouBoobInfo,
} from "../lib/youboob.ts";

/**
 * Preview for a pasted YouBoob watch link (Dave, Nov 1 2026: "make
 * sure the preview shows for any YouBoob video"). At rest it is the
 * video's poster with a big red Play button and the title underneath,
 * like the !Game embeds: nothing heavy loads until Play is tapped.
 * Tapping Play swaps in the real player right in the post: the
 * YouTube embed for yt- videos, a plain <video> for YouBoob's own
 * films. A video we cannot resolve still gets a card that links out
 * to its YouBoob watch page. Clicks inside never open the thread.
 */
export function YouBoobEmbed({ text }: { text: string }) {
  const id = extractYouBoobId(text);
  const [info, setInfo] = useState<YouBoobInfo | null>(() => (id ? baseYouBoobInfo(id) : null));
  const [playing, setPlaying] = useState(false);
  const [thumbOk, setThumbOk] = useState(true);

  // yt- titles arrive async (YouBoob catalogs, then YouTube oEmbed);
  // native films already know theirs from the base info.
  useEffect(() => {
    if (!id) return;
    let live = true;
    resolveYouBoobInfo(text)
      .then((full) => {
        if (live && full) setInfo(full);
      })
      .catch(() => {
        /* base info is enough to preview and play */
      });
    return () => {
      live = false;
    };
  }, [text, id]);

  if (!id || !info) return null;
  const title = info.title || "YouBoob video";
  const playable = !!info.ytId || !!info.srcUrl;

  return (
    <div className="yb-embed" onClick={(e) => e.stopPropagation()}>
      {playing && info.ytId ? (
        <div className="yb-frame-wrap">
          <iframe
            className="yb-frame"
            src={`https://www.youtube-nocookie.com/embed/${info.ytId}?autoplay=1&rel=0`}
            title={`${title} on YouBoob`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            loading="lazy"
          />
        </div>
      ) : playing && info.srcUrl ? (
        <video
          className="yb-video"
          src={info.srcUrl}
          poster={info.thumbUrl || undefined}
          controls
          autoPlay
          playsInline
          preload="metadata"
        />
      ) : playable ? (
        <button
          type="button"
          className="yb-cover"
          aria-label={`Play ${title}`}
          onClick={() => setPlaying(true)}
        >
          {info.thumbUrl && thumbOk ? (
            <img
              src={info.thumbUrl}
              alt={`${title} poster`}
              loading="lazy"
              decoding="async"
              onError={() => setThumbOk(false)}
            />
          ) : (
            <span className="yb-cover-fallback" aria-hidden="true">YouBoob</span>
          )}
          <span className="yb-play-btn" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z" /></svg>
          </span>
          {info.duration ? <span className="yb-dur">{info.duration}</span> : null}
        </button>
      ) : (
        <a className="yb-cover yb-cover-link" href={info.pageUrl} target="_blank" rel="noopener">
          <span className="yb-cover-fallback" aria-hidden="true">YouBoob</span>
          <span className="yb-play-btn" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z" /></svg>
          </span>
        </a>
      )}
      <div className="yb-foot">
        <span className="yb-title">
          {title}
          {info.channel ? <span className="yb-channel"> · {info.channel}</span> : null}
        </span>
        <a className="yb-watch" href={info.pageUrl} target="_blank" rel="noopener" onClick={(e) => e.stopPropagation()}>
          <img className="yb-booby" src="/booby-avatar.webp" alt="" aria-hidden="true" width="20" height="20" />
          Watch on YouBoob ↗
        </a>
      </div>
    </div>
  );
}
