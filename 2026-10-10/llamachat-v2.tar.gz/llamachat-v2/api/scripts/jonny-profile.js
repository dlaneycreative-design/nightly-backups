const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
// build handle from char codes to avoid any text-layer case mangling: j-o-n-n-y
const handle = String.fromCharCode(106, 111, 110, 110, 121);
(async () => {
  const ts = Date.now();
  const r = await sql.query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(), $1, 'Johnny', 'https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/johnny-tweets/johnny-avatar.webp', 'Rent superfan. Musicals can change the world. A tribute to Jonathan Larson.', 'https://www.thestudio.io/e2/people/jonathanlarson/', 'The tribute', $2, $2)
     ON CONFLICT (handle) DO NOTHING RETURNING id`,
    [handle, ts]
  );
  if (r.length) console.log("created johnny:", r[0].id);
  else {
    const e = await sql`SELECT id, display_name FROM profiles WHERE handle = ${handle}`;
    console.log("johnny already exists:", e[0].id, e[0].display_name);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
