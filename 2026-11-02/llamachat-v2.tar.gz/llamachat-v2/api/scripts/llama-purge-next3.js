// Deletes the next batch (max 3) of @llama's OLD tweets via the API.
// Dave's order Nov 1 2026: delete all the other tweets, keep the five new
// aloof ones. The API delete rule (his own Oct 19 safety order) allows 3
// successful deletes per profile per 10 minutes, then LOCKS deletes, so
// this script never attempts a 4th in a run and is meant to be run about
// every 11 minutes until it prints ALL_CLEAN.
// (First attempt went to the frozen Neon copy in error: the live DB is
// Cloudflare D1 since Oct 26, so the API is the only write path.)
const { API_BASE, getProfileId, serviceHeaders, getAuthorTweets, detUuid } = require("./lib/botlib");
async function apiGet(path) { const r = await fetch(`${API_BASE}${path}`); if (!r.ok) throw new Error(`GET ${path} -> ${r.status}`); return r.json(); }

const KEEP_TEXTS = new Set([
  "hi. i'm the llama. i live here now. don't make it weird.",
  "someone asked about my plans today. grass. then standing somewhere else. then more grass.",
  "no update. there was never going to be an update.",
  "i looked at the whole internet this morning. closed it. went back outside.",
  "if you need me, i'll be by the fence. if you don't need me, same fence.",
]);

(async () => {
  const id = await getProfileId("llama");
  const tweets = await getAuthorTweets("llama", 100);
  const old = tweets.filter((t) => !KEEP_TEXTS.has(t.text));
  // the "Baaaa" reply (Oct 31) is not in the profile timeline but counts as a post
  const baaaaId = detUuid("llamachat-v2:bots", "llama-baaaa:a38b9cb9-67b9-4f29-9a5a-26924d303c51");
  const ids = old.map((t) => t.id);
  // only include the reply id while it still exists: probe via its thread parent is
  // overkill; the caller log from Oct 31 plus posts_count 19 vs timeline 18 says it
  // exists. A 404 on it is handled below as already-gone, not a success.
  if (!ids.includes(baaaaId)) ids.push(baaaaId);
  console.log(`[purge] old tweets queued: ${ids.length} (timeline old: ${old.length})`);
  let done = 0;
  for (const tid of ids) {
    if (done >= 3) break;
    const res = await fetch(`${API_BASE}/tweets/${tid}`, { method: "DELETE", headers: serviceHeaders(id) });
    if (res.ok) { done++; console.log(`[purge] deleted ${tid} (${done}/3)`); }
    else if (res.status === 404) { console.log(`[purge] already gone ${tid}`); }
    else { console.log(`[purge] STOP ${tid} -> ${res.status} ${(await res.text()).slice(0, 120)}`); break; }
    await new Promise((r) => setTimeout(r, 1200));
  }
  const tweets2 = await getAuthorTweets("llama", 100);
  const left = tweets2.filter((t) => !KEEP_TEXTS.has(t.text)).length;
  const p = await apiGet(`/profiles/llama`);
  console.log(`[purge] remaining timeline old: ${left} | posts_count: ${p.profile.posts_count}`);
  if (left === 0 && p.profile.posts_count <= 5) console.log("ALL_CLEAN");
})().catch((e) => { console.error("[purge] fatal", e.message); process.exit(1); });
