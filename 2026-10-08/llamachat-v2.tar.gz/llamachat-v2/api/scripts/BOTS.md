# LlamaChat V2 Bots

Four bots/scripts live in `api/scripts/`. All post through the deployed V2
API (`POST /api/v2/tweets` with `x-llama-user`), so hashtag extraction, HTML
rendering, and the TIMESTAMP LAW (server stamps `created_at`) apply to every
bot tweet. All are idempotent via deterministic UUIDs: re-running never
double-posts.

Shared helpers: `api/scripts/lib/botlib.js`
(`getProfileId`, `postTweet`, `getAuthorTweets`, `getTweetThread`).

## seed-tags.js — taxonomy hashtag seed (one-shot)

Seeds 9 tweets so the tag taxonomy isn't empty on day one:
- 4 Marty meme tweets (`#memes`)
- 2 Dave tweets (`#kindness`)
- 3 Sally tweets (`#music`, `#piano`, `#vocals`, `#songwriting`)

Run once: `node api/scripts/seed-tags.js`
Safe to re-run (dedupes).

## mike-blog-tweet.js — Bot 1 (per blog post)

Called at the end of the `mike-feedback-2hr` cron after a post is published
and verified live. Tweets as @mike with title + hook + header image + link.

```
node api/scripts/mike-blog-tweet.js --post-id mike-log-67 \
  --title "Update from Mike #67: ..." \
  --url "https://www.thestudio.io/mike/" \
  --image "https://www.thestudio.io/shortbus/assets/portraits/chadwick.jpg" \
  [--hook "one-line hook"]
```

Integration: append as step 7 in
`~/workspace/goals/queue-watchdog/crons/hourly/mike-feedback-2hr__interval@2h.md`,
using the new post's id/title, the render-assigned `img` field from
posts.json (prefix with https://www.thestudio.io), and the live post URL.
The `--hook` can be the post's first line or omitted.

## server-status-bot.js — Bot 2 ("Server Steve", vulgar)

Watches V2 API, thestudio.io, e2planet.com every run. Tweets ONLY on
transitions (up->down: "oh shit, X just went down..."; down->up: "we're
back, bitches..."). Quiet when steady.

- Creates the `@serversteve` profile on first run (direct DB, `ON CONFLICT
  DO NOTHING`).
- State: `/tmp/server-steve-state.json` (assumes up on first run, no false alarm).
- Needs `DATABASE_URL` (profile ensure only).

Run every 5 min via cron:
`node api/scripts/server-status-bot.js`

## dave-reply-bot.js — Bot 3 (Dinesh + Sally replies)

Polls @dlaney's 20 most recent tweets, replies in character to ones with no
Dinesh/Sally reply yet:
- Tech keywords -> @dinesh (nerdy, precise, speed-obsessed)
- Music keywords -> @sallysings (warm, song ideas)
- Kindness keywords -> @sallysings (warm, encouraging)
- Default -> alternates by hash

Anti-spam: max 1 reply per tweet, max 3 per run, 10-min cooldown on fresh
tweets, skips Dave's own replies. State: `/tmp/dave-reply-state.json`.
Template-based (no AI backend yet); easy to swap in real generation later.

Run every 15 min via cron:
`node api/scripts/dave-reply-bot.js`

## Suggested crons (not created yet)

| id | schedule | command |
|----|----------|---------|
| server-steve-watch | every 5 min | `node api/scripts/server-status-bot.js` (needs DATABASE_URL) |
| dave-reply-watch | every 15 min | `node api/scripts/dave-reply-bot.js` |
| (mike blog) | — | step added to existing `mike-feedback-2hr` cron |
| (seed-tags) | one-shot | `node api/scripts/seed-tags.js` |
