import { useEffect } from "react";

// Dave's E2 Charter Member badge (his order Oct 19 2026): a minted
// founding-member achievement, not a course certificate, so it does
// not come from the sv_issued store; it is presented in the profile
// Achievements row and on the Achievements tab (Starvard skin only).
// The badge image is hosted on-origin under starvard.org/media.
// Shared by ProfileHeader (the chip) and StarvardPanels (the tab row)
// so both open the exact same lightbox.
export const CHARTER_BADGE = {
  handle: "dave",
  img: "https://starvard.org/media/starvard/e2-charter-member.webp",
  imgLarge: "https://starvard.org/media/starvard/e2-charter-member-large.webp",
  label: "E2 Charter Member",
  sub: "First 100",
  url: "https://e2.life/",
};

/** Lightbox for the Charter Member badge (Dave's order Oct 19 2026):
    clicking the badge pops the coin up big. Closes on the X,
    a backdrop click, or Escape; the caller returns focus to the
    element that opened it. */
export function BadgeModal({ onClose }: { onClose: () => void }) {
  // Lock body scroll + close on Escape while the modal is open
  // (same pattern as ComposeModal).
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="sv-badge-backdrop" onClick={onClose} role="presentation">
      <div
        className="sv-badge-modal"
        role="dialog"
        aria-modal="true"
        aria-label={CHARTER_BADGE.label}
        onClick={(e) => e.stopPropagation()}
      >
        <button type="button" className="sv-badge-close" onClick={onClose} aria-label="Close" autoFocus>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
        </button>
        <img className="sv-badge-modal-img" src={CHARTER_BADGE.imgLarge} alt={CHARTER_BADGE.label} />
        <div className="sv-badge-title">{CHARTER_BADGE.label}</div>
        <div className="sv-badge-sub">{CHARTER_BADGE.sub}</div>
      </div>
    </div>
  );
}
