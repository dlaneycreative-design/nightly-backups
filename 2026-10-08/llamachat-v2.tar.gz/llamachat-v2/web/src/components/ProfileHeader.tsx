import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Profile } from "../lib/api.ts";
import { absDate } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { getCallerId } from "../lib/session.ts";
import { upsertProfile } from "../lib/store.ts";

interface Props {
  api: ApiClient;
  profile: Profile;
  onProfile: (p: Profile) => void;
}

// V1's default profile banner (thestudio.io/llama). V2 profiles carry no
// header field, so everyone gets the same night-sky banner like V1.
const DEFAULT_BANNER = "https://www.thestudio.io/sloth/assets/headers/llama-header-nightsky.webp";

/**
 * Profile header, ported 1:1 from V1 (thestudio.io/llama):
 * sticky topbar (back + name + post count), cover banner, avatar
 * overlapping the banner edge, follow/message actions, name/handle,
 * bio, link, joined date, following/followers counts.
 */
export function ProfileHeader({ api, profile, onProfile }: Props) {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const me = getCallerId();
  const isMe = me === profile.id;

  // X-style: the slim header stays hidden until the user scrolls past the
  // banner, so the banner is never cut off at the top of the profile.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 110);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleFollow = async () => {
    if (busy || isMe) return;
    setBusy(true);
    try {
      if (profile.following) {
        await api.unfollow(profile.id);
        onProfile(upsertProfile({ ...profile, following: false, followers_count: Math.max(0, profile.followers_count - 1) }));
      } else {
        await api.follow(profile.id);
        onProfile(upsertProfile({ ...profile, following: true, followers_count: profile.followers_count + 1 }));
      }
    } finally {
      setBusy(false);
    }
  };

  const startDm = async () => {
    if (busy || isMe) return;
    setBusy(true);
    try {
      const { conversation } = await api.createConversation([profile.id]);
      navigate(`/messages/${conversation.id}`);
    } finally {
      setBusy(false);
    }
  };

  const initial = (profile.display_name || "?").slice(0, 1).toUpperCase();
  const avatarSrc = resolveImageUrl(profile.avatar_url);
  const postLine = `${profile.posts_count} post${profile.posts_count === 1 ? "" : "s"}`;

  return (
    <div>
      <div className={scrolled ? "pf-head show" : "pf-head"}>
        <button type="button" className="back" onClick={() => navigate(-1)} aria-label="Back">
          ←
        </button>
        <div>
          <div className="n">{profile.display_name}</div>
          <div className="h">{postLine}</div>
        </div>
      </div>
      <div className="pf-banner" style={{ backgroundImage: `url(${DEFAULT_BANNER})` }} />
      <div className="pf-idrow">
        {avatarSrc ? (
          <img src={avatarSrc} alt={`${profile.display_name}'s avatar`} />
        ) : (
          <div className="pf-avatar-fallback" aria-hidden="true">
            {initial}
          </div>
        )}
        {!isMe && me ? (
          <div className="pf-actions">
            <button type="button" className="msgbtn" onClick={() => void startDm()} disabled={busy} aria-label="Message">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
              </svg>
            </button>
            <button
              type="button"
              className={`followbtn${profile.following ? " following" : ""}`}
              onClick={() => void toggleFollow()}
              disabled={busy}
            >
              {profile.following ? "Following" : "Follow"}
            </button>
          </div>
        ) : null}
      </div>
      <div className="pf-bio">
        <div className="pf-n">{profile.display_name}</div>
        <div className="pf-handle">@{profile.handle}</div>
        {profile.bio ? <div id="pfBio">{profile.bio}</div> : null}
        {profile.link_url ? (
          <a href={profile.link_url} target="_blank" rel="noopener">
            {profile.link_label || profile.link_url}
          </a>
        ) : null}
        <div className="pf-joined">Joined {absDate(profile.created_at)}</div>
        <div className="pf-stats">
          <span>
            <b>{profile.following_count}</b> Following
          </span>
          <span>
            <b>{profile.followers_count}</b> Followers
          </span>
        </div>
      </div>
    </div>
  );
}
