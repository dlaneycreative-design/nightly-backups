// Client-side hashtag parsing. Mirrors api/lib/render.js extractHashtags
// exactly (same regex, same lowercasing) so client and server agree on
// what a hashtag is.
const TAG_RE = /(^|\s)#([A-Za-z0-9_]{1,64})/g;

/** Extract unique lowercase hashtags from text, in first-seen order. */
export function extractHashtags(text: string): string[] {
  const tags = new Set<string>();
  TAG_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = TAG_RE.exec(text)) !== null) tags.add(m[2].toLowerCase());
  return [...tags];
}

/** Split text into plain/highlighted segments for search highlighting. */
export interface Segment {
  text: string;
  highlight: boolean;
}

export function highlightMatches(text: string, query: string): Segment[] {
  const q = query.trim();
  if (!q) return [{ text, highlight: false }];
  const out: Segment[] = [];
  const lower = text.toLowerCase();
  const lq = q.toLowerCase();
  let i = 0;
  for (;;) {
    const idx = lower.indexOf(lq, i);
    if (idx === -1) break;
    if (idx > i) out.push({ text: text.slice(i, idx), highlight: false });
    out.push({ text: text.slice(idx, idx + q.length), highlight: true });
    i = idx + q.length;
  }
  if (i < text.length) out.push({ text: text.slice(i), highlight: false });
  if (out.length === 0) out.push({ text, highlight: false });
  return out;
}
