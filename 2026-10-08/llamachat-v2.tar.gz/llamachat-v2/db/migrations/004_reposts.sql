-- Reposts table (for retweet functionality)
CREATE TABLE reposts (
  user_id    UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tweet_id   UUID NOT NULL REFERENCES tweets(id) ON DELETE CASCADE,
  created_at BIGINT NOT NULL,
  PRIMARY KEY (user_id, tweet_id)
);

CREATE INDEX idx_reposts_tweet ON reposts(tweet_id);
CREATE INDEX idx_reposts_user ON reposts(user_id);
