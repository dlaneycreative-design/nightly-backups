const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
(async () => {
  const ids = ['0c3a8460-2c7f-5260-ac3e-0dbdcf44e648','9fcb1234-6934-59cb-b945-e99b83ae6ae2','c58e04a3-5239-5369-93d3-28259fe27672','c8e9af23-78ae-59af-98ff-ac15dc6378f4','d1ff4f95-b87b-5b3a-b776-c76e2d0a6e35'];
  for (const id of ids) {
    const r = await sql`SELECT id, image_url, left(text, 40) t FROM tweets WHERE id = ${id}`;
    if (r.length) console.log(id.slice(0,8), "| IMG:", r[0].image_url || "(none)", "|", r[0].t.replace(/\n/g," "));
    else console.log(id.slice(0,8), "| NOT FOUND");
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
