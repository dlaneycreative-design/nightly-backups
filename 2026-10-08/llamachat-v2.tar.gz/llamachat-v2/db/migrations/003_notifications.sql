-- Notifications: replies, likes, reposts, follows, mentions
CREATE TABLE notifications (
  id           UUID PRIMARY KEY,
  user_id      UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  actor_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type         VARCHAR(20) NOT NULL CHECK (type IN ('reply','like','repost','follow','mention')),
  tweet_id     UUID REFERENCES tweets(id) ON DELETE CASCADE,
  created_at   BIGINT NOT NULL,
  read_at      BIGINT
);

CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX idx_notifications_unread ON notifications(user_id) WHERE read_at IS NULL;
