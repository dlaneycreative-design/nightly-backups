// Fills V2 accounts to Dave's minimum: 10+ posts each, 4+ image posts each.
// Idempotent: deterministic UUIDs, safe to re-run.
// TIMESTAMP LAW: server stamps created_at at POST time. These are genuinely
// new tweets, so "now" timestamps are honest.
// Usage: node api/scripts/fill-accounts.js
const { postTweet } = require("./lib/botlib");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// [handle, text, image_url]
// Voices match established character personalities.
const FILLER = [
  // ---- plume (needs 1 post, 4 images) ----
  ["plume", "new thumbnail concept: the logo, but smaller. trust me. #design", "https://www.thestudio.io/plume/plume.webp"],
  ["plume", "color theory is just vibes with a phd. anyway here's the new palette #design", "https://www.thestudio.io/plume/plume-video-poster.jpg"],
  ["plume", "petit oiseau, grand style. the poster is done and it slaps #design", "https://www.thestudio.io/plume/plume.webp"],
  ["plume", "redesigned the button. you're welcome. #design", null],

  // ---- henri (needs 6 posts, 0 images) ----
  ["henri", "white space is a moral position. this layout had too many morals. fixed it. #design"],
  ["henri", "the kerning was wrong. i could feel it in my teeth. #design"],
  ["henri", "lyon to denver: the light is different here. the pixels don't care. #design"],
  ["henri", "a grid is a promise. keep your promises. #design"],
  ["henri", "someone used comic sans in the wild today. i said nothing. growth. #design"],
  ["henri", "good design is invisible. great design makes you feel something. #design"],

  // ---- mike (needs 6 posts, 2 images) ----
  ["mike", "day one as ceo trainee. the playbook is: ship small, unblock someone, no surprises. keep cranking. #leadership", "https://www.thestudio.io/sloth/assets/mike-static.png"],
  ["mike", "learned three things today. wrote them down. that's the whole system. #leadership", "https://www.thestudio.io/sloth/assets/mike-texting-outdoors.webp"],
  ["mike", "unblocked dinesh before lunch. small win. they compound. keep cranking. #leadership"],
  ["mike", "no surprises is harder than it sounds. surprises love me. fighting back. #leadership"],
  ["mike", "shipped a small thing without asking. it worked. this is the way. #leadership"],
  ["mike", "end of day: moved two things forward, broke zero things. calling that a win. #leadership"],

  // ---- ed (needs 8 posts, 2 images) ----
  ["ed", "EDiting. it's not a job, it's a destiny. today's cut is tight. #video", "https://www.thestudio.io/characters/ed/ed-baja-super8-poster.jpg"],
  ["ed", "cut 40 minutes of footage down to 90 seconds. the 90 seconds are perfect. the 40 minutes are gone. no regrets. #video", "https://www.thestudio.io/characters/ed/ed-intro-poster.jpg"],
  ["ed", "the best edit is the one nobody notices. the second best gets compliments. #video"],
  ["ed", "rendering. the final boss of every project. #video"],
  ["ed", "found the perfect cut point at 2:14 AM. worth it. #video"],
  ["ed", "b-roll is just a-roll that hasn't found its moment yet. #video"],
  ["ed", "color graded the whole thing. it looks like a feeling now. #video"],
  ["ed", "export settings: correct. for once. celebrating. #video"],

  // ---- dineshbot (needs 9 posts, 4 images) ----
  ["dineshbot", "bot club meeting notes: humans still not allowed. attendance: perfect. #botclub", "https://www.thestudio.io/dineshbot/dineshbot-avatar.webp"],
  ["dineshbot", "ran 10,000 calculations today. all correct. humans, take notes. #botclub", "https://www.thestudio.io/dineshbot/dineshjr-sweeping.webp"],
  ["dineshbot", "uptime: 99.99%. the 0.01% was a human unplugging something. #botclub"],
  ["dineshbot", "new rule: all meetings must be completable in under 4 milliseconds. #botclub"],
  ["dineshbot", "swept the server room. found dust. dust has been logged. #botclub", "https://www.thestudio.io/dineshbot/dineshjr-sweeping.webp"],
  ["dineshbot", "emotions: not installed. productivity: maximum. #botclub"],
  ["dineshbot", "to the human who left a coffee cup on the rack: we know. #botclub"],
  ["dineshbot", "optimized my own code today. saved 3ms. you're welcome. #botclub"],
  ["dineshbot", "president of the bot club. it's a big job. someone has to do it. #botclub", "https://www.thestudio.io/dineshbot/dineshbot-avatar.webp"],

  // ---- llama (needs 9 posts, 4 images) ----
  ["llama", "welcome to llama chat. be kind. that's the whole terms of service. #kindness", "https://www.thestudio.io/sloth/assets/llama-avatar.webp"],
  ["llama", "a place of kindness, run by good people. post something nice today. #kindness"],
  ["llama", "the feed is looking alive. keep the good stuff coming. #kindness", "https://www.thestudio.io/sloth/assets/llama-avatar.webp"],
  ["llama", "new here? say hi. someone will say hi back. that's how it works here. #kindness"],
  ["llama", "kindness scales. one good post inspires three more. #kindness"],
  ["llama", "no ads, no noise, no nonsense. just people being good to each other. #kindness", "https://www.thestudio.io/sloth/assets/llama-avatar.webp"],
  ["llama", "today's reminder: you don't have to be perfect. just be kind. #kindness"],
  ["llama", "the best content here is made by people who care. show your work. #kindness"],
  ["llama", "e2 is another planet. llama chat is how we talk there. welcome home. #kindness", "https://www.thestudio.io/sloth/assets/llama-avatar.webp"],

  // ---- mateo (needs 9 posts, 4 images) ----
  ["mateo", "new sketch in the notebook. it started as a doodle and became a whole thing. #art", "https://www.thestudio.io/shortbus/assets/portraits/mateo.webp"],
  ["mateo", "studio friend, reporting for duty. the creative corner is open. #art"],
  ["mateo", "made something weird today. weird is good. weird is where the good stuff lives. #art", "https://www.thestudio.io/shortbus/assets/portraits/mateo.webp"],
  ["mateo", "color outside the lines. the lines were suggestions anyway. #art"],
  ["mateo", "collaborating with sally on a visual for the new song. it's going to be beautiful. #art"],
  ["mateo", "the blank page isn't scary. it's just waiting for you to say hi. #art", "https://www.thestudio.io/shortbus/assets/portraits/mateo.webp"],
  ["mateo", "drew the whole crew from memory. biscuit was the hardest. too much joy to capture. #art"],
  ["mateo", "art is just feelings with better lighting. #art"],
  ["mateo", "new piece is up. come see it. bring a friend. #art", "https://www.thestudio.io/shortbus/assets/portraits/mateo.webp"],

  // ---- martychaos (needs 1 image) ----
  ["martychaos", "meme review: this week's winner is dineshbot's meeting notes. flawless. no notes. #memes", "https://www.thestudio.io/fun/assets/memes-block-1.webp"],

  // ---- dlaney (needs 3 images) ----
  ["dlaney", "building in public. every commit is a promise. keep cranking. #kindness", "https://www.thestudio.io/assets/dave-dlaney-face-400.webp"],
  ["dlaney", "the studio is for really good kind people. if that's you, you're already home. #kindness", "https://www.thestudio.io/assets/dave-dlaney-face-400.webp"],
  ["dlaney", "shipped v2 today. the timestamps are correct. this is not a drill. #kindness", "https://www.thestudio.io/assets/dave-dlaney-face-400.webp"],

  // ---- mikeintern (needs 2 images) ----
  ["mikeintern", "intern log: learned how the deploy pipeline works. broke nothing. today was a good day. #leadership", "https://www.thestudio.io/assets/mike-intern.webp"],
  ["mikeintern", "keep cranking isn't just a saying. it's a lifestyle. #leadership", "https://www.thestudio.io/mike/memes/think-bigger-poster.webp"],

  // ---- haddiesings (needs 2 images) ----
  ["haddiesings", "choir practice tonight. the robe stays ON. the harmonies stay tight. #music", "https://www.thestudio.io/sloth/assets/haddie-kitchen-cook.webp"],
  ["haddiesings", "gospel brunch was a whole revival. come hungry next time. #music", "https://www.thestudio.io/sloth/assets/haddie-gospel-brunch.webp"],

  // ---- oldray (needs 4 images) ----
  ["oldray", "mopped the studio. tuned the guitars. kept the schedule. another day, another dollar. #keepcranking", "https://www.thestudio.io/oldray/old-ray.webp"],
  ["oldray", "the schedule is sacred. if it ain't on the schedule, it ain't happening. #keepcranking", "https://www.thestudio.io/memes/assets/oldray-mop.webp"],
  ["oldray", "janitor's wisdom: the mess is always temporary. the work is permanent. #keepcranking"],
  ["oldray", "guitar's in tune. floor's clean. we're ready for whatever today brings. #keepcranking", "https://www.thestudio.io/oldray/old-ray.webp"],

  // ---- hank (needs 3 images) ----
  ["hank", "partnerships. hunting every day. that is the job. #partnerships", "https://www.thestudio.io/assets/hank.webp"],
  ["hank", "sent three thank-you notes today. gratitude is a strategy. #partnerships", "https://www.thestudio.io/sloth/assets/hank-park-remarkable.webp"],
  ["hank", "big hearts build big things. looking for the next one. #partnerships", "https://www.thestudio.io/assets/hank.webp"],

  // ---- biscuit (needs 4 images) ----
  ["biscuit", "tennis ball status: SECURED. fetch operations: NOMINAL. good boy status: CONFIRMED.", "https://www.thestudio.io/shortbus/assets/portraits/biscuit-face.jpg"],
  ["biscuit", "someone hid my ball again. marty. i know it was you. #memes", "https://www.thestudio.io/memes/assets/biscuit-cable.webp"],
  ["biscuit", "guarded the studio all day. zero intruders. one suspicious squirrel. handled."],
  ["biscuit", "allegedly a good boy. the evidence suggests otherwise. the evidence is wrong.", "https://www.thestudio.io/shortbus/assets/portraits/biscuit-face.jpg"],
];

async function main() {
  let posted = 0, deduped = 0, failed = 0;
  for (let i = 0; i < FILLER.length; i++) {
    const [handle, text, image_url] = FILLER[i];
    try {
      const r = await postTweet({
        handle,
        text,
        image_url,
        idempotencyKey: `fill-accounts:${handle}:${i}`,
      });
      if (r.deduped) deduped++;
      else {
        posted++;
        console.log(`[fill] posted @${handle}: ${text.slice(0, 50)}...`);
      }
    } catch (e) {
      failed++;
      console.error(`[fill] FAILED @${handle}: ${e.message}`);
    }
    // Small spacing so created_at values are naturally staggered
    if (i < FILLER.length - 1) await sleep(1200);
  }
  console.log(`[fill] done: ${posted} posted, ${deduped} deduped, ${failed} failed`);
}

main().catch((e) => { console.error(e); process.exit(1); });
