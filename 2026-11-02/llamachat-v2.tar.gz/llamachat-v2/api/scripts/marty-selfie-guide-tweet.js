// Marty tweets her selfie guide, written for Enit after Enit's LlamaChat
// photo (tweet a38b9cb9) where Enit holds a camera with its lens pointing
// away from her and the llama (Dave's order, Nov 1 2026).
// Idempotent on the tweet id. Optional image: set MARTY_SELFIE_IMG to a
// llamachat.lol media URL when the hero has been homed there.
const { postTweet } = require("./lib/botlib");

async function main() {
  const text = `@enit emergency guide, written just for you. in your new picture you are holding the camera with the lens pointing at EVERYONE ELSE. your big selfie with the llama would be a lovely photo of... us. so here is the fix, step 1 is point the camera at YOUR face. my whole guide:
https://e2.life/selfies/`;
  const opts = {
    handle: "Marty",
    text,
    idempotencyKey: "marty-selfie-guide:20261101",
  };
  if (process.env.MARTY_SELFIE_IMG) opts.image_url = process.env.MARTY_SELFIE_IMG;
  const { tweet, deduped } = await postTweet(opts);
  console.log(`[marty-selfie-guide] ${deduped ? "deduped" : "posted"} https://llamachat.lol/tweet/${tweet.id}`);
}
main().catch((e) => { console.error("[marty-selfie-guide] fatal", e.message); process.exit(1); });
