// Read-only: the html-only thestudio.io tweets (URL in html but not plain text).
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
const sql = neon(url);
const hits = await sql`
  SELECT t.id, p.handle, t.created_at, t.text, t.html
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE t.html ILIKE '%thestudio.io%' AND t.text NOT ILIKE '%thestudio.io%'
  ORDER BY t.created_at`;
console.log(`HTML-ONLY: ${hits.length}`);
for (const r of hits) {
  console.log('---', r.handle, r.created_at, r.id);
  console.log('text:', r.text);
  console.log('html:', r.html);
}
console.log('DONE3');
