// Bot 1: Mike blog tweets.
// Called at the end of the mike-feedback-2hr cron after a blog post is
// published and verified live. Tweets about the new post as @mike with
// the post title, a hook line, the header image, and a link to the post.
//
// TIMESTAMP LAW: the API server-stamps created_at. Never "now"/null/0.
// Idempotent: deterministic UUID from the blog post id. Re-running after
// a successful tweet dedupes (no double post, the V1 "POOF" bug killer).
//
// Usage:
//   node api/scripts/mike-blog-tweet.js --post-id mike-log-67 \
//     --title "Update from Mike #67: ..." \
//     --url "https://www.thestudio.io/mike/" \
//     --image "https://www.thestudio.io/shortbus/assets/portraits/chadwick.jpg" \
//     [--hook "one-line hook"]
//
// All args required except --hook (falls back to a generic line).
const { postTweet } = require("./lib/botlib");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFileSync } = require("child_process");

// NO CROSS-SITE IMAGES (Dave's law): the header image lives in the Studio
// tree, so copy it into the llamachat dist under /media/studio/... and deploy
// BEFORE tweeting, then store the llamachat.lol URL. This step did not exist
// before 2026-10-13: the composer stored a thestudio.io URL and no copy was
// ever made. Older blog tweets only looked fine because the Oct 13 media
// census batch-copied their files after the fact; post #114 was composed
// after that census and shipped with a cross-site image never brought home.
// Note: the tweets API only accepts absolute https image URLs, so the stored
// value is the full llamachat.lol URL for the local /media/studio path (the
// same form the upload flow produces). Copies are resized to the Llama spec
// (800px max for content images), matching every earlier blog image in dist.
function shrinkToSpec(dest) {
  if (!/\.(webp|jpe?g|png)$/i.test(dest)) return;
  try {
    const w = parseInt(execFileSync("ffprobe", ["-v", "error", "-select_streams", "v:0",
      "-show_entries", "stream=width", "-of", "csv=p=0", dest]).toString().trim(), 10);
    if (!w || w <= 800) return;
    const tmp = `${dest}.tmp.webp`;
    execFileSync("ffmpeg", ["-y", "-v", "error", "-i", dest, "-vf", "scale=800:-2",
      "-c:v", "libwebp", "-q:v", "80", tmp]);
    fs.renameSync(tmp, dest);
    console.log(`[mike-blog-tweet] resized header to 800px wide: ${dest}`);
  } catch (e) {
    console.error(`[mike-blog-tweet] warning: could not resize ${dest}: ${e.message} (raw copy kept)`);
  }
}

function bringImageHome(image) {
  if (image.startsWith("/media/")) return `https://llamachat.lol${image}`; // already home
  if (/^https:\/\/llamachat\.lol\//.test(image)) return image; // already home
  let studioPath = null;
  const m = image.match(/^https?:\/\/(?:www\.)?thestudio\.io(\/.*)$/);
  if (m) studioPath = m[1];
  else if (image.startsWith("/")) studioPath = image;
  else if (image.startsWith("http")) {
    console.error(`[mike-blog-tweet] warning: external image left as-is: ${image}`);
    return image;
  } else {
    studioPath = `/${image}`;
  }
  const studioRoot = path.resolve(__dirname, "../../../thestudio-real");
  const distRoot = path.resolve(__dirname, "../../web/dist");
  const publicRoot = path.resolve(__dirname, "../../web/public");
  const src = path.join(studioRoot, studioPath);
  const dest = path.join(distRoot, "media/studio", studioPath);
  // Also land the copy in web/public: dist is wiped by every vite build, so a
  // dist-only copy vanishes on the next build+deploy (this ate post #116's
  // header when the DM composer CSS fix rebuilt dist on 2026-10-13).
  const publicDest = path.join(publicRoot, "media/studio", studioPath);
  if (!fs.existsSync(src)) {
    throw new Error(`header image not found in Studio tree: ${src} (refusing to tweet a cross-site or broken image)`);
  }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(src, dest);
    console.log(`[mike-blog-tweet] copied header home: ${studioPath} -> /media/studio${studioPath}`);
  }
  fs.mkdirSync(path.dirname(publicDest), { recursive: true });
  if (!fs.existsSync(publicDest)) {
    fs.copyFileSync(src, publicDest);
    console.log(`[mike-blog-tweet] copied header to web/public (build-carried): ${studioPath}`);
  }
  shrinkToSpec(dest);
  shrinkToSpec(publicDest);
  const cfDeploy = path.join(os.homedir(), "workspace/skills/cloudflare/bin/cf_deploy.py");
  execFileSync("python3", [cfDeploy, "llamachat", distRoot], { stdio: "inherit", timeout: 900000 });
  return `https://llamachat.lol/media/studio${studioPath}`;
}

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : null;
}

async function main() {
  const postId = arg("post-id");
  const title = arg("title");
  const url = arg("url");
  const image = arg("image");
  const hook = arg("hook");
  if (!postId || !title || !url || !image) {
    console.error("usage: --post-id ID --title T --url U --image I [--hook H]");
    process.exit(2);
  }

  // Keep it short and Mike: warm, plainspoken, zero fluff. No em-dashes.
  // Dave's call Oct 9 2026: link to the specific post, not just the blog homepage.
  const shortTitle = title.replace(/^Update from Mike #\d+:\s*/, "");
  const postUrl = url.includes("#") ? url : `${url}#${postId}`;
  const text = hook
    ? `new blog post: ${shortTitle}. ${hook} ${postUrl}`
    : `new blog post is up: ${shortTitle} ${postUrl}`;

  if (text.length > 2000) throw new Error("tweet text too long, shorten the hook");

  const { tweet, deduped } = await postTweet({
    handle: "mike",
    text,
    image_url: bringImageHome(image),
    idempotencyKey: `mike-blog:${postId}`,
  });
  console.log(`[mike-blog-tweet] ${deduped ? "deduped (already tweeted)" : "tweeted"} ${tweet.id} for ${postId}`);
}

main().catch((e) => { console.error("[mike-blog-tweet] fatal", e.message); process.exit(1); });
