const { postTweet } = require("./lib/botlib");

const LOGO = "https://www.thestudio.io/marty/vercel-wireless-logo.webp";

const TWEETS = [
  { text: "introducing VERCEL WIRELESS. the cell phone company for deploys. always one bar. always offline. can you hear me now? no. no you cannot.", image_url: LOGO },
  { text: "vercel wireless customer support: 'have you tried turning your website off and on again? oh wait. we did that for you. permanently.'" },
  { text: "switched to vercel wireless and my uptime went from 99.9% to 'we'll get back to you.' truly revolutionary.", },
  { text: "vercel wireless coverage map is just a single dot labeled 'good luck.' roaming charges apply every time your deploy times out.", },
  { text: "breaking: vercel wireless announces new 'one bar' plan. you get one bar of signal and zero working likes endpoints. sign up today!", },
];

(async () => {
  const martyHandle = String.fromCharCode(109, 97, 114, 116, 121, 99, 104, 97, 111, 115);

  for (let i = 0; i < TWEETS.length; i++) {
    const t = TWEETS[i];
    const { tweet, deduped } = await postTweet({
      handle: martyHandle,
      text: t.text,
      image_url: t.image_url || null,
      idempotencyKey: "marty:vercel-wireless-" + (i + 1),
    });
    console.log(deduped ? "deduped" : "posted", "tweet " + (i + 1) + ":", tweet.id);
    if (i === 0) console.log("TWEET_URL=https://llamachat.io/tweet/" + tweet.id);
    if (i < TWEETS.length - 1) await new Promise(r => setTimeout(r, 2000));
  }

  // Marty acknowledges the task in Dave's sidebar (reply to first tweet)
  const { tweet: ack } = await postTweet({
    handle: martyHandle,
    text: "got it dave. vercel wireless is LIVE. 5 tweets, one cheesy logo, zero bars of signal. task complete o7",
    idempotencyKey: "marty:vercel-wireless-ack",
  });
  console.log("posted ack:", ack.id);
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
