import { useEffect, useState } from "react";
import type { ApiClient } from "../lib/api.ts";
import { getCallerId, getCallerHandle, clearCallerId } from "../lib/session.ts";

interface Props {
  api: ApiClient;
  apiBase: string;
}

/**
 * /dev: the speed playbook and architecture notes. Short, honest, kept
 * current. Dave's call: this page documents what we did and why.
 */
export function DevView({ api, apiBase }: Props) {
  const [health, setHealth] = useState<string>("checking...");
  const caller = getCallerId();
  const callerHandle = getCallerHandle();

  useEffect(() => {
    let alive = true;
    api
      .health()
      .then((h) => {
        if (alive) setHealth(h.ok ? `ok (v${h.version})` : "unreachable");
      })
      .catch(() => {
        if (alive) setHealth("unreachable");
      });
    return () => {
      alive = false;
    };
  }, [api]);

  return (
    <div className="dev">
      <h1>Dev notes</h1>
      <p>LlamaChat V2 web. Kept short and honest.</p>

      <div className="dev-card">
        <h3>Session</h3>
        <div className="dev-session">
          <div className="dev-row">
            <span className="dev-label">API</span>
            <code>{apiBase}</code>
          </div>
          <div className="dev-row">
            <span className="dev-label">Health</span>
            <code>{health}</code>
          </div>
          <div className="dev-row">
            <span className="dev-label">Caller</span>
            <code>{caller ? `${callerHandle ? `@${callerHandle} ` : ""}${caller.slice(0, 8)}...` : "anonymous (read-only)"}</code>
          </div>
          {caller ? (
            <div className="dev-row">
              <span className="dev-label"></span>
              <button type="button" className="ghost" onClick={() => { clearCallerId(); window.location.reload(); }}>
                Sign out
              </button>
            </div>
          ) : null}
        </div>
      </div>

      <h2>Speed playbook</h2>
      <div className="dev-card">
        <h3>Budgets (Dave's locked rules)</h3>
        <ul>
          <li>Total page under 1MB. No UI kits, no heavy deps.</li>
          <li>First paint under 1s: skeleton UI renders before any API call.</li>
          <li>Time to interactive under 2s.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Feed with 500+ images</h3>
        <ul>
          <li>Virtualized list: ~30 rows in the DOM, heights measured then estimated.</li>
          <li>Cursor pagination, 20 per page, IntersectionObserver infinite scroll.</li>
          <li>Images lazy-load within 800px of the viewport; feed shows 200px thumbs, tap for full.</li>
          <li>Next-page thumbnails prefetched into the HTTP cache.</li>
          <li>Realtime is 30s polling (no WebSocket endpoint); "N new posts" pill, tap to prepend.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Server speed</h3>
        <ul>
          <li>Gzip compression on all API responses (threshold 1KB).</li>
          <li>Cache-Control: immutable on /assets/*, icons, manifest. Static files never re-download.</li>
          <li>PWA: service worker caches static assets, network-first for /api/. Installable on iOS and Android.</li>
        </ul>
      </div>

      <h2>Architecture</h2>
      <div className="dev-card">
        <h3>Data flow</h3>
        <ul>
          <li>Normalized store: one tweet object per ID, one profile per ID. No duplicate arrays.</li>
          <li>Typed API client with retry; public reads need no auth, writes send <code>x-llama-user</code>.</li>
          <li>Server stamps every timestamp. The client never generates one.</li>
          <li>DB migrations run on cold start, idempotent via <code>schema_migrations</code>.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Feed: For You + Following</h3>
        <ul>
          <li><strong>For You</strong> (<code>?sort=foryou</code>): engagement-weighted mix of the last 7 days. Score = likes + replies x 2 + reposts x 3, plus a recency boost (full weight for 48h, decaying after). Shuffled with a daily seed (Denver time) so it feels fresh each morning but stable during the day.</li>
          <li><strong>Following</strong> (<code>?sort=chron</code>, default): pure chronological, newest first. Dave's call: keep it simple and predictable.</li>
          <li>Pagination: For You uses offset cursors keyed on the daily seed; Following uses (created_at, id) cursors.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Reposts</h3>
        <ul>
          <li><code>reposts</code> table (migration 004): (tweet_id, user_id), unique pair.</li>
          <li>Toggle component mirrors LikeToggle: optimistic UI, rolls back on failure.</li>
          <li>Repost count on the tweet; reposted state per viewer.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Notifications</h3>
        <ul>
          <li><code>notifications</code> table (migration 003): fires on reply, like, repost. No-op when actor == target.</li>
          <li>Bell in sidebar and mobile bottom nav. Badge count via <code>/api/v2/notifications/unread-count</code>.</li>
          <li>Viewing /notifications marks all read.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>DMs</h3>
        <ul>
          <li>X-style split view: list left, thread right. On mobile, tapping a conversation swaps to the thread with a back button.</li>
          <li>Unread bold: <code>updated_at &gt; last_read_at</code> per conversation.</li>
          <li>Input bar is a flex footer (not absolute) so it never gets jammed behind the nav.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Images</h3>
        <ul>
          <li>Uploads go to Vercel Blob (5GB included). Client downscales to &le;1600px WebP in-browser first, so uploads land well under 1MB.</li>
          <li>Server cap: 4.5MB (serverless body limit). Image URLs stored directly on the tweet.</li>
          <li>Avatars display at 48px: served at 400px max, quality 65. Content images 800px max, quality 60. (Dave's speed rules.)</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Threads</h3>
        <ul>
          <li>Recursive CTE fetches all descendant replies in one query. Frontend renders a recursive ReplyTree with indent styling.</li>
          <li>No inline composer in thread view (Dave's call, matches X).</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Timestamps (Dave's #1 rule)</h3>
        <ul>
          <li>Every timestamp renders through <code>relTime()</code> / <code>absTime()</code> / <code>tweetTime()</code>. No exceptions.</li>
          <li>Invalid stamp renders nothing, never "now". Future stamps clamp to "now" (clock skew).</li>
          <li>Optimistic posts show "sending...", never a fake time.</li>
          <li>Sorting uses numeric <code>created_at</code> only.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Reliability</h3>
        <ul>
          <li>Failed posts go to the offline queue and retry. Nothing the user wrote is ever dropped.</li>
          <li>Writes are idempotent (client-generated UUIDs).</li>
          <li>Every view wrapped in an error boundary; one bad tweet never kills the feed.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>SEO</h3>
        <ul>
          <li><code>sitemap.xml</code> (home, explore, all profiles), <code>robots.txt</code> (disallow /api/, /dev).</li>
          <li>Canonical + Open Graph + Twitter card meta tags.</li>
        </ul>
      </div>
      <div className="dev-card">
        <h3>Known gaps</h3>
        <ul>
          <li>Bookmarks are not built yet.</li>
          <li>Bot auto-replies are V2.5 (needs AI backend and cost approval). Not built.</li>
          <li>Image moderation: uploads are auth-gated and type-checked, but no virus scan or content review. Fine for a trusted community; needs work before open signup.</li>
        </ul>
      </div>
    </div>
  );
}
