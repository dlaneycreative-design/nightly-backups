#!/bin/bash
# Drive the hardened LlamaChat inspector to a definitive (PASS/FAIL) verdict.
# Relaunches on INCOMPLETE (exit 2: budget pause or transport-inconclusive
# sweep) so the checkpointed census keeps resuming. Stops on PASS (0) or
# FAIL (1), or after 16 launches. Waits out any inspector already running.
# Lives in the workspace (not /tmp) so it and its logs survive VM restarts.
BASE=/home/hatch/workspace/llamachat-v2
LOG=$BASE/inspector-driver.log
STATE=$BASE/inspector-state.json
cd "$BASE" || exit 1
echo "$(date -u +%FT%TZ) driver started" >> "$LOG"
attempt=0
while [ $attempt -lt 16 ]; do
  # Wait for any in-flight inspector (cron's) to finish.
  waited=0
  while pgrep -f "inspector\.py" > /dev/null; do
    sleep 20; waited=$((waited+20))
    if [ $waited -gt 3600 ]; then echo "$(date -u +%FT%TZ) waited 1h for in-flight run, continuing" >> "$LOG"; break; fi
  done
  # If a fresh definitive verdict just landed, we are done.
  fresh=$(python3 -c "
import json, time
s = json.load(open('$STATE'))
ts = time.mktime(time.strptime(s['run_at'], '%Y%m%dT%H%M%SZ')) - time.timezone
age = time.time() - ts
print('yes' if s['verdict'] in ('PASS','FAIL') and age < 900 else 'no')" 2>/dev/null)
  if [ "$fresh" = "yes" ]; then
    echo "$(date -u +%FT%TZ) definitive verdict present: $(python3 -c "import json; print(json.load(open('$STATE'))['verdict'])")" >> "$LOG"
    break
  fi
  attempt=$((attempt+1))
  echo "$(date -u +%FT%TZ) launch #$attempt" >> "$LOG"
  t0=$(date +%s)
  python3 "$BASE/inspector.py" >> "$BASE/inspector-driver-runs.log" 2>&1
  code=$?
  dur=$(( $(date +%s) - t0 ))
  echo "$(date -u +%FT%TZ) launch #$attempt exited $code after ${dur}s; state: $(python3 -c "import json; s=json.load(open('$STATE')); print(s['verdict'], s['run_at'])" 2>/dev/null)" >> "$LOG"
  if [ $code -eq 0 ] || [ $code -eq 1 ]; then break; fi
  if [ $code -eq 2 ] && [ $dur -lt 90 ]; then
    # Fast exit 2 = lock-skip (another run holds the lock), not a real
    # attempt. Do not burn the attempt budget; back off and retry.
    attempt=$((attempt-1))
    sleep 120
    continue
  fi
  sleep 45
done
echo "$(date -u +%FT%TZ) driver done after $attempt launches" >> "$LOG"
