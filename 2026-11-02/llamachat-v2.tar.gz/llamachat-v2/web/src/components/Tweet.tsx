import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import { tweetTime, absTime } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { TweetImage } from "./TweetImage.tsx";
import { TweetVideo } from "./TweetVideo.tsx";
import { getCallerId } from "../lib/session.ts";

/** Dave's profile id (@dave). Only Dave, logged in with Discord, is a
 * moderator: the server (llamachat-api lib/moderation.js) lets this
 * profile delete ANY post and snapshots each removal into the
 * moderation log Muse watches. His id can only ever be the caller
 * through a verified Discord session (lib/session.ts protected
 * accounts), so matching it here is safe. */
const DAVE_PROFILE_ID = "8d754e46-a2af-4318-a3d8-9b47e5473abb";
function isDaveModerator(): boolean {
  return (getCallerId() || "").toLowerCase() === DAVE_PROFILE_ID;
}
import { openReplyModal } from "../lib/replyModal.ts";
import { openQuoteComposer } from "../lib/composeModal.ts";
import { QuotedTweetCard, QuotedUnavailableCard } from "./QuotedTweetCard.tsx";
import { sanitizeTweetHtml } from "../lib/sanitize.ts";
import { isPendingTweet, type TweetLike } from "../lib/tweetView.ts";
import { getProfileById } from "../lib/store.ts";
import { fmtClock } from "../lib/voice.ts";
import { profilePath, shortProfilePath } from "../lib/theme.ts";
import { coverFromTweetImage } from "../lib/gameEmbed.ts";
import { GameEmbed } from "./GameEmbed.tsx";
import { useTweetGameEmbed } from "./OpenArcadeEmbed.tsx";
import { YouBoobEmbed } from "./YouBoobEmbed.tsx";

/** A tweet still waiting on the server. Renders "sending...", never a time. */
export type { PendingViewTweet, TweetLike } from "../lib/tweetView.ts";

/** Re-render on a slow tick so "5s" becomes "6s" without new data. */
function useNow(intervalMs = 30_000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function Avatar({ name, url }: { name: string; url: string | null }) {
  const src = resolveImageUrl(url);
  if (src) {
    return <img className="avatar" src={src} alt={`${name}'s avatar`} loading="lazy" decoding="async" />;
  }
  const initial = (name || "?").slice(0, 1).toUpperCase();
  return (
    <div className="avatar avatar-fallback" aria-hidden="true">
      {initial}
    </div>
  );
}

interface Props {
  tweet: TweetLike;
  api: ApiClient;
  onDeleted?: (id: string) => void;
  detail?: boolean;
  onReplyOverride?: (tweet: TweetT) => void;
}

/** Like toggle: optimistic UI, persists via /api/v2/likes. Reverts on failure. */
function LikeToggle({ tweetId, initial, initialLiked, api }: {
  tweetId: string;
  initial: number;
  initialLiked: boolean;
  api: ApiClient;
}) {
  const [on, setOn] = useState(initialLiked);
  const [count, setCount] = useState(initial);
  const busy = useRef(false);
  const toggle = async () => {
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.like(tweetId) : await api.unlike(tweetId);
      if (r.tweet) {
        setOn(r.tweet.liked);
        setCount(r.tweet.likes_count);
      }
    } catch {
      // Not signed in or network failed: revert the optimistic toggle.
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };
  return (
    <button
      type="button"
      className={`act like${on ? " on" : ""}`}
      aria-label={`${count} likes`}
      onClick={toggle}
    >
      <span className="ic">
        <svg viewBox="0 0 24 24" fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
      </span>
      <span className="n">{count > 0 ? count : null}</span>
    </button>
  );
}

/**
 * Repost button, X pattern: tapping it opens a small menu with two
 * rows — "Repost" (or "Undo repost" when already reposted) and
 * "Quote". Reposting itself is the same optimistic toggle as before,
 * persisted via /api/v2/reposts and reverted on failure. Quote opens
 * the compose modal with this tweet attached (lib/composeModal).
 */
function RepostMenu({ tweet, api }: { tweet: TweetT; api: ApiClient }) {
  const tweetId = tweet.id;
  const [on, setOn] = useState(!!tweet.reposted);
  const [count, setCount] = useState(tweet.reposts_count);
  const [menuOpen, setMenuOpen] = useState(false);
  const busy = useRef(false);

  // Close the menu on Escape (backdrop click also closes), mirroring
  // the TweetMenu pattern so no stuck overlay can block clicks.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const toggle = async () => {
    setMenuOpen(false);
    if (busy.current) return;
    busy.current = true;
    const next = !on;
    setOn(next);
    setCount((c) => Math.max(0, c + (next ? 1 : -1)));
    try {
      const r = next ? await api.repost(tweetId) : await api.unrepost(tweetId);
      if (r.tweet) {
        setOn(r.tweet.reposted);
        setCount(r.tweet.reposts_count);
      }
    } catch {
      setOn(!next);
      setCount((c) => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      busy.current = false;
    }
  };

  const quote = () => {
    setMenuOpen(false);
    openQuoteComposer(tweet);
  };

  return (
    <span className="rt-wrap">
      <button
        type="button"
        className={`act rt${on ? " on" : ""}`}
        aria-label={`${count} reposts`}
        aria-haspopup="menu"
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen((o) => !o)}
      >
        <span className="ic">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
        </span>
        <span className="n">{count > 0 ? count : null}</span>
      </button>
      {menuOpen ? (
        <>
          <button type="button" className="tw-menu-backdrop" aria-label="Close menu" onClick={() => setMenuOpen(false)} style={{ border: "none", padding: 0, background: "transparent" }} />
          <div className="tw-menu rt-menu" role="menu" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="tw-menu-item rt-menu-item" role="menuitem" aria-label={on ? "Undo repost" : "Repost"} onClick={() => void toggle()}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
              <span>{on ? "Undo repost" : "Repost"}</span>
            </button>
            <button type="button" className="tw-menu-item rt-menu-item" role="menuitem" aria-label="Quote post" onClick={quote}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
              <span>Quote</span>
            </button>
          </div>
        </>
      ) : null}
    </span>
  );
}

/**
 * Tweet card. THE timestamp path: tweetTime() only. Invalid stamps render
 * nothing; pending tweets render "sending...". No ad-hoc date formatting.
 */
interface TweetView {
  key: string;
  name: string;
  handle: string;
  avatar: string | null;
  time: string;
  text: string;
  html: string | null;
  image_url: string | null;
  audio_url: string | null;
  video_url: string | null;
  audio_for: TweetT["audio_for"];
  quote_of_id: string | null;
  quoted_tweet: TweetT | null;
  replies_count: number;
  likes_count: number;
  real: TweetT | null;
}

/** Normalize the TweetLike union into one view model for rendering. */
function toTweetView(tweet: TweetLike, now: number): TweetView {
  // The timestamp ALWAYS goes through tweetTime(): pending -> "sending...",
  // invalid -> "".
  if (isPendingTweet(tweet)) {
    return {
      key: tweet.tempId,
      name: tweet.author.display_name,
      handle: tweet.author.handle,
      avatar: tweet.author.avatar_url,
      time: tweetTime({ pending: true }, now),
      text: tweet.text,
      html: null,
      image_url: tweet.image_url,
      audio_url: tweet.audio_url,
      video_url: null,
      audio_for: null,
      quote_of_id: tweet.quote_of_id,
      quoted_tweet: tweet.quoted_tweet,
      replies_count: 0,
      likes_count: 0,
      real: null,
    };
  }
  // Prefer the store's current profile for the author: the snapshot
  // embedded in the tweet goes stale when the author edits their
  // profile (e.g. saves a new avatar), while the store copy is kept
  // fresh by the edit flow and profile fetches.
  const liveAuthor = getProfileById(tweet.author.id);
  // Voice-only posts store the server sentinel "Voice message" as
  // their text (the live DB check demands text); the voice card IS
  // the message, so that one exact text renders as no text at all.
  const voiceOnly = !!tweet.audio_url && (tweet.text || "").trim() === "Voice message";
  // Prefer the store's live profile for the recipient too (fresh avatar).
  const liveFor = tweet.audio_for ? getProfileById(tweet.audio_for.id) : undefined;
  return {
    key: tweet.id,
    name: liveAuthor?.display_name ?? tweet.author.display_name,
    handle: liveAuthor?.handle ?? tweet.author.handle,
    avatar: liveAuthor ? liveAuthor.avatar_url : tweet.author.avatar_url,
    time: tweetTime(tweet, now),
    text: voiceOnly ? "" : tweet.text,
    html: voiceOnly ? null : tweet.html,
    image_url: tweet.image_url,
    audio_url: tweet.audio_url ?? null,
    video_url: tweet.video_url ?? null,
    audio_for: tweet.audio_for
      ? {
          ...tweet.audio_for,
          display_name: liveFor?.display_name ?? tweet.audio_for.display_name,
          avatar_url: liveFor ? liveFor.avatar_url : tweet.audio_for.avatar_url,
        }
      : null,
    quote_of_id: tweet.quote_of_id ?? null,
    quoted_tweet: tweet.quoted_tweet ?? null,
    replies_count: tweet.replies_count,
    likes_count: tweet.likes_count,
    real: tweet as TweetT,
  };
}

/** Options (⋯) menu for a real tweet: delete (own tweets) + share. */
function TweetMenu({
  mine,
  deleting,
  onDelete,
  onShare,
}: {
  mine: boolean;
  deleting: boolean;
  onDelete: (e: React.MouseEvent) => void;
  onShare: (e: React.MouseEvent) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  // Close the options menu on Escape; without this a stuck backdrop can
  // block all clicks until reload.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  return (
    <div className="tw-menu-wrap">
      <button
        type="button"
        className="tw-menu-btn"
        aria-label="More options"
        onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}
      >
        <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>
      </button>
      {menuOpen ? (
        <>
          <button type="button" className="tw-menu-backdrop" aria-label="Close menu" onClick={(e) => { e.stopPropagation(); setMenuOpen(false); }} style={{ border: "none", padding: 0, background: "transparent" }} />
          <div className="tw-menu" onClick={(e) => e.stopPropagation()}>
            {mine ? (
              <button type="button" className="tw-menu-item danger" onClick={onDelete} disabled={deleting}>
                {deleting ? "Deleting..." : "Delete post"}
              </button>
            ) : null}
            <button type="button" className="tw-menu-item" onClick={(e) => { setMenuOpen(false); onShare(e); }}>
              Share post
            </button>
          </div>
        </>
      ) : null}
    </div>
  );
}

/**
 * Tapey voice card (Dave's order Oct 31 2026): a WHITE card carrying
 * the sender's avatar, the recipient's avatar when the post @mentions
 * someone, the line "Enit, here's a voice message for you from Dave",
 * and a real player (play/pause, seekable progress, time). Clicks
 * inside the card never open the thread.
 */
export function VoiceCard({ view }: { view: TweetView }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [cur, setCur] = useState(0);
  const [dur, setDur] = useState(0);
  const forProfile = view.audio_for ?? null;
  const senderFirst = (view.name || "").split(" ")[0] || view.name;
  const recipientFirst = forProfile ? (forProfile.display_name || "").split(" ")[0] || forProfile.display_name : null;
  const caption = forProfile
    ? `${recipientFirst}, here's a voice message for you from ${senderFirst}`
    : `Here's a voice message from ${senderFirst}`;
  const src = view.audio_url ? resolveImageUrl(view.audio_url) || view.audio_url : null;
  if (!src) return null;

  const toggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) void a.play().catch(() => {});
    else a.pause();
  };
  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const a = audioRef.current;
    if (!a || !dur) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    a.currentTime = ratio * dur;
  };

  return (
    <div className="voice-card" onClick={(e) => e.stopPropagation()}>
      <div className="voice-card-top">
        <span className="voice-face sender">
          <Avatar name={view.name} url={view.avatar} />
        </span>
        <div className="voice-card-txt">
          <div className="voice-card-caption">{caption}</div>
          <div className="voice-card-sub">
            {forProfile ? `For @${forProfile.handle} · ` : ""}🎙️ Tapey voice note
          </div>
        </div>
        {forProfile ? (
          <span className="voice-face recipient" title={`For ${forProfile.display_name} (@${forProfile.handle})`}>
            <Avatar name={forProfile.display_name} url={forProfile.avatar_url} />
          </span>
        ) : null}
      </div>
      <div className="voice-player">
        <button type="button" className="voice-play" onClick={toggle} aria-label={playing ? "Pause voice message" : "Play voice message"}>
          {playing ? (
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1" /><rect x="14" y="5" width="4" height="14" rx="1" /></svg>
          ) : (
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 001.54.84l10-6.5a1 1 0 000-1.68l-10-6.5A1 1 0 008 5.5z" /></svg>
          )}
        </button>
        <div className="voice-progress" onClick={seek} role="slider" aria-label="Seek" aria-valuemin={0} aria-valuemax={Math.round(dur)} aria-valuenow={Math.round(cur)}>
          <div className="voice-progress-fill" style={{ width: dur ? `${Math.min(100, (cur / dur) * 100)}%` : "0%" }} />
        </div>
        <span className="voice-time">{fmtClock(cur)}{dur ? ` / ${fmtClock(dur)}` : ""}</span>
      </div>
      <audio
        ref={audioRef}
        src={src}
        preload="metadata"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => { setPlaying(false); setCur(0); }}
        onTimeUpdate={(e) => setCur(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => setDur(e.currentTarget.duration || 0)}
      />
    </div>
  );
}

export function Tweet({ tweet, api, onDeleted, detail = false, onReplyOverride }: Props) {
  const navigate = useNavigate();
  const now = useNow();
  const [deleting, setDeleting] = useState(false);
  const [shared, setShared] = useState(false);

  const pending = isPendingTweet(tweet);
  const view = toTweetView(tweet, now);
  const mine = view.real !== null && view.real.author.id === getCallerId();

  // The tweet's playable game, if any (a !Game command, or a pasted
  // Open Arcade link once it resolves). While a pasted link is still
  // resolving we do not yet know if there is a game, so the tweet's
  // image waits too: a game tweet must never flash, or settle into,
  // the double-picture stack Dave flagged on Harsh's posts.
  const { game: tweetGame, pending: gamePending } = useTweetGameEmbed(view.text);
  // The poster's attached image IS the cover art: it becomes the
  // play screen's cover (for MURKH this replaces the generic Open
  // Arcade placeholder the catalog serves) and the standalone image
  // is not rendered at all. One big image, and you can play it.
  const embedGame = tweetGame
    ? coverFromTweetImage(tweetGame, resolveImageUrl(view.image_url))
    : null;

  // X-style repost attribution ("Name reposted", "You reposted" for the
  // viewer): only on timeline entries that exist because of a repost.
  // Prefer the store's live profile for the reposter, like the author.
  const repostedBy = view.real?.reposted_by ?? null;
  const reposterProfile = repostedBy ? getProfileById(repostedBy.id) : undefined;
  const reposterHandle = reposterProfile?.handle ?? repostedBy?.handle ?? "";
  const reposterLabel = repostedBy
    ? repostedBy.id === getCallerId()
      ? "You"
      : (reposterProfile?.display_name ?? repostedBy.display_name)
    : null;

  // Server-rendered html already linkifies #tags and @mentions; route
  // those through the SPA instead of a full page load.
  const onBodyClick = (e: React.MouseEvent) => {
    const a = (e.target as HTMLElement).closest("a");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (href.startsWith("/hashtag/") || href.startsWith("/profile/") || a.hasAttribute("data-handle")) {
      e.preventDefault();
      e.stopPropagation();
      navigate(shortProfilePath(href));
    }
  };

  const openThread = () => {
    if (view.real) navigate(`/tweet/${view.real.id}`);
  };

  // X behavior: the reply icon opens the reply modal, not the thread.
  const onReply = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    if (onReplyOverride) {
      onReplyOverride(view.real);
    } else {
      openReplyModal(view.real);
    }
  };

  const onDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real || deleting) return;
    const prompt = mine
      ? "Delete this post?"
      : `Delete @${view.handle}'s post? It is saved to the moderation log as a low-quality removal that Muse watches.`;
    if (!window.confirm(prompt)) return;
    setDeleting(true);
    try {
      await api.deleteTweet(view.real.id);
      onDeleted?.(view.real.id);
    } catch (err) {
      setDeleting(false);
      const msg = err instanceof Error ? err.message : "";
      if (msg) window.alert(`Could not delete this post: ${msg}`);
    }
  };

  const onShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!view.real) return;
    const url = `${window.location.origin}/tweet/${view.real.id}`;
    const text = `${view.name} (@${view.handle}): ${view.text}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "LlamaChat post", text, url });
      } else {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      }
    } catch {
      // user cancelled share or clipboard failed; try clipboard as fallback
      try {
        await navigator.clipboard.writeText(url);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch { /* ignore */ }
    }
  };

  return (
    <article
      className={`tweet${pending ? " pending" : ""}`}
      onClick={openThread}
      aria-label={pending ? "Sending post" : `Post by ${view.name}`}
    >
      <a
        className="avatar-link"
        href={profilePath(view.handle)}
        onClick={(e) => {
          e.stopPropagation();
          navigate(profilePath(view.handle));
        }}
      >
        <Avatar name={view.name} url={view.avatar} />
      </a>
      <div className="tweet-body">
        {repostedBy ? (
          <a
            className="tweet-repost-note"
            href={profilePath(reposterHandle)}
            onClick={(e) => {
              e.stopPropagation();
              navigate(profilePath(reposterHandle));
            }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 014-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 01-4 4H3"/></svg>
            <span>{reposterLabel} reposted</span>
          </a>
        ) : null}
        <div className="tweet-head">
          <a
            className="name"
            href={profilePath(view.handle)}
            onClick={(e) => {
              e.stopPropagation();
              navigate(profilePath(view.handle));
            }}
          >
            {view.name}
          </a>
          <span className="meta">
            <a
              className="tw-handle"
              href={profilePath(view.handle)}
              onClick={(e) => {
                e.stopPropagation();
                navigate(profilePath(view.handle));
              }}
            >
              @{view.handle}
            </a>
            {" · "}
            {view.real ? (
              <a
                className="tw-time"
                href={`/tweet/${view.real.id}`}
                title="View tweet"
                onClick={(e) => {
                  e.stopPropagation();
                  openThread();
                }}
              >
                {view.time}
              </a>
            ) : (
              <span className="tw-time sending">{view.time}</span>
            )}
          </span>
          {view.real ? (
            <TweetMenu mine={mine || isDaveModerator()} deleting={deleting} onDelete={onDelete} onShare={onShare} />
          ) : null}
          {view.real && (mine || isDaveModerator()) ? (
            <button
              type="button"
              className="tw-mod-x"
              aria-label={mine ? "Delete this post" : `Delete @${view.handle}'s post (moderator)`}
              title="Delete this post"
              disabled={deleting}
              onClick={onDelete}
            >
              ×
            </button>
          ) : null}
        </div>
        {view.html ? (
          <div className="tweet-text" onClick={onBodyClick} dangerouslySetInnerHTML={{ __html: sanitizeTweetHtml(view.html) }} />
        ) : view.text ? (
          <p className="tweet-text">{view.text}</p>
        ) : null}
        {/* X order: own text, quoted card, own image, actions. A bare
            quote has no text of its own; a deleted original renders the
            unavailable card (quote_of_id set, quoted_tweet null). */}
        {view.quote_of_id ? (
          view.quoted_tweet ? (
            <QuotedTweetCard tweet={view.quoted_tweet} now={now} />
          ) : (
            <QuotedUnavailableCard />
          )
        ) : null}
        {/* One big image per game tweet: when the tweet embeds a
            playable game, its attached image lives on the game's
            play screen as the cover and is NOT also shown above it
            (the double-picture stack Dave flagged, Oct 31 2026).
            The standalone image renders only when there is no game,
            and not while a pasted game link is still resolving. */}
        {/* A video tweet (Nov 1 2026) plays right in the feed: the
            player takes the image slot and the image becomes its
            poster frame, so the two never stack. */}
        {view.video_url && !embedGame && !gamePending ? (
          <TweetVideo videoUrl={view.video_url} posterUrl={view.image_url} />
        ) : view.image_url && !embedGame && !gamePending ? (
          <TweetImage imageUrl={view.image_url} />
        ) : null}
        {view.audio_url ? <VoiceCard view={view} /> : null}
        {embedGame ? <GameEmbed game={embedGame} /> : null}
        {/* A pasted YouBoob watch link previews right in the post
            (Dave, Nov 1 2026): poster + title, Play plays it here.
            One embed per post: a game embed wins, like the Open
            Arcade rule. */}
        {!embedGame ? <YouBoobEmbed text={view.text} /> : null}
        {detail && view.real ? (
          <div className="tw-detail-time">{absTime(view.real.created_at)}</div>
        ) : null}
        {view.real && (
          <TweetActions
            view={view}
            api={api}
            shared={shared}
            onReply={onReply}
            onShare={onShare}
          />
        )}
      </div>
    </article>
  );
}

/**
 * Reply / repost / like / views / share action row under a tweet.
 * No Delete button down here (Dave, Nov 1 2026): the little X at the
 * top right of the post is the delete, and that is plenty.
 */
function TweetActions({
  view,
  api,
  shared,
  onReply,
  onShare,
}: {
  view: TweetView;
  api: ApiClient;
  shared: boolean;
  onReply: (e: React.MouseEvent) => void;
  onShare: (e: React.MouseEvent) => void;
}) {
  if (!view.real) return null;
  const real = view.real;
  return (
    <div className="tweet-actions" onClick={(e) => e.stopPropagation()}>
      <button type="button" className="act reply" aria-label={`${view.replies_count} replies`} onClick={onReply}>
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-3-.4-4.2-1.1L3 20l1.1-5.3A8.5 8.5 0 1 1 21 11.5z"/></svg></span>
        <span className="n">{view.replies_count > 0 ? view.replies_count : null}</span>
      </button>
      <RepostMenu tweet={real} api={api} />
      <LikeToggle tweetId={real.id} initial={view.likes_count} initialLiked={!!real.liked} api={api} />
      <span className="act views" aria-label="Views">
        <span className="ic"><svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="10" width="3.5" height="10" rx="1"/><rect x="8" y="4" width="3.5" height="16" rx="1"/><rect x="13" y="12" width="3.5" height="8" rx="1"/><rect x="18" y="7" width="3.5" height="13" rx="1"/></svg></span>
      </span>
      <button type="button" className={`act share${shared ? " on" : ""}`} aria-label="Share post" onClick={onShare} title={shared ? "Link copied!" : "Share"}>
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12"/><path d="M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 002 2h10a2 2 0 002-2v-6"/></svg></span>
      </button>
      <a href={`https://e2-prod.pages.dev/songify/?url=${encodeURIComponent(`https://llamachat.lol/tweet/${real.id}`)}`} target="_blank" rel="noopener" className="act songify" aria-label="Songify this tweet" title="Songify">
        <span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span>
      </a>
    </div>
  );
}
