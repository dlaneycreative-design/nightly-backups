#!/usr/bin/env node
// Bake the Starvard flashcard decks for the in-app Flashcards view.
//
// The canonical deck data lives in the flashcards page itself
// (starvard.org/flashcards: a `const DECKS = [...]` plus `const NAMES =
// [...]` literal in its inline script). This script extracts those two
// literals from the page source and writes them as JSON to
// public-starvard/flashcards-es.json (served at /feed/flashcards-es.json)
// and public/flashcards-es.json (the Llama build's copy, Apps V1), which
// the Flashcards view lazy-loads.
//
// This mirrors scripts/fetch-seed.js: a build-time baked copy of data
// whose source of truth lives elsewhere. Progress is NOT data here:
// known/working state stays in the shared localStorage keys +
// /api/account sync the flashcards page already uses (see
// src/lib/flashcards.ts). Re-run this script whenever the decks change
// on the flashcards page, then rebuild the Starvard skin.
//
// Source: the live page first (what students actually get), falling
// back to the local slim tree copy if the fetch fails.

import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const LIVE_URL = "https://starvard.org/flashcards/";
const LOCAL_PAGE = fileURLToPath(
  new URL("../../../.tmp/starvard-merged/flashcards/index.html", import.meta.url)
);
// Both skins serve the baked decks: Starvard at /feed/flashcards-es.json,
// Llama (Apps V1, Oct 19 2026) at /flashcards-es.json.
const OUTS = [
  fileURLToPath(new URL("../public-starvard/flashcards-es.json", import.meta.url)),
  fileURLToPath(new URL("../public/flashcards-es.json", import.meta.url)),
];

async function getPage() {
  try {
    const r = await fetch(LIVE_URL);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } catch (e) {
    console.warn(`live fetch failed (${e.message}); using local tree copy`);
    return readFile(LOCAL_PAGE, "utf8");
  }
}

/** Extract `const NAME = <array literal>;` and evaluate it safely. */
function extractArray(html, name) {
  const marker = `const ${name} = `;
  const start = html.indexOf(marker);
  if (start < 0) throw new Error(`${name} literal not found`);
  const from = start + marker.length;
  // Balanced scan for the matching close bracket (string aware).
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = from; i < html.length; i++) {
    const c = html[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "[") depth++;
    else if (c === "]") {
      depth--;
      if (depth === 0) {
        const literal = html.slice(from, i + 1);
        try {
          return JSON.parse(literal);
        } catch {
          return vm.runInNewContext(`(${literal})`, Object.create(null), { timeout: 5000 });
        }
      }
    }
  }
  throw new Error(`${name} literal never closes`);
}

const html = await getPage();
const decks = extractArray(html, "DECKS");
const names = extractArray(html, "NAMES");

if (!Array.isArray(decks) || decks.length === 0) throw new Error("DECKS is empty");
if (!Array.isArray(names) || names.length !== decks.length)
  throw new Error(`NAMES (${names.length}) and DECKS (${decks.length}) length mismatch`);
for (const [l, deck] of decks.entries()) {
  if (!Array.isArray(deck) || deck.length === 0) throw new Error(`deck ${l} empty`);
  for (const card of deck) {
    if (!Array.isArray(card) || card.length < 3 || card.some((f) => typeof f !== "string"))
      throw new Error(`deck ${l} has a malformed card`);
  }
}

const out = {
  lang: "es",
  langName: "Spanish",
  frontLabel: "ESPAÑOL",
  backLabel: "ENGLISH",
  speakLang: "es-ES",
  names,
  decks,
};
for (const out_path of OUTS) await writeFile(out_path, JSON.stringify(out));
const total = decks.reduce((a, d) => a + d.length, 0);
console.log(
  `wrote ${OUTS.join(" + ")}: ${decks.length} levels, ${total} cards; level 6 = "${names[5]}"`
);
