// Instagram-first signup: Step 1 asks for Instagram, then Dave vets them.
// Dave's call Oct 9 2026: "when they click that button fire a modal and grab their insta!"
import { useEffect, useState } from "react";
import { subscribeSignupModal, closeSignupModal, isSignupOpen } from "../lib/signupModal.ts";

export function SignupModalHost() {
  const [open, setOpen] = useState(isSignupOpen());
  useEffect(() => subscribeSignupModal(setOpen), []);
  if (!open) return null;
  return <SignupModal onClose={closeSignupModal} />;
}

function SignupModal({ onClose }: { onClose: () => void }) {
  const [instagram, setInstagram] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const ig = instagram.trim().replace(/^@/, "");
    if (!ig) return;
    setBusy(true);
    setError("");
    try {
      // Send to the same join-signups store Dave vets for E2 passports
      const res = await fetch("https://www.thestudio.io/api/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "LlamaChat signup", instagram: ig }),
      });
      if (!res.ok) throw new Error("save failed");
      try {
        localStorage.setItem("llama_signup_instagram", ig);
      } catch { /* non-fatal */ }
      setDone(true);
    } catch {
      setError("Something went wrong. Try again?");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rm-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="rm-modal" style={{maxWidth:420,padding:"32px 28px",position:"relative"}} role="dialog" aria-label="Join LlamaChat">
        <button className="rm-close" onClick={onClose} aria-label="Close" style={{position:"absolute",top:12,left:12,border:"none",background:"none",cursor:"pointer",fontSize:18}}>✕</button>
        {!done ? (
          <>
            <h2 style={{fontSize:24,margin:"0 0 8px"}}>What is your Instagram?</h2>
            <p style={{color:"#536471",margin:"0 0 24px",fontSize:15}}>
              Step 1 of joining LlamaChat. We review every account by hand.
            </p>
            <form onSubmit={submit}>
              <input
                value={instagram}
                onChange={(e) => setInstagram(e.target.value)}
                placeholder="@yourhandle"
                autoFocus
                style={{width:"100%",padding:"12px 16px",fontSize:16,border:"1px solid #cfd9de",borderRadius:9999,marginBottom:12,outline:"none",boxSizing:"border-box"}}
              />
              {error && <p style={{color:"#f4212e",fontSize:14,marginBottom:12}}>{error}</p>}
              <button
                type="submit"
                disabled={busy || !instagram.trim()}
                style={{width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#1d9bf0",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",opacity:busy||!instagram.trim()?0.5:1}}
              >
                {busy ? "Sending..." : "Continue"}
              </button>
            </form>
            <p style={{fontSize:13,marginTop:16}}>
              <a href="/login" style={{color:"#1d9bf0"}}>Already have an account? Log in</a>
            </p>
          </>
        ) : (
          <>
            <h2 style={{fontSize:24,margin:"0 0 8px"}}>You're on the list! 🎉</h2>
            <p style={{color:"#536471",margin:"0 0 24px",fontSize:15}}>
              We'll take a look at @{instagram.trim().replace(/^@/, "")} and get you in soon.
            </p>
            <button
              onClick={onClose}
              style={{width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#1d9bf0",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer"}}
            >
              Done
            </button>
          </>
        )}
      </div>
    </div>
  );
}
