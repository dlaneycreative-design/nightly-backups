// YouBoob link preview tests: id extraction (the zero-step paste
// cases), the synchronous base info for yt- videos and native films,
// and the unknown-id fallback card data.
import { test } from "node:test";
import assert from "node:assert/strict";
import { extractYouBoobId, baseYouBoobInfo } from "../src/lib/youboob.ts";

test("extracts a yt- id from a full watch link (Dave's Nov 1 post)", () => {
  assert.equal(
    extractYouBoobId("@Harsh check this vid. It's good! https://youboob.lol/watch/yt-FaV90HyywFo"),
    "yt-FaV90HyywFo"
  );
});

test("extracts native slugs, bare and www hosts, trailing slash and punctuation", () => {
  assert.equal(extractYouBoobId("youboob.lol/watch/harsh-story"), "harsh-story");
  assert.equal(extractYouBoobId("see https://www.youboob.lol/watch/meet-sally/ now"), "meet-sally");
  assert.equal(extractYouBoobId("(https://youboob.lol/watch/dumb-ideas)."), "dumb-ideas");
  assert.equal(extractYouBoobId("https://youboob.pages.dev/watch/e2-film"), "e2-film");
});

test("no watch link, no id", () => {
  assert.equal(extractYouBoobId("just a post about youboob.lol"), null);
  assert.equal(extractYouBoobId("https://youboob.lol/"), null);
  assert.equal(extractYouBoobId("https://youtube.com/watch?v=FaV90HyywFo"), null);
  assert.equal(extractYouBoobId(""), null);
});

test("yt- base info: YouTube poster, embed id, watch page", () => {
  const info = baseYouBoobInfo("yt-FaV90HyywFo");
  assert.equal(info.ytId, "FaV90HyywFo");
  assert.equal(info.thumbUrl, "https://i.ytimg.com/vi/FaV90HyywFo/hqdefault.jpg");
  assert.equal(info.pageUrl, "https://youboob.lol/watch/yt-FaV90HyywFo");
  assert.equal(info.srcUrl, null);
});

test("native base info: title, channel, self-hosted mp4 and poster", () => {
  const info = baseYouBoobInfo("harsh-story");
  assert.equal(info.title, "Meet Harsh | Kindness, Community and the Calcutta Raiders");
  assert.equal(info.channel, "Harsh");
  assert.equal(info.srcUrl, "https://youboob.lol/videos/harsh-story.mp4");
  assert.equal(info.thumbUrl, "https://youboob.lol/img/t-harsh-story.jpg");
  assert.equal(info.duration, "1:52");
});

test("unknown id still gets a watch-page card", () => {
  const info = baseYouBoobInfo("some-new-video");
  assert.equal(info.pageUrl, "https://youboob.lol/watch/some-new-video");
  assert.equal(info.ytId, null);
  assert.equal(info.srcUrl, null);
  assert.equal(info.thumbUrl, null);
});
