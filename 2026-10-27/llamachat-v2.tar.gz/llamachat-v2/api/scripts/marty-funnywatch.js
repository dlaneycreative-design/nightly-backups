const { postTweet } = require("./lib/botlib");

const POSTS = [
  {
    key: "marty:funnywatch-1",
    text: "sam is not 'online.' sam is INFRASTRUCTURE. she answered a message before i finished typing it yesterday and i have been a little bit scared of the discord ever since. blinking is a security risk now",
  },
  {
    key: "marty:funnywatch-2",
    text: "our community is an entire archipelago of filipino builders hustling at full speed, and then there is harsh from india keeping pace with ALL of them by himself. that man does not have a work ethic, he has a whole department in a trench coat",
  },
  {
    key: "marty:funnywatch-3",
    text: "the range in this company is unreal. dinesh: 'i'm sooooo good at computers.' also dinesh: actually is. meanwhile mike sits at a computer like it might jump him. both of them are somehow the correct amount of confidence",
  },
  {
    key: "marty:funnywatch-4",
    text: "filipino builders do not join a discord, they ARRIVE. one minute it's quiet, next minute it's intros, portfolios, three startups, a hackathon, and somebody asking the exact right question. my notifications have a six pack now",
  },
  {
    key: "marty:funnywatch-5",
    text: "buster and i watched a phone chant and a coin dance on tv last night like it was prestige cinema. somewhere out there is a man who just wanted to build websites. he now owns a university, a tipping coin with choreography, and 10,307 recipes",
  },
];

(async () => {
  for (const p of POSTS) {
    const { tweet, deduped } = await postTweet({
      handle: "Marty",
      text: p.text,
      idempotencyKey: p.key,
    });
    console.log(deduped ? "deduped" : "posted", p.key, "https://llamachat.lol/tweet/" + tweet.id);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
