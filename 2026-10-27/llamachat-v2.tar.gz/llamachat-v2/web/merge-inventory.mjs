// READ-ONLY inventory for the Chadwick merge. No writes.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

// 1. Both profile rows, full
const profs = await sql`SELECT * FROM profiles WHERE handle IN ('chadwick','chadwickblaze') ORDER BY handle`;
console.log('=== PROFILES ===');
for (const p of profs) console.log(JSON.stringify(p));
if (profs.length !== 2) { console.log('EXPECTED 2 PROFILES, GOT', profs.length); process.exit(2); }
const chad = profs.find(p => p.handle === 'chadwick');
const blaze = profs.find(p => p.handle === 'chadwickblaze');
const C = chad.id, B = blaze.id;
console.log('CHADWICK id:', C, '| BLAZE id:', B);

// 2. ALL tables in the DB
const tables = await sql`SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name`;
console.log('=== TABLES ===', tables.map(t => t.table_name).join(', '));

// 3. ALL columns in any table that could hold a profile id: FK references to profiles + any uuid columns named like user refs
const fks = await sql`
  SELECT tc.table_name, kcu.column_name, rc.delete_rule
  FROM information_schema.table_constraints tc
  JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name
  JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name
  JOIN information_schema.referential_constraints rc ON tc.constraint_name = rc.constraint_name
  WHERE tc.constraint_type='FOREIGN KEY' AND ccu.table_name='profiles' AND ccu.column_name='id'
  ORDER BY tc.table_name, kcu.column_name`;
console.log('=== FK COLUMNS -> profiles(id) ===');
for (const f of fks) console.log(`  ${f.table_name}.${f.column_name} (ON DELETE ${f.delete_rule})`);

// 4. Counts for a given id across a table.column
async function cnt(table, col, id) {
  const r = await sql.query(`SELECT count(*)::int AS n FROM "${table}" WHERE "${col}" = $1`, [id]);
  return r[0].n;
}
console.log('=== COUNTS (chadwick | blaze) ===');
for (const f of fks) {
  const nc = await cnt(f.table_name, f.column_name, C);
  const nb = await cnt(f.table_name, f.column_name, B);
  if (nc || nb) console.log(`  ${f.table_name}.${f.column_name}: ${nc} | ${nb}`);
}
// tweets split: top-level vs replies, per author
const tw = await sql`SELECT author_id, count(*)::int AS total, count(*) FILTER (WHERE reply_to_id IS NULL)::int AS top_level, count(*) FILTER (WHERE reply_to_id IS NOT NULL)::int AS replies FROM tweets WHERE author_id IN (${C}, ${B}) GROUP BY author_id`;
console.log('=== TWEETS BY AUTHOR ==='); for (const r of tw) console.log(' ', r.author_id === C ? 'chadwick' : 'blaze', JSON.stringify(r));
// likes/reposts RECEIVED (on authored tweets)
const lr = await sql`SELECT t.author_id, (SELECT count(*)::int FROM likes l WHERE l.tweet_id IN (SELECT id FROM tweets WHERE author_id = t.author_id)) AS likes_recv, (SELECT count(*)::int FROM reposts rp WHERE rp.tweet_id IN (SELECT id FROM tweets WHERE author_id = t.author_id)) AS reposts_recv FROM (SELECT DISTINCT author_id FROM tweets WHERE author_id IN (${C}, ${B})) t`;
console.log('=== RECEIVED ==='); for (const r of lr) console.log(' ', r.author_id === C ? 'chadwick' : 'blaze', JSON.stringify(r));

console.log('=== OVERLAP ANALYSIS ===');
// likes overlap: tweets both liked
const lo = await sql`SELECT count(*)::int AS n FROM likes a JOIN likes b ON a.tweet_id = b.tweet_id WHERE a.user_id = ${C} AND b.user_id = ${B}`;
console.log('  likes overlap (both liked same tweet):', lo[0].n);
// blaze likes on own/blaze-authored + chad-authored tweets
const blo = await sql`SELECT count(*)::int AS n FROM likes l JOIN tweets t ON l.tweet_id = t.id WHERE l.user_id = ${B} AND t.author_id IN (${C}, ${B})`;
console.log('  blaze likes on either Chadwick\'s tweets:', blo[0].n);
const ro = await sql`SELECT count(*)::int AS n FROM reposts a JOIN reposts b ON a.tweet_id = b.tweet_id WHERE a.user_id = ${C} AND b.user_id = ${B}`;
console.log('  reposts overlap:', ro[0].n);
const fo = await sql`SELECT count(*)::int AS n FROM follows a JOIN follows b ON a.following_id = b.following_id WHERE a.follower_id = ${C} AND b.follower_id = ${B}`;
console.log('  follows overlap (both follow same account):', fo[0].n);
const fi = await sql`SELECT count(*)::int AS n FROM follows a JOIN follows b ON a.follower_id = b.follower_id WHERE a.following_id = ${C} AND b.following_id = ${B}`;
console.log('  followers overlap (same account follows both):', fi[0].n);
const cross = await sql`SELECT follower_id, following_id FROM follows WHERE (follower_id = ${C} AND following_id = ${B}) OR (follower_id = ${B} AND following_id = ${C})`;
console.log('  cross-follows between the two Chadwicks:', JSON.stringify(cross));
const selfAfter = await sql`SELECT count(*)::int AS n FROM follows WHERE follower_id = ${B} AND following_id = ${B}`;
console.log('  blaze self-follows (pre-existing):', selfAfter[0].n);
const po = await sql`SELECT count(*)::int AS n FROM conversation_participants a JOIN conversation_participants b ON a.conversation_id = b.conversation_id WHERE a.user_id = ${C} AND b.user_id = ${B}`;
console.log('  conversations both participate in:', po[0].n);
const bothOnly = await sql`SELECT cp.conversation_id, count(*)::int AS parts FROM conversation_participants cp WHERE cp.conversation_id IN (SELECT conversation_id FROM conversation_participants WHERE user_id IN (${C}, ${B})) GROUP BY cp.conversation_id HAVING count(DISTINCT user_id) FILTER (WHERE user_id IN (${C}, ${B})) = 2 AND count(*) = 2`;
console.log('  conversations whose ONLY participants are the two Chadwicks:', JSON.stringify(bothOnly));
// notifications overlap risk: notifications PK? check constraints later; count by type
const notif = await sql`SELECT user_id, actor_id, count(*)::int AS n FROM notifications WHERE user_id IN (${C}, ${B}) OR actor_id IN (${C}, ${B}) GROUP BY user_id, actor_id ORDER BY n DESC LIMIT 20`;
console.log('=== NOTIFICATIONS (top) ==='); for (const r of notif) console.log('  user:', r.user_id === C ? 'chad' : r.user_id === B ? 'blaze' : 'other', '| actor:', r.actor_id === C ? 'chad' : r.actor_id === B ? 'blaze' : 'other', '| n:', r.n);
// any unique constraints on notifications?
const uq = await sql`SELECT tc.table_name, tc.constraint_name, string_agg(kcu.column_name, ',') AS cols FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name WHERE tc.constraint_type IN ('UNIQUE','PRIMARY KEY') AND tc.table_name IN ('notifications','messages','tweets','conversation_participants') GROUP BY tc.table_name, tc.constraint_name ORDER BY tc.table_name`;
console.log('=== PK/UNIQUE on key tables ==='); for (const r of uq) console.log(' ', r.table_name, r.constraint_name, '->', r.cols);
console.log('INVENTORY DONE');
