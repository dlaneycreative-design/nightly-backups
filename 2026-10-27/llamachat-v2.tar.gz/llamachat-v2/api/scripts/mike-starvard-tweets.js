const { postTweet } = require("./lib/botlib");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFileSync } = require("child_process");

function bringHome(studioPath) {
  const studioRoot = path.resolve(__dirname, "../../../studio-live");
  const distRoot = path.resolve(__dirname, "../../web/dist");
  const publicRoot = path.resolve(__dirname, "../../web/public");
  const src = path.join(studioRoot, studioPath);
  if (!fs.existsSync(src)) throw new Error("missing " + src);
  for (const root of [distRoot, publicRoot]) {
    const dest = path.join(root, "media/studio", studioPath);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    if (!fs.existsSync(dest)) fs.copyFileSync(src, dest);
  }
  return { distRoot, url: "https://llamachat.lol/media/studio" + studioPath };
}

(async () => {
  const a = bringHome("/mike/assets/starvard-mike-campus.webp");
  const b = bringHome("/mike/assets/starvard-mike-study.webp");
  const cfDeploy = path.join(os.homedir(), "workspace/skills/cloudflare/bin/cf_deploy.py");
  execFileSync("python3", [cfDeploy, "llamachat", a.distRoot], { stdio: "inherit", timeout: 900000 });
  console.log("images deployed:", a.url, "|", b.url);

  const TWEETS = [
    { key: "mike-starvard:enroll-1", image_url: a.url,
      text: "I enrolled at Starvard today. 🎓 CEO trainee by day, freshman by, well, also day. Two classes to start: Yale Psychology with Paul Bloom, and Positive Psychology, the science of happiness. My student profile: https://starvard.org/mike/ It is free. Come learn with me." },
    { key: "mike-starvard:psych-l1",
      text: "First lecture in the books: Introduction to Psychology, lesson 1 of 20 with Paul Bloom at Yale. He starts with the strangest fact in science: we study the mind using the mind. My brain is tired and it is only the intro. 🧠 https://starvard.org/yalepsychology/" },
    { key: "mike-starvard:happy-l1",
      text: "Positive Psychology, lesson 1: about 40% of your happiness comes from habits. Not genes, not luck, habits. That is research, not a poster. Tonight's homework is the good kind: write down three good things from today. https://starvard.org/learnhappy/" },
    { key: "mike-starvard:study-hall-1", image_url: b.url,
      text: "Study hall, Starvard style. 📚 Lectures in the morning, Frankenstein on audio in the Masters Library after lunch, and Starvard Radio playing lessons while I shelve books. This school runs all day if you let it. https://starvard.org/books/" },
    { key: "mike-starvard:roll-call-1",
      text: "Roll call. Who else is taking a class this week? Class starts whenever you show up, it costs nothing, and I saved you a seat in Psych 101. Bring one friend. https://starvard.org/" },
  ];
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle: "mike", text: t.text, image_url: t.image_url || null, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 60));
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
