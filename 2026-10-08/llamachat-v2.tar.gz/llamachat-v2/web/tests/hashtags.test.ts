// Hashtag parsing must match the server exactly (api/lib/render.js).
// If these drift, #tags linkify on one side and not the other.
import { test } from "node:test";
import assert from "node:assert/strict";
import { extractHashtags, highlightMatches } from "../src/lib/hashtags.ts";

test("extracts lowercase tags in first-seen order", () => {
  assert.deepEqual(extractHashtags("Hello #World, this is #kind"), ["world", "kind"]);
});

test("dedupes case-insensitively", () => {
  assert.deepEqual(extractHashtags("#Hello #hello #HELLO"), ["hello"]);
});

test("requires start-of-string or whitespace before # (server parity)", () => {
  assert.deepEqual(extractHashtags("email me at a#b.com"), []);
  assert.deepEqual(extractHashtags("(#tag)"), []); // ( is not \s: server skips it too
  assert.deepEqual(extractHashtags("hey #tag, see #tag2"), ["tag", "tag2"]);
});

test("allows letters, digits, underscore; stops at punctuation", () => {
  assert.deepEqual(extractHashtags("#tag_123! #a#b"), ["tag_123", "a"]);
});

test("ignores bare #; caps tags at 64 chars like the server", () => {
  assert.deepEqual(extractHashtags("# #!"), []);
  assert.deepEqual(extractHashtags("#" + "x".repeat(64)), ["x".repeat(64)]);
  assert.deepEqual(extractHashtags("#" + "x".repeat(65)), ["x".repeat(64)]);
});

test("highlightMatches splits on case-insensitive matches", () => {
  const segs = highlightMatches("Hello hello HELLO", "hello");
  assert.deepEqual(
    segs.filter((s) => s.highlight).map((s) => s.text),
    ["Hello", "hello", "HELLO"]
  );
  assert.equal(segs.filter((s) => !s.highlight).map((s) => s.text).join(""), "  ");
});

test("highlightMatches with empty query returns one plain segment", () => {
  assert.deepEqual(highlightMatches("abc", "  "), [{ text: "abc", highlight: false }]);
});

test("highlightMatches with no match returns the whole text plain", () => {
  assert.deepEqual(highlightMatches("abc", "zzz"), [{ text: "abc", highlight: false }]);
});
