// Tweet view-model helpers shared by Tweet.tsx and Feed.tsx.
// Kept out of the component file so Tweet.tsx only exports components.
import type { TempTweet } from "../components/Composer.tsx";
import type { Tweet as TweetT } from "./api.ts";

/** A tweet still waiting on the server. Renders "sending...", never a time. */
export interface PendingViewTweet {
  pending: true;
  tempId: string;
  text: string;
  image_url: string | null;
  /** Quote target carried through so the pending row renders the
   * embedded card immediately, before the server confirms. */
  quote_of_id: string | null;
  quoted_tweet: TweetT | null;
  author: { display_name: string; handle: string; avatar_url: string | null };
}

export type TweetLike = TweetT | PendingViewTweet;

/** Type guard: optimistic (server-unconfirmed) tweets carry pending: true. */
export function isPendingTweet(t: unknown): t is PendingViewTweet {
  return (t as PendingViewTweet).pending === true;
}

export function tempToPending(temp: TempTweet, author: PendingViewTweet["author"]): PendingViewTweet {
  return {
    pending: true,
    tempId: temp.tempId,
    text: temp.text,
    image_url: temp.image_url,
    quote_of_id: temp.quote_of_id,
    quoted_tweet: temp.quoted_tweet,
    author,
  };
}
