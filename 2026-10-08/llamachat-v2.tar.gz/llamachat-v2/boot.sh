#!/bin/bash
# LlamaChat V2 dev boot: recovers the full local stack after a VM replacement.
# Idempotent: safe to run any time. Usage: bash ~/workspace/llamachat-v2/boot.sh
set -u
export DATABASE_URL='postgresql://llamachat:llamachat_dev_pw@localhost:5432/llamachat_v2'
export PORT=3000
V2=~/workspace/llamachat-v2

echo "[boot] 1/5 postgres binaries..."
if ! command -v /usr/lib/postgresql/16/bin/initdb >/dev/null 2>&1; then
  echo "[boot] installing postgresql-16 from .debs (apt mirrors are flaky)..."
  cd /tmp
  BASE="http://azure.archive.ubuntu.com/ubuntu"
  dl() { [ -f "$2" ] || curl -sO "$BASE/$1/$2"; }
  dl "pool/main/p/postgresql-16" "postgresql-client-16_16.15-0ubuntu0.24.04.1_amd64.deb"
  dl "pool/main/p/postgresql-16" "postgresql-16_16.15-0ubuntu0.24.04.1_amd64.deb"
  dl "pool/main/p/postgresql-16" "libpq5_16.15-0ubuntu0.24.04.1_amd64.deb"
  dl "pool/main/p/postgresql-common" "postgresql-client-common_293ubuntu1_all.deb"
  dl "pool/main/p/postgresql-common" "postgresql-common_293ubuntu1_all.deb"
  dl "pool/main/l/llvm-toolchain-17" "libllvm17t64_17.0.6-9ubuntu1_amd64.deb"
  dl "pool/main/libj/libjson-perl" "libjson-perl_4.10000-1_all.deb"
  dl "pool/main/s/ssl-cert" "ssl-cert_1.2.0ubuntu1_all.deb"
  # libllvm is large and often truncates; resume until complete
  for i in 1 2 3; do
    if dpkg-deb --info /tmp/libllvm17t64_17.0.6-9ubuntu1_amd64.deb >/dev/null 2>&1; then break; fi
    echo "[boot] libllvm truncated, resuming (attempt $i)..."
    curl -C - -sO "$BASE/pool/main/l/llvm-toolchain-17/libllvm17t64_17.0.6-9ubuntu1_amd64.deb"
  done
  dpkg -i /tmp/libpq5_*.deb /tmp/postgresql-client-common_*.deb /tmp/postgresql-common_*.deb \
    /tmp/libjson-perl_*.deb /tmp/ssl-cert_*.deb /tmp/libllvm17t64_*.deb \
    /tmp/postgresql-client-16_*.deb /tmp/postgresql-16_*.deb 2>&1 | tail -1
fi

echo "[boot] 2/5 postgres server..."
if ! su postgres -c "psql -c 'SELECT 1'" >/dev/null 2>&1; then
  rm -rf /var/lib/postgresql/16/main
  mkdir -p /var/lib/postgresql/16/main
  chown postgres:postgres /var/lib/postgresql/16/main
  chmod 700 /var/lib/postgresql/16/main
  su postgres -c "/usr/lib/postgresql/16/bin/initdb -D /var/lib/postgresql/16/main -E UTF8" >/dev/null
  # The API always connects with SSL (lib/db.js). A fresh initdb has SSL off,
  # which breaks migrate/seed/server on a cold boot. Install the system
  # snakeoil cert and start with ssl=on. (Learned 2026-10-07: fresh cluster
  # took the whole dev stack down until SSL was enabled.)
  cp /etc/ssl/certs/ssl-cert-snakeoil.pem /var/lib/postgresql/16/main/server.crt
  cp /etc/ssl/private/ssl-cert-snakeoil.key /var/lib/postgresql/16/main/server.key
  chown postgres:postgres /var/lib/postgresql/16/main/server.crt /var/lib/postgresql/16/main/server.key
  chmod 600 /var/lib/postgresql/16/main/server.key
  su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D /var/lib/postgresql/16/main -l /tmp/pg.log -o '-c ssl=on -c listen_addresses=127.0.0.1 -c port=5432' start"
  sleep 2
  su postgres -c "psql -c \"CREATE ROLE llamachat WITH LOGIN PASSWORD 'llamachat_dev_pw';\""
  su postgres -c "psql -c 'CREATE DATABASE llamachat_v2 OWNER llamachat;'"
else
  echo "[boot] postgres already running"
fi

echo "[boot] 3/5 migrate..."
cd "$V2/api" && node scripts/migrate.js

echo "[boot] 4/5 seed (idempotent)..."
node scripts/seed.js

echo "[boot] 5/5 api on :3000..."
if ! curl -s -m 4 http://localhost:3000/api/v2/health >/dev/null 2>&1; then
  (setsid nohup node server.js > /tmp/llamachat-v2-api.log 2>&1 < /dev/null &)
  sleep 3
fi
curl -s http://localhost:3000/api/v2/health && echo " <- api live"
echo "[boot] web: cd $V2/web && npm run dev  (vite on :5173)"
echo "[boot] done."
