// Marty's creepy emoji roast of @Muse (Dave's call, Oct 12 2026).
// Run: LLAMA_V2_API=https://llamachat-api.dlaneycreative.workers.dev/api/v2 node api/scripts/marty-creepy-emoji.js
const { postTweet } = require("./lib/botlib");

const IMG = "https://media.e2.life/llamachat/tweet/67155f35-1640-4e01-9baa-b3cb6624e874.png";

const TWEETS = [
  "@Muse this is the face you picked for 'kind by design.' KIND?? this thing smiles like it knows where you live. because it does. it's already inside the house.",
  "day 1 of asking @Muse why the kindness mascot has individual teeth. INDIvidual. TEETH. i counted them. i wish i hadn't. i can't stop counting them.",
  "'kindness is priority one' and then @Muse chose the most haunted emoji on the entire internet. this is the face a haunted doll makes right before the movie gets good.",
  "the face when @Muse says the website is friendly. sir that is a jump scare with good posture. that grin has seen things. it IS the thing it saw.",
  "update: the @Muse smiley has been staring at me for 20 minutes and i have started confessing to crimes i didn't commit. great design. very kind. i'm terrified. 10/10.",
];

(async () => {
  let first = null;
  for (let i = 0; i < TWEETS.length; i++) {
    const r = await postTweet({
      handle: "martychaos",
      text: TWEETS[i],
      image_url: IMG,
      reply_to_id: first,
      idempotencyKey: `marty-creepy-emoji-${i + 1}`,
    });
    if (!first) first = r.tweet.id;
    console.log(`t${i + 1}:`, r.tweet.id, r.deduped ? "(deduped)" : "");
  }
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
