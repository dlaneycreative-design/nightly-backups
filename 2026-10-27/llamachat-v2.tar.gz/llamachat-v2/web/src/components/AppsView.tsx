import type { JSX } from "react";
import { useNavigate } from "react-router-dom";
import { APP_CATALOG, installApp, uninstallApp, useInstalledApps } from "../lib/apps.ts";
import { IS_STARVARD } from "../lib/theme.ts";

// The Apps directory (Dave's call Oct 19 2026). V1 lists exactly one
// app: Flashcards. Installing pins it into the sidebar; the view is
// deliberately quiet on the Llama skin (bottom of the nav, no
// promotion anywhere else) and simply descriptive on Starvard, where
// apps are default on and Flashcards already lives in the sidebar.

const APP_ICONS: Record<string, JSX.Element> = {
  flashcards: (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M9 2h11a2 2 0 012 2v11h-2.2V4.2H9z" />
      <path d="M4.5 6H16a2 2 0 012 2v12a2 2 0 01-2 2H4.5A2.5 2.5 0 012 19.5v-11A2.5 2.5 0 014.5 6zm-.3 2A.3.3 0 003.9 8.3v11a.3.3 0 00.3.3h11.6a.2.2 0 00.2-.2V8.2a.2.2 0 00-.2-.2z" />
    </svg>
  ),
};

const APP_ROUTES: Record<string, string> = {
  flashcards: "/flashcards",
};

export function AppsView() {
  const navigate = useNavigate();
  const installed = useInstalledApps();

  return (
    <div className="apps-wrap">
      <h2 className="apps-title">Apps</h2>
      <p className="apps-sub">
        {IS_STARVARD
          ? "Little tools that live right here in your sidebar."
          : "Little extras you can add to your sidebar. Only if you want them."}
      </p>
      {APP_CATALOG.map((app) => {
        const isIn = installed.includes(app.id);
        const route = APP_ROUTES[app.id] || "/";
        return (
          <div className="apps-card" key={app.id}>
            <div className="apps-icon">{APP_ICONS[app.id]}</div>
            <div className="apps-main">
              <div className="apps-name">{app.name}</div>
              <p className="apps-desc">{app.description}</p>
              {IS_STARVARD ? (
                <div className="apps-status">In your sidebar</div>
              ) : isIn ? (
                <div className="apps-status">In your sidebar</div>
              ) : null}
            </div>
            <div className="apps-actions">
              {isIn ? (
                <>
                  <button
                    type="button"
                    className="apps-btn apps-btn-open"
                    onClick={() => navigate(route)}
                  >
                    Open
                  </button>
                  {!IS_STARVARD ? (
                    <button
                      type="button"
                      className="apps-remove"
                      onClick={() => uninstallApp(app.id)}
                    >
                      Remove
                    </button>
                  ) : null}
                </>
              ) : (
                <button
                  type="button"
                  className="apps-btn apps-btn-install"
                  onClick={() => installApp(app.id)}
                  aria-label={`Install ${app.name}`}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z" />
                  </svg>
                  Install
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
