// Image variant URLs + srcset. Mirrors api/lib/images.js conventions:
//   <base>-thumb.webp (200px) | -medium.webp (800px) | -full.webp (1600px)
// The DB stores the medium URL; variants are derived, no API call needed.

// Image host for V1-relative seed paths (e.g. "/sloth/assets/...").
// ONE place to change when the prod CDN lands: set VITE_IMAGE_HOST.
function imageHost(): string {
  try {
    const v = (import.meta as unknown as { env?: Record<string, string | undefined> }).env
      ?.VITE_IMAGE_HOST;
    if (v) return v.replace(/\/$/, "");
  } catch {
    /* non-vite runtime (node tests): fall through to default */
  }
  return "https://www.thestudio.io";
}

/**
 * Resolve a stored image/avatar URL to an absolute URL.
 *   "/assets/avatars/x.webp" -> "/assets/avatars/x.webp" (served locally
 *     by llamachat.io itself; same-origin, no cross-domain fetch)
 *   "/sloth/assets/x.png" -> "https://www.thestudio.io/sloth/assets/x.png"
 *     (legacy V1-relative paths still fall back to thestudio.io)
 *   absolute https/data/blob URLs pass through untouched.
 *   null/undefined/"" -> null.
 */
export function resolveImageUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  if (/^(https?:|data:|blob:)/i.test(url)) return url;
  if (url.startsWith("//")) return `https:${url}`;
  // LlamaChat-owned assets live in /assets/ and are served by this origin.
  if (url.startsWith("/assets/")) return url;
  if (url.startsWith("/")) return `${imageHost()}${url}`;
  return url;
}

export type ImageVariant = "thumb" | "medium" | "full";

export function variantUrl(publicUrl: string, variant: ImageVariant): string {
  const abs = resolveImageUrl(publicUrl) ?? publicUrl;
  const base = abs
    .replace(/\/original$/, "")
    .replace(/\.[a-z0-9]+$/i, "")
    // The DB stores the medium URL; deriving thumb/full from it must not
    // stack suffixes ("pic-medium-thumb.webp"). Strip any variant first.
    .replace(/-(thumb|medium|full)$/, "");
  return `${base}-${variant}.webp`;
}

export function mediumUrl(publicUrl: string): string {
  return variantUrl(publicUrl, "medium");
}

/** srcset for <img>: thumb 200w, medium 800w, full 1600w. */
export function srcset(publicUrl: string): string {
  return (
    `${variantUrl(publicUrl, "thumb")} 200w, ` +
    `${variantUrl(publicUrl, "medium")} 800w, ` +
    `${variantUrl(publicUrl, "full")} 1600w`
  );
}

/**
 * Downscale an image File to a <=1600px WebP Blob (Dave's speed rules:
 * small uploads, fast feed). GIFs pass through untouched so animation
 * survives. Returns the original file when it is already small enough.
 */
export function downscaleImage(file: File, maxEdge = 1600): Promise<Blob> {
  // Small files and GIFs go through as-is.
  if (file.type === "image/gif" || file.size <= 500 * 1024) {
    return Promise.resolve(file);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => (blob ? resolve(blob) : reject(new Error("downscale failed"))),
        "image/webp",
        0.82
      );
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("could not read image"));
    };
    img.src = url;
  });
}

/**
 * Upload an image to Vercel Blob via the API (POST /api/v2/uploads,
 * multipart). The client downscales first; the API puts the bytes in the
 * `llamachat-v2-uploads` Blob store and returns the public URL, which the
 * tweet stores directly as image_url.
 */
export async function uploadImage(
  apiBase: string,
  callerId: string,
  file: File,
  kind: "tweet" | "avatar" | "dm",
  onProgress?: (stage: "presign" | "uploading" | "done") => void
): Promise<string> {
  onProgress?.("presign");
  const blob = await downscaleImage(file);
  const form = new FormData();
  form.append("file", blob, file.name || "upload");
  form.append("kind", kind);
  onProgress?.("uploading");
  const res = await fetch(`${apiBase}/uploads`, {
    method: "POST",
    headers: { "x-llama-user": callerId },
    body: form,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `upload failed (${res.status})`);
  }
  const { image_url } = await res.json();
  if (!image_url) throw new Error("upload returned no image_url");
  onProgress?.("done");
  return image_url as string;
}

/** Downscale a File to a preview data URL (instant feedback, no upload yet). */
export function fileToPreviewUrl(file: File, maxEdge = 800): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/webp", 0.75));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("could not read image"));
    };
    img.src = url;
  });
}
