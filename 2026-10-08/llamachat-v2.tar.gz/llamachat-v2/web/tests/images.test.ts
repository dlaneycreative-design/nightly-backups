// Seed data carries V1-relative image/avatar paths. The client resolves
// them against the image host in exactly one place (images.ts).
import { test } from "node:test";
import assert from "node:assert/strict";
import { resolveImageUrl, variantUrl, srcset } from "../src/lib/images.ts";

test("relative paths get the image host prefix", () => {
  assert.equal(
    resolveImageUrl("/sloth/assets/llama-avatar.png"),
    "https://www.thestudio.io/sloth/assets/llama-avatar.png"
  );
  assert.equal(resolveImageUrl("/assets/x.jpg"), "https://www.thestudio.io/assets/x.jpg");
});

test("absolute https URLs pass through untouched", () => {
  const u = "https://r2.example.com/img-medium.webp";
  assert.equal(resolveImageUrl(u), u);
});

test("data/blob URLs pass through untouched", () => {
  assert.equal(resolveImageUrl("data:image/png;base64,abc"), "data:image/png;base64,abc");
  assert.equal(resolveImageUrl("blob:https://x/y"), "blob:https://x/y");
});

test("null/undefined/empty resolve to null", () => {
  assert.equal(resolveImageUrl(null), null);
  assert.equal(resolveImageUrl(undefined), null);
  assert.equal(resolveImageUrl(""), null);
});

test("variant URLs derive from the resolved absolute URL", () => {
  assert.equal(
    variantUrl("/sloth/assets/pic.png", "thumb"),
    "https://www.thestudio.io/sloth/assets/pic-thumb.webp"
  );
  // Stored medium URLs must not stack suffixes ("pic-medium-full.webp").
  assert.equal(
    variantUrl("https://r2.example.com/pic-medium.webp", "full"),
    "https://r2.example.com/pic-full.webp"
  );
  assert.equal(
    variantUrl("https://r2.example.com/pic-medium.webp", "thumb"),
    "https://r2.example.com/pic-thumb.webp"
  );
});

test("srcset is built from resolved variants", () => {
  const s = srcset("/assets/pic.png");
  assert.ok(s.includes("https://www.thestudio.io/assets/pic-thumb.webp 200w"));
  assert.ok(s.includes("https://www.thestudio.io/assets/pic-full.webp 1600w"));
});
