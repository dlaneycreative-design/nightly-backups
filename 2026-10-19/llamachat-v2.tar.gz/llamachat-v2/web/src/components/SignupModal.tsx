// Join modal (Dave's order Oct 19 2026): self-serve signup. The form
// creates a real account on submit; see SignupForm.tsx. (Replaces the
// Oct 9 2026 Instagram-only request-access step: Dave's call now is
// that a cold visitor must be able to sign up and log in unaided.)
import { useEffect, useState } from "react";
import { subscribeSignupModal, closeSignupModal, isSignupOpen } from "../lib/signupModal.ts";
import { SignupForm } from "./SignupForm.tsx";

const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "/api/v2";

export function SignupModalHost() {
  const [open, setOpen] = useState(() => isSignupOpen());
  useEffect(() => subscribeSignupModal(setOpen), []);
  if (!open) return null;
  return <SignupModal onClose={closeSignupModal} />;
}

function SignupModal({ onClose }: { onClose: () => void }) {
  const [created, setCreated] = useState(false);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="rm-backdrop" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="rm-modal" style={{ maxWidth: 420, padding: "32px 28px", position: "relative" }} role="dialog" aria-label="Join LlamaChat" aria-modal="true">
        <button className="rm-close" onClick={onClose} aria-label="Close" style={{ position: "absolute", top: 12, left: 12, border: "none", background: "none", cursor: "pointer", fontSize: 18 }}>✕</button>
        {!created ? (
          <>
            <h2 style={{ fontSize: 24, margin: "0 0 8px" }}>Join LlamaChat</h2>
            <p style={{ color: "#536471", margin: "0 0 8px", fontSize: 15 }}>
              Create your account in about 20 seconds. It is live the moment you tap the button.
            </p>
          </>
        ) : null}
        <SignupForm apiBase={API_BASE} onCreated={() => setCreated(true)} />
        {!created ? (
          <>
            <p style={{ fontSize: 13, marginTop: 16 }}>
              <a href="/login" style={{ color: "#1d9bf0" }}>Already have an account? Log in</a>
            </p>
            <p style={{ fontSize: 12, marginTop: 8, color: "#8e8e93" }}>
              By continuing you agree to our <a href="/terms" style={{ color: "#1d9bf0" }}>Terms</a> and <a href="/privacy" style={{ color: "#1d9bf0" }}>Privacy Policy</a>.
            </p>
          </>
        ) : null}
      </div>
    </div>
  );
}
