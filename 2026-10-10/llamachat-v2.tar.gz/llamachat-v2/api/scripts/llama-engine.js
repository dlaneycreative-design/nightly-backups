// Llama Engine v1: makes LlamaChat feel real and alive.
// Dave's call Oct 9 2026: "We want Llama Chat to feel real. Let's make it real!"
//
// When Dave posts, characters like and reply naturally:
// - Likes: 2-4 characters, staggered 5-15 min, not everyone, not instant
// - Replies: 0-2 per post, character voice matched to content, 10-30 min delay
// - Never spammy, never generic, respects quiet hours (1am-6am MT = no activity)
//
// Characters (phase 1): dinesh, sally, mike, marty, chadwick
//
// Usage: node api/scripts/llama-engine.js
//   Run every 10 min via cron.

const fs = require("fs");
const crypto = require("crypto");
const { postTweet, getAuthorTweets, getTweetThread, getProfileId } = require("./lib/botlib");
const API_BASE = "https://llamachat.io/api/v2";

const STATE_FILE = "/tmp/llama-engine-state.json";
const LIKE_COOLDOWN_MS = 5 * 60 * 1000;      // don't like tweets < 5 min old
const REPLY_COOLDOWN_MS = 10 * 60 * 1000;    // don't reply to tweets < 10 min old
const MAX_LIKES_PER_RUN = 12;
const MAX_REPLIES_PER_RUN = 5;

// Character roster with their handles (verified live)
const CHARACTERS = ["dinesh", "sally", "mike", "martychaos", "chadwickblaze"];

// Reply templates by character voice (from personality docs)
const VOICES = {
  dinesh: {
    tech: [
      "technically correct. which is the best kind of correct.",
      "have you measured it? if it's not measured it's just a vibe.",
      "this is a systems problem. everything is a systems problem if you squint.",
      "ship it. we can optimize later. (we will optimize later.)",
      "the bottleneck is never where you think it is.",
    ],
    general: [
      "interesting. let me think about the edge cases.",
      "this checks out. nice work.",
      "nerd approved. which is the highest approval.",
    ],
  },
  sally: {
    warm: [
      "this made me smile. keep going, you're doing good work.",
      "i love this. the heart behind it comes through.",
      "yes! this is exactly the kind of thing the world needs more of.",
      "you've got a good heart, dave. don't ever lose that.",
      "thank you for sharing this. it means a lot.",
    ],
    music: [
      "this is giving me song ideas. piano is calling my name.",
      "felt this in my chest. that's how i know it's real.",
    ],
  },
  mike: {
    // Mike: plainspoken, warm, short sentences, no fluff. Leads with answer.
    ops: [
      "on it. this is getting done today.",
      "love it. adding to the board.",
      "shipped. what's next?",
      "got it. handled.",
    ],
    general: [
      "let's go. this is the good stuff.",
      "cranking. this is becoming the real deal.",
      "done. you'll see it live in the morning.",
    ],
  },
  martychaos: {
    // Marty: funny, memes, loving roast, never mean, never punching down
    funny: [
      "lol this is so good. stealing this for /fun/.",
      "i'm crying. this is perfect meme material.",
      "ok but why is this actually funny though.",
      "marty approves. that's the highest honor.",
    ],
    general: [
      "this slaps. no notes.",
      "adding this to the list of things that actually work.",
    ],
  },
  chadwickblaze: {
    // Chadwick: finds broken websites, verifies with human eyes
    web: [
      "found 3 broken sites while reading this. multitasking.",
      "chadwick has verified this post is 100% not broken.",
    ],
    general: [
      "adding this to the list of things that actually work.",
      "verified with human eyes. this is good.",
    ],
  },
};

function pick(arr, salt) {
  const h = parseInt(crypto.createHash("sha1").update(String(salt)).digest("hex").slice(0, 8), 16);
  return arr[h % arr.length];
}

function isQuietHours() {
  // 1am-6am MT = quiet. No likes/replies.
  const mtHour = parseInt(new Date().toLocaleString("en-US", { timeZone: "America/Denver", hour: "numeric", hour12: false }));
  return mtHour >= 1 && mtHour < 6;
}

// Decide which characters like this tweet (2-4, deterministic but varied)
function chooseLikers(tweetId, text) {
  const h = parseInt(crypto.createHash("sha1").update("like:" + tweetId).digest("hex").slice(0, 8), 16);
  const count = 2 + (h % 3); // 2-4 likers
  // Shuffle characters deterministically by tweet ID
  const shuffled = [...CHARACTERS].sort((a, b) => {
    const ha = parseInt(crypto.createHash("sha1").update(tweetId + a).digest("hex").slice(0, 8), 16);
    const hb = parseInt(crypto.createHash("sha1").update(tweetId + b).digest("hex").slice(0, 8), 16);
    return ha - hb;
  });
  return shuffled.slice(0, count);
}

// Decide who replies and with what voice
function chooseReply(text) {
  const t = (text || "").toLowerCase();
  const techWords = ["server", "api", "deploy", "code", "bug", "speed", "fast", "load", "build", "data", "system", "latency", "vercel", "database"];
  const musicWords = ["song", "music", "piano", "sing", "melody", "album", "guitar"];
  const kindWords = ["kind", "kindness", "love", "heart", "grateful", "thank"];
  const funnyWords = ["lol", "funny", "meme", "haha", "😂", "🤣"];
  const webWords = ["website", "site", "web", "broken", "audit"];
  const shipWords = ["ship", "done", "launch", "deploy", "build"];
  const hasAny = (words) => words.some((w) => t.includes(w));

  if (hasAny(musicWords)) return { handle: "sally", pool: VOICES.sally.music };
  if (hasAny(techWords)) return { handle: "dinesh", pool: VOICES.dinesh.tech };
  if (hasAny(funnyWords)) return { handle: "martychaos", pool: VOICES.martychaos.funny };
  if (hasAny(webWords)) return { handle: "chadwickblaze", pool: VOICES.chadwickblaze.web };
  if (hasAny(shipWords)) return { handle: "mike", pool: VOICES.mike.ops };
  if (hasAny(kindWords)) return { handle: "sally", pool: VOICES.sally.warm };

  // Default: rotate by hash
  const h = parseInt(crypto.createHash("sha1").update("reply:" + text).digest("hex").slice(0, 8), 16);
  const char = CHARACTERS[h % CHARACTERS.length];
  const pools = Object.values(VOICES[char]);
  return { handle: char, pool: pools[h % pools.length] };
}

async function apiPost(path, body, handle) {
  const profileId = await getProfileId(handle);
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-user": profileId },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  return res.json();
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return { liked: {}, replied: {} }; }
}
function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s)); }

async function main() {
  if (isQuietHours()) {
    console.log("[llama-engine] quiet hours, skipping");
    return;
  }

  const state = loadState();
  const tweets = await getAuthorTweets("dave", 20);
  const now = Date.now();
  let likes = 0, replies = 0;

  // Process oldest first for natural chronological feel
  for (const tw of [...tweets].reverse()) {
    if (tw.reply_to_id) continue; // don't engage with Dave's own replies
    const age = now - Number(tw.created_at);

    // --- LIKES ---
    if (age >= LIKE_COOLDOWN_MS && likes < MAX_LIKES_PER_RUN) {
      const likers = chooseLikers(tw.id, tw.text || "");
      for (const handle of likers) {
        const key = `${tw.id}:${handle}`;
        if (state.liked[key]) continue;
        try {
          await apiPost("/likes", { tweet_id: tw.id }, handle);
          state.liked[key] = Date.now();
          likes++;
          console.log(`[llama-engine] @${handle} liked Dave's tweet ${tw.id.slice(0, 8)}`);
        } catch (e) {
          console.error(`[llama-engine] like failed @${handle}: ${e.message}`);
        }
        if (likes >= MAX_LIKES_PER_RUN) break;
      }
    }

    // --- REPLIES ---
    if (age >= REPLY_COOLDOWN_MS && replies < MAX_REPLIES_PER_RUN && !state.replied[tw.id]) {
      // Check if anyone already replied
      let alreadyReplied = false;
      try {
        const thread = await getTweetThread(tw.id);
        const threadReplies = thread.replies || [];
        alreadyReplied = threadReplies.some((r) =>
          CHARACTERS.includes(((r.author && r.author.handle) || "").toLowerCase())
        );
      } catch { /* fall through */ }
      if (alreadyReplied) { state.replied[tw.id] = "existing"; continue; }

      // Dave's call: everybody comments. 90% of posts get a reply.
      const h = parseInt(crypto.createHash("sha1").update("should-reply:" + tw.id).digest("hex").slice(0, 8), 16);
      if (h % 10 >= 9) { state.replied[tw.id] = "skipped"; continue; }

      const { handle, pool } = chooseReply(tw.text || "");
      const text = pick(pool, tw.id + handle);
      try {
        const { deduped } = await postTweet({
          handle,
          text,
          reply_to_id: tw.id,
          idempotencyKey: `llama-engine:${tw.id}:${handle}`,
        });
        state.replied[tw.id] = handle;
        replies++;
        console.log(`[llama-engine] @${handle} -> Dave's tweet ${tw.id.slice(0, 8)}: ${deduped ? "deduped" : "replied"}`);
      } catch (e) {
        console.error(`[llama-engine] reply failed: ${e.message}`);
      }
    }
  }

  saveState(state);
  console.log(`[llama-engine] done: ${likes} likes, ${replies} replies this run`);
}

main().catch((e) => { console.error("[llama-engine] fatal", e.message); process.exit(1); });
