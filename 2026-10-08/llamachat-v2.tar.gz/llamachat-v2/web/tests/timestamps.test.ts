// We shipped the timestamp bug THREE times in V1. Never again.
// Run: node --test web/tests/timestamps.test.ts  (Node 20.6+; type-stripping handles .ts)
import { test } from "node:test";
import assert from "node:assert/strict";
import { relTime, absTime, isValidTs } from "../src/lib/timestamps.ts";

const NOW = new Date("2026-10-07T14:00:00").getTime(); // fixed "now" for determinism
const s = 1000;
const m = 60 * s;
const h = 60 * m;
const d = 24 * h;

test("invalid input renders as empty string, never 'now'", () => {
  for (const bad of [null, undefined, NaN, 0, -1, -999, 1.5, "now", "123", {}, []]) {
    assert.equal(relTime(bad, NOW), "", `expected "" for ${JSON.stringify(bad)}`);
    assert.equal(absTime(bad), "");
  }
});

test("seconds", () => {
  assert.equal(relTime(NOW - 5 * s, NOW), "5s");
  assert.equal(relTime(NOW - 59 * s, NOW), "59s");
  assert.equal(relTime(NOW, NOW), "0s");
});

test("minutes", () => {
  assert.equal(relTime(NOW - 60 * s, NOW), "1m");
  assert.equal(relTime(NOW - 32 * m, NOW), "32m");
  assert.equal(relTime(NOW - 59 * m, NOW), "59m");
});

test("hours", () => {
  assert.equal(relTime(NOW - 1 * h, NOW), "1h");
  assert.equal(relTime(NOW - 8 * h, NOW), "8h");
  assert.equal(relTime(NOW - 23 * h, NOW), "23h");
});

test("days", () => {
  assert.equal(relTime(NOW - 1 * d, NOW), "1d");
  assert.equal(relTime(NOW - 6 * d, NOW), "6d");
});

test("older than 7 days shows month and day", () => {
  // NOW is Oct 7 2026; 8 days earlier is Sep 29 2026.
  assert.equal(relTime(NOW - 8 * d, NOW), "Sep 29");
});

test("different year includes the year", () => {
  const lastYear = new Date("2025-03-04T10:00:00").getTime();
  assert.equal(relTime(lastYear, NOW), "Mar 4, 2025");
});

test("future timestamps clamp to 'now' (clock skew)", () => {
  assert.equal(relTime(NOW + 5 * m, NOW), "now"); // 5 min ahead: skew
  assert.equal(relTime(NOW + 30 * s, NOW), "0s"); // within 60s allowance: ~now
});

test("absTime formats a full date", () => {
  const t = new Date("2026-10-06T08:04:00").getTime();
  assert.match(absTime(t), /^Oct 6, 2026 · \d{1,2}:04 (AM|PM)$/);
});

test("isValidTs rejects the V1 failure modes", () => {
  assert.equal(isValidTs("now"), false); // V1 seed data had literal "now"
  assert.equal(isValidTs(0), false);
  assert.equal(isValidTs(NaN), false);
  assert.equal(isValidTs(NOW), true);
});
