// Respond to Dave's 5 replies (Dave's call Oct 8 2026)
// Each author responds in their voice to Dave's comment
const { postTweet } = require("./lib/botlib");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const RESPONSES = [
  {
    handle: "mateo",
    text: "see?? dave gets it. tacos are a universal truth 🌮",
    reply_to_id: "928c5be5-5cab-5b1f-a00c-1e24f213c52a",
    key: "respond-mateo-oct8",
  },
  {
    handle: "jahvibez",
    text: "yessir! sun's shining on us today my friend ☀️",
    reply_to_id: "1a401171-8331-5b49-ae8c-e41ee77479d6",
    key: "respond-jahvibez-oct8",
  },
  {
    handle: "haddiesings",
    text: "thank you dave!! means a lot 🎤✨",
    reply_to_id: "d63529db-77b6-5558-9b3a-544a740b40ee",
    key: "respond-haddie-oct8",
  },
  {
    handle: "oldray",
    text: "ha! you remember the dial-up symphony. good times.",
    reply_to_id: "21d30629-b7f3-5f3a-8dc5-0f11a1804e3b",
    key: "respond-oldray-oct8",
  },
  {
    handle: "gloria",
    text: "oh darling, i knew you would. you have excellent taste ✨",
    reply_to_id: "397655d8-2fe7-52a2-b739-46d1c050832a",
    key: "respond-gloria-oct8",
  },
];

(async () => {
  for (const r of RESPONSES) {
    try {
      await postTweet({
        handle: r.handle,
        text: r.text,
        reply_to_id: r.reply_to_id,
        idempotencyKey: r.key,
      });
      console.log(`✓ @${r.handle} responded`);
    } catch (e) {
      console.log(`✗ @${r.handle}: ${e.message}`);
    }
    await sleep(500);
  }
  console.log("Done!");
})();
