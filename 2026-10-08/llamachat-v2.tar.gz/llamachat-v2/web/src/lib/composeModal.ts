// Global compose-modal opener. The sidebar Post button opens the X-style
// new-post modal without prop drilling: App.tsx calls openComposeModal(),
// and ComposeModalHost (mounted once in App) renders the modal.
type Listener = (open: boolean) => void;
const listeners = new Set<Listener>();

let isOpen = false;

/** Open the compose modal. */
export function openComposeModal(): void {
  isOpen = true;
  for (const l of listeners) l(isOpen);
}

/** Close the compose modal. */
export function closeComposeModal(): void {
  isOpen = false;
  for (const l of listeners) l(isOpen);
}

/** Whether the compose modal is currently open. */
export function isComposeOpen(): boolean {
  return isOpen;
}

export function subscribeComposeModal(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
