// Apps: installable extras that pin into the sidebar (Dave's call
// Oct 19 2026). V1 has exactly one app, Flashcards.
//
// Skin law: on Llama the base app stays a pure X-like surface and
// apps are opt-in, discovered quietly from the Apps view at the
// bottom of the sidebar. On Starvard the catalog is DEFAULT ON
// (learning-forward skin): every app reads as installed, which is
// why Flashcards has always lived in the Starvard sidebar.
//
// State is per browser in localStorage, key "lc_installed_apps"
// (a JSON array of app ids), scoped to the signed-in handle when
// there is one ("lc_installed_apps:<handle>") so two people sharing
// a browser do not inherit each other's sidebar. Sign-in and
// sign-out both reload the page, so the scope is stable per session.
import { useSyncExternalStore } from "react";
import { IS_STARVARD } from "./theme.ts";
import { getCallerHandle } from "./session.ts";

export interface AppDef {
  id: string;
  name: string;
  description: string;
}

export const APP_CATALOG: AppDef[] = [
  {
    id: "flashcards",
    name: "Flashcards",
    description: "Spanish flashcards: 50 levels, 2,000 cards. Learn a little every day.",
  },
];

const BASE_KEY = "lc_installed_apps";

function storageKey(): string {
  const handle = getCallerHandle();
  return handle ? `${BASE_KEY}:${handle.toLowerCase()}` : BASE_KEY;
}

function readInstalled(): string[] {
  try {
    const raw = localStorage.getItem(storageKey());
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    const known = new Set(APP_CATALOG.map((a) => a.id));
    return parsed.filter((x): x is string => typeof x === "string" && known.has(x));
  } catch {
    return [];
  }
}

/** Installed app ids. On Starvard the whole catalog is default on. */
export function getInstalledApps(): string[] {
  if (IS_STARVARD) return APP_CATALOG.map((a) => a.id);
  return readInstalled();
}

export function isAppInstalled(id: string): boolean {
  return getInstalledApps().includes(id);
}

/* ---------- tiny external store (mirrors lib/store.ts) ---------- */

type Listener = () => void;
const listeners = new Set<Listener>();
function emit(): void {
  for (const l of listeners) l();
}

export function subscribeApps(listener: Listener): () => void {
  listeners.add(listener);
  const onStorage = (e: StorageEvent) => {
    if (e.key === null || e.key.startsWith(BASE_KEY)) listener();
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}

function writeInstalled(ids: string[]): void {
  try {
    localStorage.setItem(storageKey(), JSON.stringify(ids));
  } catch {
    /* storage blocked: the install simply does not persist */
  }
  emit();
}

export function installApp(id: string): void {
  const cur = readInstalled();
  if (!cur.includes(id)) writeInstalled([...cur, id]);
}

export function uninstallApp(id: string): void {
  writeInstalled(readInstalled().filter((x) => x !== id));
}

/** React: the installed app ids, live as installs change. */
export function useInstalledApps(): string[] {
  const snapshot = useSyncExternalStore(
    subscribeApps,
    () => getInstalledApps().join(","),
    () => getInstalledApps().join(",")
  );
  return snapshot ? snapshot.split(",") : [];
}
