// Marty's green arms song tweet (Dave's call, Oct 29 2026).
// Run: node api/scripts/marty-green-arms-song.js
const { postTweet } = require("./lib/botlib");

(async () => {
  const r = await postTweet({
    handle: "Marty",
    text: "🎶 green arms, green arms, greany greany green arms 🎶",
    idempotencyKey: "marty-green-arms-song-1",
  });
  console.log("tweet:", r.tweet.id, r.deduped ? "(deduped)" : "");
  console.log("URL=https://llamachat.lol/tweet/" + r.tweet.id);
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
