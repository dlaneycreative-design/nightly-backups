// Image variant URLs + srcset. Mirrors api/lib/images.js conventions:
//   <base>-thumb.webp (200px) | -medium.webp (800px) | -full.webp (1600px)
// The DB stores the medium URL; variants are derived, no API call needed.

// Image host for V1-relative seed paths (e.g. "/sloth/assets/...").
// ONE place to change when the prod CDN lands: set VITE_IMAGE_HOST.
function imageHost(): string {
  try {
    const v = (import.meta as unknown as { env?: Record<string, string | undefined> }).env
      ?.VITE_IMAGE_HOST;
    if (v) return v.replace(/\/$/, "");
  } catch {
    /* non-vite runtime (node tests): fall through to default */
  }
  // Dave's call Oct 11 2026: thestudio.io is on Cloudflare cutover, use llamachat.lol
  return "https://llamachat.lol";
}

/**
 * Resolve a stored image/avatar URL to an absolute URL.
 *   "/assets/avatars/x.webp" -> "/assets/avatars/x.webp" (served locally
 *     by llamachat.io itself; same-origin, no cross-domain fetch)
 *   "/sloth/assets/x.png" -> "https://www.thestudio.io/sloth/assets/x.png"
 *     (legacy V1-relative paths still fall back to thestudio.io)
 *   absolute https/data/blob URLs pass through untouched.
 *   null/undefined/"" -> null.
 */
export function resolveImageUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  // Dave's call Oct 11 2026: thestudio.io is on Cloudflare cutover and unreachable.
  // Rewrite any absolute thestudio.io URLs to the canonical /assets/avatars/ copies.
  const absoluteAvatarMap: Record<string, string> = {
    "https://www.thestudio.io/casting/willa-portrait.webp": "/assets/avatars/willa.webp",
    "https://www.thestudio.io/casting/finn-portrait.webp": "/assets/avatars/finn.webp",
    "https://www.thestudio.io/daveos/img/chadwick-waving.png": "/assets/avatars/chadwick.webp",
    "https://www.thestudio.io/muse-avatar-final.webp": "/assets/avatars/muse.webp",
    "https://www.thestudio.io/e2/people/judgetootie/judgetootie.webp": "/assets/avatars/judge.webp",
    "https://www.thestudio.io/mike/assets/mike-gym-selfie.webp": "/assets/avatars/songify.webp",
    "https://e2.life/people/sam/sam.webp": "/assets/avatars/sam.webp",
  };
  if (absoluteAvatarMap[url]) return absoluteAvatarMap[url];
  if (url.startsWith("https://www.thestudio.io/")) {
    return "https://llamachat.lol/" + url.slice("https://www.thestudio.io/".length);
  }
  if (url.startsWith("https://thestudio.io/")) {
    return "https://llamachat.lol/" + url.slice("https://thestudio.io/".length);
  }
  if (/^(https?:|data:|blob:)/i.test(url)) return url;
  if (url.startsWith("//")) return `https:${url}`;
  // Legacy avatar paths: map to /assets/avatars/ where the canonical copies
  // live (Dave's call Oct 11 2026: ALL files hosted on llamachat.lol).
  const legacyAvatarMap: Record<string, string> = {
    "/sloth/assets/llama-avatar.webp": "/assets/avatars/llama.webp",
    "/shortbus/assets/portraits/sally.jpg": "/assets/avatars/sally.jpg",
    "/shortbus/assets/portraits/marty-face.jpg": "/assets/avatars/martychaos.jpg",
    "/shortbus/assets/portraits/dinesh-solo.webp": "/assets/avatars/dinesh.webp",
    "/sloth/assets/ricky-avatar.webp": "/assets/avatars/memebot.webp",
    "/shortbus/assets/portraits/mateo.webp": "/assets/avatars/mateo.webp",
    "/shortbus/assets/portraits/haddie-face.jpg": "/assets/avatars/haddiesings.jpg",
    "/sloth/assets/harsh-avatar.jpg": "/assets/avatars/harsh.jpg",
    "/shortbus/assets/portraits/tex.jpg": "/assets/avatars/tex.webp",
    "/shortbus/assets/portraits/chadwick-face.jpg": "/assets/avatars/chadwickblaze.jpg",
    "/shortbus/assets/portraits/jaylen-bass.jpg": "/assets/avatars/jaylen.webp",
    "/shortbus/assets/portraits/jah-vibez.jpg": "/assets/avatars/jahvibez.webp",
    "/shortbus/assets/portraits/biscuit-face.jpg": "/assets/avatars/biscuit.jpg",
    "/shortbus/assets/portraits/gloria.jpg": "/assets/avatars/gloria.webp",
    "/sloth/assets/mike-static.png": "/assets/avatars/mike.png",
    "/plume/plume.webp": "/assets/avatars/plume.webp",
    "/henri/henri-hue.webp": "/assets/avatars/henri.webp",
    "/oldray/old-ray.webp": "/assets/avatars/oldray.webp",
    "/enrique/enrique.png": "/assets/avatars/enrique.webp",
    "/lemonHD/assets/leo-remake.webp": "/assets/avatars/leo.webp",
    "/dineshbot/dineshbot-avatar.webp": "/assets/avatars/dineshbot.webp",
    "/sally/doodle-bot.png": "/assets/avatars/doodle.webp",
    "/pixel/buster/buster-portrait.webp": "/assets/avatars/buster.webp",
    "/e2/map/sprite-mappy.webp": "/assets/avatars/mappy.webp",
    "/assets/hank.webp": "/assets/avatars/hank.webp",
    "/assets/ed.webp": "/assets/avatars/ed.webp",
    "/assets/avatars/dave-dlaney-face-400.webp": "/assets/avatars/dave.webp",
  };
  if (legacyAvatarMap[url]) return legacyAvatarMap[url];
  // LlamaChat-owned assets live in /assets/ and are served by this origin.
  if (url.startsWith("/assets/")) return url;
  if (url.startsWith("/")) return `${imageHost()}${url}`;
  return url;
}

export type ImageVariant = "thumb" | "medium" | "full";

export function variantUrl(publicUrl: string, variant: ImageVariant): string {
  const abs = resolveImageUrl(publicUrl) ?? publicUrl;
  const base = abs
    .replace(/\/original$/, "")
    .replace(/\.[a-z0-9]+$/i, "")
    // The DB stores the medium URL; deriving thumb/full from it must not
    // stack suffixes ("pic-medium-thumb.webp"). Strip any variant first.
    .replace(/-(thumb|medium|full)$/, "");
  return `${base}-${variant}.webp`;
}

export function mediumUrl(publicUrl: string): string {
  return variantUrl(publicUrl, "medium");
}

/** srcset for <img>: thumb 200w, medium 800w, full 1600w. */
export function srcset(publicUrl: string): string {
  return (
    `${variantUrl(publicUrl, "thumb")} 200w, ` +
    `${variantUrl(publicUrl, "medium")} 800w, ` +
    `${variantUrl(publicUrl, "full")} 1600w`
  );
}

/**
 * Downscale an image File to a <=1600px WebP Blob (Dave's speed rules:
 * small uploads, fast feed). GIFs pass through untouched so animation
 * survives. Returns the original file when it is already small enough.
 */
export function downscaleImage(file: File, maxEdge = 1600): Promise<Blob> {
  // Small files and GIFs go through as-is.
  if (file.type === "image/gif" || file.size <= 500 * 1024) {
    return Promise.resolve(file);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => (blob ? resolve(blob) : reject(new Error("downscale failed"))),
        "image/webp",
        0.82
      );
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("could not read image"));
    };
    img.src = url;
  });
}

/**
 * Upload an image to Vercel Blob via the API (POST /api/v2/uploads,
 * multipart). The client downscales first; the API puts the bytes in the
 * `llamachat-v2-uploads` Blob store and returns the public URL, which the
 * tweet stores directly as image_url.
 */
export async function uploadImage(
  apiBase: string,
  callerId: string,
  file: File,
  kind: "tweet" | "avatar" | "dm",
  onProgress?: (stage: "presign" | "uploading" | "done") => void
): Promise<string> {
  onProgress?.("presign");
  const blob = await downscaleImage(file);
  const form = new FormData();
  form.append("file", blob, file.name || "upload");
  form.append("kind", kind);
  onProgress?.("uploading");
  const res = await fetch(`${apiBase}/uploads`, {
    method: "POST",
    headers: { "x-llama-user": callerId },
    body: form,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `upload failed (${res.status})`);
  }
  const { image_url } = await res.json();
  if (!image_url) throw new Error("upload returned no image_url");
  onProgress?.("done");
  return image_url as string;
}

/** Downscale a File to a preview data URL (instant feedback, no upload yet). */
export function fileToPreviewUrl(file: File, maxEdge = 800): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/webp", 0.75));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("could not read image"));
    };
    img.src = url;
  });
}
