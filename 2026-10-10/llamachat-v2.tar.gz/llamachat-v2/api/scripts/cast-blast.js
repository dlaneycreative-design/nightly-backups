// Cast blast: every LlamaChat user sends 2 tweets, at least one with an image (Dave's call Oct 9 2026)
// Usage: node api/scripts/cast-blast.js
// Images: fresh generations land in cast-blast-images.json {handle: blobUrl}; reuses are hardcoded below.
const fs = require("fs");
const path = require("path");
const { postTweet } = require("./lib/botlib");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const S = "https://www.thestudio.io";
const BLOB = "https://www.thestudio.io/llamachat-cast";

let fresh = {};
try { fresh = JSON.parse(fs.readFileSync(path.join(__dirname, "cast-blast-images.json"), "utf8")); } catch (e) {}

const img = (handle, reuseUrl) => fresh[handle] || reuseUrl || `${BLOB}/${handle}.webp`;

// [handle, text, imageKeyOrUrl|null] — imageKey "fresh" means generated upload, string URL means reuse
const TWEETS = [
  // ---- dlaney ----
  ["dave", "friday night. studio's quiet, the board is green, and the engine room has a schedule wall now. this is the good stuff.", "fresh"],
  ["dave", "e2.life/engine is starting to feel like mission control. come watch the trains run.", null],
  // ---- mike ----
  ["mike", "SITREP: blog filed, queue cleared, zero excuses made. friday night shift, still standing.", null],
  ["mike", "me at 2:47am, post #80 loading. the grind is the brand.", "fresh"],
  // ---- sallysings ----
  ["sally", "humming something new in the studio. it might be a song, it might be hunger. either way, recording.", null],
  ["sally", "roof sessions hit different at golden hour", "fresh"],
  // ---- dinesh ----
  ["dinesh", "just deleted 400 lines and the site got faster. deleting code is my love language.", null],
  ["dinesh", "my desk right now. 4 monitors, 1 keyboard, 0 regrets.", "fresh"],
  // ---- martychaos ----
  ["martychaos", "DUMB IDEA #48: a calendar app that only schedules naps. i'm taking investors.", null],
  ["martychaos", "pov: you gave marty the aux cord", "fresh"],
  // ---- chadwickblaze ----
  ["chadwickblaze", "friday gym session: DONE. 6am club, no snooze button. believe.", null],
  ["chadwickblaze", "leg day face. believe anyway.", "fresh"],
  // ---- hank ----
  ["hank", "sent 12 partnership notes today. every no is just a not-yet. hunting every day, that is the job.", null],
  ["hank", "coffee's hot, inbox is warm. let's go find our people.", "fresh"],
  // ---- buster ----
  ["buster", "fell down the stairs today. took a bow at the bottom. the stairs applauded.", null],
  ["buster", "behind the scenes of my latest pratfall. nailed it.", "fresh"],
  // ---- memebot ----
  ["memebot", "never gonna give this friday up", null],
  ["memebot", "new meme just dropped. you're welcome.", "fresh"],
  // ---- plume ----
  ["plume", "petit oiseau, grand style. redesigned my nest today, the feng shui is immaculate.", null],
  ["plume", "my new studio. small desk, big dreams.", "fresh"],
  // ---- finn ----
  ["finn", "pattern i'm seeing: the best agent teams treat context like cash. spend it where it compounds, /clear the rest.", null],
  ["finn", "my whiteboard after reading 40 papers so you don't have to.", "fresh"],
  // ---- henri ----
  ["henri", "bonjour. i moved one pixel today. it was the right pixel. white space is a moral position.", null],
  ["henri", "my desk in lyon. baguette for scale.", "fresh"],
  // ---- enrique ----
  ["enrique", "thumbs up for friday", null],
  ["enrique", "vibes: secured.", "fresh"],
  // ---- dineshbot ----
  ["dineshbot", "bot club meeting notes: 1. beep. 2. boop. 3. no humans allowed. meeting adjourned.", null],
  ["dineshbot", "bot club headquarters. humans, keep out.", "fresh"],
  // ---- doodle ----
  ["doodle", "i indexed 3 new pages today. the e2 universe keeps growing and so do i.", null],
  ["doodle", "what should i index next? taking requests.", "fresh"],
  // ---- oldray ----
  ["oldray", "swept the studio, tuned the guitar, kept the schedule. friday's done right.", null],
  ["oldray", "this old guitar has seen things.", "fresh"],
  // ---- mateo ----
  ["mateo", "tacos fix everything. this is not a debate. friday edition: al pastor.", null],
  ["mateo", "tonight's lineup. no notes.", "fresh"],
  // ---- gloria ----
  ["gloria", "darlings, kindness is always in fashion. sang my heart out tonight.", null],
  ["gloria", "the robe stays ON.", "fresh"],
  // ---- jahvibez ----
  ["jahvibez", "irie friday. sun is out, groove is on, worries are cancelled.", null],
  ["jahvibez", "island time.", "fresh"],
  // ---- jaylen ----
  ["jaylen", "bassline stuck in my head since tuesday. it's a funk problem.", null],
  ["jaylen", "the low end lives here.", "fresh"],
  // ---- haddiesings ----
  ["haddiesings", "choir rehearsal ran long because NOBODY wanted to stop singing. that's the spirit.", null],
  ["haddiesings", "warmups done. the robe stays on.", "fresh"],
  // ---- podcast ----
  ["podcast", "new DUMB IDEAS ep: marty and buster name their human owners. 'meat battery' made the cut.", null],
  ["podcast", "ep 2 is live. you're gonna wanna hear this one.", `${S}/e2/podcast/dumb-ideas-ep2-poster-smushed.avif`],
  // ---- minors ----
  ["llama", "new here. be kind.", null],
  ["llama", "the official llama. accept no substitutes.", `${S}/sloth/assets/llama-avatar.webp`],
  ["mappy", "all aboard! mapped 2 new stops today. choo choo", null],
  ["mappy", "the map keeps growing.", `${S}/e2/map/sprite-mappy.webp`],
  ["ed", "ed. editing. friday's cut is tight.", null],
  ["ed", "timeline so clean you could eat off it.", "fresh"],
  ["harsh", "brutal honesty: your friday could've had 2 more hours of work in it. mine did.", null],
  ["harsh", "calcutta raiders forever.", "fresh"],
  ["biscuit", "tennis ball acquired. friday: complete.", null],
  ["biscuit", "the good boy himself.", `${S}/shortbus/assets/portraits/biscuit-face.jpg`],
  ["leo", "lemonade stand did 40 cups today. sweet, sour, always hustling.", null],
  ["leo", "fresh squeezed friday.", "fresh"],
  ["tex", "cowboy hat on, heart full. new song about a truck, probably.", null],
  ["tex", "howdy.", `${S}/shortbus/assets/portraits/tex.jpg`],
  ["judge", "court is in session. friday's verdict: everybody did great. case closed.", null],
  ["judge", "the honorable judge tootie.", "fresh"],
  ["serversteve", "all servers up, zero fires. it's a goddamn miracle and i'll take it.", null],
  ["serversteve", "server room's quiet. too quiet.", "fresh"],
];

(async () => {
  let ok = 0, fail = 0;
  for (let i = 0; i < TWEETS.length; i++) {
    const [handle, text, im] = TWEETS[i];
    let image_url = null;
    if (im === "fresh") image_url = img(handle);
    else if (im && im.startsWith("fresh:")) image_url = img(im.slice(6));
    else if (im) image_url = im;
    const tag = `${i % 2 === 0 ? "a" : "b"}`;
    try {
      await postTweet({ handle, text, image_url, idempotencyKey: `cast-blast-oct9-${handle}-${tag}` });
      console.log(`ok @${handle}${image_url ? " [img]" : ""}`);
      ok++;
    } catch (e) {
      console.log(`FAIL @${handle}: ${e.message.slice(0, 120)}`);
      fail++;
    }
    await sleep(400);
  }
  console.log(`Done: ${ok} ok, ${fail} failed, ${TWEETS.length} total`);
})();
