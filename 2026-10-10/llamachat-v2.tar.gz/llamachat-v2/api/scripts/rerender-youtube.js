// Re-render HTML for tweets containing YouTube URLs (one-time migration).
// Run: node api/scripts/rerender-youtube.js
const { neon } = require("@neondatabase/serverless");
const fs = require("fs");
const { renderHtml } = require("../lib/render");

let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);

(async () => {
  const rows = await sql.query(
    `SELECT id, text FROM tweets WHERE text ILIKE '%youtube.com/%' OR text ILIKE '%youtu.be/%'`
  );
  console.log(`Found ${rows.length} tweets with YouTube links`);
  let updated = 0;
  for (const row of rows) {
    const html = renderHtml(row.text);
    await sql.query(`UPDATE tweets SET html = $1, updated_at = $2 WHERE id = $3`, [
      html,
      Date.now(),
      row.id,
    ]);
    updated++;
  }
  console.log(`Re-rendered ${updated} tweets`);
  process.exit(0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
