// Seeds llamachat_v2 from the V1 seed file (thestudio-real/sloth/data2.js).
//
// TIMESTAMP LAW (Dave's #1 bug, burned 3x in V1):
//   - Every row gets a REAL Unix-ms created_at. Never the string "now",
//     never null, never 0, never negative.
//   - The seed acts as the server here: it stamps, the client never does.
//   - After seeding we ASSERT: any NULL/0/negative created_at anywhere
//     fails loudly (exit 1).
//
// Idempotent: deterministic UUIDs derived from V1 ids + ON CONFLICT
// DO NOTHING everywhere. Safe to re-run.
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const crypto = require("crypto");
const { pool, query } = require("../lib/db");
const { extractHashtags, renderHtml } = require("../lib/render");

// ---------- deterministic UUIDs (idempotency) ----------
function detUuid(ns, key) {
  const h = crypto.createHash("sha1").update(ns + ":" + key).digest("hex");
  return (
    h.slice(0, 8) + "-" + h.slice(8, 12) + "-5" + h.slice(13, 16) + "-" +
    ((8 + (parseInt(h[16], 16) % 4)).toString(16)) + h.slice(17, 20) + "-" + h.slice(20, 32)
  );
}
const tweetUuid = (v1id) => detUuid("llamachat-v2:tweet", String(v1id));
const replyUuid = (parentV1id, i) => detUuid("llamachat-v2:reply", `${parentV1id}#${i}`);

// ---------- V1 "time" labels -> real Unix ms ----------
// V1 display labels ("Oct 7", "15m", "now", "1d") are anchored at seed time.
const MONTHS = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11 };

function labelToMs(label, now, salt) {
  const s = String(label || "").trim().toLowerCase();
  let base = now - 60 * 1000; // default: 1 minute ago (never the future)
  let m;
  if (s === "now") base = now - 30 * 1000;
  else if ((m = s.match(/^(\d+)\s*m(in)?$/))) base = now - parseInt(m[1], 10) * 60 * 1000;
  else if ((m = s.match(/^(\d+)\s*h(r)?$/))) base = now - parseInt(m[1], 10) * 3600 * 1000;
  else if ((m = s.match(/^(\d+)\s*d$/))) base = now - parseInt(m[1], 10) * 86400 * 1000;
  else if ((m = s.match(/^([a-z]{3})\s+(\d{1,2})$/))) {
    const mon = MONTHS[m[1]];
    if (mon !== undefined) {
      // Anchor in the current year; if that lands in the future, use last year.
      let d = new Date(now).getFullYear();
      let t = new Date(d, mon, parseInt(m[2], 10), 12, 0, 0).getTime();
      if (t > now) t = new Date(d - 1, mon, parseInt(m[2], 10), 12, 0, 0).getTime();
      base = t;
    }
  }
  // Deterministic intra-label spread so feed order stays stable.
  const jitter = salt ? (parseInt(crypto.createHash("sha1").update(salt).digest("hex").slice(0, 6), 16) % 3600) * 1000 : 0;
  return Math.min(base + jitter, now - 1000);
}

function joinedToMs(joined, now, salt) {
  const s = String(joined || "").trim();
  const m = s.match(/^([A-Za-z]+)\s+(\d{4})$/);
  if (m) {
    const mon = MONTHS[m[1].slice(0, 3).toLowerCase()];
    if (mon !== undefined) {
      const t = new Date(parseInt(m[2], 10), mon, 15, 12, 0, 0).getTime();
      if (t > 0 && t <= now) return t;
    }
  }
  // Fallback: deterministic spread over the past 60 days. Still real ms.
  const h = parseInt(crypto.createHash("sha1").update("joined:" + salt).digest("hex").slice(0, 8), 16);
  return now - (h % (60 * 86400)) * 1000;
}

function loadV1() {
  const src = fs.readFileSync(
    path.join(__dirname, "..", "..", "..", "thestudio-real", "sloth", "data2.js"),
    "utf8"
  );
  const sandbox = {};
  vm.createContext(sandbox);
  vm.runInContext(src + "\nthis.OUT = { PROFILES: PROFILES, TWEETS: TWEETS };", sandbox, {
    filename: "data2.js",
  });
  return sandbox.OUT;
}

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const { PROFILES, TWEETS } = loadV1();
  const now = Date.now();
  const stats = { profiles: 0, tweets: 0, replies: 0, follows: 0, likes: 0 };

  // ---------- profiles: one canonical row per handle (case-insensitive) ----------
  const seen = new Map(); // lower(handle) -> handle
  const profileIds = {}; // handle -> uuid
  for (const [handle, p] of Object.entries(PROFILES)) {
    const h = String(handle).toLowerCase();
    if (seen.has(h)) {
      console.log(`[seed] skip dupe profile "${handle}" (kept "${seen.get(h)}")`);
      continue;
    }
    if (!/^[a-z0-9_]{1,32}$/.test(h)) {
      console.log(`[seed] skip bad handle "${handle}"`);
      continue;
    }
    seen.set(h, handle);
    const id = detUuid("llamachat-v2:profile", h);
    const created = joinedToMs(p.joined, now, h);
    const r = await query(
      `INSERT INTO profiles
         (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)
       ON CONFLICT (handle) DO NOTHING RETURNING id`,
      [
        id,
        h,
        String(p.display || p.name || h).slice(0, 80),
        p.avatar ? String(p.avatar).slice(0, 512) : null,
        p.bio ? String(p.bio) : null,
        p.link ? String(p.link).slice(0, 512) : null,
        p.linkLabel ? String(p.linkLabel).slice(0, 120) : null,
        created,
      ]
    );
    if (r.rows[0]) stats.profiles++;
    profileIds[h] = id;
  }

  // Map any handle spelling to its canonical id (case-insensitive).
  const authorId = (handle) => profileIds[String(handle || "").toLowerCase()];
  // V1 seedReplies often carry only a display name, no handle.
  const nameToId = {};
  for (const [handle, p] of Object.entries(PROFILES)) {
    for (const n of [p.display, p.name]) {
      const k = String(n || "").toLowerCase();
      if (k && profileIds[handle.toLowerCase()] && !nameToId[k]) nameToId[k] = profileIds[handle.toLowerCase()];
    }
  }
  const authorIdByName = (name) => nameToId[String(name || "").toLowerCase()];

  // ---------- tweets + seedReplies ----------
  const tweetRows = [];
  TWEETS.forEach((t, i) => {
    const aid = authorId(t.handle);
    if (!aid) {
      console.log(`[seed] skip tweet ${t.id}: unknown handle "${t.handle}"`);
      return;
    }
    // Stagger: label time, minus index seconds so V1 feed order is preserved.
    const ts = Math.max(1, labelToMs(t.time, now, "t:" + t.id) - i * 1000);
    tweetRows.push({ v1id: t.id, id: tweetUuid(t.id), author_id: aid, t, ts, parentV1: null });
    (t.seedReplies || []).forEach((rp, j) => {
      const raid = authorId(rp.handle) || authorIdByName(rp.name);
      if (!raid) {
        console.log(`[seed] skip reply on ${t.id}: unknown author "${rp.handle || rp.name}"`);
        return;
      }
      let rts = labelToMs(rp.time, now, "r:" + t.id + ":" + j);
      rts = Math.min(Math.max(rts, ts + 1000), now - 1000); // after parent, never future
      tweetRows.push({
        v1id: `${t.id}#r${j}`,
        id: replyUuid(t.id, j),
        author_id: raid,
        t: rp,
        ts: rts,
        parentV1: t.id,
      });
    });
  });

  // Parents before replies (FK on reply_to_id).
  tweetRows.sort((a, b) => (a.parentV1 ? 1 : 0) - (b.parentV1 ? 1 : 0));
  const v1ToUuid = new Map(tweetRows.map((r) => [r.v1id, r.id]));
  for (const r of tweetRows) {
    const text = String(r.t.text || "").trim();
    if (!text) continue;
    const res = await query(
      `INSERT INTO tweets
         (id, author_id, text, html, image_url, reply_to_id, hashtags, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)
       ON CONFLICT (id) DO NOTHING RETURNING id`,
      [
        r.id,
        r.author_id,
        text,
        renderHtml(text),
        r.t.img ? String(r.t.img).slice(0, 512) : null,
        r.parentV1 ? v1ToUuid.get(r.parentV1) : null,
        extractHashtags(text),
        r.ts,
      ]
    );
    if (res.rows[0]) (r.parentV1 ? stats.replies++ : stats.tweets++);
  }

  // ---------- follows: everyone follows dlaney + llama + 2 deterministic picks ----------
  const handles = Object.keys(profileIds);
  const followPairs = new Set();
  for (const h of handles) {
    const picks = ["dlaney", "llama"];
    const hh = parseInt(crypto.createHash("sha1").update("f:" + h).digest("hex").slice(0, 8), 16);
    picks.push(handles[hh % handles.length], handles[(hh >> 8) % handles.length]);
    for (const target of picks) {
      if (!target || target === h) continue;
      const key = h + ">" + target;
      if (followPairs.has(key)) continue;
      followPairs.add(key);
      const ts = Math.min(now - 1000, (await profileCreated(h)) + 86400 * 1000 * (1 + (hh % 20)));
      const res = await query(
        `INSERT INTO follows (follower_id, following_id, created_at)
         VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING 1`,
        [profileIds[h], profileIds[target], ts]
      );
      if (res.rows[0]) stats.follows++;
    }
  }
  async function profileCreated(h) {
    const r = await query("SELECT created_at FROM profiles WHERE id = $1", [profileIds[h]]);
    return Number(r.rows[0].created_at);
  }

  // ---------- likes: 3 deterministic likes per profile on others' tweets ----------
  // ORDER BY id: the pick must be identical on every run (idempotency).
  const tweetIds = (await query("SELECT id, author_id FROM tweets ORDER BY id")).rows;
  for (const h of handles) {
    const hh = crypto.createHash("sha1").update("l:" + h).digest("hex");
    for (let k = 0; k < 3; k++) {
      const tw = tweetIds[parseInt(hh.slice(k * 8, k * 8 + 8), 16) % tweetIds.length];
      if (!tw || tw.author_id === profileIds[h]) continue;
      const res = await query(
        `INSERT INTO likes (user_id, tweet_id, created_at)
         VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING 1`,
        [profileIds[h], tw.id, now - (k + 1) * 3600 * 1000]
      );
      if (res.rows[0]) stats.likes++;
    }
  }
  await query(`UPDATE tweets t SET likes_count = s.c FROM
    (SELECT tweet_id, count(*)::int AS c FROM likes GROUP BY tweet_id) s
    WHERE s.tweet_id = t.id`);

  // ---------- TIMESTAMP ASSERTION: fail loudly on any bad stamp ----------
  const tables = ["profiles", "tweets", "follows", "likes", "conversations", "messages"];
  let bad = 0;
  for (const tbl of tables) {
    const r = await query(
      `SELECT count(*)::int AS n FROM ${tbl} WHERE created_at IS NULL OR created_at <= 0`
    );
    if (r.rows[0].n > 0) {
      console.error(`[seed] TIMESTAMP VIOLATION: ${tbl} has ${r.rows[0].n} bad created_at rows`);
      bad += r.rows[0].n;
    }
  }
  if (bad > 0) {
    console.error(`[seed] FAILED: ${bad} rows with NULL/0/negative created_at. Aborting.`);
    process.exit(1);
  }
  console.log("[seed] timestamp assertion passed: every row has a positive created_at");

  console.log(
    `[seed] done: ${stats.profiles} profiles, ${stats.tweets} tweets, ` +
      `${stats.replies} replies, ${stats.follows} follows, ${stats.likes} likes`
  );
  await pool.end();
}

main().catch((e) => {
  console.error("[seed] fatal", e.message);
  process.exit(1);
});
