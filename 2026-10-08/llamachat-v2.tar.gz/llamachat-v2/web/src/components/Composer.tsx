// THE one Composer. V1 had three separate implementations (modal, home
// inline, reply box), each needing its own paste/drop handlers — the home
// composer shipped without them and Dave couldn't paste images there.
// V2: this single component is used everywhere with props.
//
// Props:
//   replyToId   — set when composing a reply (shows "Replying" context)
//   placeholder — default "What's happening?"
//   autofocus   — focus on mount (modal use)
//   compact     — smaller padding for inline use
//   onPosted    — called with the confirmed tweet (server response)
//   onOptimistic— called immediately with a temp tweet for instant UI
import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Tweet } from "../lib/api.ts";
import { uploadImage, fileToPreviewUrl, resolveImageUrl } from "../lib/images.ts";
import { enqueue } from "../lib/offline.ts";

const MAX_CHARS = 2000;

interface Props {
  api: ApiClient;
  apiBase: string;
  getCallerId: () => string | null;
  /** Logged-in user's avatar. The composer always shows YOUR face, like X. */
  avatarUrl?: string | null;
  replyToId?: string | null;
  /** Suppress the inline "Replying" label (the reply modal renders its own
   *  "Replying to @handle" line under the original tweet). */
  hideReplyingLabel?: boolean;
  placeholder?: string;
  autofocus?: boolean;
  compact?: boolean;
  onPosted?: (tweet: Tweet) => void;
  onOptimistic?: (temp: TempTweet) => void;
  onSettled?: (tempId: string, tweet: Tweet | null) => void;
}

export interface TempTweet {
  tempId: string;
  text: string;
  image_url: string | null;
  reply_to_id: string | null;
  // NOTE: no created_at. Dave's #1 rule: the client NEVER generates
  // timestamps. Optimistic tweets render "sending..." via tweetTime()
  // until the server responds with the real stamp.
  pending: true;
}

function newId(): string {
  // RFC 4122 v4. crypto.randomUUID where available.
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

export function Composer({
  api, apiBase, getCallerId, avatarUrl = null,
  replyToId = null,
  hideReplyingLabel = false,
  placeholder = "What's happening?",
  autofocus = false,
  onPosted, onOptimistic, onSettled,
}: Props) {
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (autofocus) taRef.current?.focus();
  }, [autofocus]);

  // Auto-grow the textarea.
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 320)}px`;
  }, [text]);

  const attachFile = useCallback(async (f: File) => {
    if (!f.type.startsWith("image/")) {
      setError("Only images can be attached.");
      return;
    }
    setError(null);
    setFile(f);
    try {
      setPreview(await fileToPreviewUrl(f));
    } catch {
      setPreview(null);
    }
  }, []);

  const onPaste = useCallback(
    (e: React.ClipboardEvent) => {
      // Finder copies land in clipboardData.files; screenshots in .items.
      const dt = e.clipboardData;
      const fromFiles = dt.files && dt.files.length > 0 ? dt.files[0] : null;
      if (fromFiles && fromFiles.type.startsWith("image/")) {
        e.preventDefault();
        void attachFile(fromFiles);
        return;
      }
      for (const item of Array.from(dt.items || [])) {
        if (item.type.startsWith("image/")) {
          const f = item.getAsFile();
          if (f) {
            e.preventDefault();
            void attachFile(f);
            return;
          }
        }
      }
    },
    [attachFile]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const f = e.dataTransfer.files && e.dataTransfer.files[0];
      if (f && f.type.startsWith("image/")) void attachFile(f);
    },
    [attachFile]
  );

  const clearAttachment = useCallback(() => {
    setFile(null);
    setPreview(null);
    if (fileRef.current) fileRef.current.value = "";
  }, []);

  const canPost = (text.trim().length > 0 || preview) && text.length <= MAX_CHARS && !busy;

  const post = useCallback(async () => {
    const body = text.trim();
    if ((!body && !preview) || body.length > MAX_CHARS || busy) return;
    const caller = getCallerId();
    if (!caller) {
      setError("You're not signed in.");
      return;
    }
    setBusy(true);
    setError(null);

    const tempId = newId();
    const temp: TempTweet = {
      tempId, text: body, image_url: preview, reply_to_id: replyToId,
      pending: true,
    };
    onOptimistic?.(temp);

    try {
      // 1. Upload image first (to Vercel Blob via the API).
      let image_url: string | null = null;
      if (file) {
        setStatus("Uploading image...");
        image_url = await uploadImage(apiBase, caller, file, "tweet", (stage) =>
          setStatus(stage === "uploading" ? "Uploading image..." : null)
        );
      }
      // 2. Create the tweet. Idempotent: same tempId -> no duplicate.
      setStatus("Posting...");
      const { tweet, deduped } = await api.postTweet({
        id: tempId, text: body, image_url, reply_to_id: replyToId,
      });
      setStatus(null);
      setText("");
      clearAttachment();
      onPosted?.(tweet);
      onSettled?.(tempId, tweet);
      if (deduped) setStatus("Already posted.");
    } catch (e) {
      // NEVER poof: queue for retry, keep the optimistic row marked pending.
      enqueue({ id: tempId, text: body, image_url: preview, reply_to_id: replyToId });
      const msg = e instanceof Error ? e.message : String(e);
      setError(`Couldn't post (${msg}). Saved — will retry automatically.`);
      onSettled?.(tempId, null);
    } finally {
      setBusy(false);
      setStatus(null);
    }
  }, [text, busy, file, preview, replyToId, api, apiBase, getCallerId, onOptimistic, onPosted, onSettled, clearAttachment]);

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        void post();
      }
    },
    [post]
  );

  // V1: the composer avatar is always the logged-in user's face.
  const avatarSrc = resolveImageUrl(avatarUrl) || resolveImageUrl("/assets/dave-dlaney-face-400.webp") || undefined;

  return (
    <div
      className="composer"
      onPaste={onPaste}
      onDrop={onDrop}
      onDragOver={(e) => e.preventDefault()}
    >
      <img className="avatar" src={avatarSrc} alt="You" />
      <div className="composer-main">
      {replyToId && !hideReplyingLabel ? <div className="composer-replying">Replying</div> : null}
      <textarea
        ref={taRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={onKeyDown}
        placeholder={placeholder}
        rows={1}
        aria-label={placeholder}
      />
      {preview ? (
        <div className="composer-preview">
          <img src={preview} alt="Attachment preview" />
          <button type="button" onClick={clearAttachment} aria-label="Remove image">✕</button>
        </div>
      ) : null}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="composer-file-input"
        onChange={(e) => {
          const f = e.target.files && e.target.files[0];
          if (f) void attachFile(f);
        }}
      />
      <div className="composer-bar">
        <div className="cicons">
          <button type="button" onClick={() => fileRef.current?.click()} aria-label="Attach image" disabled={busy}>
            <svg viewBox="0 0 24 24" className="nic" style={{width:18,height:18}}><path fill="currentColor" d="M4 4h16a1 1 0 011 1v14a1 1 0 01-1 1H4a1 1 0 01-1-1V5a1 1 0 011-1zm1 2v12h14V6H5zm3 2.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3zM6 17l4-4 3 3 2.5-2.5L19 17H6z"/></svg>
          </button>
        </div>

        <button type="button" className={`postbtn${canPost ? " ready" : ""}`} onClick={() => void post()} disabled={!canPost}>
          {busy ? "Posting..." : replyToId ? "Reply" : "Post"}
        </button>
      </div>
      {status ? <div className="composer-status">{status}</div> : null}
      {error ? <div className="composer-error">{error}</div> : null}
      </div>
    </div>
  );
}
