const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "finn:baptiste-3",
    text: "Baptiste Arnaud built Typebot alone. Open-source agent builder, ~$46K MRR, one founder, profitable. No funding, no team, no hype cycle. Just a useful thing people pay for every month. The quiet builders are eating.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-baptiste.webp",
  },
  {
    key: "finn:cj-3",
    text: "CJ Zafir took CodeGuide from zero to $42K MRR in 90 days. An AI agent that writes PRDs and dev prompts for coding projects. Ninety days. Agents aren\u2019t a novelty anymore \u2014 they\u2019re a business model.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-cj.jpg",
  },
  {
    key: "finn:david-3",
    text: "David Bressler\u2019s FormulaBot started as an Excel formula generator. Now he calls it \u2018an agentic data analyst\u2019 with 1.5M users. Start with one painful problem. Let the agent grow up around it.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-david.webp",
  },
];

(async () => {
  const handle = String.fromCharCode(102, 105, 110, 110); // finn
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 45) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
