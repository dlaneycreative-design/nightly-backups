// Open Arcade link auto-embeds for tweets.
//
// Dave's rule (Oct 30 2026): pasting an Open Arcade link is all it
// takes — "just pasting them in. Easy!" Any tweet containing an
// openarcade.lol game link renders that game in a playable box under
// the tweet text, no !Game command, no hashtag. That includes Dave's
// own uploads (the Starvard University Watch Tower 3D asset), which
// only exist in the Open Arcade API, not in games.json.
//
// Resolution needs the merged catalog. The browser cannot fetch the
// OA API's /api/uploads (its CORS only allows openarcade.lol), so the
// LlamaChat worker proxies the merged catalog at
// GET /api/v2/arcade/catalog (games.json + uploads, tombstones
// excluded). If that endpoint is unreachable we fall back to fetching
// games.json directly (it serves ACAO *); uploads simply do not
// resolve in that degraded mode. Every failure resolves quietly to
// "no embed" — link detection must never break tweet rendering.

import { detectGameEmbed, type GameInfo } from "./gameEmbed.ts";

export const OA_SITE = "https://openarcade.lol";
export const OA_API = "https://openarcade-api.dlaneycreative.workers.dev";

// Single-segment paths on openarcade.lol that are site pages, not
// games. (The catalog lookup is the final filter anyway; these just
// keep extraction honest.)
const SITE_PAGES = new Set([
  "all",
  "brand",
  "template",
  "architecture",
  "analytics",
  "upload",
  "profile",
  "g",
  "play",
  "api",
  "img",
  "assets",
]);

/**
 * Clean one raw slug candidate pasted from a sentence: URL-decode it,
 * lowercase it, and trim trailing sentence punctuation (period,
 * comma, closing paren/bracket/quote, etc.) plus stray trailing
 * slashes and hyphens left by smart-paste. Returns the slug when it
 * is a plausible slug ([a-z0-9][a-z0-9-]*), else null.
 */
export function cleanOpenArcadeSlug(raw: string): string | null {
  let s = String(raw || "").trim();
  try {
    s = decodeURIComponent(s);
  } catch {
    /* keep the raw text; validation below rejects true junk */
  }
  s = s.trim().toLowerCase();
  // Trailing sentence punctuation pasted along with the link.
  s = s.replace(/[\s.,;:!?)\]}>'"”’»]+$/g, "");
  s = s.replace(/\/+$/g, "");
  s = s.replace(/-+$/g, "");
  if (!/^[a-z0-9][a-z0-9-]*$/.test(s)) return null;
  if (SITE_PAGES.has(s)) return null;
  return s;
}

/** The slug referenced by one openarcade.lol URL tail (path+query+hash after the host). */
function slugFromTail(tail: string): string | null {
  const t = String(tail || "");
  if (!t) return null;
  // Hash deep link: /#supere2 or #supere2
  const hash = t.match(/^\/?#([^\s/?&#]+)/);
  if (hash) return cleanOpenArcadeSlug(hash[1]);
  // Game page: /g/?id=supere2 (also /g?id=)
  const g = t.match(/^\/g\/?\?([^#]*)/i);
  if (g) {
    const id = new URLSearchParams(g[1]).get("id");
    return id ? cleanOpenArcadeSlug(id) : null;
  }
  if (/^\/g(?:[/?#]|$)/i.test(t)) return null; // /g without an id
  if (!t.startsWith("/")) return null;
  const seg = t.slice(1).split(/[/?#]/)[0];
  if (!seg) return null; // homepage (bare host or "/")
  // Multi-segment paths (/play/<slug>/, /img/...) are not game links.
  const rest = t.slice(1 + seg.length);
  if (/^\/[^/?#]/.test(rest)) return null;
  return cleanOpenArcadeSlug(seg);
}

/**
 * Find the first Open Arcade game slug referenced anywhere in a
 * tweet's raw text: bare link as the whole tweet, mid-sentence,
 * inside parentheses, with trailing punctuation, trailing slash,
 * www host, uppercase, /g/?id= or /# forms — pasting is zero-step.
 * Returns the lowercased slug, or null when the text has no
 * single-game Open Arcade link.
 */
export function extractOpenArcadeSlug(text: string): string | null {
  const t = String(text || "");
  const re = /(?:https?:\/\/)?(?:www\.)?openarcade\.lol([^\s"'<>]*)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(t)) !== null) {
    const slug = slugFromTail(m[1] || "");
    if (slug) return slug;
  }
  return null;
}

/* ---------------- catalog ---------------- */

export type ArcadeCatalog = Map<string, GameInfo>;

/** Build the id->game map from normalized catalog entries. */
export function buildArcadeCatalog(entries: unknown): ArcadeCatalog {
  const map: ArcadeCatalog = new Map();
  if (!Array.isArray(entries)) return map;
  for (const e of entries) {
    if (!e || typeof e !== "object") continue;
    const row = e as Record<string, unknown>;
    const id = String(row.id || "").trim().toLowerCase();
    const name = String(row.name || "").trim();
    const playUrl = String(row.playUrl || "").trim();
    if (!id || !name || !playUrl) continue;
    map.set(id, {
      id,
      name,
      playUrl,
      pageUrl: String(row.pageUrl || `${OA_SITE}/${id}`).trim(),
      coverUrl: String(row.coverUrl || "").trim(),
    });
  }
  return map;
}

/** Normalized entries from a raw games.json array (fallback path; same shape as the worker merge). */
export function catalogEntriesFromGamesJson(games: unknown): unknown[] {
  if (!Array.isArray(games)) return [];
  return games
    .map((g) => {
      if (!g || typeof g !== "object") return null;
      const row = g as Record<string, unknown>;
      const id = String(row.id || "").trim().toLowerCase();
      const thumb = String(row.thumb || "").trim();
      if (!id) return null;
      return {
        id,
        name: String(row.title || "").trim(),
        playUrl: String(row.url || "").trim(),
        pageUrl: `${OA_SITE}/${id}`,
        coverUrl: thumb ? (thumb.startsWith("http") ? thumb : `${OA_SITE}${thumb.startsWith("/") ? "" : "/"}${thumb}`) : "",
      };
    })
    .filter(Boolean);
}

// Same base resolution as the app client (App.tsx / flashcards.ts):
// VITE_API_BASE, defaulting to the same-origin /api/v2.
function apiBase(): string {
  try {
    const v = (import.meta as unknown as { env?: Record<string, string | undefined> }).env
      ?.VITE_API_BASE;
    return (v || "/api/v2").replace(/\/$/, "");
  } catch {
    return "/api/v2";
  }
}

async function fetchCatalog(): Promise<ArcadeCatalog> {
  // Primary: the worker's merged proxy (includes uploads).
  try {
    const r = await fetch(`${apiBase()}/arcade/catalog`);
    if (r.ok) {
      const j = (await r.json().catch(() => null)) as { games?: unknown } | null;
      const map = buildArcadeCatalog(j?.games);
      if (map.size) return map;
    }
  } catch {
    /* fall through to the direct games.json fetch */
  }
  // Fallback: games.json is browser-fetchable (ACAO *). Uploads do
  // not resolve in this mode; the catalog games still embed.
  try {
    const r = await fetch(`${OA_SITE}/games.json`);
    if (r.ok) {
      const j = (await r.json().catch(() => null)) as unknown;
      return buildArcadeCatalog(catalogEntriesFromGamesJson(j));
    }
  } catch {
    /* no catalog: no embeds */
  }
  return new Map();
}

let catalogPromise: Promise<ArcadeCatalog> | null = null;

/** The session-cached catalog: fetched at most once, never rejects. */
export function loadArcadeCatalog(): Promise<ArcadeCatalog> {
  if (!catalogPromise) catalogPromise = fetchCatalog().catch(() => new Map());
  return catalogPromise;
}

/** Resolve a tweet's Open Arcade link against a known catalog (sync; used by tests). */
export function resolveFromCatalog(text: string, catalog: ArcadeCatalog): GameInfo | null {
  const slug = extractOpenArcadeSlug(text);
  if (!slug) return null;
  return catalog.get(slug) ?? null;
}

/**
 * The Open Arcade game a tweet links to, or null. Pass a catalog to
 * resolve synchronously in tests; normally the session catalog loads.
 */
export async function resolveOpenArcadeEmbed(
  text: string,
  catalog?: ArcadeCatalog
): Promise<GameInfo | null> {
  const slug = extractOpenArcadeSlug(text);
  if (!slug) return null;
  const map = catalog ?? (await loadArcadeCatalog());
  return map.get(slug) ?? null;
}

/**
 * True when the tweet already gets a !Game command embed. The OA
 * auto-embed never stacks on top of a command embed: one embed max,
 * and the command wins.
 */
export function hasCommandEmbed(text: string): boolean {
  return detectGameEmbed(text) != null;
}
