// Search autocomplete dropdown (Dave's call Oct 9 2026).
// Type a name -> matching people pop down. Click or Enter to visit profile.
// Keyboard: Up/Down to move, Enter to select, Escape to close.
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Profile } from "../lib/api.ts";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  api: ApiClient;
  query: string;
  onNavigate?: () => void;
}

export function SearchAutocomplete({ api, query, onNavigate }: Props) {
  const navigate = useNavigate();
  const [users, setUsers] = useState<Profile[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const timer = useRef<number | null>(null);
  const reqSeq = useRef(0);
  const wrapRef = useRef<HTMLDivElement>(null);

  const q = query.trim();

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    if (!q || q.length < 2) {
      setUsers([]);
      setOpen(false);
      return;
    }
    timer.current = window.setTimeout(async () => {
      const seq = ++reqSeq.current;
      try {
        const res = await api.search(q, "users");
        if (seq !== reqSeq.current) return;
        const list = (res.users || []).slice(0, 7);
        setUsers(list);
        setActive(0);
        setOpen(list.length > 0);
      } catch {
        // Silent: dropdown just stays closed on error.
      }
    }, 200);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [q, api]);

  // Close on outside click.
  useEffect(() => {
    const onDown = (e: PointerEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, []);

  const go = (u: Profile) => {
    setOpen(false);
    onNavigate?.();
    navigate(`/profile/${u.handle}`);
  };

  // Keyboard nav: global listener while open (focus stays in the input).
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive((a) => (a + 1) % users.length);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive((a) => (a - 1 + users.length) % users.length);
      } else if (e.key === "Enter" && users.length > 0) {
        e.preventDefault();
        go(users[active]);
      } else if (e.key === "Escape") {
        setOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, users, active]);

  if (!open || users.length === 0) return null;

  return (
    <div ref={wrapRef} className="search-ac-wrap">
      <div className="search-ac" role="listbox" aria-label="Matching people">
        {users.map((u, i) => {
          const src = resolveImageUrl(u.avatar_url);
          return (
            <button
              key={u.id}
              type="button"
              role="option"
              aria-selected={i === active}
              className={`search-ac-row${i === active ? " active" : ""}`}
              onClick={() => go(u)}
              onMouseEnter={() => setActive(i)}
            >
              {src ? (
                <img src={src} alt="" loading="lazy" decoding="async" />
              ) : (
                <div className="avatar-fallback" aria-hidden="true">
                  {(u.display_name || "?").slice(0, 1).toUpperCase()}
                </div>
              )}
              <div className="search-ac-txt">
                <div className="search-ac-name">{u.display_name}</div>
                <div className="search-ac-handle">@{u.handle}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
