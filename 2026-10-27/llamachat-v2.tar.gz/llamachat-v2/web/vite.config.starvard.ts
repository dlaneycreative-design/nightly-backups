import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

// Starvard build of the SAME Llama Chat app (architecture plan: one
// codebase, themed deployments, never a fork). Differences from the
// default build, all baked at build time:
//   - base "/feed/": the app mounts under starvard.org/feed.
//   - publicDir "public-starvard": only the assets this skin needs.
//   - tokens.css and overrides.css are swapped for the Starvard skin
//     (minimal white, one blue accent, prominent dice).
//   - index.html head tags are retitled for Starvard; the Llama GA tag,
//     manifest, icons, and service worker registration do not carry over.
// Build with:
//   VITE_THEME=starvard VITE_API_BASE=https://llamachat-api.dlaneycreative.workers.dev/api/v2 \
//     npx vite build --config vite.config.starvard.ts

const sv = (p: string) => fileURLToPath(new URL(p, import.meta.url));

const FEED_DESCRIPTION =
  "The Starvard campus feed. Students and friends learning out loud: levels finished, books completed, certificates earned.";

function starvardSkin(): Plugin {
  return {
    name: "starvard-skin",
    enforce: "pre",
    resolveId(id) {
      if (id.endsWith("styles/tokens.css")) return sv("./src/styles/tokens-starvard.css");
      if (id.endsWith("styles/overrides.css")) return sv("./src/styles/overrides-starvard.css");
      return null;
    },
    transformIndexHtml(html) {
      return html
        .replace(
          '<meta name="description" content="LlamaChat is the kind corner of the internet. Short posts, real conversations, and a whole lot of character from the Studio universe and friends." />',
          `<meta name="description" content="${FEED_DESCRIPTION}" />`
        )
        .replace('<link rel="canonical" href="https://llamachat.lol/" />', '<link rel="canonical" href="https://starvard.org/feed/" />')
        .replace('<meta property="og:site_name" content="LlamaChat" />', '<meta property="og:site_name" content="Starvard" />')
        .replace(
          '<meta property="og:title" content="LlamaChat — The Kind Corner of the Internet" />',
          '<meta property="og:title" content="Starvard Feed" />'
        )
        .replace(
          '<meta property="og:description" content="LlamaChat is the kind corner of the internet. Short posts, real conversations, and a whole lot of character." />',
          `<meta property="og:description" content="${FEED_DESCRIPTION}" />`
        )
        .replace('<meta property="og:url" content="https://llamachat.lol/" />', '<meta property="og:url" content="https://starvard.org/feed/" />')
        .replace('<meta property="og:image" content="https://llamachat.lol/icon-512.png" />', '<meta property="og:image" content="https://starvard.org/feed/icon-512.png" />')
        .replace('<meta name="twitter:title" content="LlamaChat — The Kind Corner of the Internet" />', '<meta name="twitter:title" content="Starvard Feed" />')
        .replace(
          '<meta name="twitter:description" content="Short posts, real conversations, and a whole lot of character from the Studio universe." />',
          `<meta name="twitter:description" content="${FEED_DESCRIPTION}" />`
        )
        .replace('<meta name="twitter:image" content="https://llamachat.lol/icon-512.png" />', '<meta name="twitter:image" content="https://starvard.org/feed/icon-512.png" />')
        .replace('<link rel="manifest" href="/manifest.json" />', '<link rel="manifest" href="/feed/manifest.json" />')
        .replace('<link rel="icon" type="image/x-icon" href="/favicon.ico" />', '<link rel="icon" type="image/png" sizes="32x32" href="/feed/favicon-32.png" />')
        .replace('<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png" />', '<link rel="icon" type="image/png" sizes="32x32" href="/feed/favicon-32.png" />')
        .replace('<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png" />', '<link rel="icon" type="image/png" sizes="16x16" href="/feed/favicon-16.png" />')
        .replace('<meta name="apple-mobile-web-app-title" content="LlamaChat" />', '<meta name="apple-mobile-web-app-title" content="Starvard" />')
        .replace('<link rel="apple-touch-icon" href="/apple-touch-icon.png" />', '<link rel="apple-touch-icon" href="/feed/apple-touch-icon.png" />')
        .replace("<title>LlamaChat — The Kind Corner of the Internet | Short Posts</title>", "<title>Starvard Feed</title>")
        // No Llama GA property on the Starvard surface.
        .replace(/<script async src="https:\/\/www\.googletagmanager\.com[^>]*><\/script>/, "")
        .replace(/<script>\s*window\.dataLayer[\s\S]*?<\/script>/, "")
        // No service worker registration in the Starvard build.
        .replace(/<script>\s*\/\/ Register service worker[\s\S]*?<\/script>/, "")
        .replace(
          /<noscript>[\s\S]*?<\/noscript>/,
          `<noscript>
      <header style="text-align:center;padding:40px 20px;font-family:system-ui,sans-serif">
        <h1>Starvard Feed</h1>
        <p>The Starvard campus feed. Students and friends learning out loud: levels finished, books completed, certificates earned.</p>
        <p>Enable JavaScript to see the feed, post your wins, and follow your classmates.</p>
      </header>
    </noscript>`
        );
    },
  };
}

export default defineConfig({
  plugins: [react(), starvardSkin()],
  base: "/feed/",
  publicDir: "public-starvard",
  build: {
    outDir: "dist-starvard",
    target: "es2020",
    chunkSizeWarningLimit: 180,
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: (id) => {
          if (id.includes("node_modules")) {
            if (id.includes("react-router")) return "vendor-router";
            if (id.includes("react")) return "vendor-react";
            return "vendor";
          }
        },
      },
    },
  },
});
