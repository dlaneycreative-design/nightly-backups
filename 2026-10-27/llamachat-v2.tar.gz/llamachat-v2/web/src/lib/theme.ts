// Per-deployment theme, selected at BUILD time (architecture plan: one
// app, two skins, never a fork). The default build is Llama Chat at
// llamachat.lol, and every value here reduces to exactly today's
// behavior there. The Starvard build (vite.config.starvard.ts with
// VITE_THEME=starvard) bakes the Starvard skin instead: same components,
// same store, same API, different tokens, logo, and labels.

function env(key: string): string | undefined {
  try {
    return (import.meta as unknown as { env?: Record<string, string | undefined> }).env?.[key];
  } catch {
    return undefined;
  }
}

export const THEME_NAME = env("VITE_THEME") || "llama";
export const IS_STARVARD = THEME_NAME === "starvard";

/** Mount prefix of this deployment: "" at a domain root, "/feed" on Starvard. */
export const APP_BASE = (env("BASE_URL") || "/").replace(/\/$/, "");

export const SITE_NAME = IS_STARVARD ? "Starvard" : "LlamaChat";
export const LOGO_URL = `${APP_BASE}${IS_STARVARD ? "/assets/avatars/starvard.webp" : "/llama-logo.avif"}`;
export const HOME_URL = `${APP_BASE}/`;

/** Prefix an app-owned absolute path ("/assets/...") with the mount base. */
export function appPath(path: string): string {
  return path.startsWith("/") ? `${APP_BASE}${path}` : path;
}
