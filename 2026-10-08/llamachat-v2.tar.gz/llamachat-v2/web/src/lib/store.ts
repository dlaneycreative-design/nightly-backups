// Normalized cache: one tweet object per ID, one profile per ID/handle.
// Feed, profile, hashtag, and search views all reference the same objects,
// so a like in the feed is a like everywhere. No duplicate arrays.
import type { Profile, Tweet } from "./api.ts";

const tweetsById = new Map<string, Tweet>();
const profilesById = new Map<string, Profile>();
const profilesByHandle = new Map<string, Profile>();

type Listener = () => void;
const listeners = new Set<Listener>();
function emit(): void {
  for (const l of listeners) l();
}

/** Subscribe to cache changes (returns unsubscribe). For React: useSyncExternalStore. */
export function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function upsertTweet(t: Tweet): Tweet {
  const existing = tweetsById.get(t.id);
  const merged = existing ? { ...existing, ...t } : t;
  tweetsById.set(t.id, merged);
  emit();
  return merged;
}

export function upsertTweets(list: Tweet[]): Tweet[] {
  return list.map(upsertTweet);
}

export function getTweet(id: string): Tweet | undefined {
  return tweetsById.get(id);
}

export function removeTweet(id: string): void {
  tweetsById.delete(id);
  emit();
}

export function upsertProfile(p: Profile): Profile {
  const existing = profilesById.get(p.id);
  const merged = existing ? { ...existing, ...p } : p;
  profilesById.set(p.id, merged);
  profilesByHandle.set(p.handle.toLowerCase(), merged);
  emit();
  return merged;
}

export function upsertProfiles(list: Profile[]): Profile[] {
  return list.map(upsertProfile);
}

/** Profile lookup by handle (case-insensitive). The spec'd "profile lookup". */
export function getProfileByHandle(handle: string): Profile | undefined {
  return profilesByHandle.get(handle.toLowerCase());
}

export function getProfileById(id: string): Profile | undefined {
  return profilesById.get(id);
}

/** Clear everything (sign-out, hard refresh). */
export function clearStore(): void {
  tweetsById.clear();
  profilesById.clear();
  profilesByHandle.clear();
  emit();
}

/** All cached tweets that reply to a parent, oldest first. Lets the thread
 *  view pick up replies posted from the reply modal without a refetch. */
export function repliesTo(parentId: string): Tweet[] {
  const out: Tweet[] = [];
  for (const t of tweetsById.values()) {
    if (t.reply_to_id === parentId) out.push(t);
  }
  out.sort((a, b) => a.created_at - b.created_at);
  return out;
}
