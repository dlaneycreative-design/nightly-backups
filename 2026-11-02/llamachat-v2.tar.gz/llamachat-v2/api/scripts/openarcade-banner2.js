// Swap @openarcade's LlamaChat banner to the generated high-end E2
// arcade artwork (Dave's order, Nov 1 2026: "Change the background
// profile picture to a cool, high-end arcade using E2 style").
// Navy + gold luxury arcade hall, big E2 laurel banner in the middle,
// island coast through the windows, 2736x912 (3:1) in
// ~/workspace/openarcade-llama-assets/openarcade-banner2.webp.
// Uploads through the API (cached in upload-state.json under banner2)
// and PATCHes only banner_url. Usage: node api/scripts/openarcade-banner2.js
const fs = require("fs");
const { API_BASE, getProfileId, serviceHeaders } = require("./lib/botlib");

const handle = String.fromCharCode(111, 112, 101, 110, 97, 114, 99, 97, 100, 101); // openarcade
const UPLOAD_STATE = "/home/hatch/workspace/openarcade-llama-assets/upload-state.json";
const PATH = "/home/hatch/workspace/openarcade-llama-assets/openarcade-banner2.webp";

(async () => {
  const id = await getProfileId(handle);
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(UPLOAD_STATE, "utf8"));
  } catch {}
  let url = saved.banner2;
  if (!url) {
    const bytes = fs.readFileSync(PATH);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: "image/webp" }), "openarcade-banner2.webp");
    form.append("kind", "tweet");
    const up = await fetch(`${API_BASE}/uploads`, {
      method: "POST",
      headers: serviceHeaders(id),
      body: form,
    });
    if (!up.ok) throw new Error(`upload -> ${up.status} ${(await up.text()).slice(0, 200)}`);
    url = (await up.json()).image_url;
    saved.banner2 = url;
    fs.writeFileSync(UPLOAD_STATE, JSON.stringify(saved, null, 2));
    console.log("[openarcade-banner2] uploaded:", url);
  } else {
    console.log("[openarcade-banner2] reusing upload:", url);
  }
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify({ banner_url: url }),
  });
  if (!res.ok) throw new Error(`PATCH -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[openarcade-banner2] banner set:", d.profile.banner_url);
})().catch((e) => {
  console.error("[openarcade-banner2] fatal", e.message);
  process.exit(1);
});
