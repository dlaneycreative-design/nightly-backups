// Simple toast system: blue notification bar bottom-right after actions.
// Dave's call Oct 9 2026: "after posting a comment the blue notification bar
// in the corner doesn't show up in the bottom right."

export interface ToastAction {
  label: string;
  href: string;
}

interface ToastMsg {
  text: string;
  action?: ToastAction;
}

type Listener = (msg: ToastMsg | null) => void;
let current: ToastMsg | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
const listeners = new Set<Listener>();

export function showToast(text: string, action?: ToastAction, ms = 4000) {
  current = { text, action };
  listeners.forEach((l) => l(current));
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    current = null;
    listeners.forEach((l) => l(null));
  }, ms);
}

export function subscribeToast(fn: Listener): () => void {
  listeners.add(fn);
  fn(current);
  return () => { listeners.delete(fn); };
}
