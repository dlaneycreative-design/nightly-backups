import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Profile } from "../lib/api.ts";
import { absDate } from "../lib/timestamps.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { getCallerId } from "../lib/session.ts";
import { IS_STARVARD, profilePath } from "../lib/theme.ts";
import { upsertProfile } from "../lib/store.ts";
import { showToast } from "../lib/toast.ts";
import { EditProfileSheet } from "./EditProfileSheet.tsx";
import { BadgeModal, CHARTER_BADGE } from "./BadgeModal.tsx";

interface Props {
  api: ApiClient;
  apiBase?: string;
  profile: Profile;
  onProfile: (p: Profile) => void;
}

// V1's default profile banner (thestudio.io/llama). V2 profiles carry no
// header field, so everyone gets the same night-sky banner like V1.
const DEFAULT_BANNER = "/assets/banners/llama-header-nightsky.avif";

// Starvard skin only: the gold check from Dave's endorsed profile mock.
// There is no verified field in the API yet, so until one exists this is
// a small presentation list for the owner and institution accounts.
const SV_VERIFIED = new Set(["dave", "starvard"]);

// Display-case overrides (Dave's call, Nov 1 2026): link labels and
// Instagram handles are derived from the URL when stored, which
// lowercases them, but Dave's brand names carry real capitals.
// Presentation only: stored values and hrefs stay canonical lowercase.
const CASE_OVERRIDES: Record<string, { link_label?: string; instagram?: string }> = {
  dave: { link_label: "HiDave.lol", instagram: "Dlaney__" },
};

/**
 * Profile header, ported 1:1 from V1 (thestudio.io/llama):
 * sticky topbar (back + name + post count), cover banner, avatar
 * overlapping the banner edge, follow/message actions, name/handle,
 * bio, link, joined date, following/followers counts.
 */
export function ProfileHeader({ api, apiBase, profile, onProfile }: Props) {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  // The Charter Member chip opens the shared badge lightbox (the same
  // BadgeModal the Achievements tab row opens), Dave's order Oct 19 2026.
  const [badgeOpen, setBadgeOpen] = useState(false);
  // Achievements stay tucked under a chevron until tapped, then the
  // chips pop down (Dave's order Nov 1 2026).
  const [achOpen, setAchOpen] = useState(false);
  const badgeChipRef = useRef<HTMLButtonElement>(null);
  const closeBadge = useCallback(() => {
    setBadgeOpen(false);
    // Return focus to the chip that opened the modal.
    badgeChipRef.current?.focus();
  }, []);
  const me = getCallerId();
  const isMe = me === profile.id;

  // X-style: the slim header stays hidden until the user scrolls past the
  // banner, so the banner is never cut off at the top of the profile.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 110);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleFollow = async () => {
    if (busy || isMe) return;
    setBusy(true);
    try {
      if (profile.following) {
        await api.unfollow(profile.id);
        onProfile(upsertProfile({ ...profile, following: false, followers_count: Math.max(0, profile.followers_count - 1) }));
      } else {
        await api.follow(profile.id);
        onProfile(upsertProfile({ ...profile, following: true, followers_count: profile.followers_count + 1 }));
      }
    } finally {
      setBusy(false);
    }
  };

  const startDm = async () => {
    if (busy || isMe) return;
    setBusy(true);
    try {
      const { conversation } = await api.createConversation([profile.id]);
      // Pass the fresh conversation via state so the DM thread shows
      // the person's name immediately (list may not have refreshed yet).
      navigate(`/messages/${conversation.id}`, { state: { conversation } });
    } catch (e) {
      showToast("Couldn't start conversation. Try again.");
    } finally {
      setBusy(false);
    }
  };

  const initial = (profile.display_name || "?").slice(0, 1).toUpperCase();
  const avatarSrc = resolveImageUrl(profile.avatar_url);
  const postLine = `${profile.posts_count} post${profile.posts_count === 1 ? "" : "s"}`;

  // Starvard skin only: Dave's E2 Charter Member badge rides along in
  // the Achievements row (Dave's order Oct 19 2026). Its image lives on
  // starvard.org, so it must never render on the Llama skin; the Llama
  // build's row is exactly the API achievements, unchanged.
  const achList =
    IS_STARVARD && profile.handle.toLowerCase() === CHARTER_BADGE.handle
      ? [
          ...(profile.achievements ?? []),
          { icon: CHARTER_BADGE.img, label: CHARTER_BADGE.label, sub: CHARTER_BADGE.sub, url: CHARTER_BADGE.url },
        ]
      : (profile.achievements ?? []);

  return (
    <div>
      <div className={scrolled ? "pf-head show" : "pf-head"}>
        <button type="button" className="back" onClick={() => navigate(-1)} aria-label="Back">
          ←
        </button>
        <div>
          <div className="n">{profile.display_name}</div>
          <div className="h">{postLine}</div>
        </div>
      </div>
      <div
        className={profile.banner_url ? "pf-banner custom" : "pf-banner"}
        style={{ backgroundImage: `url(${resolveImageUrl(profile.banner_url) || DEFAULT_BANNER})` }}
      />
      <div className="pf-idrow">
        {avatarSrc ? (
          <img src={avatarSrc} alt={`${profile.display_name}'s avatar`} />
        ) : (
          <div className="pf-avatar-fallback" aria-hidden="true">
            {initial}
          </div>
        )}
        {isMe ? (
          <div className="pf-actions">
            <button
              type="button"
              className="followbtn"
              onClick={() => setEditOpen(true)}
            >
              Edit profile
            </button>
          </div>
        ) : null}
        {!isMe && me ? (
          <div className="pf-actions">
            <button type="button" className="msgbtn" onClick={() => void startDm()} disabled={busy} aria-label="Message">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
              </svg>
            </button>
            <button
              type="button"
              className={`followbtn${profile.following ? " following" : ""}`}
              onClick={() => void toggleFollow()}
              disabled={busy}
            >
              {profile.following ? "Following" : "Follow"}
            </button>
          </div>
        ) : null}
      </div>
      <div className="pf-bio">
        <div className="pf-n">
          {profile.display_name}
          {IS_STARVARD && SV_VERIFIED.has(profile.handle.toLowerCase()) ? (
            <span className="pf-verified" title="Verified" role="img" aria-label="Verified">
              <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                <circle cx="12" cy="12" r="10" fill="#b58520" />
                <path d="M8.2 12.4l2.5 2.5 5.1-5.4" stroke="#fff" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          ) : null}
        </div>
        <div className="pf-handle">@{profile.handle}</div>
        {IS_STARVARD ? (
          <a
            className="pf-also"
            href={`https://llamachat.lol${profilePath(profile.handle)}`}
            target="_blank"
            rel="noopener"
          >
            also on LlamaChat
          </a>
        ) : null}
        {profile.bio ? <div id="pfBio">{profile.bio}</div> : null}
        {profile.link_url ? (
          <a href={profile.link_url} target="_blank" rel="noopener">
            {CASE_OVERRIDES[profile.handle]?.link_label || profile.link_label || profile.link_url}
          </a>
        ) : null}
        {profile.instagram ? (
          <a
            href={`https://instagram.com/${profile.instagram.replace(/^@/, "")}`}
            target="_blank"
            rel="noopener"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, marginTop: 6 }}
            aria-label={`${profile.display_name} on Instagram`}
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <rect x="2" y="2" width="20" height="20" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
            </svg>
            @{CASE_OVERRIDES[profile.handle]?.instagram || profile.instagram.replace(/^@/, "")}
          </a>
        ) : null}
        <div className="pf-joined">Joined {absDate(profile.created_at)}</div>
        <div className="pf-stats">
          <span>
            <b>{profile.following_count}</b> Following
          </span>
          <span>
            <b>{profile.followers_count}</b> Followers
          </span>
        </div>
        {achList.length ? (
          <div className="pf-achwrap">
            <button
              type="button"
              className="pf-ach-head pf-ach-toggle"
              aria-expanded={achOpen}
              onClick={() => setAchOpen((v) => !v)}
            >
              Achievements
              <span className={achOpen ? "pf-ach-chev open" : "pf-ach-chev"} aria-hidden="true">
                ▾
              </span>
            </button>
            {achOpen ? (
            <div className="pf-ach">
              {achList.map((a) => {
                const inner = (
                  <>
                    {a.icon.startsWith("http") || a.icon.startsWith("/") ? (
                      <img className="pf-chip-img" src={a.icon} alt="" aria-hidden="true" />
                    ) : (
                      <span className="pf-chip-ic" aria-hidden="true">
                        {a.icon}
                      </span>
                    )}
                    {a.label}
                  </>
                );
                // The Charter Member chip pops the badge lightbox
                // instead of navigating away (Dave's order Oct 19 2026).
                if (IS_STARVARD && a.label === CHARTER_BADGE.label) {
                  return (
                    <button
                      key={a.label}
                      ref={badgeChipRef}
                      type="button"
                      className="pf-chip"
                      onClick={() => setBadgeOpen(true)}
                      aria-haspopup="dialog"
                      title={a.sub || a.label}
                    >
                      {inner}
                    </button>
                  );
                }
                return (
                  <a
                    key={a.label}
                    className="pf-chip"
                    href={a.url}
                    target="_blank"
                    rel="noopener"
                    title={a.sub || a.label}
                  >
                    {inner}
                  </a>
                );
              })}
            </div>
            ) : null}
            {badgeOpen ? <BadgeModal onClose={closeBadge} /> : null}
          </div>
        ) : null}
      </div>
      {editOpen && isMe ? (
        <EditProfileSheet
          api={api}
          apiBase={apiBase ?? "/api/v2"}
          profile={profile}
          onClose={() => setEditOpen(false)}
          onSaved={(p) => onProfile(upsertProfile(p))}
        />
      ) : null}
    </div>
  );
}
