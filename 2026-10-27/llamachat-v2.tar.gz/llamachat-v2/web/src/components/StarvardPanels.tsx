import { useCallback, useRef, useState } from "react";
import type { Profile } from "../lib/api.ts";
import { getCallerId } from "../lib/session.ts";
import { BadgeModal, CHARTER_BADGE } from "./BadgeModal.tsx";

// Starvard profile tab panel (Achievements).
// This component is only ever rendered by ProfileTabs in the
// Starvard build; the Llama build never mounts it.
//
// Data honesty rules for this file:
// - Certificates on your own profile come from this browser's
//   sv_issued store, exactly what cert/quiz.js writes when a quiz is
//   passed. Links rebuild the real certificate URL from the record.
// - No invented member counts, balances, or stats anywhere.

const SV = "https://starvard.org";

interface SvCert {
  id: string;
  name: string;
  slug: string;
  title: string;
  date: string;
  v: string;
}

function loadLocalCerts(): SvCert[] {
  try {
    const raw = localStorage.getItem("sv_issued");
    const arr: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(arr)) return [];
    return arr.filter(
      (c): c is SvCert =>
        !!c && typeof c === "object" && typeof (c as SvCert).id === "string" && typeof (c as SvCert).title === "string"
    );
  } catch {
    return [];
  }
}

function certUrl(c: SvCert): string {
  const q = new URLSearchParams({
    id: c.id,
    name: c.name,
    slug: c.slug,
    title: c.title,
    date: c.date,
    v: c.v,
  });
  return `${SV}/certificate/?${q.toString()}`;
}

export function CertificatesPanel({ profile }: { profile: Profile }) {
  const isMe = !!getCallerId() && getCallerId() === profile.id;
  const [certs] = useState<SvCert[]>(() => (isMe ? loadLocalCerts() : []));
  const [badgeOpen, setBadgeOpen] = useState(false);
  const badgeBtnRef = useRef<HTMLButtonElement>(null);
  const closeBadge = useCallback(() => {
    setBadgeOpen(false);
    // Return focus to the row that opened the modal.
    badgeBtnRef.current?.focus();
  }, []);

  const badge =
    profile.handle.toLowerCase() === CHARTER_BADGE.handle ? (
      <>
        <button
          ref={badgeBtnRef}
          type="button"
          className="sv-cert sv-cert-btn"
          onClick={() => setBadgeOpen(true)}
          aria-haspopup="dialog"
        >
          <img className="sv-badge-img" src={CHARTER_BADGE.img} alt="" />
          <span>
            <span className="tt">{CHARTER_BADGE.label}</span>
            <br />
            <span className="ss">{CHARTER_BADGE.sub}</span>
          </span>
        </button>
        {badgeOpen ? <BadgeModal onClose={closeBadge} /> : null}
      </>
    ) : null;

  if (!isMe) {
    return (
      <div className="sv-panel">
        {badge}
        {badge ? null : (
          <div className="empty">
            <p>Certificates appear here as they are earned.</p>
          </div>
        )}
      </div>
    );
  }
  if (certs.length === 0) {
    return (
      <div className="sv-panel">
        {badge}
        <div className="empty">
          <p>No certificates yet. Pass a course quiz on starvard.org and yours will show up here.</p>
        </div>
      </div>
    );
  }
  return (
    <div className="sv-panel">
      <h3 className="sv-h">Your certificates</h3>
      <p className="sv-note">Earned on starvard.org, stored in this browser.</p>
      {badge}
      {certs.map((c) => (
        <a key={c.id} className="sv-cert" href={certUrl(c)}>
          <span className="ic" aria-hidden="true">
            🏆
          </span>
          <span>
            <span className="tt">{c.title}</span>
            <br />
            <span className="ss">
              {c.name} · {c.date}
            </span>
          </span>
        </a>
      ))}
    </div>
  );
}
