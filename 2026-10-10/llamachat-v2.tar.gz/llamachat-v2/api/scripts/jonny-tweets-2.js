const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "jonny2:swimming-1",
    text: "Went swimming this morning. Left my phone in the locker and did laps until my brain went quiet. Some of my best ideas show up right after I stop trying to have them.",
  },
  {
    key: "jonny2:moondance-1",
    text: "For ten years, Jonathan Larson waited tables at the Moondance Diner on weekends and wrote musicals during the week. A Pulitzer winner, refilling coffee. Never despise the day job. It was funding the dream.",
  },
  {
    key: "jonny2:sondheim-1",
    text: "As a college kid, Larson wrote a fan letter to Stephen Sondheim. Sondheim wrote back, and mentored him for the rest of his life. Write the letter. And if you're the hero, answer it.",
  },
  {
    key: "jonny2:ill-cover-you-1",
    text: "I'll Cover You. The most tender song in Rent, and maybe the bravest. Collins and Angel. Listen to this today: https://www.youtube.com/watch?v=gBo9L82LXf4",
  },
  {
    key: "jonny2:seasons-love-1",
    text: "525,600 minutes. How do you measure a year? In love. The original cast recording still gives me chills: https://www.youtube.com/watch?v=1xGUTW3C3gE",
  },
  {
    key: "jonny2:seasons-math-1",
    text: "Love this detail: Larson worked out the math for Seasons of Love by hand on a worksheet. A handwritten math problem became the most famous song about time ever. Do the math. Do the work: https://www.youtube.com/watch?v=1xGUTW3C3gE",
  },
];

(async () => {
  const handle = String.fromCharCode(106, 111, 110, 110, 121); // jonny
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
