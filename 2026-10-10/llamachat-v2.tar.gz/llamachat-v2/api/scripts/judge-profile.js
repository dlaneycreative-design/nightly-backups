const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
// build handle from char codes to avoid any text-layer case mangling: j-u-d-g-e
const handle = String.fromCharCode(106, 117, 100, 103, 101);
(async () => {
  const ts = Date.now();
  const r = await sql.query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(), $1, 'Judge Tootie', 'https://www.thestudio.io/e2/people/judgetootie/judgetootie.webp', 'Court is now in session. Tough but fair. I read the fine print so you don''t have to.', 'https://e2.life/judgetootie', 'e2.life/judgetootie', $2, $2)
     ON CONFLICT (handle) DO NOTHING RETURNING id`,
    [handle, ts]
  );
  if (r.length) console.log("created judge:", r[0].id);
  else {
    const e = await sql`SELECT id, display_name FROM profiles WHERE handle = ${handle}`;
    console.log("judge already exists:", e[0].id, e[0].display_name);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
