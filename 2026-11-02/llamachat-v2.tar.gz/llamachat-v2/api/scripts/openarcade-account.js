// Creates the @openarcade profile on LlamaChat (Open Arcade, the E2 game
// arcade at openarcade.lol) and posts its launch set: four of our best
// games first, then the introduction post last so the intro crowns the
// profile (the e2-account-v2 pattern).
// Dave's order (Nov 1 2026, this side chat): "Set this up on Llama Chat
// and have five posts. One like an introduction post with an image
// screenshot of the site and then four of our best games, just post the
// link and it'll actually show up right there in the feed."
// The four games (all E2-made, top fun scores, all in the live arcade
// catalog so their links embed playable in the feed):
//   Super E2 (96), E2 World (98), Coastal Ridge GP (91), Enit Walks (92).
// Game posts are TEXT + LINK ONLY on purpose: the openarcade.lol link
// auto-embeds the playable game in the feed (Dave's rule, Oct 30 2026).
// Intro post carries a screenshot of openarcade.lol (the site's player
// showing E2 World, with the Up Next shelf).
// Profile creation via POST /profiles with the bot service secret;
// @openarcade is on the BOT_SERVICE_HANDLES allowlist (lib/auth.js) and
// in NON_HUMAN_HANDLES (presence.js) so botlib posts work and the
// account never shows in the humans-online list.
// Idempotent: creation 409s if @openarcade exists, uploads cached in
// ~/workspace/openarcade-llama-assets/upload-state.json, tweets dedupe
// on deterministic keys.
// Usage: node api/scripts/openarcade-account.js
const fs = require("fs");
const { API_BASE, postTweet, getProfileId, serviceHeaders, botServiceSecret } = require("./lib/botlib");

const handle = String.fromCharCode(111, 112, 101, 110, 97, 114, 99, 97, 100, 101); // openarcade
const UPLOAD_STATE = "/home/hatch/workspace/openarcade-llama-assets/upload-state.json";

const LOCAL_IMAGES = {
  avatar: [
    "/home/hatch/workspace/openarcade-llama-assets/openarcade-avatar.png",
    "image/png",
    "openarcade-avatar.png",
  ],
  banner: [
    "/home/hatch/workspace/openarcade-llama-assets/openarcade-banner.webp",
    "image/webp",
    "openarcade-banner.webp",
  ],
  home: [
    "/home/hatch/workspace/openarcade-llama-assets/openarcade-home.webp",
    "image/webp",
    "openarcade-home.webp",
  ],
};

async function ensureProfile() {
  const res = await fetch(`${API_BASE}/profiles`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-service": botServiceSecret() },
    body: JSON.stringify({ handle, display_name: "Open Arcade" }),
  });
  if (res.status === 201) {
    const d = await res.json();
    console.log("created @openarcade via API:", d.profile.id);
    return d.profile.id;
  }
  if (res.status === 409) {
    const id = await getProfileId(handle);
    console.log("@openarcade already exists:", id);
    return id;
  }
  throw new Error(`POST /profiles -> ${res.status} ${(await res.text()).slice(0, 200)}`);
}

async function uploadAll(id) {
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(UPLOAD_STATE, "utf8"));
  } catch {}
  const urls = {};
  for (const [key, [path, type, name]] of Object.entries(LOCAL_IMAGES)) {
    if (saved[key]) {
      urls[key] = saved[key];
      console.log(`[openarcade] reusing upload ${key}: ${saved[key]}`);
      continue;
    }
    const bytes = fs.readFileSync(path);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type }), name);
    form.append("kind", "tweet");
    const up = await fetch(`${API_BASE}/uploads`, {
      method: "POST",
      headers: serviceHeaders(id),
      body: form,
    });
    if (!up.ok) throw new Error(`upload ${key} -> ${up.status} ${(await up.text()).slice(0, 200)}`);
    const { image_url } = await up.json();
    console.log(`[openarcade] uploaded ${key}: ${image_url}`);
    urls[key] = image_url;
    saved[key] = image_url;
    fs.writeFileSync(UPLOAD_STATE, JSON.stringify(saved, null, 2));
  }
  return urls;
}

async function patchProfile(id, urls) {
  const fields = {
    display_name: "Open Arcade",
    avatar_url: urls.avatar,
    bio: "🕹️ Open Arcade is E2's game arcade: 100+ free games that play right in your browser, no downloads, no ads. Our own games, community games, and classics we love. Play a game, earn Points, remix one and make it yours.",
    link_url: "https://openarcade.lol",
    link_label: "openarcade.lol",
    banner_url: urls.banner,
  };
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify(fields),
  });
  if (!res.ok) throw new Error(`PATCH /profiles/${handle} -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[openarcade] profile set:", d.profile.handle, "| banner:", d.profile.banner_url ? "yes" : "NO");
  return d.profile;
}

// Posting order is BOTTOM-UP: the profile shows newest on top, so we
// post the games in reverse display order and the intro last, which
// leaves the finished profile reading top-down: intro, Super E2,
// E2 World, Coastal Ridge GP, Enit Walks.
function tweets(urls) {
  return [
    {
      key: "openarcade:game-enitwalks",
      text: "🌼 Enit Walks\n\nA morning walk Dave made for Enit: down Meadow Lane, through the walled garden, and into town for a coffee. Slow down and take the walk.\n\nPlay it right here: https://openarcade.lol/enitwalks",
    },
    {
      key: "openarcade:game-coastal-ridge-gp",
      text: "🏎️ Coastal Ridge GP\n\nOur 90s style arcade racer. Powerslide the red #3 around a coastal circuit of beach, town and harbor, beat the checkpoints and pass all 11 rivals.\n\nPlay it right here: https://openarcade.lol/coastal-ridge-gp",
    },
    {
      key: "openarcade:game-e2world",
      text: "🏝️ E2 World\n\nThe whole E2 cast in one walkable 3D world: Dave, Sally, Dinesh, Mike, Harsh and friends, with places to explore and people to meet. The front door of E2, playable.\n\nPlay it right here: https://openarcade.lol/e2world",
    },
    {
      key: "openarcade:game-supere2",
      text: "⭐ Super E2\n\nDave's pixel platformer. Pick your runner: Dave, Marty, Jen, Sally, Jah Vibez, Dinesh, Chadwick or Mike, then run the E2 world. Built to be remixed, put yourself in the game.\n\nPlay it right here: https://openarcade.lol/supere2",
    },
    {
      key: "openarcade:intro",
      image_url: urls.home,
      text: "🕹️ Hi! We are Open Arcade, E2's game arcade, now on LlamaChat.\n\n100+ free games that play right in your browser: no downloads, no ads. Our own games, community games, and classics we love, all in one big player with an Up Next shelf.\n\nBest part here on LlamaChat: when we post a game link, the game shows up playable right in your feed. The four below are a good place to start.\n\nBrowse them all: https://openarcade.lol",
    },
  ];
}

(async () => {
  const id = await ensureProfile();
  const urls = await uploadAll(id);
  await patchProfile(id, urls);
  for (const t of tweets(urls)) {
    const { tweet, deduped } = await postTweet({
      handle,
      text: t.text,
      image_url: t.image_url || null,
      idempotencyKey: t.key,
    });
    console.log(`[openarcade] ${deduped ? "deduped" : "posted"} ${t.key} -> ${tweet.id}`);
    await new Promise((res) => setTimeout(res, 1500));
  }
  console.log("[openarcade] done");
})().catch((e) => {
  console.error("[openarcade] fatal", e.message);
  process.exit(1);
});
