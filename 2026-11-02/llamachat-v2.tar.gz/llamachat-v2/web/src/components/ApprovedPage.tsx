// /approved: the link we hand to invited people. One door only
// (Dave's call Nov 1 2026): log in with Discord and you are in.
// Anyone can use it, invited or not, and the API creates their
// account automatically on the first login. No signup form.
import type { Profile } from "../lib/api.ts";
import { DISCORD_LOGIN_URL, HOME_URL, IS_STARVARD, SITE_NAME } from "../lib/theme.ts";
import { clearCallerId } from "../lib/session.ts";
import { clearStore } from "../lib/store.ts";

export function ApprovedPage({ me }: { me: Profile | null }) {
  return (
    <div style={{ maxWidth: 420, margin: "48px auto", padding: "0 20px", textAlign: "center" }}>
      <h1 style={{ fontSize: 28, margin: "0 0 8px" }}>Welcome to {SITE_NAME}{IS_STARVARD ? "" : " 🦙"}</h1>
      <p style={{ color: "#536471", margin: "0 0 24px", fontSize: 15 }}>
        Log in with Discord and you are in. New here? Your account is created automatically the first time you log in.
      </p>
      {me ? (
        <div style={{ display: "flex", gap: 12, alignItems: "center", background: "#f7f9f9", border: "1px solid #e3e8ea", borderRadius: 16, padding: "12px 14px", margin: "0 0 18px", textAlign: "left" }}>
          {me.avatar_url ? (
            <img src={me.avatar_url} alt="" style={{ width: 42, height: 42, borderRadius: "50%", objectFit: "cover", flex: "none" }} />
          ) : (
            <span style={{ width: 42, height: 42, borderRadius: "50%", background: "#1d9bf0", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 17, flex: "none" }}>{(me.display_name || me.handle || "?").slice(0, 1).toUpperCase()}</span>
          )}
          <div style={{ minWidth: 0 }}>
            <p style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#0f1419" }}>You are already logged in as @{me.handle}</p>
            <p style={{ margin: "8px 0 0", fontSize: 14 }}>
              <a href={HOME_URL} style={{ color: "#1d9bf0", fontWeight: 700 }}>Continue as @{me.handle}</a>
              <span style={{ color: "#aab8c2", margin: "0 8px" }}>·</span>
              <button type="button" onClick={() => { clearCallerId(); clearStore(); window.location.href = HOME_URL; }} style={{ background: "none", border: "none", padding: 0, font: "inherit", color: "#536471", fontWeight: 600, cursor: "pointer" }}>Log out</button>
            </p>
          </div>
        </div>
      ) : (
        <a
          href={DISCORD_LOGIN_URL}
          style={{ display: "block", width: "100%", padding: "14px", fontSize: 17, fontWeight: 700, background: "#5865F2", color: "#fff", borderRadius: 9999, textDecoration: "none", boxSizing: "border-box" }}
        >
          Log in with Discord
        </a>
      )}
    </div>
  );
}
