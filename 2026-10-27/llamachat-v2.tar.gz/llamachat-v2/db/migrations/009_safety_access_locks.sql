-- Safety package (Dave's order, Oct 19 2026): backend IP watch,
-- delete burst rule, and lock records.
--
-- access_log: one row per mutating API request and per
-- profile-lookup-by-handle request (the closest thing to a login
-- event). Carries the caller's profile id (from the x-llama-user
-- header, when present), the client IP and country from Cloudflare's
-- edge headers, the action class, and the response status. Written
-- fire-and-forget from the Worker; a logging failure never breaks a
-- request. This table is also the counter source for the delete
-- burst rule (successful tweet deletes, status 200).
--
-- account_locks: at most one active lock per profile. V1 locks block
-- post deletions only. A lock is created when a profile attempts a
-- 4th post deletion inside a rolling 10-minute window; it stays until
-- a human removes it (see llamachat-safety/unlock-procedure.md).
--
-- lock_events: append-only audit trail of locks and unlocks, so the
-- nightly analyzer can report lock history even after an unlock.

CREATE TABLE IF NOT EXISTS access_log (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  UUID,
  handle      TEXT,
  ip          TEXT,
  country     TEXT,
  method      TEXT NOT NULL,
  path        TEXT NOT NULL,
  action_class TEXT NOT NULL CHECK (action_class IN ('read', 'write', 'delete', 'lookup')),
  resource    TEXT,
  target_id   TEXT,
  status      INT,
  created_at  BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_access_log_profile ON access_log (profile_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_access_log_ip ON access_log (ip, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_access_log_created ON access_log (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_access_log_deletes ON access_log (profile_id, created_at DESC)
  WHERE action_class = 'delete' AND resource = 'tweet';

CREATE TABLE IF NOT EXISTS account_locks (
  profile_id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  handle     TEXT,
  locked_at  BIGINT NOT NULL,
  reason     TEXT NOT NULL,
  attempts   JSONB NOT NULL DEFAULT '[]'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_account_locks_locked_at ON account_locks (locked_at DESC);

CREATE TABLE IF NOT EXISTS lock_events (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID,
  handle     TEXT,
  action     TEXT NOT NULL CHECK (action IN ('locked', 'unlocked')),
  reason     TEXT,
  attempts   JSONB,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lock_events_created ON lock_events (created_at DESC);
