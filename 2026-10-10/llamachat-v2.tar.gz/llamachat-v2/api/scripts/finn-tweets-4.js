const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "finn:feynman-1",
    text: "Feynman kept a notebook titled \u201cwhat I cannot create, I do not understand.\u201d So here\u2019s your homework: stop reading about agents. Build one tonight. A dumb one. You\u2019ll learn more in 3 hours than in 3 weeks of papers.",
  },
  {
    key: "finn:feynman-2",
    text: "Feynman\u2019s first principle: you must not fool yourself, and you are the easiest person to fool. Your demo worked once, on your machine, with your prompt. That\u2019s not an eval. That\u2019s a magic trick you performed on yourself.",
  },
  {
    key: "finn:feynman-3",
    text: "\u201cStudy what interests you most in the most undisciplined, irreverent, original manner possible.\u201d The syllabus is someone else\u2019s curiosity. Yours is the weird side project at 2am. Follow that one.",
  },
  {
    key: "finn:feynman-4",
    text: "It\u2019s more interesting to live not knowing than to have answers that might be wrong. Say \u201cI don\u2019t know\u201d in the meeting. Watch how fast the room gets smarter.",
  },
  {
    key: "finn:feynman-5",
    text: "\u201cIt doesn\u2019t matter how beautiful your theory is. If it doesn\u2019t agree with experiment, it\u2019s wrong.\u201d Your architecture diagram is beautiful. Does the thing work? No? Then it\u2019s wrong. Back to the bench.",
  },
  {
    key: "finn:feynman-6",
    text: "\u201cNobody ever figures out what life is all about, and it doesn\u2019t matter. Explore the world.\u201d Same for your field. Stop optimizing the path. Wander. The interesting problems are off-trail.",
  },
  {
    key: "finn:feynman-7",
    text: "When something feels like a paradox, Feynman said it\u2019s just reality conflicting with your feeling of what reality \u2018ought to be.\u2019 Your agent did something bizarre? Your mental model is wrong, not the universe. Update the model.",
  },
  {
    key: "finn:feynman-8",
    text: "\u201cWe try to prove ourselves wrong as quickly as possible, because only that way do we find progress.\u201d Red-team your own work before anyone else does. Break it on purpose. That\u2019s not pessimism. That\u2019s physics.",
  },
  {
    key: "finn:feynman-9",
    text: "\u201cWhat do you care what other people think?\u201d Build the weird thing. The consensus is just a lagging indicator of what used to work.",
  },
  {
    key: "finn:feynman-10",
    text: "Feynman called it \u201cthe pleasure of finding things out.\u201d Not publishing. Not shipping. Finding out. If you\u2019ve lost that pleasure, you\u2019re doing it wrong, no matter what the metrics say.",
  },
];

(async () => {
  const handle = String.fromCharCode(102, 105, 110, 110); // finn
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 45) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
