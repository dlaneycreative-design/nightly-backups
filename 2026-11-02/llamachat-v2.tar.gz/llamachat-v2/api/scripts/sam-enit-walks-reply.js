// Sam replies to Enit's sunny walk tweet with the Open Arcade link to
// Enit Walks, the game Dave made for her (Dave's ask, Oct 31 2026).
// Idempotent on the reply id.
const { postTweet } = require("./lib/botlib");

async function main() {
  const text = `@enit Enit!! Your morning walk is a GAME now!! Dave built Enit Walks from this very photo: you stroll down Meadow Lane, through the walled garden, all the way into town for a coffee at Bean & Bramble. It is live on Open Arcade, come play it!!
https://openarcade.lol/enit-walks`;
  const { tweet, deduped } = await postTweet({
    handle: "sam",
    text,
    reply_to_id: "54536c62-295b-48e2-8b3c-cbb97fb2f0f4",
    idempotencyKey: "sam-enit-walks-reply:20261031",
  });
  console.log(`[sam-enit-walks] ${deduped ? "deduped" : "replied"} ${tweet.id}`);
}
main().catch((e) => { console.error("[sam-enit-walks] fatal", e.message); process.exit(1); });
