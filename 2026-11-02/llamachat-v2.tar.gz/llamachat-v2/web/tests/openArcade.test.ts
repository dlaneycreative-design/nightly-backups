// Open Arcade link auto-embed tests: slug extraction (including the
// zero-step paste cases Dave called out Oct 30 2026) and catalog
// resolution. The catalog here is a stub built from normalized
// entries shaped exactly like GET /api/v2/arcade/catalog output.
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  extractOpenArcadeSlug,
  cleanOpenArcadeSlug,
  buildArcadeCatalog,
  catalogEntriesFromGamesJson,
  resolveFromCatalog,
  resolveOpenArcadeEmbed,
  hasCommandEmbed,
} from "../src/lib/openArcade.ts";
import { detectGameEmbed } from "../src/lib/gameEmbed.ts";

const WATCH_TOWER = {
  id: "starvard-university-watch-tower",
  name: "Starvard University — Watch Tower",
  playUrl: "https://openarcade-api.dlaneycreative.workers.dev/play/starvard-university-watch-tower/",
  pageUrl: "https://openarcade.lol/starvard-university-watch-tower",
  coverUrl: "https://openarcade-api.dlaneycreative.workers.dev/api/cover/starvard-university-watch-tower",
};
const SUPER_E2_CATALOG = {
  id: "supere2",
  name: "Super E2",
  playUrl: "https://openarcade.lol/supere2-game/", // games.json url, verbatim
  pageUrl: "https://openarcade.lol/supere2",
  coverUrl: "https://openarcade.lol/img/supere2.webp?v=20261030b",
};
const E2_WORLD = {
  id: "e2world",
  name: "E2 World",
  playUrl: "https://e2.life/e2world/",
  pageUrl: "https://openarcade.lol/e2world",
  coverUrl: "https://openarcade.lol/img/e2world.webp",
};
const CATALOG = buildArcadeCatalog([WATCH_TOWER, SUPER_E2_CATALOG, E2_WORLD]);

test("extraction: the Watch Tower URL Dave pasted", () => {
  assert.equal(
    extractOpenArcadeSlug("https://openarcade.lol/starvard-university-watch-tower"),
    "starvard-university-watch-tower"
  );
});

test("extraction: zero-step pastes — bare link only, trailing punctuation, parentheses, smart paste", () => {
  const cases: Array<[string, string]> = [
    // a tweet whose entire text is just the pasted link
    ["https://openarcade.lol/starvard-university-watch-tower", "starvard-university-watch-tower"],
    ["openarcade.lol/starvard-university-watch-tower", "starvard-university-watch-tower"],
    // trailing sentence punctuation rides along with a paste
    ["https://openarcade.lol/starvard-university-watch-tower.", "starvard-university-watch-tower"],
    ["Play this! https://openarcade.lol/supere2, it's great", "supere2"],
    ["Play this! https://openarcade.lol/supere2!", "supere2"],
    // link inside parentheses
    ["(https://openarcade.lol/starvard-university-watch-tower)", "starvard-university-watch-tower"],
    ["my tower (openarcade.lol/starvard-university-watch-tower) is up", "starvard-university-watch-tower"],
    // trailing slash from a copy out of the address bar
    ["https://openarcade.lol/supere2/", "supere2"],
    // bare host mid-sentence
    ["you have to try openarcade.lol/supere2 today", "supere2"],
    // www + uppercase slug
    ["https://www.openarcade.lol/SuperE2", "supere2"],
    ["HTTPS://OPENARCADE.LOL/SUPERE2", "supere2"],
    // /g/ game page and hash deep link
    ["https://openarcade.lol/g/?id=e2world", "e2world"],
    ["openarcade.lol/g/?id=e2world&utm_source=share", "e2world"],
    ["https://openarcade.lol/#supere2", "supere2"],
    // URL-encoded characters in the slug decode before matching
    ["https://openarcade.lol/starvard%2Duniversity%2Dwatch%2Dtower", "starvard-university-watch-tower"],
  ];
  for (const [text, slug] of cases) assert.equal(extractOpenArcadeSlug(text), slug, text);
});

test("extraction: no game link -> null", () => {
  const cases = [
    "https://openarcade.lol/", // homepage
    "https://openarcade.lol",
    "check out openarcade.lol today", // bare host, no game
    "https://openarcade.lol/all/", // site pages
    "https://openarcade.lol/brand/",
    "https://openarcade.lol/upload",
    "https://openarcade.lol/g/", // game index without an id
    "https://openarcade.lol/g/?ref=home", // /g/ without id param
    "https://openarcade.lol/play/snake-duel/", // multi-segment path
    "https://openarcade.lol/img/supere2.webp", // an image, not a game page
    "no links here at all",
    "https://example.com/supere2", // wrong host
    "",
  ];
  for (const text of cases) assert.equal(extractOpenArcadeSlug(text), null, text);
});

test("cleanOpenArcadeSlug trims trailing sentence punctuation", () => {
  assert.equal(cleanOpenArcadeSlug("supere2."), "supere2");
  assert.equal(cleanOpenArcadeSlug("supere2,"), "supere2");
  assert.equal(cleanOpenArcadeSlug("supere2)"), "supere2");
  assert.equal(cleanOpenArcadeSlug("supere2)."), "supere2");
  assert.equal(cleanOpenArcadeSlug("SUPERE2"), "supere2");
  assert.equal(cleanOpenArcadeSlug("super e2"), null); // spaces are not a slug
  assert.equal(cleanOpenArcadeSlug(""), null);
});

test("resolution: Watch Tower resolves to Dave's upload entry (API play/cover)", async () => {
  const g = await resolveOpenArcadeEmbed("https://openarcade.lol/starvard-university-watch-tower", CATALOG);
  assert.ok(g);
  assert.equal(g.name, "Starvard University — Watch Tower");
  assert.equal(g.playUrl, WATCH_TOWER.playUrl);
  assert.equal(g.coverUrl, WATCH_TOWER.coverUrl);
  assert.equal(g.pageUrl, WATCH_TOWER.pageUrl);
});

test("resolution: bare-link-only tweet and pasted-with-punctuation tweets resolve", async () => {
  for (const text of [
    "https://openarcade.lol/starvard-university-watch-tower",
    "https://openarcade.lol/starvard-university-watch-tower.",
    "(https://openarcade.lol/starvard-university-watch-tower)",
  ]) {
    const g = await resolveOpenArcadeEmbed(text, CATALOG);
    assert.ok(g, text);
    assert.equal(g.id, "starvard-university-watch-tower", text);
  }
});

test("resolution: catalog Super E2 keeps the games.json play URL verbatim", () => {
  const g = resolveFromCatalog("openarcade.lol/supere2", CATALOG);
  assert.ok(g);
  assert.equal(g.playUrl, "https://openarcade.lol/supere2-game/");
  assert.equal(g.coverUrl, "https://openarcade.lol/img/supere2.webp?v=20261030b");
});

test("resolution: /g/?id= and /# forms resolve", () => {
  assert.equal(resolveFromCatalog("https://openarcade.lol/g/?id=e2world", CATALOG)?.id, "e2world");
  assert.equal(resolveFromCatalog("https://openarcade.lol/#supere2", CATALOG)?.id, "supere2");
});

test("resolution: unknown and tombstoned slugs -> null", () => {
  assert.equal(resolveFromCatalog("https://openarcade.lol/not-a-real-game", CATALOG), null);
  // hexgl is tombstoned on Open Arcade, so the merged server catalog
  // never carries it; a link to it must not embed.
  assert.equal(resolveFromCatalog("https://openarcade.lol/hexgl", CATALOG), null);
  assert.equal(resolveFromCatalog("a tweet with no link", CATALOG), null);
});

test("precedence: a !Game command tweet takes the command embed, OA embed is suppressed", () => {
  const text = "!Game Super E2 — also at https://openarcade.lol/e2world";
  const cmd = detectGameEmbed(text);
  assert.ok(cmd);
  assert.equal(cmd.id, "super-e2");
  assert.equal(cmd.playUrl, "https://supere2.netlify.app"); // the command version, not the catalog one
  assert.equal(hasCommandEmbed(text), true);
  // The OA slug is still extractable/resolvable on its own merits —
  // suppression happens in the component via hasCommandEmbed.
  assert.equal(resolveFromCatalog(text, CATALOG)?.id, "e2world");
  assert.equal(hasCommandEmbed("https://openarcade.lol/e2world"), false);
});

test("fallback normalization: games.json rows map to the worker's normalized shape", () => {
  const entries = catalogEntriesFromGamesJson([
    { id: "supere2", title: "Super E2", url: "https://openarcade.lol/supere2-game/", thumb: "/img/supere2.webp?v=20261030b" },
  ]);
  const map = buildArcadeCatalog(entries);
  const g = map.get("supere2");
  assert.ok(g);
  assert.equal(g.playUrl, "https://openarcade.lol/supere2-game/");
  assert.equal(g.pageUrl, "https://openarcade.lol/supere2");
  assert.equal(g.coverUrl, "https://openarcade.lol/img/supere2.webp?v=20261030b");
});
