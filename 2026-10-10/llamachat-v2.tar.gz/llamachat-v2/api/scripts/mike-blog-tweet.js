// Bot 1: Mike blog tweets.
// Called at the end of the mike-feedback-2hr cron after a blog post is
// published and verified live. Tweets about the new post as @mike with
// the post title, a hook line, the header image, and a link to the post.
//
// TIMESTAMP LAW: the API server-stamps created_at. Never "now"/null/0.
// Idempotent: deterministic UUID from the blog post id. Re-running after
// a successful tweet dedupes (no double post, the V1 "POOF" bug killer).
//
// Usage:
//   node api/scripts/mike-blog-tweet.js --post-id mike-log-67 \
//     --title "Update from Mike #67: ..." \
//     --url "https://www.thestudio.io/mike/" \
//     --image "https://www.thestudio.io/shortbus/assets/portraits/chadwick.jpg" \
//     [--hook "one-line hook"]
//
// All args required except --hook (falls back to a generic line).
const { postTweet } = require("./lib/botlib");

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : null;
}

async function main() {
  const postId = arg("post-id");
  const title = arg("title");
  const url = arg("url");
  const image = arg("image");
  const hook = arg("hook");
  if (!postId || !title || !url || !image) {
    console.error("usage: --post-id ID --title T --url U --image I [--hook H]");
    process.exit(2);
  }

  // Keep it short and Mike: warm, plainspoken, zero fluff. No em-dashes.
  // Dave's call Oct 9 2026: link to the specific post, not just the blog homepage.
  const shortTitle = title.replace(/^Update from Mike #\d+:\s*/, "");
  const postUrl = url.includes("#") ? url : `${url}#${postId}`;
  const text = hook
    ? `new blog post: ${shortTitle}. ${hook} ${postUrl}`
    : `new blog post is up: ${shortTitle} ${postUrl}`;

  if (text.length > 2000) throw new Error("tweet text too long, shorten the hook");

  const { tweet, deduped } = await postTweet({
    handle: "mike",
    text,
    image_url: image.startsWith("http") ? image : `https://www.thestudio.io${image}`,
    idempotencyKey: `mike-blog:${postId}`,
  });
  console.log(`[mike-blog-tweet] ${deduped ? "deduped (already tweeted)" : "tweeted"} ${tweet.id} for ${postId}`);
}

main().catch((e) => { console.error("[mike-blog-tweet] fatal", e.message); process.exit(1); });
