// Read-only inventory part 2: URL-pattern census of thestudio.io tweets,
// profile columns, latest top-level tweets.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
const sql = neon(url);

const hits = await sql`
  SELECT t.id, p.handle, t.created_at, t.reply_to_id, t.text
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE t.text ILIKE '%thestudio.io%' OR t.html ILIKE '%thestudio.io%'
  ORDER BY t.created_at`;
const pats = {};
for (const r of hits) {
  const urls = r.text.match(/https?:\/\/www\.thestudio\.io[^\s]*/g) || ['(html-only)'];
  for (const u of urls) {
    const key = u.replace(/#mike-log-\d+/, '#mike-log-NN');
    pats[key] = pats[key] || { count: 0, authors: new Set(), ids: [] };
    pats[key].count++; pats[key].authors.add(r.handle); pats[key].ids.push(r.id);
  }
}
console.log('URL PATTERN CENSUS (from tweet text):');
for (const [k, v] of Object.entries(pats)) console.log(` ${v.count}x ${k}  authors=${[...v.authors].join(',')}`);

const cols = await sql`SELECT column_name FROM information_schema.columns WHERE table_name='profiles' ORDER BY ordinal_position`;
console.log('\nprofiles columns:', cols.map(c => c.column_name).join(', '));
const profs = await sql`SELECT * FROM profiles WHERE bio ILIKE '%thestudio.io%' OR avatar_url ILIKE '%thestudio.io%'`;
console.log(`profiles w/ thestudio in bio/avatar: ${profs.length}`);
for (const r of profs) console.log(' ', r.handle, '| bio:', r.bio, '| avatar:', r.avatar_url);

const latest = await sql`
  SELECT t.id, p.handle, t.created_at, left(t.text, 60) AS text
  FROM tweets t JOIN profiles p ON p.id = t.author_id
  WHERE t.reply_to_id IS NULL
  ORDER BY t.created_at DESC, t.id DESC LIMIT 14`;
console.log('\nLATEST 14 TOP-LEVEL:');
for (const r of latest) console.log(' ', r.created_at, r.handle, '|', (r.text || '').replace(/\n/g, ' '));
console.log('DONE2');
