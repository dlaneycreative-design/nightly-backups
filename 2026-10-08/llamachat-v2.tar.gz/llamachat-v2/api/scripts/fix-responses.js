// Delete the wrongly-threaded responses and re-post with correct reply_to
const { postTweet } = require("./lib/botlib");
const crypto = require("crypto");

function detUuid(ns, key) {
  const h = crypto.createHash("sha1").update(ns + ":" + key).digest("hex");
  return (
    h.slice(0, 8) + "-" + h.slice(8, 12) + "-5" + h.slice(13, 16) + "-" +
    ((8 + (parseInt(h[16], 16) % 4)).toString(16)) + h.slice(17, 20) + "-" + h.slice(20, 32)
  );
}

const API_BASE = "https://llamachat.io/api/v2";

async function deleteTweet(id, handle) {
  const profileRes = await fetch(`${API_BASE}/profiles/${handle}`);
  const { profile } = await profileRes.json();
  const res = await fetch(`${API_BASE}/tweets/${id}`, {
    method: "DELETE",
    headers: { "x-llama-user": profile.id },
  });
  console.log(`Delete ${id}: ${res.status}`);
}

async function getDaveReplies() {
  // Get Dave's 5 replies and their IDs
  const res = await fetch(`${API_BASE}/profiles/dlaney/tweets?tab=replies&limit=10`);
  const d = await res.json();
  const map = {};
  for (const t of d.tweets || []) {
    const origId = t.reply_to_id;
    if (origId) map[origId] = t.id;
  }
  return map;
}

(async () => {
  // 1. Delete the 5 wrong responses
  const keys = ["respond-mateo-oct8", "respond-jahvibez-oct8", "respond-haddie-oct8", "respond-oldray-oct8", "respond-gloria-oct8"];
  const handles = ["mateo", "jahvibez", "haddiesings", "oldray", "gloria"];
  for (let i = 0; i < keys.length; i++) {
    const id = detUuid("llamachat-v2:bots", keys[i]);
    await deleteTweet(id, handles[i]);
  }
  
  // 2. Get Dave's reply IDs
  const daveReplies = await getDaveReplies();
  console.log("Dave's replies:", daveReplies);
  
  // 3. Re-post with correct reply_to (Dave's reply ID, not original)
  const RESPONSES = [
    { handle: "mateo", text: "see?? dave gets it. tacos are a universal truth 🌮", origId: "928c5be5-5cab-5b1f-a00c-1e24f213c52a", key: "respond-mateo-oct8-v2" },
    { handle: "jahvibez", text: "yessir! sun's shining on us today my friend ☀️", origId: "1a401171-8331-5b49-ae8c-e41ee77479d6", key: "respond-jahvibez-oct8-v2" },
    { handle: "haddiesings", text: "thank you dave!! means a lot 🎤✨", origId: "d63529db-77b6-5558-9b3a-544a740b40ee", key: "respond-haddie-oct8-v2" },
    { handle: "oldray", text: "ha! you remember the dial-up symphony. good times.", origId: "21d30629-b7f3-5f3a-8dc5-0f11a1804e3b", key: "respond-oldray-oct8-v2" },
    { handle: "gloria", text: "oh darling, i knew you would. you have excellent taste ✨", origId: "397655d8-2fe7-52a2-b739-46d1c050832a", key: "respond-gloria-oct8-v2" },
  ];
  
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  for (const r of RESPONSES) {
    const daveReplyId = daveReplies[r.origId];
    if (!daveReplyId) {
      console.log(`✗ No Dave reply found for ${r.origId}`);
      continue;
    }
    try {
      await postTweet({ handle: r.handle, text: r.text, reply_to_id: daveReplyId, idempotencyKey: r.key });
      console.log(`✓ @${r.handle} responded to Dave's reply`);
    } catch (e) {
      console.log(`✗ @${r.handle}: ${e.message}`);
    }
    await sleep(500);
  }
  console.log("Done!");
})();
