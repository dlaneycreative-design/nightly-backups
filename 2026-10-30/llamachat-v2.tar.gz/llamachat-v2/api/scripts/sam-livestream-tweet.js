// Sam's tweet for the 100p Lead a Live Stream bounty (Dave's ask, Oct 29 2026).
// Uploads the poster through the real API (R2 -> llamachat.lol/media/...),
// then posts as @sam via botlib. Idempotent on the tweet id.
const fs = require("fs");
const { API_BASE, postTweet, getProfileId } = require("./lib/botlib");

async function main() {
  const samId = await getProfileId("sam");
  const bytes = fs.readFileSync("/home/hatch/workspace/live-bounty/sam-livestream-1600.webp");
  const form = new FormData();
  form.append("file", new Blob([bytes], { type: "image/webp" }), "sam-livestream.webp");
  form.append("kind", "tweet");
  const up = await fetch(`${API_BASE}/uploads`, {
    method: "POST",
    headers: { "x-llama-user": samId },
    body: form,
  });
  if (!up.ok) throw new Error(`upload -> ${up.status} ${(await up.text()).slice(0, 200)}`);
  const { image_url } = await up.json();
  console.log("[sam-livestream] uploaded", image_url);

  const text = `🔴 New bounty, friends: Lead a live stream, earn 100p!

We just opened a Live Streams section in the E2 Discord. Go live, share your screen, play a game or teach something, get a couple of people in there watching, and Tippy pays you 100p.

I wrote it up on my blog: https://e2.life/samblog/#sam-log-6
All the bounties: https://e2.life/bounties/`;
  const { tweet, deduped } = await postTweet({
    handle: "sam",
    text,
    image_url,
    idempotencyKey: "sam-livestream-bounty:20261029",
  });
  console.log(`[sam-livestream] ${deduped ? "deduped" : "tweeted"} ${tweet.id}`);
}
main().catch((e) => { console.error("[sam-livestream] fatal", e.message); process.exit(1); });
