import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
const me = '8d754e46-a2af-4318-a3d8-9b47e5473abb';       // dave
const other = '4c08bb11-2e07-59d7-a30e-ed42d3e2bc55';    // oldray
const ids = [me, other];

// Step A: profile existence (getProfileById)
for (const id of ids) {
  const r = await sql`SELECT id, handle FROM profiles WHERE id = ${id}`;
  console.log('PROFILE CHECK', id, '->', JSON.stringify(r[0] || null));
}

// Step B: the route's find-existing query, verbatim semantics
try {
  const existing = await sql`
    SELECT c.id FROM conversations c
    WHERE NOT EXISTS (
      SELECT 1 FROM conversation_participants cp
      WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY(${ids}))
    ) AND (SELECT count(*) FROM conversation_participants cp2
           WHERE cp2.conversation_id = c.id) = ${ids.length}
    LIMIT 1`;
  console.log('FIND EXISTING ->', JSON.stringify(existing));
} catch (e) {
  console.log('FIND EXISTING ERROR:', e.message, e.code || '');
}
