// Server-side text rendering: hashtag extraction + HTML rendering.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { esc, extractHashtags, renderHtml } = require("../lib/render");

test("extractHashtags lowercases and strips #", () => {
  assert.deepEqual(extractHashtags("#Hello world"), ["hello"]);
});

test("extractHashtags removes duplicates", () => {
  assert.deepEqual(extractHashtags("#Kind #kind #KIND"), ["kind"]);
});

test("extractHashtags handles multiples and underscores", () => {
  assert.deepEqual(extractHashtags("a #one b #two_c"), ["one", "two_c"]);
});

test("extractHashtags ignores # not at a word boundary", () => {
  assert.deepEqual(extractHashtags("foo#bar"), []);
  assert.deepEqual(extractHashtags("# alone"), []);
});

test("extractHashtags unicode edge cases", () => {
  // The tag charset is ASCII [A-Za-z0-9_]; "#café" matches only "caf".
  // Documented behavior: extraction is conservative, never crashes.
  assert.deepEqual(extractHashtags("#café"), ["caf"]);
  assert.deepEqual(extractHashtags("#日本語"), []);
  assert.deepEqual(extractHashtags(""), []);
});

test("renderHtml escapes HTML before linkifying", () => {
  const html = renderHtml('<script>alert("x")</script>');
  assert.ok(!html.includes("<script>"), "raw tags must not survive");
  assert.ok(html.includes("&lt;script&gt;"), "tags must be escaped");
});

test("renderHtml linkifies hashtags and mentions", () => {
  const html = renderHtml("hi #Kind @dlaney");
  assert.ok(html.includes('href="/hashtag/Kind"'), "hashtag link");
  assert.ok(html.includes('href="/profile/dlaney"'), "mention link");
});

test("renderHtml linkifies the public .@mention convention", () => {
  // X/Twitter: ".@Sam ..." is a public post that still mentions Sam.
  const html = renderHtml(".@Sam has been doing such a great job lately.");
  assert.ok(html.startsWith('.<a href="/profile/Sam" data-handle="Sam">@Sam</a>'), "dot stays plain, @Sam links");
});

test("renderHtml linkifies .@ after whitespace too", () => {
  const html = renderHtml("hi .@Sam !");
  assert.ok(html.includes('.<a href="/profile/Sam"'), "mid-post .@ links");
});

test("extractMentions includes .@ and dedupes case-insensitively", () => {
  const { extractMentions } = require("../lib/render");
  assert.deepEqual(extractMentions(".@Sam hi @sam and @Dave"), ["sam", "dave"]);
  assert.deepEqual(extractMentions("mail user@example.com"), []);
  assert.deepEqual(extractMentions("mail user.@example.com"), []);
});

test("renderHtml does not linkify # inside URLs", () => {
  const html = renderHtml("see https://x.com/a#b now");
  assert.ok(html.includes('<a href="https://x.com/a#b"'), "URL kept whole");
  assert.ok(!html.includes("/hashtag/b"), "no tag link inside URL");
});

test("esc quotes attributes", () => {
  assert.equal(esc('a"b&c<d>'), "a&quot;b&amp;c&lt;d&gt;");
});

test("renderHtml linkifies bare domains", () => {
  const html = renderHtml("anyway, clearrecipe.net");
  assert.ok(html.includes('<a href="https://clearrecipe.net" target="_blank" rel="noopener">clearrecipe.net</a>'), "bare domain links with https href");
});

test("renderHtml keeps trailing punctuation outside bare domain links", () => {
  const html = renderHtml("visit clearrecipe.net. it's great!");
  assert.ok(html.includes('>clearrecipe.net</a>.'), "period stays outside the link");
});

test("renderHtml does not linkify emails as domains", () => {
  const html = renderHtml("mail user@example.com today");
  assert.ok(!html.includes('href="https://example.com"'), "email domain must not link");
});

test("renderHtml does not linkify version numbers", () => {
  const html = renderHtml("shipped v2.0 today");
  assert.ok(!html.includes("<a href="), "no links at all");
});

test("renderHtml does not double-wrap full URLs", () => {
  const html = renderHtml("see https://clearrecipe.net/pie now");
  const count = (html.match(/<a href=/g) || []).length;
  assert.equal(count, 1, "exactly one link");
  assert.ok(html.includes('<a href="https://clearrecipe.net/pie"'), "full URL kept whole");
});

test("renderHtml linkifies bare domains with paths", () => {
  const html = renderHtml("try clearrecipe.net/recipes/pie");
  assert.ok(html.includes('href="https://clearrecipe.net/recipes/pie"'), "path included in href");
});
