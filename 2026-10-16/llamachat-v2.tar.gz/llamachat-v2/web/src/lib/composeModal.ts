// Global compose-modal opener. The sidebar Post button opens the X-style
// new-post modal without prop drilling: App.tsx calls openComposeModal(),
// and ComposeModalHost (mounted once in App) renders the modal.
type Listener = (open: boolean) => void;
const listeners = new Set<Listener>();

let isOpen = false;

/** Open the compose modal. */
export function openComposeModal(): void {
  isOpen = true;
  for (const l of listeners) l(isOpen);
}

/** Close the compose modal. */
export function closeComposeModal(): void {
  isOpen = false;
  for (const l of listeners) l(isOpen);
}

/** Whether the compose modal is currently open. */
export function isComposeOpen(): boolean {
  return isOpen;
}

export function subscribeComposeModal(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

// The profile currently on screen, registered by ProfileView while it is
// mounted. When the compose modal opens over a profile, the composer
// prefills a mention of that person (Dave's call Oct 13 2026: "it should
// say @Jen when I pop up that modal").
let viewedProfileHandle: string | null = null;

export function setViewedProfileHandle(handle: string | null): void {
  viewedProfileHandle = handle;
}

export function getViewedProfileHandle(): string | null {
  return viewedProfileHandle;
}
