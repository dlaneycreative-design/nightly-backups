import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
const B = '222f29f0-4944-5e03-a270-2e759802866e';
const out = await sql`SELECT p.handle AS follows FROM follows f JOIN profiles p ON p.id = f.following_id WHERE f.follower_id = ${B}`;
console.log('blaze FOLLOWS:', out.map(r => '@' + r.follows).join(', '));
const inn = await sql`SELECT p.handle AS follower FROM follows f JOIN profiles p ON p.id = f.follower_id WHERE f.following_id = ${B}`;
console.log('blaze FOLLOWERS:', inn.map(r => '@' + r.follower).join(', '));
const dm = await sql`SELECT cp.conversation_id, p.handle AS other FROM conversation_participants cp LEFT JOIN conversation_participants cp2 ON cp2.conversation_id = cp.conversation_id AND cp2.user_id <> ${B} LEFT JOIN profiles p ON p.id = cp2.user_id WHERE cp.user_id = ${B}`;
console.log('blaze DM conversations:', JSON.stringify(dm));
const liked = await sql`SELECT count(DISTINCT l.tweet_id)::int AS n FROM likes l WHERE l.user_id = ${B}`;
console.log('blaze distinct liked tweets:', liked[0].n);
