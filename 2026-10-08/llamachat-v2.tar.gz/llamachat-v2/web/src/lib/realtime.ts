// Polling-based new-post check (Dave's call: polling is the V2 realtime
// implementation; the API has no WebSocket endpoint). Every 30s the newest
// feed page is compared against the newest tweet we already hold; the
// difference feeds the "N new posts" pill. Tapping the pill prepends the
// new tweets and resets the count. All ordering uses numeric created_at.
import { isValidTs } from "./timestamps.ts";
import type { ApiClient, Tweet } from "./api.ts";
import { upsertTweets } from "./store.ts";

const POLL_MS = 30_000;

export interface Realtime {
  /** Number of unseen new posts (0 = pill hidden). */
  newCount: number;
  /** Force a check right now (e.g. on visibilitychange). */
  checkNow: () => void;
  /** User tapped the pill: take the new tweets, reset count. */
  acknowledge: () => Tweet[];
  /** Subscribe to count changes (returns unsubscribe). */
  subscribe: (listener: () => void) => () => void;
  /** Stop the interval (unmount). */
  stop: () => void;
}

/**
 * Start polling. `getNewest` returns the newest tweet id + created_at the
 * feed currently shows (null until the first page loads).
 */
export function startRealtime(api: ApiClient, getNewest: () => { id: string; created_at: number } | null): Realtime {
  let newCount = 0;
  let pending: Tweet[] = [];
  let stopped = false;
  const listeners = new Set<() => void>();
  const emit = () => {
    for (const l of listeners) l();
  };

  async function check(): Promise<void> {
    if (stopped) return;
    const newest = getNewest();
    if (!newest || !isValidTs(newest.created_at)) return;
    try {
      const { tweets } = await api.feed(null, 20);
      const fresh = upsertTweets(tweets);
      const known = new Set(pending.map((p) => p.id));
      let changed = false;
      for (const t of fresh) {
        // Strictly newer stamp than anything on screen. created_at ties
        // are ignored: UUIDs have no reliable order, and the feed refresh
        // will pick them up anyway.
        if (isValidTs(t.created_at) && t.created_at > newest.created_at && !known.has(t.id)) {
          pending.push(t);
          known.add(t.id);
          changed = true;
        }
      }
      if (changed && !stopped) {
        pending.sort((a, b) => b.created_at - a.created_at);
        newCount = pending.length;
        emit();
      }
    } catch {
      // Poll failure is non-fatal; the next tick retries.
    }
  }

  const timer = setInterval(() => {
    void check();
  }, POLL_MS);
  const onVisible = () => {
    if (document.visibilityState === "visible") void check();
  };
  document.addEventListener("visibilitychange", onVisible);

  return {
    get newCount() {
      return newCount;
    },
    checkNow: () => {
      void check();
    },
    acknowledge: () => {
      const out = pending;
      pending = [];
      newCount = 0;
      emit();
      return out;
    },
    subscribe: (listener: () => void) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    stop: () => {
      stopped = true;
      clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
    },
  };
}
