import { useEffect, useState } from "react";
import { detectGameEmbed, type GameInfo } from "../lib/gameEmbed.ts";
import { extractOpenArcadeSlug, hasCommandEmbed, resolveOpenArcadeEmbed } from "../lib/openArcade.ts";
import { GameEmbed } from "./GameEmbed.tsx";

/**
 * Resolve the ONE game a tweet embeds, if any (Dave's rules, Oct 30
 * + Oct 31 2026): a !Game command embed wins; otherwise a pasted
 * Open Arcade link auto-embeds once its slug resolves against the
 * catalog. Never both. `pending` is true while a pasted link is
 * still resolving, so callers can hold back the tweet's own image
 * until they know whether it becomes the play screen's cover —
 * a game tweet shows ONE big image you can play, never the same
 * picture twice (the attached image stacked over the game box).
 */
export function useTweetGameEmbed(text: string): { game: GameInfo | null; pending: boolean } {
  const commandGame = detectGameEmbed(text);
  const slug = commandGame ? null : extractOpenArcadeSlug(text);
  const [resolved, setResolved] = useState<{ slug: string; game: GameInfo | null } | null>(null);

  useEffect(() => {
    if (!slug) return;
    let live = true;
    resolveOpenArcadeEmbed(text)
      .then((g) => {
        if (live) setResolved({ slug, game: g });
      })
      .catch(() => {
        if (live) setResolved({ slug, game: null });
      });
    return () => {
      live = false;
    };
  }, [text, slug]);

  if (commandGame) return { game: commandGame, pending: false };
  if (!slug) return { game: null, pending: false };
  if (resolved && resolved.slug === slug) return { game: resolved.game, pending: false };
  return { game: null, pending: true };
}

/**
 * Auto-embed for a pasted Open Arcade link (Dave, Oct 30 2026: "just
 * pasting them in. Easy!"). Renders nothing until the slug resolves
 * against the merged Open Arcade catalog, then the same cover + Play
 * box the !Game embeds use. A tweet with a !Game command embed never
 * gets this too — the command wins, one embed per tweet.
 */
export function OpenArcadeEmbed({ text }: { text: string }) {
  const { game } = useTweetGameEmbed(text);
  if (!game || hasCommandEmbed(text)) return null;
  return <GameEmbed game={game} />;
}
