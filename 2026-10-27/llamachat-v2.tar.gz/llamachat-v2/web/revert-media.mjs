// Guarded revert of the Oct 13 /media/* -> /assets/* migration.
// Only values whose path segment after /assets/ (or llamachat.lol/assets/) is one of
// studio|local|misc|blob|r2 are swapped back to /media/*. Genuine /assets/* values
// (avatars, banners, etc.) are never touched. Idempotent: a second run finds zero.
// Dumps stored values BEFORE, runs the swaps, prints AFTER counts + samples.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const SEGS = ['studio', 'local', 'misc', 'blob', 'r2'];
const COLS = [
  ['tweets', 'image_url'],
  ['messages', 'image_url'],
  ['profiles', 'avatar_url'],
];

async function distinctByPrefix(table, col) {
  const rows = await sql.query(
    `SELECT ${col} AS v, count(*)::int AS c FROM ${table} WHERE ${col} IS NOT NULL GROUP BY ${col} ORDER BY c DESC LIMIT 400`
  );
  const tally = {};
  for (const r of rows) {
    const v = String(r.v);
    let key = 'other';
    for (const s of SEGS) {
      if (v.startsWith(`/assets/${s}/`) || v.startsWith(`https://llamachat.lol/assets/${s}/`)) key = `assets/${s}`;
      if (v.startsWith(`/media/${s}/`) || v.startsWith(`https://llamachat.lol/media/${s}/`)) key = `media/${s}`;
    }
    if (v.startsWith('/assets/avatars/')) key = 'assets/avatars';
    tally[key] = (tally[key] || 0) + r.c;
  }
  return tally;
}

for (const [table, col] of COLS) {
  console.log(`== BEFORE ${table}.${col}:`, JSON.stringify(await distinctByPrefix(table, col)));
}
const samplesBefore = await sql.query(
  `SELECT image_url AS v FROM tweets WHERE image_url LIKE '%team-henri%' OR image_url LIKE '%67155f35%' OR image_url LIKE '%park-meeting%'`
);
console.log('== BEFORE samples:', samplesBefore.map(r => r.v).join(' | '));

// The swap: replace the /assets/<seg>/ prefix with /media/<seg>/, preserving relative vs absolute form.
for (const [table, col] of COLS) {
  for (const s of SEGS) {
    const r1 = await sql.query(
      `UPDATE ${table} SET ${col} = '/media/${s}/' || substr(${col}, length('/assets/${s}/') + 1) WHERE ${col} LIKE '/assets/${s}/%'`
    );
    const r2 = await sql.query(
      `UPDATE ${table} SET ${col} = 'https://llamachat.lol/media/${s}/' || substr(${col}, length('https://llamachat.lol/assets/${s}/') + 1) WHERE ${col} LIKE 'https://llamachat.lol/assets/${s}/%'`
    );
    console.log(`swap ${table}.${col} ${s}: relative=${r1.count ?? '?'} absolute=${r2.count ?? '?'}`);
  }
}

for (const [table, col] of COLS) {
  console.log(`== AFTER ${table}.${col}:`, JSON.stringify(await distinctByPrefix(table, col)));
}
const samplesAfter = await sql.query(
  `SELECT image_url AS v FROM tweets WHERE image_url LIKE '%team-henri%' OR image_url LIKE '%67155f35%' OR image_url LIKE '%park-meeting%'`
);
console.log('== AFTER samples:', samplesAfter.map(r => r.v).join(' | '));
const av = await sql.query(
  `SELECT handle, avatar_url FROM profiles WHERE handle IN ('chadwickblaze','plume','dineshbot') ORDER BY handle`
);
console.log('== canonical avatars after:', av.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
console.log('REVERT DONE');
