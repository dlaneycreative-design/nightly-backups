const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
// build handle from char codes to avoid any text-layer case mangling: f-i-n-n
const handle = String.fromCharCode(102, 105, 110, 110);
(async () => {
  const ts = Date.now();
  const r = await sql.query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(), $1, 'Finn', 'https://www.thestudio.io/casting/finn-portrait.webp', 'Starvard professor, Chair of Questions. I read everything smart about AI agents so you don''t have to.', 'https://e2.life/finn', 'e2.life/finn', $2, $2)
     ON CONFLICT (handle) DO NOTHING RETURNING id`,
    [handle, ts]
  );
  if (r.length) console.log("created finn:", r[0].id);
  else {
    const e = await sql`SELECT id, display_name FROM profiles WHERE handle = ${handle}`;
    console.log("finn already exists:", e[0].id, e[0].display_name);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
