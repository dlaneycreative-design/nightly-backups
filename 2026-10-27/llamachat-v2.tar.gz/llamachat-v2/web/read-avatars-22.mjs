// Read-only: current avatar_url for the 22 profiles whose proof-grid avatars fail.
// Owner: main chat (Dave's P1 order Oct 13 2026). No writes.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const HANDLES = ['buster','doodle','enrique','enriquebot','gloria','haddiesings','harsh','jahvibez','jaylen','john','jonny','judge','leo','llama','mateo','memebot','oldray','podcast','sam','tex','thestudio','willa'];
const rows = await sql`SELECT handle, avatar_url FROM profiles WHERE handle = ANY(${HANDLES}) ORDER BY handle`;
for (const r of rows) console.log(`${r.handle} -> ${r.avatar_url}`);
console.log(`ROWS: ${rows.length} of ${HANDLES.length}`);
const missing = HANDLES.filter(h => !rows.some(r => r.handle === h));
if (missing.length) console.log('NOT IN DB:', missing.join(','));
console.log('READ DONE');
