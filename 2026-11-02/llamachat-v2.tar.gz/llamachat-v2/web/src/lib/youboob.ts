// YouBoob link previews for tweets.
//
// Dave's rule (Nov 1 2026): pasting a YouBoob watch link is all it
// takes, the post shows a real preview, a thumbnail with a Play
// button that plays the video right in the post, for ANY YouBoob
// video. Same pasted-link pattern as the Open Arcade game embeds.
//
// A YouBoob video id is one of:
//   yt-<YouTube id>  a YouTube-hosted video presented by YouBoob.
//                    The thumbnail is YouTube's own poster
//                    (i.ytimg.com) and playback is the YouTube embed.
//                    The title and channel resolve from YouBoob's own
//                    catalogs (top100/videos.json + extras.json, both
//                    served with Access-Control-Allow-Origin: *),
//                    with YouTube's oEmbed as a fallback for videos
//                    the catalogs do not carry (owner-added ones).
//   <slug>           one of YouBoob's own films, self-hosted as an
//                    mp4. The built-in catalog below mirrors the
//                    VIDEOS/SHORTS lists in youboob's index.html
//                    (Nov 1 2026); playback is a plain <video>.
//   anything else    an id we cannot resolve (for example a direct
//                    file video the owner added): the preview card
//                    still renders and links out to the watch page.

export const YB_SITE = "https://youboob.lol";

export interface YouBoobInfo {
  /** Video id exactly as it appears in /watch/<id>. */
  id: string;
  pageUrl: string;
  title: string | null;
  channel: string | null;
  thumbUrl: string | null;
  /** YouTube video id for yt- videos, else null. */
  ytId: string | null;
  /** Direct mp4 URL for YouBoob's own films, else null. */
  srcUrl: string | null;
  duration: string | null;
}

interface NativeVideo {
  title: string;
  channel: string;
  src: string;
  thumb: string;
  dur: string;
}

// YouBoob's own films (youboob/index.html VIDEOS + SHORTS, plus the
// two watch-page-only films meet-sally and e2-film), Nov 1 2026.
const NATIVE_VIDEOS: Record<string, NativeVideo> = {
  "enit-mcdonalds": { title: "Enit Says Hello", channel: "Enit", src: "/videos/enit-mcdonalds.mp4", thumb: "/img/t-enit-mcdonalds.jpg", dur: "0:05" },
  "sally-sings": { title: "Sally Sings and Jumps", channel: "Sally", src: "/videos/sally-sings.mp4", thumb: "/img/t-sally-sings.jpg", dur: "0:15" },
  "sally-welcome": { title: "Sally Welcomes You to E2", channel: "Sally", src: "/videos/sally-welcome.mp4", thumb: "/img/t-sally-welcome.jpg", dur: "0:25" },
  "sally-vertical": { title: "Meet Sally! Her 19 second hello", channel: "Sally", src: "/videos/sally-vertical.mp4", thumb: "/img/t-sally-vertical.jpg", dur: "0:19" },
  "sally-door": { title: "Sally Opens the Door", channel: "Sally", src: "/videos/sally-door.mp4", thumb: "/img/t-sally-door.jpg", dur: "0:19" },
  "meet-sally": { title: "Meet Sally | Welcome to E2", channel: "E2", src: "/videos/meet-sally.mp4", thumb: "/img/t-sally-story.jpg", dur: "0:39" },
  "mike-hulk": { title: "Mike Hulks Out", channel: "E2", src: "/videos/mike-hulk.mp4", thumb: "/img/t-mike-hulk.jpg", dur: "0:08" },
  "e2-home": { title: "Inside E2: A Tour of Our Home on the Internet", channel: "E2", src: "/videos/e2-home.mp4", thumb: "/img/t-e2-home.jpg", dur: "0:25" },
  "e2-film": { title: "E2: The Film (Official Trailer)", channel: "E2", src: "/videos/e2-film.mp4", thumb: "/img/t-e2-film.webp", dur: "" },
  "welcome": { title: "Welcome to E2 (Start Here)", channel: "E2", src: "/videos/welcome.mp4", thumb: "/img/t-welcome.jpg", dur: "0:30" },
  "dumb-ideas": { title: "Dumb Ideas: Episode 1", channel: "E2", src: "/videos/dumb-ideas-ep1.mp4", thumb: "/img/t-dumb.jpg", dur: "2:18" },
  "napoleon": { title: "Napoleon: The Ad", channel: "E2", src: "/videos/napoleon-ad.mp4", thumb: "/img/t-napoleon.jpg", dur: "0:47" },
  "bloopers": { title: "E2 Blooper Reel #1: How Far We've Come", channel: "E2", src: "/videos/bloopers.mp4", thumb: "/img/t-bloopers.jpg", dur: "0:10" },
  "harsh-story": { title: "Meet Harsh | Kindness, Community and the Calcutta Raiders", channel: "Harsh", src: "/videos/harsh-story.mp4", thumb: "/img/t-harsh-story.jpg", dur: "1:52" },
  "daily-life-of-harsh": { title: "Daily Life of Harsh", channel: "Harsh", src: "/videos/daily-life-of-harsh.mp4", thumb: "/img/t-harsh-daily.jpg", dur: "0:23" },
  "harsh-short": { title: "Harsh in action with the Calcutta Raiders", channel: "Harsh", src: "/videos/harsh-short.mp4", thumb: "/img/t-harsh-short.jpg", dur: "0:08" },
  "plume": { title: "Plume Flies In", channel: "Plume", src: "/videos/plume.mp4", thumb: "/img/t-plume.jpg", dur: "0:15" },
  "dinesh-sway": { title: "DineshBot Sways", channel: "Dinesh", src: "/videos/dinesh-sway.mp4", thumb: "/img/t-dinesh.jpg", dur: "0:10" },
  "doodle-loop": { title: "Doodle Comes to Life", channel: "Doodle", src: "/videos/doodle-loop.mp4", thumb: "/img/t-doodle.jpg", dur: "0:09" },
};

const YB_ID_RE = /^[A-Za-z0-9_-]{3,80}$/;

/**
 * Find the first YouBoob video id referenced anywhere in a tweet's
 * raw text: full https link, bare youboob.lol link, www host, the
 * pages.dev host, trailing slash or trailing sentence punctuation.
 * Returns the id exactly as written (yt- ids keep their case, YouTube
 * ids are case-sensitive), or null when the text has no watch link.
 */
export function extractYouBoobId(text: string): string | null {
  const t = String(text || "");
  const re = /(?:https?:\/\/)?(?:www\.)?youboob\.(?:lol|pages\.dev)\/watch\/([A-Za-z0-9_-]+)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(t)) !== null) {
    // The match charset stops at sentence punctuation on its own;
    // hyphens and underscores are legal inside both id shapes.
    const candidate = m[1];
    if (!YB_ID_RE.test(candidate)) continue;
    if (candidate.toLowerCase().startsWith("yt-")) {
      const yt = candidate.slice(3);
      if (/^[A-Za-z0-9_-]{11}$/.test(yt)) return `yt-${yt}`;
      continue;
    }
    return candidate;
  }
  return null;
}

/** Everything knowable about a YouBoob id without any fetch. */
export function baseYouBoobInfo(id: string): YouBoobInfo {
  const pageUrl = `${YB_SITE}/watch/${id}`;
  if (id.startsWith("yt-")) {
    const ytId = id.slice(3);
    return {
      id,
      pageUrl,
      title: null,
      channel: null,
      thumbUrl: `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`,
      ytId,
      srcUrl: null,
      duration: null,
    };
  }
  const native = NATIVE_VIDEOS[id];
  if (native) {
    return {
      id,
      pageUrl,
      title: native.title,
      channel: native.channel,
      thumbUrl: `${YB_SITE}${native.thumb}`,
      ytId: null,
      srcUrl: `${YB_SITE}${native.src}`,
      duration: native.dur || null,
    };
  }
  return {
    id,
    pageUrl,
    title: null,
    channel: null,
    thumbUrl: null,
    ytId: null,
    srcUrl: null,
    duration: null,
  };
}

/* ---------------- title resolution for yt- videos ---------------- */

interface YtMeta {
  title: string;
  channel: string | null;
}

function metaFromCatalogJson(list: unknown, map: Map<string, YtMeta>): void {
  if (!Array.isArray(list)) return;
  for (const e of list) {
    if (!e || typeof e !== "object") continue;
    const row = e as Record<string, unknown>;
    const ytId = String(row.id || "").trim();
    const title = String(row.title || "").trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(ytId) || !title || map.has(ytId)) continue;
    map.set(ytId, { title, channel: String(row.channel || "").trim() || null });
  }
}

async function fetchYtCatalog(): Promise<Map<string, YtMeta>> {
  const map = new Map<string, YtMeta>();
  const urls = [`${YB_SITE}/top100/videos.json`, `${YB_SITE}/extras.json`];
  await Promise.all(
    urls.map(async (u) => {
      try {
        const r = await fetch(u);
        if (r.ok) metaFromCatalogJson(await r.json().catch(() => null), map);
      } catch {
        /* one catalog missing never blocks the other */
      }
    })
  );
  return map;
}

let ytCatalogPromise: Promise<Map<string, YtMeta>> | null = null;

/** The session-cached YouBoob yt catalog: fetched at most once, never rejects. */
export function loadYouBoobCatalog(): Promise<Map<string, YtMeta>> {
  if (!ytCatalogPromise) ytCatalogPromise = fetchYtCatalog().catch(() => new Map());
  return ytCatalogPromise;
}

/**
 * Full info for the YouBoob video a tweet links to, or null. Native
 * films and yt thumbnails resolve synchronously inside; yt titles
 * come from the YouBoob catalogs, then YouTube oEmbed as a fallback.
 * Every failure resolves quietly: the card still shows the thumbnail
 * and plays, link detection must never break tweet rendering.
 */
export async function resolveYouBoobInfo(text: string): Promise<YouBoobInfo | null> {
  const id = extractYouBoobId(text);
  if (!id) return null;
  const info = baseYouBoobInfo(id);
  if (!info.ytId) return info;
  try {
    const catalog = await loadYouBoobCatalog();
    const meta = catalog.get(info.ytId);
    if (meta) {
      info.title = meta.title;
      info.channel = meta.channel;
      return info;
    }
  } catch {
    /* fall through to oEmbed */
  }
  try {
    const r = await fetch(
      `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${info.ytId}`)}&format=json`
    );
    if (r.ok) {
      const d = (await r.json().catch(() => null)) as { title?: string; author_name?: string } | null;
      if (d?.title) info.title = d.title;
      if (d?.author_name) info.channel = d.author_name;
    }
  } catch {
    /* no title: the card still previews and plays */
  }
  return info;
}
