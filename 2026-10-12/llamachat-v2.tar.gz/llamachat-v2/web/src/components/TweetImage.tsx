// Lazy tweet image. Twitter-style aspect-ratio handling (Dave's call Oct 9 2026):
// wide, tall, and square images all display at their natural ratio, fitted
// within max bounds, never cropped, never stretched. Tap opens the full
// image in a lightbox. Images only load when near the viewport (native
// lazy) so long feeds stay fast.
import { useState } from "react";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  /** The medium image_url stored on the tweet. */
  imageUrl: string;
  alt?: string;
}

export function TweetImage({ imageUrl, alt = "Tweet image" }: Props) {
  const [lightbox, setLightbox] = useState(false);
  const src = resolveImageUrl(imageUrl) || imageUrl;
  const openLightbox = () => setLightbox(true);
  const closeLightbox = () => setLightbox(false);

  return (
    <>
      <div className="tweet-img-wrap">
        <button
          type="button"
          onClick={openLightbox}
          className="tweet-img-btn"
          aria-label={`Open image: ${alt}`}
          style={{ border: "none", padding: 0, background: "none", cursor: "zoom-in", display: "block", width: "100%" }}
        >
          <img
            src={src}
            alt={alt}
            loading="lazy"
            decoding="async"
            className="tweet-img"
          />
        </button>
      </div>
      {lightbox ? (
        <button
          type="button"
          className="lightbox"
          onClick={closeLightbox}
          aria-label="Close image viewer"
          style={{ border: "none", padding: 0, cursor: "zoom-out" }}
        >
          <img src={src} alt={alt} className="lightbox-img" />
        </button>
      ) : null}
    </>
  );
}
