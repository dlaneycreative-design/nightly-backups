// Page-load timing for the "this page generated in X.X seconds" footer.
// bootTime is captured at module import (app boot). Feed calls
// recordFeedReady() once its initial tweets have painted; SideNav
// subscribes via onFeedReady() and shows the elapsed time.
export const bootTime: number =
  typeof performance !== "undefined" ? performance.now() : 0;

let feedReadyAt: number | null = null;
const listeners = new Set<(ms: number) => void>();

export function recordFeedReady(): void {
  if (feedReadyAt !== null) return;
  feedReadyAt = typeof performance !== "undefined" ? performance.now() : 0;
  const ms = feedReadyAt - bootTime;
  for (const fn of listeners) fn(ms);
}

export function onFeedReady(fn: (ms: number) => void): () => void {
  if (feedReadyAt !== null) fn(feedReadyAt - bootTime);
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
