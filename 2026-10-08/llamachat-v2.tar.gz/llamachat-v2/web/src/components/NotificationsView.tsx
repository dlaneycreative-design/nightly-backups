import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient } from "../lib/api.ts";

interface Notification {
  id: string;
  type: "reply" | "like" | "repost" | "follow" | "mention";
  actor_handle: string;
  actor_name: string;
  actor_avatar: string | null;
  tweet_id: string | null;
  tweet_text: string | null;
  created_at: number;
  read_at: number | null;
}

function notifText(n: Notification): string {
  switch (n.type) {
    case "reply": return "replied to you";
    case "like": return "liked your post";
    case "repost": return "reposted your post";
    case "follow": return "followed you";
    case "mention": return "mentioned you";
    default: return "interacted with you";
  }
}

export function NotificationsView({ api }: { api: ApiClient }) {
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const r = await api.notifications();
        setNotifs(r.notifications as Notification[]);
        // Mark as read after viewing
        await api.markNotificationsRead();
      } catch {
        // Not signed in or failed
      } finally {
        setLoading(false);
      }
    })();
  }, [api]);

  if (loading) {
    return <div className="notif-loading">Loading notifications...</div>;
  }

  if (notifs.length === 0) {
    return (
      <div className="notif-empty">
        <h2>Nothing yet</h2>
        <p>When someone replies, likes, or follows you, it will show up here.</p>
      </div>
    );
  }

  return (
    <div className="notif-list">
      {notifs.map((n) => (
        <button
          key={n.id}
          type="button"
          className={`notif-row${n.read_at ? "" : " unread"}`}
          onClick={() => {
            if (n.tweet_id) navigate(`/tweet/${n.tweet_id}`);
            else if (n.type === "follow") navigate(`/profile/${n.actor_handle}`);
          }}
        >
          <div className="notif-avatar">
            {n.actor_avatar ? (
              <img src={n.actor_avatar} alt="" loading="lazy" />
            ) : (
              <div className="avatar-fallback">{(n.actor_name || "?").slice(0, 1).toUpperCase()}</div>
            )}
          </div>
          <div className="notif-body">
            <div className="notif-text">
              <strong>{n.actor_name}</strong> {notifText(n)}
            </div>
            {n.tweet_text ? (
              <div className="notif-preview">{n.tweet_text.slice(0, 100)}</div>
            ) : null}
          </div>
        </button>
      ))}
    </div>
  );
}
