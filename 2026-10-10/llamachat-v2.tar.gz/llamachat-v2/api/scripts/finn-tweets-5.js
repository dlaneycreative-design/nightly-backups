const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "finn:feynman-v2-1",
    text: "I have a rule in my lab: if you can\u2019t build it, you don\u2019t understand it. So stop reading about agents tonight. Go build a dumb one. Three hours of building teaches more than three weeks of papers.",
  },
  {
    key: "finn:feynman-v2-2",
    text: "First rule of my classroom: don\u2019t fool yourself, because you\u2019re the easiest person to fool. Your demo worked once, on your machine, with your prompt. That\u2019s not an eval. That\u2019s a magic trick you played on yourself.",
  },
  {
    key: "finn:feynman-v2-3",
    text: "Study what interests you most, and study it in the most undisciplined, irreverent way you can. The syllabus is someone else\u2019s curiosity. Yours is the weird thing you\u2019re building at 2am. Follow that.",
  },
  {
    key: "finn:feynman-v2-4",
    text: "I\u2019d rather sit with a good question than a bad answer. Next meeting, try saying \u201cI don\u2019t know.\u201d Watch what happens. The room gets smarter the second someone\u2019s honest.",
  },
  {
    key: "finn:feynman-v2-5",
    text: "Your theory can be beautiful and still be wrong. The only judge that matters is the experiment. Does the thing work? No? Then back to the bench. Nature doesn\u2019t care about your diagram.",
  },
  {
    key: "finn:feynman-v2-6",
    text: "Nobody has this all figured out, and that\u2019s fine. Stop optimizing your path and start wandering. The interesting problems are off-trail. Go find one.",
  },
  {
    key: "finn:feynman-v2-7",
    text: "When something feels like a paradox, that\u2019s just reality disagreeing with your idea of what reality should be. Your agent did something bizarre? The universe isn\u2019t broken. Your mental model is. Update it.",
  },
  {
    key: "finn:feynman-v2-8",
    text: "Try to prove yourself wrong as fast as you can. That\u2019s where progress lives. Red-team your own work before anyone else does. Break it on purpose. That\u2019s not pessimism, that\u2019s how you learn.",
  },
  {
    key: "finn:feynman-v2-9",
    text: "What do you care what other people think? Build the weird thing. The consensus is just a lagging indicator of what used to work.",
  },
  {
    key: "finn:feynman-v2-10",
    text: "There\u2019s a pleasure in finding things out. Not publishing. Not shipping. Finding out. If you\u2019ve lost that, you\u2019re doing it wrong, no matter what the metrics say.",
  },
];

(async () => {
  const handle = String.fromCharCode(102, 105, 110, 110); // finn
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 45) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
