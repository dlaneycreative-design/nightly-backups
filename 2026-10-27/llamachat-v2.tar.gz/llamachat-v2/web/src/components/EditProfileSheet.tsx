// Edit profile sheet, modeled on X's (Dave's reference screenshots,
// Oct 19 2026): header row (X close, "Edit profile", black Save pill),
// banner photo full width with circular dark overlay buttons (change
// photo / remove), avatar circle overlapping the banner's bottom-left
// with a centered camera badge, then floating-label fields.
// Picking a photo detours through the Edit media adjust step
// (drag + zoom + Apply) before anything is baked; the defaults are a
// sane center crop, so the easy path is pick, Apply, Save.
import { useEffect, useState } from "react";
import type { ApiClient, Profile } from "../lib/api.ts";
import { loadAvatarImage, resolveImageUrl, uploadImage, type LoadedAvatarImage } from "../lib/images.ts";
import { getCallerId } from "../lib/session.ts";
import { showToast } from "../lib/toast.ts";
import { EditMedia } from "./EditMedia.tsx";

interface Props {
  api: ApiClient;
  apiBase: string;
  profile: Profile;
  onClose: () => void;
  onSaved: (p: Profile) => void;
}

const DEFAULT_BANNER = "/assets/banners/llama-header-nightsky.avif";

function CameraPlusIcon({ size = 22 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" transform="scale(0.92) translate(1 1)" />
      <circle cx="12" cy="13" r="3.5" />
      <path d="M19 2v4M17 4h4" strokeWidth="2.2" />
    </svg>
  );
}

type AdjustTarget = { kind: "avatar" | "banner"; loaded: LoadedAvatarImage };

export function EditProfileSheet({ api, apiBase, profile, onClose, onSaved }: Props) {
  const [displayName, setDisplayName] = useState(profile.display_name);
  const [bio, setBio] = useState(profile.bio ?? "");
  const [link, setLink] = useState(profile.link_url ?? "");
  const [instagram, setInstagram] = useState(profile.instagram ?? "");

  const [pendingAvatar, setPendingAvatar] = useState<File | null>(null);
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState<string | null>(null);
  const [pendingBanner, setPendingBanner] = useState<File | null>(null);
  const [bannerPreviewUrl, setBannerPreviewUrl] = useState<string | null>(null);
  const [bannerCleared, setBannerCleared] = useState(false);

  const [adjust, setAdjust] = useState<AdjustTarget | null>(null);
  const [photoNote, setPhotoNote] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [savedMsg, setSavedMsg] = useState("");

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (adjust) {
          URL.revokeObjectURL(adjust.loaded.url);
          setAdjust(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose, adjust]);

  // Revoke preview object URLs when the sheet goes away.
  useEffect(() => {
    return () => {
      if (avatarPreviewUrl) URL.revokeObjectURL(avatarPreviewUrl);
      if (bannerPreviewUrl) URL.revokeObjectURL(bannerPreviewUrl);
    };
  }, [avatarPreviewUrl, bannerPreviewUrl]);

  const pickPhoto = async (kind: "avatar" | "banner", files: FileList | null) => {
    const f = files?.[0];
    if (!f) return;
    setError("");
    setPhotoNote("");
    try {
      const loaded = await loadAvatarImage(f);
      setAdjust({ kind, loaded });
    } catch (err) {
      setError(err instanceof Error ? err.message : "That photo could not be read. Please try a different one.");
    }
  };

  const onAdjusted = (file: File) => {
    if (!adjust) return;
    URL.revokeObjectURL(adjust.loaded.url);
    if (adjust.kind === "avatar") {
      setPendingAvatar(file);
      setAvatarPreviewUrl(URL.createObjectURL(file));
      setPhotoNote("New photo framed and ready. Tap Save to use it.");
    } else {
      setPendingBanner(file);
      setBannerPreviewUrl(URL.createObjectURL(file));
      setBannerCleared(false);
      setPhotoNote("New banner framed and ready. Tap Save to use it.");
    }
    setAdjust(null);
  };

  const cancelAdjust = () => {
    if (adjust) URL.revokeObjectURL(adjust.loaded.url);
    setAdjust(null);
  };

  const removeBanner = () => {
    setPendingBanner(null);
    if (bannerPreviewUrl) URL.revokeObjectURL(bannerPreviewUrl);
    setBannerPreviewUrl(null);
    setBannerCleared(true);
    setPhotoNote("Banner will go back to the default when you save.");
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const caller = getCallerId();
      if (!caller) throw new Error("You are signed out. Please log in again.");
      // Normalize the link the way the profile shows it: bare domains
      // get https, http upgrades to https, and the display label is
      // derived from the URL itself. The label used to be a separate
      // stored field nothing updated, so changing the URL left the old
      // label ("e2.life/dave") on the profile and the edit looked lost.
      let linkUrl: string | null = null;
      let linkLabel: string | null = null;
      const rawLink = link.trim();
      if (rawLink) {
        const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(rawLink) ? rawLink : `https://${rawLink}`;
        let u: URL;
        try {
          u = new URL(withScheme);
        } catch {
          throw new Error("That link doesn't look like a valid web address.");
        }
        if (u.protocol !== "http:" && u.protocol !== "https:") {
          throw new Error("Links must be http or https web addresses.");
        }
        u.protocol = "https:";
        linkUrl = u.toString();
        const path = u.pathname === "/" ? "" : u.pathname.replace(/\/+$/, "");
        linkLabel = u.host + path + u.search;
      }
      const patch: Parameters<ApiClient["updateProfile"]>[1] = {
        display_name: displayName.trim() || profile.display_name,
        bio: bio.trim() ? bio.trim() : null,
        link_url: linkUrl,
        link_label: linkLabel,
        instagram: instagram.trim().replace(/^@/, "") || null,
      };
      let photoChanged = false;
      if (pendingAvatar) {
        patch.avatar_url = await uploadImage(apiBase, caller, pendingAvatar, "avatar");
        photoChanged = true;
      }
      if (pendingBanner) {
        // The uploads route files profile imagery under kind "avatar".
        patch.banner_url = await uploadImage(apiBase, caller, pendingBanner, "avatar");
        photoChanged = true;
      } else if (bannerCleared) {
        patch.banner_url = null;
        photoChanged = true;
      }
      const { profile: updated } = await api.updateProfile(profile.handle, patch);
      onSaved(updated);
      const msg = photoChanged ? "Photo updated" : "Profile saved";
      setSavedMsg(msg);
      showToast(msg);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong saving. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const avatarSrc = avatarPreviewUrl || resolveImageUrl(profile.avatar_url);
  const bannerSrc = bannerPreviewUrl || (bannerCleared ? DEFAULT_BANNER : resolveImageUrl(profile.banner_url) || DEFAULT_BANNER);
  const hasCustomBanner = Boolean(pendingBanner || (!bannerCleared && profile.banner_url));
  const initial = (profile.display_name || "?").slice(0, 1).toUpperCase();

  return (
    <div className="rm-backdrop" role="presentation" onClick={(e) => { if (e.target === e.currentTarget && !adjust) onClose(); }}>
      <div className="rm-modal ep-modal" role="dialog" aria-label={adjust ? "Edit media" : "Edit profile"} aria-modal="true">
        {savedMsg ? (
          <div style={{ textAlign: "center", padding: "40px 28px 32px" }}>
            <div style={{ fontSize: 40, marginBottom: 8 }} aria-hidden="true">✓</div>
            <h2 style={{ fontSize: 24, margin: "0 0 8px" }}>{savedMsg}</h2>
            <p style={{ color: "#536471", margin: "0 0 24px", fontSize: 15 }}>
              Your profile now shows the new {savedMsg === "Photo updated" ? "photo" : "details"}.
            </p>
            <button
              type="button"
              onClick={onClose}
              style={{ width: "100%", padding: "12px", fontSize: 16, fontWeight: 700, background: "#1d9bf0", color: "#fff", border: "none", borderRadius: 9999, cursor: "pointer" }}
            >
              Done
            </button>
          </div>
        ) : adjust ? (
          <EditMedia loaded={adjust.loaded} shape={adjust.kind} onApply={onAdjusted} onBack={cancelAdjust} />
        ) : (
          <form onSubmit={save}>
            <div className="ep-head">
              <button type="button" className="ep-close" onClick={onClose} aria-label="Close">
                ✕
              </button>
              <div className="ep-title">Edit profile</div>
              <button type="submit" className="followbtn" disabled={busy}>
                {busy ? "Saving..." : "Save"}
              </button>
            </div>

            <div className="ep-banner" style={{ backgroundImage: `url(${bannerSrc})` }}>
              <div className="ep-banner-btns">
                <label className="ep-round-btn" aria-label="Change banner photo">
                  <input
                    type="file"
                    accept="image/*"
                    className="ep-file-input"
                    aria-label="Change banner photo"
                    onChange={(e) => {
                      void pickPhoto("banner", e.target.files);
                      e.target.value = "";
                    }}
                  />
                  <CameraPlusIcon />
                </label>
                {hasCustomBanner ? (
                  <button type="button" className="ep-round-btn" onClick={removeBanner} aria-label="Remove banner photo">
                    ✕
                  </button>
                ) : null}
              </div>
            </div>

            <div className="ep-avatar-row">
              <label className="ep-avatar" aria-label="Change profile photo">
                <input
                  id="ep-avatar-file"
                  type="file"
                  accept="image/*"
                  className="ep-file-input"
                  aria-label="Change profile photo"
                  onChange={(e) => {
                    void pickPhoto("avatar", e.target.files);
                    e.target.value = "";
                  }}
                />
                {avatarSrc ? (
                  <img src={avatarSrc} alt="Your profile photo" />
                ) : (
                  <span className="ep-avatar-fallback" aria-hidden="true">{initial}</span>
                )}
                <span className="ep-avatar-badge" aria-hidden="true">
                  <CameraPlusIcon size={20} />
                </span>
              </label>
              <label className="ep-change-text" htmlFor="ep-avatar-file">
                Change photo
              </label>
            </div>
            <p className="ep-help">
              Tap the photo to change it. Any photo works: big, small, wide or tall. You frame it, we resize it.
            </p>
            {photoNote ? <p className="ep-note">{photoNote}</p> : null}

            <div className="ep-fields">
              <div className="ep-field">
                <label htmlFor="ep-name">Name</label>
                <input
                  id="ep-name"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your name"
                />
              </div>
              <div className="ep-field">
                <label htmlFor="ep-bio">Bio</label>
                <textarea
                  id="ep-bio"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell people about yourself"
                  rows={3}
                />
              </div>
              <div className="ep-field">
                <label htmlFor="ep-link">Link</label>
                <input
                  id="ep-link"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="https://yoursite.com"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                />
              </div>
              <div className="ep-field">
                <label htmlFor="ep-ig">Instagram</label>
                <input
                  id="ep-ig"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  placeholder="@yourhandle"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                />
              </div>
              {error ? (
                <p style={{ color: "#f4212e", fontSize: 14, margin: "4px 0 0" }} role="alert">
                  {error}
                </p>
              ) : null}
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
