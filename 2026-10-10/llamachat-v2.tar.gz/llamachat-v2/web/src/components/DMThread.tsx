import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Conversation, Message } from "../lib/api.ts";
import { newestFirst } from "../lib/timestamps.ts";
import { getCallerId } from "../lib/session.ts";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  api: ApiClient;
  conversationId: string;
  conversation?: Conversation | null;
}

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

/**
 * Conversation view. Messages sorted by numeric created_at (oldest at
 * the bottom). Optimistic bubbles show "sending...", never a fake time.
 */
export function DMThread({ api, conversationId, conversation = null }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [failedIds, setFailedIds] = useState<Set<string>>(new Set());
  const [retryKey, setRetryKey] = useState(0);
  const me = getCallerId();
  const bottomRef = useRef<HTMLDivElement>(null);
  // Staleness token: ignores async responses from a previous conversation
  // after the user has switched. (Fix Oct 9 2026: rapid convo switches
  // could mix messages from the old thread into the new one.)
  const loadToken = useRef(0);

  // Expose retry to the ErrorBoundary's "Try again" button via a custom event.
  // (Dave's call Oct 9 2026: DMs sometimes show "Something hiccuped" with no recovery.)
  useEffect(() => {
    const onRetry = () => setRetryKey((k) => k + 1);
    window.addEventListener("dm-retry", onRetry);
    return () => window.removeEventListener("dm-retry", onRetry);
  }, []);

  const merge = useCallback((incoming: Message[]) => {
    setMessages((prev) => {
      const byId = new Map(prev.map((m) => [m.id, m]));
      // Guard against malformed API responses (null entries, missing ids)
      // which would otherwise throw during render and trip the ErrorBoundary.
      for (const m of incoming) {
        if (m && typeof m.id === "string" && m.id) byId.set(m.id, m);
      }
      // Numeric sort, oldest first for chat layout.
      return [...byId.values()].sort((a, b) => newestFirst(b, a));
    });
  }, []);

  const load = useCallback(async (silent = false) => {
    const token = ++loadToken.current;
    if (!silent) {
      setError(null);
      setLoading(true);
    }
    try {
      const { messages: list } = await api.messages(conversationId, null, 50);
      // Drop stale responses: user switched conversations mid-flight.
      if (token !== loadToken.current) return;
      merge(list);
    } catch (e) {
      if (token !== loadToken.current) return;
      if (!silent) setError(e instanceof Error ? e.message : "Could not load messages.");
    } finally {
      if (token === loadToken.current && !silent) setLoading(false);
    }
  }, [api, conversationId, merge]);

  useEffect(() => {
    setMessages([]);
    setFailedIds(new Set());
    void load(false);
  }, [load, retryKey]);

  // Lightweight poll while the thread is open (no WebSocket endpoint).
  // Silent: never flashes skeletons over the message list.
  // (Fix Oct 9 2026: poll used to set loading=true every 15s, making
  // the whole thread blink — looked like flakiness.)
  useEffect(() => {
    const t = setInterval(() => {
      void load(true);
    }, 15000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  const send = useCallback(async (retryId?: string) => {
    const body = retryId
      ? messages.find((m) => m.id === retryId)?.text ?? ""
      : text.trim();
    if (!body || sending) return;
    setSending(true);
    // On retry, clear the failed flag first; on fresh send, mint an id.
    const id = retryId ?? newId();
    if (retryId) {
      setFailedIds((prev) => {
        const next = new Set(prev);
        next.delete(retryId);
        return next;
      });
    }
    const optimistic: Message = {
      id,
      conversation_id: conversationId,
      sender_id: me || "",
      text: body,
      created_at: NaN, // invalid on purpose: renders as "sending...", never a fake time
      handle: "",
      display_name: "",
      avatar_url: null,
    };
    merge([optimistic]);
    if (!retryId) setText("");
    try {
      const { message } = await api.postMessage(conversationId, { id, text: body });
      merge([message]);
    } catch {
      // Mark failed so the bubble shows a retry tap instead of
      // hanging on "sending..." forever. (Fix Oct 9 2026.)
      setFailedIds((prev) => new Set(prev).add(id));
    } finally {
      setSending(false);
    }
  }, [text, sending, api, conversationId, me, merge, messages]);

  if (loading) {
    return (
      <div className="dm-messages" aria-label="Loading messages">
        {[0, 1, 2].map((i) => (
          <div className="skel skel-line" key={i} />
        ))}
      </div>
    );
  }

  return (
    <div className="dm-thread">
      {conversation && (conversation.others?.length ?? 0) > 0 ? (
        <div className="dm-thread-header">
          <button
            type="button"
            className="dm-back-btn"
            aria-label="Back to messages"
            onClick={() => window.history.back()}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          {(() => {
            const other = conversation.others[0];
            const avatar = resolveImageUrl(other.avatar_url);
            return (
              <>
                {avatar ? (
                  <img src={avatar} alt="" className="dm-thread-avatar" />
                ) : (
                  <div className="avatar-fallback" aria-hidden="true">
                    {(other.display_name || "?").slice(0, 1).toUpperCase()}
                  </div>
                )}
                <div className="dm-thread-info">
                  <div className="dm-thread-name">{other.display_name}</div>
                  <div className="dm-thread-handle">@{other.handle}</div>
                </div>
              </>
            );
          })()}
        </div>
      ) : null}
      {error ? (
        <div className="errorbox" role="alert">
          <p>{error}</p>
          <button type="button" className="ghost" onClick={() => void load(false)}>
            Try again
          </button>
        </div>
      ) : null}
      <div className="dm-messages">
        {messages.length === 0 ? (
          <div className="empty">
            <h2>No messages yet</h2>
            <p>Say hi to start the conversation.</p>
          </div>
        ) : (
          messages.filter((m) => m && m.id).map((m) => {
            const mine = m.sender_id === me;
            const failed = failedIds.has(m.id);
            return (
              <div key={m.id} className={`dm-bubble${mine ? " me" : " them"}`}>
                <div>{m.text ?? ""}</div>
                {failed ? (
                  <button
                    type="button"
                    className="dm-retry"
                    onClick={() => void send(m.id)}
                  >
                    Tap to retry
                  </button>
                ) : null}
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>
      <div className="dm-inputbar">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write a message"
          aria-label="Write a message"
          maxLength={2000}
          onKeyDown={(e) => {
            if (e.key === "Enter") void send();
          }}
        />
        <button type="button" onClick={() => void send()} disabled={!text.trim() || sending} aria-label="Send message">
          {sending ? "..." : "Send"}
        </button>
      </div>
    </div>
  );
}
