const {neon} = require("@neondatabase/serverless");
const fs = require("fs");
let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local","utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);
// Dave's call, Oct 12 2026: the original Enrique account becomes Enrique Bot (@enriquebot),
// and a fresh @enrique is set up as the behind-the-scenes guy at Clear, day 1.
const OLD_ID = "21ca8f94-5b3b-5765-bbeb-3e12c0f6f98a";
(async () => {
  const ts = Date.now();
  // 1. Move the existing account to @enriquebot, keeping posts, follows, avatar, bio, link.
  const moved = await sql.query(
    `UPDATE profiles SET handle = 'enriquebot', display_name = 'Enrique Bot', updated_at = $2
     WHERE id = $1 AND handle = 'enrique' RETURNING id, handle, display_name`,
    [OLD_ID, ts]
  );
  if (moved.length) console.log("moved to enriquebot:", moved[0].id);
  else {
    const cur = await sql`SELECT handle, display_name FROM profiles WHERE id = ${OLD_ID}`;
    console.log("no move needed, current state:", JSON.stringify(cur[0]));
  }
  // 2. Set up the fresh @enrique.
  const bio = "VP of vibes. Behind the scenes at Clear. Day 1.";
  const r = await sql.query(
    `INSERT INTO profiles (id, handle, display_name, avatar_url, bio, link_url, link_label, created_at, updated_at)
     VALUES (gen_random_uuid(), 'enrique', 'Enrique', '/assets/avatars/enrique-day1.webp', $1, 'https://e2.life/enrique', 'e2.life/enrique', $2, $2)
     ON CONFLICT (handle) DO NOTHING RETURNING id`,
    [bio, ts]
  );
  if (r.length) console.log("created enrique:", r[0].id);
  else {
    const e = await sql`SELECT id, display_name FROM profiles WHERE handle = 'enrique'`;
    console.log("enrique already exists:", e[0].id, e[0].display_name);
  }
  // 3. Show both rows.
  const both = await sql`SELECT id, handle, display_name, avatar_url, bio, link_url, followers_count, following_count, posts_count FROM profiles WHERE handle IN ('enrique', 'enriquebot') ORDER BY handle`;
  for (const row of both) console.log("ROW:", JSON.stringify(row));
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
