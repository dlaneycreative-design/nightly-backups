import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
const DAVE = '8d754e46-a2af-4318-a3d8-9b47e5473abb';
const OLDRAY = '4c08bb11-2e07-59d7-a30e-ed42d3e2bc55';
const TESTCONV = '9e035f01-adaf-4ec7-b267-d69381e9ec0b';
const ids = [DAVE, OLDRAY];
const lit = `{${ids.join(',')}}`;

// BEFORE: the route's (fixed) find query for {dave, oldray}
const before = await sql`SELECT c.id FROM conversations c WHERE NOT EXISTS (SELECT 1 FROM conversation_participants cp WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY(${lit}::uuid[]))) AND (SELECT count(*) FROM conversation_participants cp2 WHERE cp2.conversation_id = c.id) = 2 LIMIT 1`;
console.log('BEFORE find {dave,oldray}:', JSON.stringify(before));

// CREATE exactly as the route does (INSERT conversation; INSERT participants ON CONFLICT DO NOTHING)
let convId;
if (!before[0]) {
  const ts = Date.now();
  const created = await sql`INSERT INTO conversations (created_at, updated_at) VALUES (${ts}, ${ts}) RETURNING *`;
  convId = created[0].id;
  for (const id of ids) {
    await sql`INSERT INTO conversation_participants (conversation_id, user_id) VALUES (${convId}, ${id}) ON CONFLICT DO NOTHING`;
  }
  console.log('CREATED conversation:', convId);
} else { convId = before[0].id; console.log('ALREADY EXISTED:', convId); }

// AFTER: find query must now return it (this is Dave's next click -> deduped:true -> navigate)
const after = await sql`SELECT c.id FROM conversations c WHERE NOT EXISTS (SELECT 1 FROM conversation_participants cp WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY(${lit}::uuid[]))) AND (SELECT count(*) FROM conversation_participants cp2 WHERE cp2.conversation_id = c.id) = 2 LIMIT 1`;
console.log('AFTER find {dave,oldray}:', JSON.stringify(after));

// AFTER: roster well-formed?
const roster = await sql`SELECT cp.user_id, p.handle FROM conversation_participants cp JOIN profiles p ON p.id = cp.user_id WHERE cp.conversation_id = ${convId} ORDER BY p.handle`;
console.log('ROSTER:', JSON.stringify(roster));

// AFTER: route's conversation-list SQL as dave (others, last_text, unread)
const list = await sql`
  SELECT c.id, (SELECT json_agg(json_build_object('id', p.id, 'handle', p.handle, 'display_name', p.display_name, 'avatar_url', p.avatar_url)) FROM conversation_participants cp2 JOIN profiles p ON p.id = cp2.user_id WHERE cp2.conversation_id = c.id AND cp2.user_id <> ${DAVE}) AS others,
  (SELECT m.text FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_text,
  (cp.last_read_at IS NULL OR c.updated_at > cp.last_read_at) AS unread
  FROM conversations c JOIN conversation_participants cp ON cp.conversation_id = c.id
  WHERE cp.user_id = ${DAVE} AND c.id = ${convId}`;
console.log('DAVE LIST ENTRY:', JSON.stringify(list[0]));

// CLEANUP: delete the muse<->oldray HTTP test conversation (participants cascade; 0 messages)
const del = await sql`DELETE FROM conversations WHERE id = ${TESTCONV} RETURNING id`;
console.log('TEST CONV DELETED:', JSON.stringify(del));
const leftovers = await sql`SELECT count(*)::int AS n FROM conversation_participants WHERE conversation_id = ${TESTCONV}`;
console.log('TEST CONV PARTICIPANT LEFTOVERS:', JSON.stringify(leftovers[0]));
console.log('DAVE_OLDRAY_CONV_ID:', convId);
