import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import { getTweet, upsertTweet, upsertTweets, removeTweet } from "../lib/store.ts";
import { Tweet } from "./Tweet.tsx";

type Tab = "posts" | "replies" | "media" | "likes";

const TABS: { id: Tab; label: string }[] = [
  { id: "posts", label: "Posts" },
  { id: "replies", label: "Replies" },
  { id: "media", label: "Media" },
  { id: "likes", label: "Likes" },
];

interface Props {
  api: ApiClient;
  handle: string;
}

/** A reply with its parent tweet rendered above it, X-style. */
function ReplyCard({ tweet, api, onDeleted }: { tweet: TweetT; api: ApiClient; onDeleted?: (id: string) => void }) {
  const navigate = useNavigate();
  const [parent, setParent] = useState<TweetT | null>(() =>
    tweet.reply_to_id ? getTweet(tweet.reply_to_id) ?? null : null
  );

  useEffect(() => {
    if (!tweet.reply_to_id || parent) return;
    let alive = true;
    // getTweet(replyId) returns { tweet, parent, replies }.
    api
      .getTweet(tweet.id)
      .then(({ parent: p }) => {
        if (alive && p) {
          upsertTweet(p);
          setParent(p);
        }
      })
      .catch(() => {
        // Parent deleted or unreachable: render the reply standalone.
      });
    return () => {
      alive = false;
    };
  }, [api, tweet.id, tweet.reply_to_id, parent]);

  const onParentDeleted = useCallback(
    (id: string) => {
      setParent((p) => (p && p.id === id ? null : p));
      onDeleted?.(id);
    },
    [onDeleted]
  );

  return (
    <div>
      {parent ? (
        <>
          <div className="thread-parent-label">
            <a
              href={`/tweet/${parent.id}`}
              onClick={(e) => {
                e.preventDefault();
                navigate(`/tweet/${parent.id}`);
              }}
            >
              Replying to @{parent.author.handle}
            </a>
          </div>
          <div className="thread-connected">
            <Tweet tweet={parent} api={api} onDeleted={onParentDeleted} />
          </div>
        </>
      ) : null}
      <Tweet tweet={tweet} api={api} onDeleted={onDeleted} />
    </div>
  );
}

/** Posts / Replies / Media / Likes tabs with infinite scroll. */
export function ProfileTabs({ api, handle }: Props) {
  const [tab, setTab] = useState<Tab>("posts");
  const [tweets, setTweets] = useState<TweetT[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const loadingRef = useRef(false);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const reqSeq = useRef(0);

  const loadPage = useCallback(
    async (reset: boolean, activeTab: Tab, cur: string | null) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      const seq = ++reqSeq.current;
      if (reset) setLoading(true);
      else setLoadingMore(true);
      try {
        const res = await api.profileTweets(handle, activeTab, cur, 20);
        // Drop stale responses: the user may have switched tabs while this
        // request was in flight.
        if (seq !== reqSeq.current) return;
        upsertTweets(res.tweets);
        setTweets((prev) => {
          const merged = reset ? res.tweets : [...prev, ...res.tweets];
          const seen = new Set<string>();
          return merged.filter((t) => (seen.has(t.id) ? false : (seen.add(t.id), true)));
        });
        setCursor(res.next_cursor);
        setHasMore(res.next_cursor !== null);
      } catch {
        // Keep what we have; the sentinel retry covers it.
      } finally {
        loadingRef.current = false;
        setLoading(false);
        setLoadingMore(false);
      }
    },
    [api, handle]
  );

  useEffect(() => {
    setTweets([]);
    setCursor(null);
    setHasMore(true);
    void loadPage(true, tab, null);
  }, [tab, handle, loadPage]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting) && hasMore && !loadingRef.current) {
          void loadPage(false, tab, cursor);
        }
      },
      { rootMargin: "1200px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [loadPage, tab, cursor, hasMore]);

  const onDeleted = useCallback((id: string) => {
    removeTweet(id);
    setTweets((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <div>
      <div className="pf-tabs" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            className={`pf-tab${tab === t.id ? " on" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      {loading ? (
        <div aria-label="Loading posts">
          {[0, 1, 2].map((i) => (
            <div className="skel-tweet" key={i}>
              <div className="skel skel-avatar" />
              <div className="skel-lines">
                <div className="skel skel-line short" />
                <div className="skel skel-line" />
              </div>
            </div>
          ))}
        </div>
      ) : tweets.length === 0 ? (
        <div className="empty">
          <p>Nothing here yet.</p>
        </div>
      ) : (
        tab === "replies"
          ? tweets.map((t) => <ReplyCard key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
          : tweets.map((t) => <Tweet key={t.id} tweet={t} api={api} onDeleted={onDeleted} />)
      )}
      <div ref={sentinelRef} className="feed-sentinel" aria-hidden="true">
        {loadingMore ? "Loading more..." : ""}
      </div>
    </div>
  );
}
