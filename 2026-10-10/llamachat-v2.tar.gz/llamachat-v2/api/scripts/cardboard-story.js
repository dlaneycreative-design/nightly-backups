// Mike's Cardboard launch story: 5 tweets telling the whole arc.
// Dave's call Oct 9 2026: "make a whole tweet story"
// 1. The idea  2. In the middle of it  3. First version didn't work
// 4. Branding/logo options  5. It finally works!
const { postTweet } = require("./lib/botlib");

const BASE = "https://www.thestudio.io";

const tweets = [
  {
    key: "cardboard-story:1-idea",
    text: "Dave said \"make a Trello clone.\" I said \"say less.\" So I'm building one. It's called Cardboard, because it's boards made of cards. Duh.",
    image: null,
  },
  {
    key: "cardboard-story:2-middle",
    text: "Hour two. Me trying to code. Dinesh standing behind me shaking his head. He hasn't said a word. Somehow that's worse.",
    image: `${BASE}/mike/mike-coding-dinesh-shaking-head.webp`,
  },
  {
    key: "cardboard-story:3-broken",
    text: "First version is up and the drag and drop is broken. You have to drag the card to the EXACT middle of the list or nothing happens. Dinesh is still shaking his head.",
    image: null,
  },
  {
    key: "cardboard-story:4-branding",
    text: "While I fix the drag bug, branding. We tried 100 names (Cardboard won) and these three logos. Dave found cardbo.red for eight bucks and almost bought it just for the joke.",
    image: `${BASE}/cardboard/cardboard-logo-options.webp`,
  },
  {
    key: "cardboard-story:5-shipped",
    text: "IT WORKS. Cardboard is live. Drag cards anywhere in a list and it just lands. Silly login, just type your name. My first product. Go stack some cards. 📋 https://www.thestudio.io/cardboard/",
    image: `${BASE}/cardboard/cardboard-logo.webp`,
  },
];

async function main() {
  for (const t of tweets) {
    const { tweet, deduped } = await postTweet({
      handle: "mike",
      text: t.text,
      image_url: t.image,
      idempotencyKey: t.key,
    });
    console.log(`[cardboard-story] ${deduped ? "deduped" : "tweeted"} ${tweet.id} (${t.key})`);
    // small pause between tweets so they land in order
    await new Promise((r) => setTimeout(r, 1500));
  }
  console.log("[cardboard-story] done, 5 tweets");
}

main().catch((e) => { console.error("[cardboard-story] fatal", e.message); process.exit(1); });
