import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// LlamaChat V2 web. Dave's locked rules: total page < 1MB, first paint < 1s.
// No heavy deps: virtualization is hand-rolled, no UI kits. One manual
// chunk split keeps the router + views out of the initial paint path... in
// practice the whole app is tiny, so a single entry chunk is fine and
// avoids extra round trips on mobile.
export default defineConfig({
  plugins: [react()],
  build: {
    target: "es2020",
    // Bundle budget (Dave's call Oct 9 2026): fail the build if the initial
    // JS chunk exceeds 180KB. Keeps us honest as the app grows.
    chunkSizeWarningLimit: 180,
    sourcemap: false,

  },
  server: {
    port: 5173,
  },
});
