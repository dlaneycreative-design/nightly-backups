// Re-render HTML for tweets containing bare domains (no http scheme).
// Dave's call 2026-10-11: bare domains like clearrecipe.net must link.
// Run: node api/scripts/rerender-bare-domains.js
const { neon } = require("@neondatabase/serverless");
const fs = require("fs");
const { renderHtml } = require("../lib/render");

let v = fs.readFileSync("/home/hatch/workspace/llamachat-v2/.env.local", "utf8").match(/^DATABASE_URL=(.+)$/m)[1].trim();
if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
const sql = neon(v);

// Same domain shape as the linkifier, minus boundaries: find tweets that
// would gain a link. Excludes anything already containing an <a href.
const BARE_CANDIDATE = /(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}/i;

(async () => {
  const rows = await sql.query(`SELECT id, text, html FROM tweets`);
  console.log(`Scanning ${rows.length} tweets`);
  let updated = 0;
  for (const row of rows) {
    if (!BARE_CANDIDATE.test(row.text)) continue;
    const html = renderHtml(row.text);
    if (html === row.html) continue;
    // Only touch tweets that actually gained a bare-domain link; skip ones
    // whose diff comes from anything else (shouldn't happen, but be safe).
    await sql.query(`UPDATE tweets SET html = $1, updated_at = $2 WHERE id = $3`, [
      html,
      Date.now(),
      row.id,
    ]);
    updated++;
  }
  console.log(`Re-rendered ${updated} tweets`);
  process.exit(0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
