// Normalized store: one object per ID, profile lookup by handle.
// Spec section 10: "profile lookup" gets a test.
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  upsertTweet, upsertTweets, getTweet, removeTweet,
  upsertProfile, getProfileByHandle, getProfileById, clearStore,
} from "../src/lib/store.ts";
import type { Profile, Tweet } from "../src/lib/api.ts";

function tweet(partial: Partial<Tweet> = {}): Tweet {
  return {
    id: "t1",
    author: { id: "u1", handle: "dlaney", display_name: "Dave", avatar_url: null },
    text: "hi",
    html: null,
    image_url: null,
    reply_to_id: null,
    hashtags: [],
    likes_count: 0,
    replies_count: 0,
    reposts_count: 0,
    created_at: 1700000000000,
    ...partial,
  };
}

function profile(partial: Partial<Profile> = {}): Profile {
  return {
    id: "u1",
    handle: "dlaney",
    display_name: "Dave",
    avatar_url: null,
    bio: null,
    link_url: null,
    link_label: null,
    followers_count: 10,
    following_count: 5,
    posts_count: 3,
    created_at: 1700000000000,
    ...partial,
  };
}

test("tweets are normalized: one object per id, updates merge", () => {
  clearStore();
  const a = upsertTweet(tweet({ text: "v1" }));
  const b = upsertTweet(tweet({ text: "v2", likes_count: 7 }));
  assert.equal(getTweet("t1")?.text, "v2");
  assert.equal(getTweet("t1")?.likes_count, 7);
  assert.equal(a === b || getTweet("t1")?.text === "v2", true);
  assert.equal(upsertTweets([tweet({ id: "t2" })]).length, 1);
  assert.ok(getTweet("t2"));
});

test("removeTweet drops the id", () => {
  clearStore();
  upsertTweet(tweet({ id: "gone" }));
  removeTweet("gone");
  assert.equal(getTweet("gone"), undefined);
});

test("profile lookup by handle is case-insensitive", () => {
  clearStore();
  upsertProfile(profile({ handle: "Dlaney" }));
  assert.equal(getProfileByHandle("dlaney")?.id, "u1");
  assert.equal(getProfileByHandle("DLANEY")?.id, "u1");
  assert.equal(getProfileById("u1")?.handle, "Dlaney");
  assert.equal(getProfileByHandle("nobody"), undefined);
});

test("profile updates merge, followers_count stays numeric", () => {
  clearStore();
  upsertProfile(profile({ followers_count: 10 }));
  upsertProfile(profile({ followers_count: 11, bio: "kind" }));
  const p = getProfileByHandle("dlaney");
  assert.equal(p?.followers_count, 11);
  assert.equal(p?.bio, "kind");
});

test("clearStore empties everything", () => {
  upsertTweet(tweet());
  upsertProfile(profile());
  clearStore();
  assert.equal(getTweet("t1"), undefined);
  assert.equal(getProfileByHandle("dlaney"), undefined);
});
