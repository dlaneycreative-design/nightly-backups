import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient } from "../lib/api.ts";
import { resolveImageUrl } from "../lib/images.ts";

interface Notification {
  id: string;
  type: "reply" | "like" | "repost" | "follow" | "mention";
  actor_handle: string;
  actor_name: string;
  actor_avatar: string | null;
  tweet_id: string | null;
  tweet_text: string | null;
  created_at: number;
  read_at: number | null;
}

function notifText(n: Notification): string {
  switch (n.type) {
    case "reply": return "replied to your post";
    case "like": return "liked your post";
    case "repost": return "reposted your post";
    case "follow": return "followed you";
    case "mention": return "mentioned you";
    default: return "interacted with you";
  }
}

// X-style type icon (heart for likes, person for follows, etc.)
function TypeIcon({ type }: { type: Notification["type"] }) {
  const style: React.CSSProperties = { width: 28, height: 28, flexShrink: 0 };
  switch (type) {
    case "like":
      return <svg viewBox="0 0 24 24" fill="#f91880" style={style}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
    case "follow":
      return <svg viewBox="0 0 24 24" fill="#1d9bf0" style={style}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
    case "repost":
      return <svg viewBox="0 0 24 24" fill="#536471" style={{ width: 14, height: 14, flexShrink: 0 }}><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>;
    default:
      return <svg viewBox="0 0 24 24" fill="#1d9bf0" style={style}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>;
  }
}

export function NotificationsView({ api }: { api: ApiClient }) {
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const r = await api.notifications();
        setNotifs(r.notifications as Notification[]);
        // Mark as read after viewing, and update local state so the
        // unread styling clears immediately.
        await api.markNotificationsRead();
        setNotifs((prev) =>
          prev.map((n) => ({ ...n, read_at: n.read_at ?? Date.now() }))
        );
      } catch {
        // Not signed in or failed
      } finally {
        setLoading(false);
      }
    })();
  }, [api]);

  if (loading) {
    return <div className="notif-loading">Loading notifications...</div>;
  }

  if (notifs.length === 0) {
    return (
      <div className="notif-empty">
        <h2>Nothing yet</h2>
        <p>When someone replies, likes, or follows you, it will show up here.</p>
      </div>
    );
  }

  return (
    <div className="notif-list">
      {notifs.map((n) => (
        <button
          key={n.id}
          type="button"
          className={`notif-row${n.read_at ? "" : " unread"}`}
          onClick={() => {
            if (n.tweet_id) navigate(`/tweet/${n.tweet_id}`);
            else if (n.type === "follow") navigate(`/profile/${n.actor_handle}`);
          }}
        >
          <TypeIcon type={n.type} />
          <div className="notif-avatar">
            {n.actor_avatar ? (
              <img src={resolveImageUrl(n.actor_avatar) || ""} alt="" loading="lazy" decoding="async" />
            ) : (
              <div className="avatar-fallback">{(n.actor_name || "?").slice(0, 1).toUpperCase()}</div>
            )}
          </div>
          <div className="notif-body">
            <div className="notif-text">
              <strong>{n.actor_name}</strong> {notifText(n)}
            </div>
            {n.tweet_text ? (
              <div className="notif-preview">{n.tweet_text.slice(0, 100)}</div>
            ) : null}
          </div>
        </button>
      ))}
    </div>
  );
}
