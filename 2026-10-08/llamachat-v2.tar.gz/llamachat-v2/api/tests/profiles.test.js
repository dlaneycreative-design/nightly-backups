// Profile lookup against the real seeded DB: one canonical profile per
// handle, case-insensitive. Needs DATABASE_URL pointing at a seeded DB.
const { test } = require("node:test");
const assert = require("node:assert/strict");

const hasDb = !!process.env.DATABASE_URL;
let query;
if (hasDb) ({ query } = require("../lib/db"));

// Same lookup the API uses (server.js getProfileByHandle).
async function getProfileByHandle(handle) {
  const r = await query("SELECT * FROM profiles WHERE lower(handle) = lower($1)", [handle]);
  return r.rows[0] || null;
}

test("case-insensitive lookup returns the canonical profile", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const lower = await getProfileByHandle("dlaney");
  const upper = await getProfileByHandle("DLANEY");
  const mixed = await getProfileByHandle("DlAnEy");
  assert.ok(lower, "dlaney must exist");
  assert.equal(upper.id, lower.id, "upper-case must hit the same row");
  assert.equal(mixed.id, lower.id, "mixed-case must hit the same row");
  assert.equal(lower.handle, "dlaney", "canonical handle is lowercase");
});

test("unknown handle returns null (404 upstream)", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  assert.equal(await getProfileByHandle("no_such_handle_xyz"), null);
});

test("no duplicate handles exist (case-insensitive)", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const r = await query(
    "SELECT lower(handle) AS h, count(*)::int AS n FROM profiles GROUP BY 1 HAVING count(*) > 1"
  );
  assert.deepEqual(r.rows, [], "duplicate handles found");
});

test("every profile has a positive created_at", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const r = await query("SELECT count(*)::int AS n FROM profiles WHERE created_at IS NULL OR created_at <= 0");
  assert.equal(r.rows[0].n, 0, "profiles with bad created_at");
});
