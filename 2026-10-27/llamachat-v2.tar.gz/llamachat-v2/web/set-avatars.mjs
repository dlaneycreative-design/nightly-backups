// Set Steve's avatar (was NULL) and slim Chadwick's 1.76MB avatar to the canonical WebP.
// Owner: main chat (Dave's order Oct 13 2026). Idempotent.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const before = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('serversteve','chadwick') ORDER BY handle`;
console.log('BEFORE:', before.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));

const u1 = await sql`UPDATE profiles SET avatar_url = '/assets/avatars/serversteve.webp' WHERE handle = 'serversteve'`;
console.log('serversteve update count:', u1.count);
const u2 = await sql`UPDATE profiles SET avatar_url = '/assets/avatars/chadwick.webp' WHERE handle = 'chadwick'`;
console.log('chadwick update count:', u2.count);

const after = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('serversteve','chadwick') ORDER BY handle`;
console.log('AFTER:', after.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
console.log('AVATAR UPDATE DONE');
