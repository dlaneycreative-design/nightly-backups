import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { upsertTweets, upsertProfiles } from "../lib/store.ts";
import { highlightMatches } from "../lib/hashtags.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { Tweet } from "./Tweet.tsx";
import { SearchAutocomplete } from "./SearchAutocomplete.tsx";

type SearchType = "all" | "tweets" | "users" | "hashtags";

interface Props {
  api: ApiClient;
}

function Highlighted({ text, query }: { text: string; query: string }) {
  const segs = highlightMatches(text, query);
  return (
    <>
      {segs.map((s, i) =>
        s.highlight ? <mark key={i}>{s.text}</mark> : <span key={i}>{s.text}</span>
      )}
    </>
  );
}

/** Search with match highlighting across tweets, users, and hashtags. */
export function SearchView({ api }: Props) {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [input, setInput] = useState(params.get("q") || "");
  const [type, setType] = useState<SearchType>("all");
  const [tweets, setTweets] = useState<TweetT[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [tags, setTags] = useState<{ tag: string; count: number }[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const timer = useRef<number | null>(null);
  const reqSeq = useRef(0);

  const run = useCallback(
    async (q: string, t: SearchType) => {
      const query = q.trim();
      if (!query) {
        setTweets([]);
        setUsers([]);
        setTags([]);
        setSearched(false);
        return;
      }
      const seq = ++reqSeq.current;
      setLoading(true);
      try {
        const res = await api.search(query, t);
        // Drop stale responses from earlier keystrokes.
        if (seq !== reqSeq.current) return;
        const tw = upsertTweets(res.tweets || []);
        const us = upsertProfiles(res.users || []);
        setTweets(tw);
        setUsers(us);
        setTags(res.hashtags || []);
        setSearched(true);
      } catch {
        // Keep the old results; a retry happens on the next keystroke.
      } finally {
        setLoading(false);
      }
    },
    [api]
  );

  // Debounced search as you type; URL holds the query for shareability.
  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      setParams(input.trim() ? { q: input.trim() } : {}, { replace: true });
      void run(input, type);
    }, 350);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [input, type, run, setParams]);

  const query = params.get("q") || "";

  return (
    <div>
      <div className="searchbar">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Search posts, people, #tags"
          aria-label="Search"
          autoComplete="off"
        />
        <SearchAutocomplete api={api} query={input} />
      </div>
      <div className="pf-tabs" role="tablist" aria-label="Search type">
        {(["all", "tweets", "users", "hashtags"] as SearchType[]).map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={type === t}
            className={`pf-tab${type === t ? " on" : ""}`}
            onClick={() => setType(t)}
          >
            {t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>
      {loading ? <div className="feed-sentinel">Searching...</div> : null}
      {!searched && !loading ? (
        <div className="empty">
          <p>Type to search the whole Studio.</p>
        </div>
      ) : null}
      {searched && tweets.length === 0 && users.length === 0 && tags.length === 0 && !loading ? (
        <div className="empty">
          <h2>No matches</h2>
          <p>Nothing found for "{query}". Try a different word.</p>
        </div>
      ) : null}
      {users.length > 0 ? (
        <>
          <div className="search-section-title">People</div>
          {users.map((u) => {
            const src = resolveImageUrl(u.avatar_url);
            return (
            <button key={u.id} type="button" className="user-row" onClick={() => navigate(`/profile/${u.handle}`)}>
              {src ? (
                <img className="" src={src} alt="" loading="lazy" decoding="async" />
              ) : (
                <div className="avatar-fallback" aria-hidden="true">
                  {(u.display_name || "?").slice(0, 1).toUpperCase()}
                </div>
              )}
              <div className="tweet-body">
                <div className="n">
                  <Highlighted text={u.display_name} query={query} />
                </div>
                <div className="h">
                  <Highlighted text={`@${u.handle}`} query={query} />
                </div>
                {u.bio ? (
                  <div className="user-bio">
                    <Highlighted text={u.bio} query={query} />
                  </div>
                ) : null}
              </div>
            </button>
            );
          })}
        </>
      ) : null}
      {tags.length > 0 ? (
        <>
          <div className="search-section-title">Tags</div>
          {tags.map((h) => (
            <button key={h.tag} type="button" className="user-row" onClick={() => navigate(`/hashtag/${h.tag}`)}>
              <div className="tweet-body">
                <div className="n">
                  <Highlighted text={`#${h.tag}`} query={query} />
                </div>
                <div className="user-bio">
                  {h.count} post{h.count === 1 ? "" : "s"}
                </div>
              </div>
            </button>
          ))}
        </>
      ) : null}
      {tweets.length > 0 ? (
        <>
          <div className="search-section-title">Posts</div>
          {tweets.map((t) => (
            <Tweet key={t.id} tweet={t} api={api} />
          ))}
        </>
      ) : null}
    </div>
  );
}
