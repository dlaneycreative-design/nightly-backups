import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ApiClient, Tweet as TweetT } from "../lib/api.ts";
import { upsertTweets, removeTweet, subscribe, repliesTo } from "../lib/store.ts";
import { Tweet } from "./Tweet.tsx";

interface Props {
  api: ApiClient;
  id: string;
}

/** Tweet detail: parent context (if a reply), the tweet, replies. */
export function TweetThread({ api, id }: Props) {
  const navigate = useNavigate();
  const goBack = useCallback(() => {
    if (window.history.length > 1) navigate(-1);
    else navigate("/", { replace: true });
  }, [navigate]);
  const [tweet, setTweet] = useState<TweetT | null>(null);
  const [parent, setParent] = useState<TweetT | null>(null);
  const [replies, setReplies] = useState<TweetT[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { tweet: t, parent: p, replies: r } = await api.getTweet(id);
      upsertTweets([t, ...(p ? [p] : []), ...r]);
      setTweet(t);
      setParent(p);
      setReplies(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load this post.");
    } finally {
      setLoading(false);
    }
  }, [api, id]);

  useEffect(() => {
    void load();
  }, [load]);

  // Replies posted from the reply modal land in the store; merge them into
  // this thread's reply list without a refetch.
  useEffect(
    () =>
      subscribe(() => {
        const fresh = repliesTo(id);
        if (fresh.length === 0) return;
        setReplies((prev) => {
          const seen = new Set(prev.map((r) => r.id));
          const extra = fresh.filter((r) => !seen.has(r.id));
          if (extra.length === 0) return prev;
          return [...prev, ...extra].sort((a, b) => a.created_at - b.created_at);
        });
      }),
    [id]
  );

  const onDeleted = useCallback(
    (deletedId: string) => {
      removeTweet(deletedId);
      if (deletedId === id) {
        setTweet(null);
        setError("This post was deleted.");
      } else {
        setReplies((prev) => prev.filter((r) => r.id !== deletedId));
      }
    },
    [id]
  );

  const backHead = (
    <div className="thread-head">
      <button type="button" className="back" onClick={goBack} aria-label="Back">
        &#8592;
      </button>
      <span className="n">Post</span>
    </div>
  );

  if (loading) {
    return (
      <div aria-label="Loading post">
        {backHead}
        {[0, 1, 2].map((i) => (
          <div className="skel-tweet" key={i}>
            <div className="skel skel-avatar" />
            <div className="skel-lines">
              <div className="skel skel-line short" />
              <div className="skel skel-line" />
              <div className="skel skel-line" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error || !tweet) {
    return (
      <div className="errorbox" role="alert">
        {backHead}
        <h2>Post unavailable</h2>
        <p>{error || "This post does not exist."}</p>
        <button type="button" className="ghost" onClick={() => void load()}>
          Try again
        </button>
      </div>
    );
  }

  return (
    <div className="thread-view">
      {backHead}
      {parent ? (
        <>
          <div className="thread-parent-label">In reply to</div>
          <div className="thread-connected">
            <Tweet tweet={parent} api={api} onDeleted={onDeleted} />
          </div>
        </>
      ) : null}
      <div className={replies.length > 0 ? "thread-connected" : ""}>
        <Tweet tweet={tweet} api={api} onDeleted={onDeleted} detail />
      </div>
      {replies.length > 0 ? <div className="thread-replies-label">Replies</div> : null}
      <ReplyTree replies={replies} parentId={tweet.id} api={api} onDeleted={onDeleted} depth={0} />
    </div>
  );
}

/** Recursive nested reply tree. */
function ReplyTree({ replies, parentId, api, onDeleted, depth }: {
  replies: TweetT[];
  parentId: string;
  api: ApiClient;
  onDeleted: (id: string) => void;
  depth: number;
}) {
  const children = replies.filter((r) => r.reply_to_id === parentId);
  if (children.length === 0) return null;
  return (
    <>
      {children.map((r) => (
        <div key={r.id} className={depth > 0 ? "thread-nested" : ""}>
          <Tweet tweet={r} api={api} onDeleted={onDeleted} />
          <ReplyTree replies={replies} parentId={r.id} api={api} onDeleted={onDeleted} depth={depth + 1} />
        </div>
      ))}
    </>
  );
}
