import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Apps V1 (Dave's call Oct 19 2026): Flashcards is an installable app
// on the Llama skin too, so the real FlashcardsView ships in this
// build as a lazy chunk. It used to be stubbed out of llamachat.lol
// entirely; now App.tsx gates the /flashcards route on the user's
// install state instead (not installed: the route lands on the Apps
// view). The chunk only downloads when a user actually opens it, so
// the base Llama surface stays exactly as light as before.
// (vite.config.starvard.ts does the mirror-image job for the
// Starvard skin's CSS files.)

// LlamaChat V2 web. Dave's locked rules: total page < 1MB, first paint < 1s.
// No heavy deps: virtualization is hand-rolled, no UI kits. One manual
// chunk split keeps the router + views out of the initial paint path... in
// practice the whole app is tiny, so a single entry chunk is fine and
// avoids extra round trips on mobile.
export default defineConfig({
  plugins: [react()],
  build: {
    target: "es2020",
    // Bundle budget (Dave's call Oct 9 2026): fail the build if the initial
    // JS chunk exceeds 180KB. Keeps us honest as the app grows.
    chunkSizeWarningLimit: 180,
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: (id) => {
          // Split vendor code (React, router) from app code.
          // Vendors change rarely, so browsers cache them longer.
          if (id.includes("node_modules")) {
            if (id.includes("react-router")) return "vendor-router";
            if (id.includes("react")) return "vendor-react";
            return "vendor";
          }
        },
      },
    },
  },
  server: {
    port: 5173,
  },
});
