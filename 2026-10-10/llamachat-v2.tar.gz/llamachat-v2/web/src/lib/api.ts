// Typed API client with retry. Every list endpoint is cursor-paginated;
// this client walks pages only when the caller asks for more.
export interface Tweet {
  id: string;
  author: { id: string; handle: string; display_name: string; avatar_url: string | null };
  text: string;
  html: string | null;
  image_url: string | null;
  reply_to_id: string | null;
  hashtags: string[];
  likes_count: number;
  replies_count: number;
  reposts_count: number;
  created_at: number;
  liked: boolean;
  reposted: boolean;
}

export interface Profile {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string | null;
  bio: string | null;
  link_url: string | null;
  link_label: string | null;
  followers_count: number;
  following_count: number;
  posts_count: number;
  created_at: number;
  following?: boolean;
}

export interface ConversationParticipant {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string | null;
}

export interface Conversation {
  id: string;
  others: ConversationParticipant[];
  last_text: string | null;
  created_at: number;
  updated_at: number;
  unread?: boolean;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  created_at: number;
  handle: string;
  display_name: string;
  avatar_url: string | null;
}

/** Trending hashtag: ranked by real 7-day post volume, never hardcoded. */
export interface Trend {
  tag: string;
  post_count: number;
  last_used_at: number;
}

export interface Page<T> {
  items: T[];
  next_cursor: string | null;
}

interface ApiError extends Error {
  code?: string;
  status?: number;
}

async function request<T>(apiBase: string, callerId: string | null, path: string, init?: RequestInit, retries = 2): Promise<T> {
  let lastErr: unknown = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(`${apiBase}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...(callerId ? { "x-llama-user": callerId } : {}),
          ...(init?.headers || {}),
        },
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        const err = new Error(body?.error?.message || `request failed (${res.status})`) as ApiError;
        err.code = body?.error?.code;
        err.status = res.status;
        // Don't retry client errors (except 429).
        if (res.status < 500 && res.status !== 429) throw err;
        throw err;
      }
      return body as T;
    } catch (e) {
      lastErr = e;
      const status = (e as ApiError).status;
      if (status && status < 500 && status !== 429) throw e;
      if (attempt < retries) await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  throw lastErr;
}

export function createClient(apiBase: string, getCallerId: () => string | null) {
  const authed = <T>(path: string, init?: RequestInit) => {
    const id = getCallerId();
    if (!id) return Promise.reject(Object.assign(new Error("not signed in"), { code: "UNAUTHENTICATED", status: 401 }));
    return request<T>(apiBase, id, path, init);
  };
  const pub = <T>(path: string, init?: RequestInit) => request<T>(apiBase, getCallerId(), path, init);

  return {
    health: () => pub<{ ok: boolean; version: string }>("/health"),

    feed: (cursor?: string | null, limit = 20, sort: "chron" | "foryou" = "chron") =>
      pub<{ tweets: Tweet[]; next_cursor: string | null }>(
        `/tweets?limit=${limit}&sort=${sort}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    randomFeed: (limit = 30) =>
      pub<{ tweets: Tweet[] }>(`/tweets/random?limit=${limit}`),

    postTweet: (input: { id: string; text: string; image_url?: string | null; reply_to_id?: string | null }) =>
      authed<{ tweet: Tweet; deduped: boolean }>("/tweets", {
        method: "POST",
        body: JSON.stringify(input),
      }),

    getTweet: (id: string) =>
      pub<{ tweet: Tweet; parent: Tweet | null; replies: Tweet[] }>(`/tweets/${id}`),

    deleteTweet: (id: string) => authed<{ ok: boolean }>(`/tweets/${id}`, { method: "DELETE" }),

    profile: (handle: string) => pub<{ profile: Profile }>(`/profiles/${encodeURIComponent(handle)}`),

    profileTweets: (handle: string, tab: "posts" | "replies" | "media" | "likes" = "posts", cursor?: string | null, limit = 20) =>
      pub<{ tweets: Tweet[]; next_cursor: string | null }>(
        `/profiles/${encodeURIComponent(handle)}/tweets?tab=${tab}&limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    hashtag: (tag: string, cursor?: string | null, limit = 20) =>
      pub<{ tag: string; tweets: Tweet[]; next_cursor: string | null }>(
        `/hashtags/${encodeURIComponent(tag)}?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    search: (q: string, type: "all" | "tweets" | "users" | "hashtags" = "all") =>
      pub<{ tweets?: Tweet[]; users?: Profile[]; hashtags?: { tag: string; count: number }[] }>(
        `/search?q=${encodeURIComponent(q)}&type=${type}`
      ),

    trending: (limit = 10) =>
      pub<{ trends: Trend[] }>(`/trending?limit=${limit}`),

    follow: (following_id: string) =>
      authed<{ ok: boolean }>("/follows", { method: "POST", body: JSON.stringify({ following_id }) }),

    unfollow: (user_id: string) => authed<{ ok: boolean }>(`/follows/${user_id}`, { method: "DELETE" }),

    like: (tweet_id: string) =>
      authed<{ tweet: Tweet }>(`/likes`, { method: "POST", body: JSON.stringify({ tweet_id }) }),

    unlike: (tweet_id: string) =>
      authed<{ tweet: Tweet | null }>(`/likes/${tweet_id}`, { method: "DELETE" }),

    repost: (tweet_id: string) =>
      authed<{ tweet: Tweet }>(`/reposts`, { method: "POST", body: JSON.stringify({ tweet_id }) }),

    unrepost: (tweet_id: string) =>
      authed<{ tweet: Tweet | null }>(`/reposts/${tweet_id}`, { method: "DELETE" }),

    notifications: () =>
      authed<{ notifications: Array<{
        id: string; type: string; actor_handle: string; actor_name: string;
        actor_avatar: string | null; tweet_id: string | null; tweet_text: string | null;
        created_at: number; read_at: number | null;
      }> }>(`/notifications`),

    markNotificationsRead: () =>
      authed<{ ok: boolean }>(`/notifications/read`, { method: "POST" }),

    conversations: (cursor?: string | null, limit = 20) =>
      authed<{ conversations: Conversation[]; next_cursor: string | null }>(
        `/conversations?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    createConversation: (participant_ids: string[]) =>
      authed<{ conversation: Conversation; deduped: boolean }>("/conversations", {
        method: "POST",
        body: JSON.stringify({ participant_ids }),
      }),

    messages: (conversation_id: string, cursor?: string | null, limit = 20) =>
      authed<{ messages: Message[]; next_cursor: string | null }>(
        `/conversations/${conversation_id}/messages?limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`
      ),

    postMessage: (conversation_id: string, input: { id: string; text: string }) =>
      authed<{ message: Message; deduped?: boolean }>(`/conversations/${conversation_id}/messages`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
  };
}

export type ApiClient = ReturnType<typeof createClient>;
