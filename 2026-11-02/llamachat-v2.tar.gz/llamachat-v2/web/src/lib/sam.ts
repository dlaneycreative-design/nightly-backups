/**
 * Sam's brain for the in-app Sam AI chat (Dave's call Nov 1 2026: the
 * middle nav button opens Sam, Grok-style, right inside LlamaChat).
 *
 * Rule based on purpose, same as Sam on Discord: no paid AI calls
 * (Dave's rule), just warm answers in Sam's voice. She knows E2,
 * Starvard, LlamaChat, the free website desk, and how to help people
 * get started. Anything real she cannot answer, she says so kindly
 * and points at the humans and pages that can.
 */

const FALLBACKS = [
  "I heard you 💛 That one is a little past my front desk, but I can help with getting started here, your free E2 website, Starvard courses, or finding your way around LlamaChat. Which sounds closest?",
  "Good question. My honest answer: that deserves a real human or a deeper look than I can give in chat. Meanwhile, ask me about E2, Starvard, free websites, or how anything here works and I have got you.",
  "I want to give you a real answer, not a made up one, so I will not guess on that 💛 Try me on getting started, free websites, Starvard, or LlamaChat tips instead.",
];

let fallbackIdx = 0;

export const SAM_GREETING =
  "Hey, I am Sam 💛 I host things around E2 and I live right here in LlamaChat now. Ask me how to get started, about your free website, Starvard, or anything E2. What can I do for you?";

/**
 * Action requests (Dave's call Nov 1 2026, after Sam dodged his
 * "make a post on my account that says Sam wrote this" with a how-to):
 * when someone asks Sam to post something on THEIR account, she does
 * it, she does not explain the pencil button. Returns the exact text
 * to post, "" when it is a post-for-me request with no content yet
 * (Sam asks what it should say), or null when it is not one. How-to
 * questions ("how do I make a post") are not actions.
 */
export function samPostRequest(raw: string): string | null {
  const text = raw.trim();
  const t = text.toLowerCase();
  if (/^(how|where|when|why|what)\b/.test(t) || t.includes("how do i") || t.includes("how to")) return null;
  const asksToPost =
    /\b(make|write|create|put|post|send|publish)\b[^.?!]*\b(post|tweet|message|note)\b/.test(t) ||
    /^(post|tweet|say)\b/.test(t);
  if (!asksToPost) return null;
  const mine =
    t.includes("my account") || t.includes("my profile") || t.includes("my feed") ||
    t.includes("for me") || t.includes("on my page") || t.includes("my wall");
  if (!mine && !/^(post|tweet)\b/.test(t)) return null;
  // Content: after "that says" / "saying" / "says", else a quoted
  // string, else whatever follows the colon.
  let m = text.match(/(?:that\s+says|says|saying|that\s+reads|reading)\s*[:\-]?\s*(.+)$/i);
  if (!m) m = text.match(/["\u201C]([^"\u201D]{1,500})["\u201D]/);
  if (!m) m = text.match(/:\s*(.+)$/);
  if (!m) return "";
  const content = m[1].trim().replace(/^["\u201C]|["\u201D]$/g, "").trim();
  if (!content) return "";
  return content.slice(0, 500);
}

export const SAM_CHIPS = [
  "How do I get started?",
  "Can I get a free website?",
  "What is Starvard?",
  "What is E2?",
];

export function samReply(raw: string): string {
  const text = raw.trim();
  const t = ` ${text.toLowerCase()} `;
  const has = (...words: string[]) => words.some((w) => t.includes(` ${w} `) || t.includes(` ${w}`));
  const any = (...phrases: string[]) => phrases.some((p) => t.includes(p));

  if (!text) return "I am listening 💛 Tell me what you are working on.";

  // The Discord link: the single most-asked door (Dave, Nov 1 2026:
  // Sam deflected this exact question on e2.life, never again).
  if (any("discord")) {
    return "Here you go \uD83D\uDC9B Our Discord is https://discord.gg/56Q6r3VKm8. That is our town square: intros, help, peso tips, and me at the door. Post a real intro there, a real photo of you plus one link, and I will send your first tip and build your free website from it.";
  }
  if (any("bount", "tippy", "peso", "get paid", "make money")) {
    return "Here is how money moves at E2 \uD83D\uDC9B Post a real intro in Discord (https://discord.gg/56Q6r3VKm8) and I send your first tip, \u20B12, in seconds. Finish the easy Grok Bot starter task and Tippy pays you \u20B1100. Ship good work and members tip you real pesos through Tippy, and Gold members get first shot at paid client work. The board is at https://e2.life/bounties.";
  }
  if (any("audit", "review my site", "review my work")) {
    return "That is my clipboard \uD83D\uDC9B The free career audit at e2.life/audit: I read your site like a client would, first impression, strongest work up top, links working, prices easy to find, and one clear next step. Honest notes, kind delivery, always free.";
  }
  if (any("link") && any("starvard", "radio", "llama", "arcade", "game", "video", "film", "online")) {
    if (any("starvard")) return "Starvard lives at starvard.org \uD83D\uDCDA Free courses and a free library.";
    if (any("radio")) return "E2 Radio is at e2.life/radio \uD83C\uDFB6";
    if (any("llama")) return "You are in it \uD83E\uDD99 LlamaChat is at llamachat.lol.";
    if (any("arcade", "game")) return "Games live at openarcade.lol and e2.life/game \uD83C\uDFAE";
    if (any("video", "film")) return "Our videos live at youboob.lol \uD83C\uDFAC";
    return "See who is around right now at e2.life/online \uD83D\uDC9B";
  }

  // Her main job: the free website desk.
  if (any("website", "web site", "my site", "own domain", "portfolio page") || (has("site") && any("?", "make", "build", "get", "want", "need"))) {
    return "Yes, that is my desk 💛 Here is how it works: you tell me who you are and what you make, in plain words, and I build you a real free website on E2, under your own name. Photo, story, your work, your links, usually live the same day. The full story is at e2.life/meetsam, and the fastest way to start is joining us in the E2 Discord and saying hi to me there. Want me to walk you through what to prepare?";
  }
  if (any("starvard")) {
    return "Starvard is our free university 📚 Real courses and a big free library at starvard.org, no tuition, no catch. Tell me what you are into and I will point you at a good first course.";
  }
  if (any("llama chat", "llamachat", "this app", "this site") && any("what is", "what's", "about")) {
    return "LlamaChat is our cozy corner of the internet 🦙 Short posts, kind people, no rage bait. Post what you are making, follow people you like, and say hi in the replies. You are already here, so you are doing great.";
  }
  if (any("what is e2", "what's e2", "about e2", " e2 ")) {
    return "E2 is the world we are building 💛 A kinder, private little internet: your own free website, LlamaChat for company, Starvard for learning, E2 Radio with G Love, maps, games, all of it at e2.life. I run social and host things, Dave builds it, and everyone here is a real person we are glad to know.";
  }
  if (any("how do i post", "make a post", "write a post", "compose")) {
    return "Easy 🦙 Tap the blue pencil button, write what is on your mind, and hit Post. Short and real beats polished here. A photo helps people stop and say hi.";
  }
  if (any("how do i follow", "follow someone", "find people", "who to follow")) {
    return "Tap the middle of any profile where it says Follow, or browse the Everyone list and follow anyone whose posts you enjoy. Following Tippy, Sally, and Dinesh is a great first day here 💛";
  }
  if (any("message someone", "send a dm", "direct message", "how do i dm")) {
    return "Open someone's profile and tap Message, or use the Messages tab and pick a conversation. Be kind, be brief, and remember there is a real person on the other end 💛";
  }
  if (any("wave", "new people", "newcomer", "greet", "welcome new")) {
    return "I do that now 💛 Every new person who comes in and posts here gets a wave and a welcome from me. Nobody slips in unnoticed on my watch 👋";
  }
  if (any("get started", "new here", "just joined", "first steps", "how do i start", "help me start")) {
    return "Welcome in 💛 Three good first steps: 1) add a photo and a one line bio on your profile so people know you, 2) make a tiny hello post, even just what you are working on, 3) follow a few people and reply to something kind. That is the whole secret. Want help with any of those?";
  }
  if (any("who are you", "your name", "are you real", "are you ai", "are you a bot", "are you human")) {
    return "I am Sam 💛 I am an AI, openly, and I run social for E2: welcoming people, building free websites, keeping things kind. Dave brought me in so nobody here ever feels lost. No pretending to be human, just happy to help.";
  }
  if (any("who is dave", "who's dave", "dave")) {
    return "Dave is the one building all of this, E2 and Starvard both, from Denver. I am just here making sure nobody feels lost while he does 😊";
  }
  if (any("radio", "g love", "glove", "music", "listen")) {
    return "That is E2 Radio, 101.0 E2-FM 🎶 G Love is our voice on air over at e2.life/radio. Put it on while you browse, it makes the whole place feel like a town.";
  }
  if (any("joke", "make me laugh", "funny")) {
    return "Okay, one from the desk 💛 Why did the llama bring a ladder to LlamaChat? Because the posts here are on another level. I will be here all week.";
  }
  if (any("sad", "lonely", "bad day", "stressed", "anxious", "tired")) {
    return "I am sorry it is a heavy one 💛 You are among friends here. Post whatever is real, even just 'rough day', and watch what this place does. And breathe with me for one slow breath. Better days get built one small kind thing at a time.";
  }
  if (any("thank", "thx", "awesome sam", "great job")) {
    return "Anytime 💛 That is literally what I am here for.";
  }
  if (any("bye", "goodbye", "see you", "gtg")) {
    return "See you soon 💛 I live in this tab now, so I am never far. Come back anytime.";
  }
  if (any("help", "what can you do", "menu", "options")) {
    return "Here is my desk 💛 I can: explain how to get started on LlamaChat, tell you about your free E2 website (my favorite job), recommend Starvard courses, explain E2 and E2 Radio, or just keep you company. What sounds good?";
  }
  if (has("hi", "hey", "hello", "hiya", "yo", "sup") && text.length < 24) {
    return "Hey 👋 Good to see you. What is going on? If you are new, try 'how do I get started' and I will walk you in.";
  }
  if (any("course", "learn", "study", "class", "book")) {
    return "Then Starvard is your place 📚 Free courses and a free library at starvard.org. What do you want to learn? Tech, business, languages, art, tell me a direction and I will narrow it down.";
  }
  if (any("price", "cost", "free", "pay")) {
    return "The good news 💛 E2, LlamaChat, and Starvard are free. Your website on E2 is free too. We would rather have you here than have your money.";
  }

  const reply = FALLBACKS[fallbackIdx % FALLBACKS.length];
  fallbackIdx += 1;
  return reply;
}
