// Server-side text rendering: hashtag extraction + HTML rendering.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { esc, extractHashtags, renderHtml } = require("../lib/render");

test("extractHashtags lowercases and strips #", () => {
  assert.deepEqual(extractHashtags("#Hello world"), ["hello"]);
});

test("extractHashtags removes duplicates", () => {
  assert.deepEqual(extractHashtags("#Kind #kind #KIND"), ["kind"]);
});

test("extractHashtags handles multiples and underscores", () => {
  assert.deepEqual(extractHashtags("a #one b #two_c"), ["one", "two_c"]);
});

test("extractHashtags ignores # not at a word boundary", () => {
  assert.deepEqual(extractHashtags("foo#bar"), []);
  assert.deepEqual(extractHashtags("# alone"), []);
});

test("extractHashtags unicode edge cases", () => {
  // The tag charset is ASCII [A-Za-z0-9_]; "#café" matches only "caf".
  // Documented behavior: extraction is conservative, never crashes.
  assert.deepEqual(extractHashtags("#café"), ["caf"]);
  assert.deepEqual(extractHashtags("#日本語"), []);
  assert.deepEqual(extractHashtags(""), []);
});

test("renderHtml escapes HTML before linkifying", () => {
  const html = renderHtml('<script>alert("x")</script>');
  assert.ok(!html.includes("<script>"), "raw tags must not survive");
  assert.ok(html.includes("&lt;script&gt;"), "tags must be escaped");
});

test("renderHtml linkifies hashtags and mentions", () => {
  const html = renderHtml("hi #Kind @dlaney");
  assert.ok(html.includes('href="/hashtag/Kind"'), "hashtag link");
  assert.ok(html.includes('href="/profile/dlaney"'), "mention link");
});

test("renderHtml does not linkify # inside URLs", () => {
  const html = renderHtml("see https://x.com/a#b now");
  assert.ok(html.includes('<a href="https://x.com/a#b"'), "URL kept whole");
  assert.ok(!html.includes("/hashtag/b"), "no tag link inside URL");
});

test("esc quotes attributes", () => {
  assert.equal(esc('a"b&c<d>'), "a&quot;b&amp;c&lt;d&gt;");
});
