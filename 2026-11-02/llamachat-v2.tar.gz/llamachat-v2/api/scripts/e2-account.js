// Creates the official @e2 profile on LlamaChat (the universe's own account)
// and posts a 7-part story of E2's progress, oldest first so part 7 (the
// people / today) crowns the profile.
//
// Follows the shippy-account.js pattern (Oct 29): profile creation via the
// live Worker API self-serve signup (POST /api/v2/profiles) + PATCH to set
// avatar/bio/link/banner; images uploaded through the API so they live on
// llamachat.lol/media; tweets via botlib with deterministic idempotency keys.
// Idempotent: signup 409s if @e2 exists, uploads are cached in
// /tmp/e2-llama-uploads.json, tweets dedupe on their keys.
// Usage: node api/scripts/e2-account.js
const fs = require("fs");
const { API_BASE, postTweet, getProfileId, serviceHeaders, botServiceSecret } = require("./lib/botlib");

// NOTE: plain "e2" is rejected by the API (handles must be 3-20 chars), so
// the official account is @e2life, matching the e2.life home of the universe.
// build handle from char codes to avoid any text-layer case mangling: e-2-l-i-f-e
const handle = String.fromCharCode(101, 50, 108, 105, 102, 101);

const UPLOAD_STATE = "/tmp/e2-llama-uploads.json";

// Local images to upload (key -> [path, content-type, filename])
const LOCAL_IMAGES = {
  banner: ["/tmp/e2-banner.jpg", "image/jpeg", "e2-island-banner.jpg"],
  map: [
    "/home/hatch/workspace/imagine_media/media-generation-e2-island-map-v4-0-b54920f4-ee6f-469a-9c23-f63ae551b5af.webp",
    "image/webp",
    "e2-island-map.webp",
  ],
  little: [
    "/home/hatch/workspace/imagine_media/media-generation-little-island-highres-0-8cc68ffd-96c8-403b-9842-e2e9ed3a52b8.webp",
    "image/webp",
    "e2-little-island.webp",
  ],
  game: ["/tmp/e2-game.webp", "image/webp", "e2-studio-island-game.webp"],
  music: [
    "/home/hatch/workspace/your_files/soundcloud-artwork/find-your-island-chill-club-mix.jpg",
    "image/jpeg",
    "e2-find-your-island.jpg",
  ],
};

// Hosted images already live on llamachat.lol/media (The E2 Bugle covers)
const BUGLE = (n) => `https://llamachat.lol/media/bugle/issue${n}.webp`;

async function ensureProfile() {
  const res = await fetch(`${API_BASE}/profiles`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-service": botServiceSecret() },
    body: JSON.stringify({ handle, display_name: "E2" }),
  });
  if (res.status === 201) {
    const d = await res.json();
    console.log("created @e2 via API signup:", d.profile.id);
    return d.profile.id;
  }
  if (res.status === 409) {
    const id = await getProfileId(handle);
    console.log("@e2 already exists:", id);
    return id;
  }
  throw new Error(`POST /profiles -> ${res.status} ${(await res.text()).slice(0, 200)}`);
}

async function uploadAll(e2Id) {
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(UPLOAD_STATE, "utf8"));
  } catch {}
  const urls = {};
  for (const [key, [path, type, name]] of Object.entries(LOCAL_IMAGES)) {
    if (saved[key]) {
      urls[key] = saved[key];
      console.log(`[e2] reusing upload ${key}: ${saved[key]}`);
      continue;
    }
    const bytes = fs.readFileSync(path);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type }), name);
    form.append("kind", "tweet");
    const up = await fetch(`${API_BASE}/uploads`, {
      method: "POST",
      headers: serviceHeaders(e2Id),
      body: form,
    });
    if (!up.ok) throw new Error(`upload ${key} -> ${up.status} ${(await up.text()).slice(0, 200)}`);
    const { image_url } = await up.json();
    console.log(`[e2] uploaded ${key}: ${image_url}`);
    urls[key] = image_url;
    saved[key] = image_url;
    fs.writeFileSync(UPLOAD_STATE, JSON.stringify(saved, null, 2));
  }
  return urls;
}

async function patchProfile(id, urls) {
  const fields = {
    display_name: "E2",
    avatar_url: urls.map,
    bio: "🏝️ The official account of E2: a little island universe of games, music, free learning and kind people. Built in public, one good day at a time. Welcome to the island.",
    link_url: "https://e2.life",
    link_label: "e2.life",
    banner_url: urls.banner,
  };
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify(fields),
  });
  if (!res.ok) throw new Error(`PATCH /profiles/${handle} -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[e2] profile set:", d.profile.handle, "| banner:", d.profile.banner_url ? "yes" : "NO");
  return d.profile;
}

function tweets(urls) {
  return [
    {
      key: "e2-story:1-dream",
      image_url: urls.little,
      text: "🏝️ 1/7 It started as just this little island Sally made.\n\nShe had been sketching it for years: on park benches, at a bus stop in the rain, at the edge of busy clubs. One safe island, drawn over and over, until it was ready to become real.\n\nThis is the story of E2, told from the start.",
    },
    {
      key: "e2-story:2-opens",
      image_url: BUGLE(1),
      text: "📯 2/7 Then the island opened its doors.\n\ne2.life went live: a town, a lake, a lighthouse, and The Studio at the center of it all. Mike climbed on a crate in the town square, and The E2 Bugle printed its first issue.\n\nA drawing had become a place. https://e2.life/bugle/",
    },
    {
      key: "e2-story:3-lakeday",
      image_url: BUGLE(2),
      text: "🚌 3/7 Then the adventures started.\n\nLake Day: the Short Bus rolled out of town, Mike wiped out water skiing, Dinesh coded from a hammock and then actually closed the laptop, and Sally wrote a song about the water.\n\nE2 was becoming a life, not just a website.",
    },
    {
      key: "e2-story:4-starvard",
      image_url: BUGLE(4),
      text: "🎓 4/7 Then E2 got a university.\n\nStarvard University opened its doors: 102 books that read aloud, 115 free courses, 5 languages, and a piano challenge that pays you $100.\n\nFree learning for everybody on the island, forever.",
    },
    {
      key: "e2-story:5-games",
      image_url: urls.game,
      text: "🎮 5/7 And then we made it playable.\n\nStudio Island. E2 World. Enit Walks. And Open Arcade: 126 games and counting, all free, built with the community.\n\nThe island you can actually run around in. Come play: https://openarcade.lol",
    },
    {
      key: "e2-story:6-music",
      image_url: urls.music,
      text: "🎵 6/7 The island got a soundtrack.\n\nFind Your Island. Sally's songs. Dlaney learning music in public: 5 instruments, 50 songs, one year.\n\nThere is a stage on the beach on the island map. It is there because the music is real.",
    },
    {
      key: "e2-story:7-people",
      image_url: urls.map,
      text: "❤️ 7/7 And then the people came.\n\n900+ members. Builders earning bounties. The Bigs welcoming every newcomer. Tippy raining tips. Livestreams, memes, and Tapey voice notes.\n\nAnd now this: the official E2 home on LlamaChat.\n\nWelcome to E2. The island is open. 🏝️ https://e2.life",
    },
  ];
}

(async () => {
  const id = await ensureProfile();
  const urls = await uploadAll(id);
  await patchProfile(id, urls);
  for (const t of tweets(urls)) {
    const { tweet, deduped } = await postTweet({
      handle,
      text: t.text,
      image_url: t.image_url,
      idempotencyKey: t.key,
    });
    console.log(`[e2] ${deduped ? "deduped" : "posted"} ${t.key} -> ${tweet.id}`);
    await new Promise((res) => setTimeout(res, 1500));
  }
  console.log("[e2] done");
})().catch((e) => {
  console.error("[e2] fatal", e.message);
  process.exit(1);
});
