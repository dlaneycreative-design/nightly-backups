import { useCallback, useEffect, useRef, useState } from "react";
import type { ApiClient, Profile, Tweet as TweetT } from "../lib/api.ts";
import { upsertTweets, getTweet, removeTweet } from "../lib/store.ts";
import { startRealtime, type Realtime } from "../lib/realtime.ts";
import { prefetch } from "../lib/lazyload.ts";
import { resolveImageUrl } from "../lib/images.ts";
import { recordFeedReady } from "../lib/perf.ts";
import { getCallerId } from "../lib/session.ts";
import { Tweet, tempToPending, type PendingViewTweet, type TweetLike } from "./Tweet.tsx";
import { Composer, type TempTweet } from "./Composer.tsx";

interface Props {
  api: ApiClient;
  apiBase: string;
  me: Profile | null;
  sort?: "chron" | "foryou";
}

/**
 * Virtualized feed: only ~30 rows in the DOM (visible + overscan), cursor
 * pagination 20/page, IntersectionObserver infinite scroll, "N new posts"
 * pill via polling, pull-to-refresh on mobile. Row positioning uses an
 * imperative transform in a layout effect (dynamic per-row geometry lives
 * in the DOM, not in JSX style attributes).
 */
export function Feed({ api, apiBase, me, sort = "chron" }: Props) {
  const [order, setOrder] = useState<string[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pulling, setPulling] = useState(false);
  const [pillCount, setPillCount] = useState(0);

  const cursorRef = useRef<string | null>(null);
  const hasMoreRef = useRef(true);
  const loadingRef = useRef(false);
  const pendingRef = useRef(new Map<string, PendingViewTweet>());
  const rtRef = useRef<Realtime | null>(null);
  const orderRef = useRef<string[]>([]);
  const touchStartY = useRef<number | null>(null);

  orderRef.current = order;

  const resolveItem = useCallback((id: string): TweetLike | undefined => {
    if (id.startsWith("temp:")) return pendingRef.current.get(id.slice(5));
    return getTweet(id);
  }, []);

  const loadMore = useCallback(async () => {
    if (loadingRef.current || !hasMoreRef.current) return;
    const cursor = cursorRef.current;
    loadingRef.current = true;
    setLoadingMore(true);
    setError(null);
    try {
      const { tweets, next_cursor } = await api.feed(cursor, 20, sort);
      upsertTweets(tweets);
      const ids = tweets.map((t) => t.id);
      setOrder((prev) => {
        const seen = new Set(prev);
        return [...prev, ...ids.filter((id) => !seen.has(id))];
      });
      cursorRef.current = next_cursor;
      hasMoreRef.current = next_cursor !== null;
      setHasMore(next_cursor !== null);
      for (const t of tweets) {
        if (t.image_url) prefetch(resolveImageUrl(t.image_url) ?? t.image_url);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load posts.");
    } finally {
      loadingRef.current = false;
      setLoadingMore(false);
      setInitialLoading(false);
    }
  }, [api]);

  const refresh = useCallback(async () => {
    cursorRef.current = null;
    hasMoreRef.current = true;
    setHasMore(true);
    pendingRef.current.clear();
    if (loadingRef.current) return;
    loadingRef.current = true;
    setError(null);
    try {
      const { tweets, next_cursor } = await api.feed(null, 20);
      upsertTweets(tweets);
      setOrder(tweets.map((t) => t.id));
      cursorRef.current = next_cursor;
      setHasMore(next_cursor !== null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load posts.");
    } finally {
      loadingRef.current = false;
      setInitialLoading(false);
    }
  }, [api]);

  // Initial load: STATIC seed (Dave's call Oct 8 2026). The first batch of
  // tweets is baked into /seed-feed.json at build time and served from the
  // edge cache (~50ms), so the homepage paints instantly with zero API
  // calls. The API is only hit when the user scrolls for more (loadMore),
  // pulls to refresh, or taps the "N new posts" pill.
  const loadSeed = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch("/seed-feed.json", { cache: "force-cache" });
      if (!res.ok) throw new Error(`seed ${res.status}`);
      const seed: { tweets: TweetT[]; next_cursor: string | null } = await res.json();
      upsertTweets(seed.tweets);
      setOrder(seed.tweets.map((t) => t.id));
      cursorRef.current = seed.next_cursor;
      hasMoreRef.current = seed.next_cursor !== null;
      setHasMore(seed.next_cursor !== null);
    } catch (e) {
      // Seed missing or stale build: fall back to a live refresh.
      await refresh();
      return;
    } finally {
      setInitialLoading(false);
    }
  }, [refresh]);

  // Initial load.
  useEffect(() => {
    void loadSeed();
  }, [loadSeed]);

  // Realtime: "N new posts" pill.
  useEffect(() => {
    const rt = startRealtime(api, () => {
      const first = orderRef.current[0];
      if (!first || first.startsWith("temp:")) return null;
      const t = getTweet(first);
      return t ? { id: t.id, created_at: t.created_at } : null;
    });
    rtRef.current = rt;
    const unsub = rt.subscribe(() => setPillCount(rt.newCount));
    return () => {
      unsub();
      rt.stop();
      rtRef.current = null;
    };
  }, [api]);

  const takeNewPosts = useCallback(() => {
    const rt = rtRef.current;
    if (!rt) return;
    const fresh = rt.acknowledge();
    setPillCount(0);
    if (fresh.length === 0) return;
    const ids = fresh.map((t) => t.id);
    setOrder((prev) => {
      const seen = new Set(prev);
      return [...ids.filter((id) => !seen.has(id)), ...prev];
    });
    window.scrollTo({ top: 0 });
  }, []);

  // Explicit "Load more" like X: no auto infinite scroll. The first 20
  // load on mount; the user clicks to fetch the next page.
  // Record page-generation time once the initial feed has painted.
  useEffect(() => {
    if (initialLoading || order.length === 0) return;
    const raf = requestAnimationFrame(() => recordFeedReady());
    return () => cancelAnimationFrame(raf);
  }, [initialLoading, order.length]);

  // ---- optimistic posting ----
  const onOptimistic = useCallback(
    (temp: TempTweet) => {
      const author = me
        ? { display_name: me.display_name, handle: me.handle, avatar_url: me.avatar_url }
        : { display_name: "You", handle: "you", avatar_url: null };
      pendingRef.current.set(temp.tempId, tempToPending(temp, author));
      setOrder((prev) => [`temp:${temp.tempId}`, ...prev]);
    },
    [me]
  );

  const onSettled = useCallback((tempId: string, tweet: TweetT | null) => {
    if (!tweet) {
      // Post failed and was queued for retry: the optimistic row stays up
      // showing "sending..." until the retry confirms it. Never poof.
      return;
    }
    pendingRef.current.delete(tempId);
    upsertTweets([tweet]);
    setOrder((prev) => prev.map((id) => (id === `temp:${tempId}` ? tweet.id : id)));
  }, []);

  const onPosted = useCallback((_t: TweetT) => {
    // Settled via onSettled; nothing extra needed.
  }, []);

  const onDeleted = useCallback((id: string) => {
    removeTweet(id);
    setOrder((prev) => prev.filter((x) => x !== id));
  }, []);

  // ---- pull to refresh ----
  const onTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY === 0) touchStartY.current = e.touches[0].clientY;
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    if (e.touches[0].clientY - touchStartY.current > 90) setPulling(true);
  };
  const onTouchEnd = () => {
    if (pulling) {
      setPulling(false);
      void refresh();
    }
    touchStartY.current = null;
  };

  return (
    <div
      className="feed"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {pillCount > 0 ? (
        <button type="button" className="newposts-pill" onClick={takeNewPosts}>
          {pillCount} new post{pillCount === 1 ? "" : "s"}
        </button>
      ) : null}
      {pulling ? <div className="pullhint">Release to refresh</div> : null}
      {getCallerId() ? (
        <Composer
          api={api}
          apiBase={apiBase}
          getCallerId={getCallerId}
          avatarUrl={me?.avatar_url ?? null}
          onOptimistic={onOptimistic}
          onPosted={onPosted}
          onSettled={onSettled}
        />
      ) : null}
      {initialLoading ? (
        <div aria-label="Loading feed">
          {[0, 1, 2, 3, 4].map((i) => (
            <div className="skel-tweet" key={i}>
              <div className="skel skel-avatar" />
              <div className="skel-lines">
                <div className="skel skel-line short" />
                <div className="skel skel-line" />
                <div className="skel skel-line" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="feed-simple">
          {order.map((id) => {
            const tweet = resolveItem(id);
            if (!tweet) return null;
            return <Tweet key={id} tweet={tweet} api={api} onDeleted={onDeleted} />;
          })}
        </div>
      )}
      {error ? (
        <div className="errorbox" role="alert">
          <h2>Feed hiccup</h2>
          <p>{error}</p>
          <button type="button" className="ghost" onClick={() => void loadMore()}>
            Try again
          </button>
        </div>
      ) : null}
      <div className="feed-sentinel" aria-hidden={!hasMore && order.length > 0 ? "false" : "true"}>
        {!initialLoading && hasMore && order.length > 0 ? (
          <button
            type="button"
            className="loadmore"
            onClick={() => void loadMore()}
            disabled={loadingMore}
          >
            {loadingMore ? "Loading..." : "Load more"}
          </button>
        ) : null}
        {!initialLoading && !hasMore && order.length > 0 ? "You are all caught up" : null}
      </div>
      {!initialLoading && order.length === 0 && !error ? (
        <div className="empty">
          <h2>Nothing here yet</h2>
          <p>Be the first to post. The feed is waiting.</p>
        </div>
      ) : null}
    </div>
  );
}

// TweetImage and other helpers below
