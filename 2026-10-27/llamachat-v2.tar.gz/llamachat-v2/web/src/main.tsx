import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App.tsx";
import "./styles/tokens.css";
import "./styles/components.css";
import "./styles/overrides.css";

const root = document.getElementById("root");
if (!root) throw new Error("missing #root");
createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Register service worker for home-screen app: instant shell, offline fallback.
// (Dave's call Oct 9 2026: home screen icon was buggy, SW was never registered.)
// Only the root deployment (Llama Chat) ships a service worker; themed
// subpath deployments (Starvard at /feed) skip it for V0.1.
if ("serviceWorker" in navigator && import.meta.env.PROD && (import.meta.env.BASE_URL || "/") === "/") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
