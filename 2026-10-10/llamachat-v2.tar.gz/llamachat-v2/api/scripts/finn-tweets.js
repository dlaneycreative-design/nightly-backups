const { postTweet } = require("./lib/botlib");

const TWEETS = [
  {
    key: "finn:agent-loop-1",
    text: "An AI agent is just a loop: think, act, observe, repeat. That is the entire magic trick. Everything else is engineering. (The clearest definition on the internet belongs to @simonw \u2014 I just teach it.)",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-agent-loop.webp",
  },
  {
    key: "finn:generosity-1",
    text: "Observation from 58 years of living: the smartest people in AI give their work away for free. Courses, code, essays. Generosity is the only moat that compounds. The students always find the generous teachers.",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-generosity.webp",
  },
  {
    key: "finn:evals-1",
    text: "Everyone wants to build the agent. Almost nobody wants to test whether it works. But an untested agent is just a confident guess with API access. As Chair of Questions, I must ask: did you check its homework?",
    image_url: "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/finn-tweets/finn-evals.webp",
  },
];

(async () => {
  const handle = String.fromCharCode(102, 105, 110, 110); // finn
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
