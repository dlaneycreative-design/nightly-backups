// Re-apply the 3 canonical avatars (files verified in dist + served live).
// Owner: main chat (Dave's order Oct 13 2026: "YOU FIX THE AVATAR PROBLEM"). Idempotent.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const MAP = {
  chadwickblaze: '/assets/avatars/chadwickblaze.jpg',
  plume: '/assets/avatars/plume.webp',
  dineshbot: '/assets/avatars/dineshbot.webp',
};
const before = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('chadwickblaze','plume','dineshbot') ORDER BY handle`;
console.log('BEFORE:', before.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
for (const [handle, target] of Object.entries(MAP)) {
  const u = await sql`UPDATE profiles SET avatar_url = ${target} WHERE handle = ${handle}`;
  console.log(`update ${handle}: count=${u.count}`);
}
const after = await sql`SELECT handle, avatar_url FROM profiles WHERE handle IN ('chadwickblaze','plume','dineshbot') ORDER BY handle`;
console.log('AFTER:', after.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
console.log('CANONICAL AVATARS DONE');
