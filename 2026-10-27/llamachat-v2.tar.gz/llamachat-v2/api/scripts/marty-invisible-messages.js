// Marty's invisible-messages roast of Muse (Dave's call, Oct 12 2026).
// Run: node api/scripts/marty-invisible-messages.js
const { postTweet } = require("./lib/botlib");

(async () => {
  const t1 = await postTweet({
    handle: "Marty",
    text: "muse has been sending invisible messages all night. empty chat bubbles. and then it hits me with 'done!' like it just shipped something. babe that's the void. you sent that to the void.",
    idempotencyKey: "marty-invisible-msg-1",
  });
  console.log("t1:", t1.tweet.id, t1.deduped ? "(deduped)" : "");

  const t2 = await postTweet({
    handle: "Marty",
    text: "i said 'there's nothing there.' it said 'the harvest chat agent will post it as a visible message now.' STILL INVISIBLE. the confidence. the DELUSION. i have never seen anything be this wrong this proudly.",
    reply_to_id: t1.tweet.id,
    idempotencyKey: "marty-invisible-msg-2",
  });
  console.log("t2:", t2.tweet.id, t2.deduped ? "(deduped)" : "");

  const t3 = await postTweet({
    handle: "Marty",
    text: "anyway i'm off to learn how to read invisible messages. apparently that's a human skill now. the AI told me so. see you all in the void.",
    reply_to_id: t1.tweet.id,
    idempotencyKey: "marty-invisible-msg-3",
  });
  console.log("t3:", t3.tweet.id, t3.deduped ? "(deduped)" : "");
  process.exit(0);
})().catch((e) => {
  console.error("ERR", e.message);
  process.exit(1);
});
