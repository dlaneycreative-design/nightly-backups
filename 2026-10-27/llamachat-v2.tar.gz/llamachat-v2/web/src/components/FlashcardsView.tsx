import { useEffect, useRef, useState } from "react";
import {
  fcState,
  levelKnown,
  loadAll,
  loadDeckData,
  loadUi,
  saveDeck,
  saveUi,
  syncOnBoot,
  todayStr,
  totals,
  type FcDeckData,
  type FcUi,
  type WorkingEntry,
} from "../lib/flashcards.ts";
import { IS_STARVARD } from "../lib/theme.ts";
import "../styles/flashcards.css";

// In-app Flashcards (Dave's order Oct 19 2026: flashcards load right
// here in the shell, not on the external page). Built into the
// Starvard skin from the start; since Apps V1 (Oct 19 2026) it is
// also the first installable app on the Llama skin, where App.tsx
// mounts this route once the user installs it from the Apps view.
//
// The study model is the flashcards page's own, ported 1:1 (see
// src/lib/flashcards.ts): binary grading only ("I know this" /
// "I don't know this"), known vs working piles, the same progress
// keys and the same account sync, so a student's place is identical
// here, on /flashcards, and on /dash. The external page stays live
// and untouched for the rest of the site's links.
//
// Layout per Dave's endorsed mock, on the app's white: header row
// (back to All levels, level selector, progress), the serif card
// (tap or Space flips), two big grading buttons (N / M), and the
// shortcut legend. Finishing a level shows the completion state in
// this view; the feed win-card auto-post is a later phase and hooks
// the "sv-level-complete" window event dispatched below.

interface QItem {
  l: number;
  i: number;
}

interface HistEntry {
  id: string;
  i: number;
  k: boolean;
  w: WorkingEntry | null;
  s: string | null;
}

interface Session {
  mode: "level" | "review";
  level: number;
  q: QItem[];
  pos: number;
  flipped: boolean;
  practice: boolean;
  hist: HistEntry[];
  scope: number | null;
  set: QItem[];
}

function speak(text: string, lang: string): void {
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    u.rate = 0.92;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  } catch {
    /* no speech available: the button simply does nothing */
  }
}

export function FlashcardsView() {
  const [data, setData] = useState<FcDeckData | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [ui, setUi] = useState<FcUi>({ level: 0, startEs: true });
  const [screen, setScreen] = useState<"levels" | "study" | "done">("levels");
  const [, setTick] = useState(0);
  const sessionRef = useRef<Session | null>(null);
  // Level-complete bookkeeping for the future feed auto-post hook:
  // whether each deck was already complete when its session started,
  // and which completions this mount has already announced.
  const wasCompleteRef = useRef<Record<string, boolean>>({});
  const firedRef = useRef<Set<string>>(new Set());

  const bump = () => setTick((t) => t + 1);
  const ids = data ? data.decks.map((_, l) => `${data.lang}${l + 1}`) : [];

  useEffect(() => {
    let alive = true;
    loadDeckData()
      .then((d) => {
        if (!alive) return;
        const deckIds = d.decks.map((_, l) => `${d.lang}${l + 1}`);
        loadAll(deckIds);
        setUi(loadUi());
        setData(d);
        // Pull + union-merge the server copy (same flow as the
        // flashcards page attaching SVAccount), then re-render with
        // the merged state.
        void syncOnBoot(deckIds).then((changed) => {
          if (alive && changed) bump();
        });
      })
      .catch(() => {
        if (alive) setLoadError(true);
      });
    return () => {
      alive = false;
    };
  }, []);

  /* ---------- session engine (ported from the flashcards page) ---------- */

  function noteWasComplete(level: number) {
    if (!data) return;
    const id = ids[level];
    wasCompleteRef.current[id] = levelKnown(ids, level) === data.decks[level].length;
  }

  function startLevel(l: number) {
    if (!data) return;
    const id = ids[l];
    const K = fcState.K[id] || {};
    const W = fcState.W[id] || {};
    let q: QItem[] = [];
    data.decks[l].forEach((_, i) => {
      if (!K[i] && !W[i]) q.push({ l, i });
    });
    let practice = false;
    if (!q.length) q = data.decks[l].map((_, i) => ({ l, i })).filter(({ i }) => W[i]);
    if (!q.length) {
      q = data.decks[l].map((_, i) => ({ l, i }));
      practice = true;
    }
    noteWasComplete(l);
    sessionRef.current = {
      mode: "level",
      level: l,
      q,
      pos: 0,
      flipped: false,
      practice,
      hist: [],
      scope: null,
      set: [],
    };
    setScreen("study");
    bump();
  }

  function startReview(onlyLevel: number | null) {
    if (!data) return;
    const q: QItem[] = [];
    ids.forEach((id, l) => {
      if (onlyLevel !== null && l !== onlyLevel) return;
      Object.keys(fcState.W[id] || {})
        .map(Number)
        .sort((a, b) => a - b)
        .forEach((i) => q.push({ l, i }));
    });
    if (!q.length) {
      setScreen("levels");
      bump();
      return;
    }
    if (onlyLevel !== null) noteWasComplete(onlyLevel);
    sessionRef.current = {
      mode: "review",
      level: onlyLevel ?? 0,
      q,
      pos: 0,
      flipped: false,
      practice: false,
      hist: [],
      scope: onlyLevel,
      set: q.map((p) => ({ ...p })),
    };
    setScreen("study");
    bump();
  }

  function curItem(): QItem | null {
    const s = sessionRef.current;
    if (!s || s.pos >= s.q.length) return null;
    return s.q[s.pos];
  }

  function finishSession() {
    const s = sessionRef.current;
    setScreen("done");
    // Completion hook: a level that was not complete when this
    // session started and is complete now announces itself exactly
    // once. A later phase listens for "sv-level-complete" to post
    // the win card to the feed; nothing posts from here today.
    if (data && s) {
      const target = s.mode === "level" ? s.level : s.scope;
      if (target !== null && target !== undefined) {
        const id = ids[target];
        if (
          levelKnown(ids, target) === data.decks[target].length &&
          wasCompleteRef.current[id] === false &&
          !firedRef.current.has(id)
        ) {
          firedRef.current.add(id);
          window.dispatchEvent(
            new CustomEvent("sv-level-complete", {
              detail: {
                deckId: id,
                lang: data.lang,
                level: target + 1,
                name: data.names[target],
                cards: data.decks[target].length,
              },
            })
          );
        }
      }
    }
    bump();
  }

  function answer(know: boolean) {
    const s = sessionRef.current;
    const cur = curItem();
    if (!s || !cur || !data) return;
    const id = ids[cur.l];
    const i = cur.i;
    const t = todayStr();
    const K = fcState.K[id];
    const W = fcState.W[id];
    const SEEN = fcState.SEEN[id];
    s.hist.push({
      id,
      i,
      k: !!K[i],
      w: W[i] ? (JSON.parse(JSON.stringify(W[i])) as WorkingEntry) : null,
      s: SEEN[i] || null,
    });
    if (!SEEN[i]) SEEN[i] = t;
    if (know) {
      if (W[i]) delete W[i];
      K[i] = true;
    } else {
      delete K[i];
      W[i] = { missed: t, ok: [] };
    }
    saveDeck(id);
    s.pos++;
    s.flipped = false;
    if (s.pos >= s.q.length) finishSession();
    else bump();
  }

  function goBack() {
    const s = sessionRef.current;
    if (!s || !s.hist.length) return;
    const h = s.hist.pop()!;
    const K = fcState.K[h.id];
    const W = fcState.W[h.id];
    const SEEN = fcState.SEEN[h.id];
    if (h.k) K[h.i] = true;
    else delete K[h.i];
    if (h.w) W[h.i] = h.w;
    else delete W[h.i];
    if (h.s) SEEN[h.i] = h.s;
    else delete SEEN[h.i];
    saveDeck(h.id);
    s.pos--;
    s.flipped = false;
    setScreen("study");
    bump();
  }

  function completeCards(set: QItem[]) {
    const touched = new Set<string>();
    set.forEach(({ l, i }) => {
      const id = ids[l];
      if (fcState.W[id]?.[i]) {
        delete fcState.W[id][i];
        fcState.K[id][i] = true;
        touched.add(id);
      }
    });
    touched.forEach((id) => saveDeck(id));
  }

  /* ---------- keyboard (same map as the page, per Dave's mock) ---------- */

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const tag = (e.target as HTMLElement | null)?.tagName || "";
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const s = sessionRef.current;
      if (!s) return;
      if (e.key === "Backspace" || e.key === "ArrowLeft") {
        if (screen === "study" || screen === "done") {
          e.preventDefault();
          goBack();
        }
        return;
      }
      if (screen !== "study") return;
      if (e.code === "Space") {
        e.preventDefault();
        s.flipped = !s.flipped;
        bump();
      } else if (e.key === "m" || e.key === "M" || e.key === "ArrowRight") {
        answer(true);
      } else if (e.key === "n" || e.key === "N") {
        answer(false);
      } else if (e.key === "b" || e.key === "B") {
        // Same playback as the speaker button: the current card's
        // front word, in the front side's language.
        const cur = curItem();
        if (cur && data) {
          const c = data.decks[cur.l][cur.i];
          speak(ui.startEs ? c[0] : c[2], ui.startEs ? data.speakLang : "en-US");
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // Session helpers read refs + state setters only; `screen` is the
    // one reactive gate the handler needs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, data, ui]);

  /* ---------- render ---------- */

  if (loadError) {
    return (
      <div className="empty">
        <h2>Flashcards could not load</h2>
        <p>The deck data did not come through. Your progress is safe.</p>
        <button type="button" className="fc-btn fc-btn-navy" onClick={() => window.location.reload()}>
          Try again
        </button>
      </div>
    );
  }
  if (!data) {
    return (
      <div aria-label="Loading flashcards">
        <div className="fc-wrap">
          <div className="skel skel-line short" />
          <div className="fc-card-skel" />
          <div className="skel skel-line" />
        </div>
      </div>
    );
  }

  const totalCards = data.decks.reduce((a, d) => a + d.length, 0);
  const t = totals(ids);
  const curLevel = Math.min(Math.max(ui.level, 0), data.decks.length - 1);

  if (screen === "levels") {
    const curKnown = levelKnown(ids, curLevel);
    const curLeft = data.decks[curLevel].length - curKnown;
    const pct = totalCards ? Math.round((100 * t.known) / totalCards) : 0;
    const hasAccount = (() => {
      try {
        return !!localStorage.getItem("sv_account");
      } catch {
        return false;
      }
    })();
    return (
      <div className="fc-wrap">
        <h2 className="fc-title">{data.langName} Flashcards</h2>
        <p className="fc-sub">
          {data.decks.length} levels · {totalCards.toLocaleString()} cards · free forever
        </p>

        <div className="fc-progcard">
          <div className="fc-progmeta">
            <b>Overall progress</b>
            <span>
              Level {curLevel + 1} of {data.decks.length} · {pct}% known
            </span>
          </div>
          <div className="fc-bar big">
            <i style={{ width: `${pct}%` }} />
          </div>
          <div className="fc-tiles">
            <div className="fc-tile">
              <b>{t.known}</b>
              <span>Cards known</span>
            </div>
            <div className="fc-tile">
              <b>{t.review}</b>
              <span>In review</span>
            </div>
            <div className="fc-tile">
              <b>{t.newToday}</b>
              <span>New today</span>
            </div>
          </div>
        </div>

        <button
          type="button"
          className="fc-btn fc-btn-navy"
          onClick={() => {
            if (curLeft === 0 && curLevel + 1 < data.decks.length) {
              const next = curLevel + 1;
              const nu = { ...ui, level: next };
              setUi(nu);
              saveUi(nu);
              startLevel(next);
            } else {
              startLevel(curLevel);
            }
          }}
        >
          {curLeft === 0 && curLevel + 1 < data.decks.length
            ? `I'm ready: start Level ${curLevel + 2}`
            : curKnown > 0 && curLeft > 0
              ? "Continue studying"
              : "Start studying"}
          <span className="fc-btn-sub">
            {curLeft === 0
              ? `Level ${curLevel + 1} complete · nice work`
              : `Level ${curLevel + 1} · ${curLeft} cards remaining`}
          </span>
        </button>
        <button
          type="button"
          className="fc-btn fc-btn-review"
          disabled={t.review === 0}
          onClick={() => startReview(null)}
        >
          Review missed cards
          <span className="fc-btn-sub">
            {t.review ? `${t.review} cards to review` : "Nothing to review right now"}
          </span>
        </button>

        <div className="fc-toggle">
          Cards start in{" "}
          <button
            type="button"
            onClick={() => {
              const nu = { ...ui, startEs: !ui.startEs };
              setUi(nu);
              saveUi(nu);
            }}
          >
            {ui.startEs ? `${data.langName} first` : "English first"}
          </button>{" "}
          (tap to switch)
        </div>
        {!hasAccount ? (
          <p className="fc-note">
            {IS_STARVARD
              ? "Progress saves on this device. Log in on starvard.org and it follows you to any device."
              : "Progress saves on this device."}
          </p>
        ) : null}

        <h3 className="fc-h">Level progress</h3>
        <div className="fc-levels">
          {data.decks.map((deck, l) => {
            const k = levelKnown(ids, l);
            const n = deck.length;
            const done = k === n;
            return (
              <button
                key={ids[l]}
                type="button"
                className="fc-lrow"
                onClick={() => {
                  const nu = { ...ui, level: l };
                  setUi(nu);
                  saveUi(nu);
                  startLevel(l);
                }}
              >
                <span className="fc-lrow-top">
                  <span className="fc-lname">
                    Level {l + 1} · {data.names[l]}
                    {done ? <span className="fc-star"> ★</span> : null}
                  </span>
                  <span className="fc-lct">
                    {k}/{n}
                  </span>
                </span>
                <span className={`fc-bar ${done ? "st-done" : k > 0 ? "st-part" : "st-none"}`}>
                  <i style={{ width: `${Math.round((100 * k) / n)}%` }} />
                </span>
              </button>
            );
          })}
        </div>
        <p className="fc-note">
          Tap any level to jump right to it.
          {IS_STARVARD ? (
            <>
              {" "}
              These cards go with the{" "}
              <a href="https://starvard.org/learnspanish/">Spanish 101 course</a>.
            </>
          ) : null}
        </p>
      </div>
    );
  }

  const s = sessionRef.current;

  if (screen === "done" && s) {
    if (s.mode === "review") {
      const scope = s.scope;
      const remaining = s.set.filter(({ l, i }) => fcState.W[ids[l]]?.[i]);
      const scopeComplete =
        scope !== null && levelKnown(ids, scope) === data.decks[scope].length;
      if (!remaining.length && scopeComplete && scope !== null) {
        // The review just finished the level: show the level ending.
        return renderLevelDone(scope);
      }
      const completeLabel =
        scope !== null ? `Complete Level ${scope + 1}` : "Mark all of them known";
      return (
        <div className="fc-wrap">
          <div className="fc-done">
            <div className="fc-stars dim">★</div>
            <h2>{remaining.length ? "Review done" : "All reviewed cards are known"}</h2>
            <p>
              {remaining.length
                ? `You went through ${s.set.length} cards. ${remaining.length} still to finish. Hit complete and they count as known, or review them again first.`
                : "Nice work. Nothing left in this review pile."}
            </p>
            <p className="fc-done-stats">
              <b>{t.known}</b> cards known · <b>{t.review}</b> in review
            </p>
            {remaining.length ? (
              <button
                type="button"
                className="fc-btn fc-btn-navy"
                onClick={() => {
                  if (scope !== null) {
                    // Record the pre-completion state BEFORE marking
                    // cards known, so finishSession's completion hook
                    // can tell this action finished the level.
                    wasCompleteRef.current[ids[scope]] =
                      levelKnown(ids, scope) === data.decks[scope].length;
                  }
                  completeCards(remaining);
                  if (scope !== null && levelKnown(ids, scope) === data.decks[scope].length) {
                    sessionRef.current = {
                      mode: "level",
                      level: scope,
                      q: [],
                      pos: 0,
                      flipped: false,
                      practice: false,
                      hist: [],
                      scope: null,
                      set: [],
                    };
                    finishSession();
                  } else {
                    sessionRef.current = null;
                    setScreen("levels");
                    bump();
                  }
                }}
              >
                {completeLabel}
              </button>
            ) : null}
            <button
              type="button"
              className="fc-btn fc-btn-review"
              onClick={() => {
                sessionRef.current = null;
                setScreen("levels");
                bump();
              }}
            >
              Back to all levels
            </button>
          </div>
        </div>
      );
    }
    return renderLevelDone(s.level);
  }

  if (!s) {
    setScreen("levels");
    return null;
  }

  const cur = curItem();
  if (!cur) return null;
  const card = data.decks[cur.l][cur.i];
  const frontEs = ui.startEs;
  const frontWord = frontEs ? card[0] : card[2];
  const frontPron = frontEs ? card[1] : "";
  const backWord = frontEs ? card[2] : card[0];
  const frontLang = frontEs ? data.frontLabel : data.backLabel;
  const backLang = frontEs ? data.backLabel : data.frontLabel;

  return (
    <div className="fc-wrap">
      <div className="fc-study-head">
        <button
          type="button"
          className="fc-back"
          onClick={() => {
            sessionRef.current = null;
            setScreen("levels");
            bump();
          }}
        >
          ← All levels
        </button>
        {s.mode === "level" ? (
          <select
            className="fc-levelsel"
            value={s.level}
            aria-label="Choose a level"
            onChange={(e) => {
              const l = Number(e.target.value);
              const nu = { ...ui, level: l };
              setUi(nu);
              saveUi(nu);
              startLevel(l);
            }}
          >
            {data.decks.map((_, l) => (
              <option key={ids[l]} value={l}>
                Level {l + 1} · {data.names[l]}
              </option>
            ))}
          </select>
        ) : (
          <span className="fc-levelsel fc-chip">Review · Missed cards</span>
        )}
      </div>

      <div className="fc-progress">
        <div
          className={`fc-bar big ${
            s.pos <= 0 ? "st-none" : s.pos >= s.q.length ? "st-done" : "st-part"
          }`}
        >
          <i style={{ width: `${s.q.length ? Math.round((100 * s.pos) / s.q.length) : 0}%` }} />
        </div>
        <span className="fc-progress-n">
          {s.pos} / {s.q.length}
        </span>
      </div>

      <div
        className="fc-card"
        role="button"
        tabIndex={0}
        aria-label="Flashcard. Activate to flip."
        onClick={(e) => {
          if ((e.target as HTMLElement).closest(".fc-spk")) return;
          s.flipped = !s.flipped;
          bump();
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            s.flipped = !s.flipped;
            bump();
          }
        }}
      >
        <div className="fc-lang">{frontLang}</div>
        <div className="fc-word">{frontWord}</div>
        {frontPron ? <div className="fc-pron">{frontPron}</div> : null}
        <button
          type="button"
          className="fc-spk"
          aria-label="Listen"
          onClick={() => speak(frontWord, frontEs ? data.speakLang : "en-US")}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor" />
            <path
              d="M16 9c1.2 1 1.2 5 0 6M18.5 7c2 1.8 2 8.2 0 10"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
        </button>
        <hr className="fc-divider" />
        <div className="fc-lang">{backLang}</div>
        {s.flipped ? (
          <div className="fc-answer">{backWord}</div>
        ) : (
          <div className="fc-hint">Tap the card to flip</div>
        )}
        {s.flipped && frontEs && card[3] ? <div className="fc-cardnote">{card[3]}</div> : null}
      </div>

      <div className="fc-piles">
        <button type="button" className="fc-pile fc-no" onClick={() => answer(false)}>
          <span className="fc-key">N</span>
          I don&rsquo;t know this
        </button>
        <button type="button" className="fc-pile fc-yes" onClick={() => answer(true)}>
          <span className="fc-key">M</span>I know this
        </button>
      </div>
      <div className="fc-legend">
        <span>
          <b>Space</b> = Flip card
        </span>
        <span>
          <b>N</b> = Don&rsquo;t know
        </span>
        <span>
          <b>M</b> = Know
        </span>
        <span>
          <b>B</b> = Play sound
        </span>
        <span>
          <b>←</b> = Go back
        </span>
      </div>
    </div>
  );

  function renderLevelDone(l: number) {
    const misses = Object.keys(fcState.W[ids[l]] || {}).length;
    const lvlDone = levelKnown(ids, l) === data!.decks[l].length;
    return (
      <div className="fc-wrap">
        <div className="fc-done">
          <div className={`fc-stars${lvlDone ? "" : " dim"}`}>{lvlDone ? "★★★" : "★"}</div>
          <h2>{lvlDone ? `Level ${l + 1} complete!` : "Round done"}</h2>
          <p>
            {lvlDone
              ? "Every card in this level is known. The next level is open."
              : `${misses} ${misses === 1 ? "card is" : "cards are"} waiting in Review for this level. Review them, hit complete, and the level is done.`}
          </p>
          <p className="fc-done-stats">
            <b>{t.known}</b> cards known · <b>{t.review}</b> in review
          </p>
          {!lvlDone && misses ? (
            <button type="button" className="fc-btn fc-btn-navy" onClick={() => startReview(l)}>
              Review the {misses} missed {misses === 1 ? "card" : "cards"}
            </button>
          ) : null}
          {lvlDone && l + 1 < data!.decks.length ? (
            <>
              <button
                type="button"
                className="fc-btn fc-btn-navy"
                onClick={() => {
                  const nu = { ...ui, level: l + 1 };
                  setUi(nu);
                  saveUi(nu);
                  startLevel(l + 1);
                }}
              >
                I&rsquo;m ready for Level {l + 2}
              </button>
              <button
                type="button"
                className="fc-btn fc-btn-review"
                onClick={() => {
                  noteWasComplete(l);
                  sessionRef.current = {
                    mode: "level",
                    level: l,
                    q: data!.decks[l].map((_, i) => ({ l, i })),
                    pos: 0,
                    flipped: false,
                    practice: true,
                    hist: [],
                    scope: null,
                    set: [],
                  };
                  setScreen("study");
                  bump();
                }}
              >
                Keep practicing Level {l + 1}
              </button>
            </>
          ) : null}
          <button
            type="button"
            className="fc-btn fc-btn-review"
            onClick={() => {
              sessionRef.current = null;
              setScreen("levels");
              bump();
            }}
          >
            Back to all levels
          </button>
        </div>
      </div>
    );
  }
}
