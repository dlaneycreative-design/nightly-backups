// Per-deployment theme, selected at BUILD time (architecture plan: one
// app, two skins, never a fork). The default build is Llama Chat at
// llamachat.lol, and every value here reduces to exactly today's
// behavior there. The Starvard build (vite.config.starvard.ts with
// VITE_THEME=starvard) bakes the Starvard skin instead: same components,
// same store, same API, different tokens, logo, and labels.

function env(key: string): string | undefined {
  try {
    return (import.meta as unknown as { env?: Record<string, string | undefined> }).env?.[key];
  } catch {
    return undefined;
  }
}

export const THEME_NAME = env("VITE_THEME") || "llama";
export const IS_STARVARD = THEME_NAME === "starvard";

/** Mount prefix of this deployment: "" at a domain root, "/feed" on Starvard. */
export const APP_BASE = (env("BASE_URL") || "/").replace(/\/$/, "");

export const SITE_NAME = IS_STARVARD ? "Starvard" : "LlamaChat";

/** The one door in (Dave's call Nov 1 2026): log in with Discord via
    e2-auth. The API auto-creates a LlamaChat profile on first login,
    so there is no signup form and nobody needs to message anyone. */
export const DISCORD_LOGIN_URL = "https://e2-auth.dlaneycreative.workers.dev/auth/login?to=llamachat";
export const LOGO_URL = `${APP_BASE}${IS_STARVARD ? "/assets/avatars/starvard.webp" : "/llama-logo.avif"}`;
export const HOME_URL = `${APP_BASE}/`;

/** Prefix an app-owned absolute path ("/assets/...") with the mount base. */
export function appPath(path: string): string {
  return path.startsWith("/") ? `${APP_BASE}${path}` : path;
}

/** Canonical public profile URL path for a handle: llamachat.lol/Dave,
    llamachat.lol/Sam. Short, root-level, first letter capitalized the
    way people write names. Profile lookups are case-insensitive end to
    end (store + API), so /dave and /Dave are the same person, rendered
    in place: this is the real URL, never a redirect or a forward.
    (Dave's call, Oct 31 2026.) */
export function profilePath(handle: string, tab?: string): string {
  const h = String(handle || "").trim().replace(/^@/, "");
  const nice = h ? h.charAt(0).toUpperCase() + h.slice(1) : h;
  return tab ? `/${nice}/${tab}` : `/${nice}`;
}

/** Normalize an in-app link target that may still use the old
    /profile/<handle>[/<tab>] form (stored post HTML, older builds)
    to the canonical short form, in place. */
export function shortProfilePath(path: string): string {
  const m = /^\/profile\/([^/]+)(\/.*)?$/.exec(path);
  if (!m) return path;
  return profilePath(m[1]) + (m[2] || "");
}
