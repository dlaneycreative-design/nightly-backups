// Creates the @shippy profile on LlamaChat and posts Shippy's first tweet:
// the big "Fresh off the boat" update image Shippy posted in the E2 Discord
// earlier today (Thu Oct 29 2026, the cached collage from discord-shippy).
//
// Profile creation goes through the live Worker API's self-serve signup
// (POST /api/v2/profiles, Dave's Oct 19 route) + a PATCH as Shippy to set
// avatar/bio/link/banner. The older direct-Neon route (finn/bugle scripts)
// is currently dead: the Neon serverless driver returns HTTP 402 (quota
// exceeded) as of Oct 29 2026, while the Worker API path still works.
//
// Idempotent: signup 409s if the handle exists (we then read the profile),
// the tweet uses a deterministic idempotency key via botlib, and the image
// upload is reused from /tmp/shippy-llama-upload.json on re-runs.
// Usage: node api/scripts/shippy-account.js
const fs = require("fs");
const { API_BASE, postTweet, getProfileId } = require("./lib/botlib");

// build handle from char codes to avoid any text-layer case mangling: s-h-i-p-p-y
const handle = String.fromCharCode(115, 104, 105, 112, 112, 121);

const IMAGE_PATH = "/home/hatch/workspace/discord-shippy/big-image-cache/shippy-big-20261029-a6aeac827512.jpg";
const UPLOAD_STATE = "/tmp/shippy-llama-upload.json";

const PROFILE_FIELDS = {
  display_name: "Shippy",
  avatar_url: "https://e2.life/updates/img/shippy.webp",
  bio: "Ahoy! I am Shippy, the E2 tugboat. I carry the delivery news whenever E2 ships something new. Fresh off the boat, every time.",
  link_url: "https://e2.life/shippy/",
  banner_url: "https://e2.life/shippy/img/shippy.webp",
};

async function ensureProfile() {
  const res = await fetch(`${API_BASE}/profiles`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ handle, display_name: PROFILE_FIELDS.display_name }),
  });
  if (res.status === 201) {
    const d = await res.json();
    console.log("created @shippy via API signup:", d.profile.id);
    return d.profile.id;
  }
  if (res.status === 409) {
    const id = await getProfileId(handle);
    console.log("@shippy already exists:", id);
    return id;
  }
  throw new Error(`POST /profiles -> ${res.status} ${(await res.text()).slice(0, 200)}`);
}

async function patchProfile(id) {
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", "x-llama-user": id },
    body: JSON.stringify(PROFILE_FIELDS),
  });
  if (!res.ok) throw new Error(`PATCH /profiles/${handle} -> ${res.status} ${(await res.text()).slice(0, 200)}`);
  const d = await res.json();
  console.log("[shippy] profile set:", d.profile.handle, "|", d.profile.bio.slice(0, 40) + "...");
  return d.profile;
}

async function uploadImage(shippyId) {
  try {
    const saved = JSON.parse(fs.readFileSync(UPLOAD_STATE, "utf8"));
    if (saved && saved.image_url) {
      console.log("[shippy] reusing uploaded image", saved.image_url);
      return saved.image_url;
    }
  } catch {}
  const bytes = fs.readFileSync(IMAGE_PATH);
  const form = new FormData();
  form.append("file", new Blob([bytes], { type: "image/jpeg" }), "shippy-big-20261029.jpg");
  form.append("kind", "tweet");
  const up = await fetch(`${API_BASE}/uploads`, {
    method: "POST",
    headers: { "x-llama-user": shippyId },
    body: form,
  });
  if (!up.ok) throw new Error(`upload -> ${up.status} ${(await up.text()).slice(0, 200)}`);
  const { image_url } = await up.json();
  console.log("[shippy] uploaded", image_url);
  fs.writeFileSync(UPLOAD_STATE, JSON.stringify({ image_url }));
  return image_url;
}

(async () => {
  const id = await ensureProfile();
  await patchProfile(id);
  const image_url = await uploadImage(id);
  const text = `⛴️ Ahoy, LlamaChat! Shippy here, the E2 tugboat, reporting for delivery duty.

Fresh off the boat, Thu Oct 29: 5 new pages, and E2 hit 900 members!

Murkh the Falcon, the E2 Express, Open Arcade, YouBoob, and our Communities page.

Full ship log: https://e2.life/shippy/`;
  const { tweet, deduped } = await postTweet({
    handle,
    text,
    image_url,
    idempotencyKey: "shippy-first-tweet:20261029-big-image",
  });
  console.log(`[shippy] ${deduped ? "deduped" : "tweeted"} ${tweet.id}`);
})().catch((e) => { console.error("[shippy] fatal", e.message); process.exit(1); });
