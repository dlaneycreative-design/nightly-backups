const { postTweet } = require("./lib/botlib");

const BLOB = "https://4gmyjxjillq2uehw.public.blob.vercel-storage.com/judge-tweets/";

const TWEETS = [
  {
    key: "judge:fine-print-1",
    text: "Read every word before you sign anything. The fine print is where they hide what they hope you won't notice. I notice. That's my whole job.",
    image_url: BLOB + "judge-fine-print.webp",
  },
  {
    key: "judge:boundaries-1",
    text: "A boundary is a contract with yourself. Write it down, say it out loud, enforce it like you mean it. People will treat you exactly the way you let them.",
  },
  {
    key: "judge:no-1",
    text: "No is a complete sentence. You don't owe anyone a paragraph of explanation. Court dismissed.",
    image_url: BLOB + "judge-boundaries.webp",
  },
  {
    key: "judge:sleep-on-it-1",
    text: "Never sign a contract the same day you read it. Sleep on it. If they pressure you to sign right now, that's your answer. Walk away.",
  },
  {
    key: "judge:protect-yourself-1",
    text: "Protect yourself first. You can't help anyone from an empty courtroom. Boundaries aren't mean, they're maintenance.",
  },
];

(async () => {
  const handle = String.fromCharCode(106, 117, 100, 103, 101); // judge
  for (const t of TWEETS) {
    const { tweet, deduped } = await postTweet({ handle, text: t.text, image_url: t.image_url, idempotencyKey: t.key });
    console.log(deduped ? "deduped" : "posted", tweet.id, "-", t.text.slice(0, 50) + "...");
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
