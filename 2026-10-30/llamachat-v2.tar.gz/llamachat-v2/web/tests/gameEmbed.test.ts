// !Game web detection tests. Case list MUST match the worker parser
// tests (llamachat-worker/test/game.test.mjs).
import { test } from "node:test";
import assert from "node:assert/strict";
import { detectGameEmbed, parseGameCommand, normalizeGameName, SUPER_E2, MURKH, SNAKE, SNAKE_DUEL } from "../src/lib/gameEmbed.ts";

const KNOWN = [
  "!Game Super E2",
  "!Game SuperE2",
  "!game super e2",
  "!GAME SUPER E2",
  "!Game SUPER-E2",
  "!Game super_e2",
  "!Game Super  E2",
  "!games Super E2",
  "!play Super E2",
  "!Play supere2",
  "  !Game Super E2  ",
  "!SuperE2", // direct shout
  "!supere2",
  "!Super E2",
  "!super E2",
  "!super",
  "!play super",
  "!Game supper E2",
  "!lay Super E2",
  "!Game Super E2 is the best", // trailing chatter still resolves
];

test("all Super E2 variations embed Super E2", () => {
  for (const text of KNOWN) {
    const g = detectGameEmbed(text);
    assert.ok(g, text);
    assert.equal(g.id, SUPER_E2.id, text);
    assert.equal(g.playUrl, "https://supere2.netlify.app", text);
    assert.equal(g.pageUrl, "https://openarcade.lol/supere2", text);
    assert.equal(g.coverUrl, "https://e2.life/games/img/e2world.webp", text);
  }
});

const KNOWN_MURKH = [
  "!MURKH", // the direct shout Dave asked for
  "!murkh",
  "!Murkh",
  "!MURKH!",
  "! MURKH",
  "!!MURKH",
  "!play MURKH", // the other form Dave named
  "!Game MURKH",
  "!games murkh",
  "!play Murkh",
  "!Game MURKH: Disaster in the Sky",
  "!play murkh-disaster-in-the-sky",
  "!playmurkh", // glued
  "!gamemurkh",
  "!MURKH is live", // trailing chatter
  "!play MURKH let's go",
  "!play murk", // partial name
  "!M-U-R-K-H",
  "!merk",
  "!play merc",
  "!murch",
  "!gmae murkh",
];

test("all MURKH variations embed MURKH", () => {
  for (const text of KNOWN_MURKH) {
    const g = detectGameEmbed(text);
    assert.ok(g, text);
    assert.equal(g.id, MURKH.id, text);
    assert.equal(g.id, "murkh-disaster-in-the-sky", text);
    assert.equal(g.playUrl, "https://openarcade-api.dlaneycreative.workers.dev/play/murkh-disaster-in-the-sky/", text);
    assert.equal(g.pageUrl, "https://openarcade.lol/murkh-disaster-in-the-sky", text);
    assert.equal(g.coverUrl, "https://openarcade-api.dlaneycreative.workers.dev/api/cover/murkh-disaster-in-the-sky", text);
  }
});

const KNOWN_SNAKE = [
  "!snake",
  "!Snake",
  "!SNAKE",
  "!play snake",
  "!Game Snake",
  "!games snake",
  "!sanke",
  "!play sanke",
  "!lay snake",
  "!gmae snake",
  "!gaem snake",
  "!playsnake",
  "!play Google Snake",
  "!googlesnake",
  "!snake!",
];

test("all Snake variations embed Snake", () => {
  for (const text of KNOWN_SNAKE) {
    const g = detectGameEmbed(text);
    assert.ok(g, text);
    assert.equal(g.id, SNAKE.id, text);
    assert.equal(g.id, "google-snake", text);
    assert.equal(g.playUrl, "https://doodlecricket.github.io/doodle-snake", text);
    assert.equal(g.pageUrl, "https://openarcade.lol/google-snake", text);
    assert.equal(g.coverUrl, "https://openarcade.lol/img/google-snake.webp", text);
  }
});

const KNOWN_SNAKE_DUEL = [
  "!snakeduel",
  "!play Snake Duel",
  "!games snake duel",
  "!play snakeduels",
];

test("all Snake Duel variations embed Snake Duel", () => {
  for (const text of KNOWN_SNAKE_DUEL) {
    const g = detectGameEmbed(text);
    assert.ok(g, text);
    assert.equal(g.id, SNAKE_DUEL.id, text);
    assert.equal(g.playUrl, "https://openarcade.lol/play/snake-duel/", text);
  }
});

const LIST = [
  "!games",
  "!game",
  "!Games",
  "!GAME",
  "!play",
  "!arcade",
  "!!games",
  "! games",
  "!games list",
  "!game all",
  "!play help",
  "!games games",
];

test("bare commands and list words parse as the list and embed nothing", () => {
  for (const text of LIST) {
    const p = parseGameCommand(text);
    assert.ok(p, text);
    assert.equal(p.list, true, text);
    assert.equal(p.game, null, text);
    assert.equal(detectGameEmbed(text), null, text);
  }
});

test("normalizeGameName strips spacing, case and punctuation", () => {
  for (const raw of ["Super E2", "SuperE2", "super e2", "SUPER-E2", "super_e2", "Super  E2"]) {
    assert.equal(normalizeGameName(raw), "supere2", raw);
  }
});

test("unknown game names parse as commands but embed nothing", () => {
  for (const text of ["!Game Mario", "!play chess", "!games GTA"]) {
    const p = parseGameCommand(text);
    assert.ok(p, text);
    assert.equal(p.known, false, text);
    assert.equal(detectGameEmbed(text), null, text);
  }
});

test("non-commands never embed", () => {
  for (const text of [
    "I love games",
    "!gambling is bad",
    "Super E2 is great", // plain mention, no command
    "playing Super E2 tonight !Game",
    "$tip @harsh 5p",
    "hello !game super e2",
    "!mario", // unknown direct shout is not a command (no help spam)
    "!hello world",
    "MURKH is great", // plain mention, no command
    "!startled by the news",
    "!layer cake",
    "",
    "!",
  ]) {
    assert.equal(parseGameCommand(text), null, JSON.stringify(text));
    assert.equal(detectGameEmbed(text), null, JSON.stringify(text));
  }
});
