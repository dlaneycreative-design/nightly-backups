import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
// EXACT find query from dms.js, ANY as its own param
const ids = ['8d754e46-a2af-4318-a3d8-9b47e5473abb', '4c08bb11-2e07-59d7-a30e-ed42d3e2bc55'];
const q = "SELECT c.id FROM conversations c WHERE NOT EXISTS (SELECT 1 FROM conversation_participants cp WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY($1))) AND (SELECT count(*) FROM conversation_participants cp2 WHERE cp2.conversation_id = c.id) = 2 LIMIT 1";
const bind = await sql.query ? null : null;
// neon serverless: use sql.query for positional params if available, else fall back to unsafe-free template:
let res;
try {
  res = await sql`SELECT c.id FROM conversations c WHERE NOT EXISTS (SELECT 1 FROM conversation_participants cp WHERE cp.conversation_id = c.id AND NOT (cp.user_id = ANY(${ids}::uuid[]))) AND (SELECT count(*) FROM conversation_participants cp2 WHERE cp2.conversation_id = c.id) = 2 LIMIT 1`;
  console.log('CAST FIND ->', JSON.stringify(res));
} catch (e) { console.log('CAST FIND ERROR:', e.message); }
// henri solo conv: does it contain any messages and from whom?
const hm = await sql`SELECT m.id, m.sender_id, p.handle, m.text, m.created_at FROM messages m LEFT JOIN profiles p ON p.id = m.sender_id WHERE m.conversation_id = '26148d02-08ea-4ca3-afd4-a1c0ff621f5c'`;
console.log('HENRI SHELL MESSAGE:', JSON.stringify(hm));
const hc = await sql`SELECT * FROM conversations WHERE id = '26148d02-08ea-4ca3-afd4-a1c0ff621f5c'`;
console.log('HENRI SHELL ROW:', JSON.stringify(hc));
