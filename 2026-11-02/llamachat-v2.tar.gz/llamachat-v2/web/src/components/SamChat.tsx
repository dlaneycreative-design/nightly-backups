import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { SAM_CHIPS, SAM_GREETING, samPostRequest, samReply } from "../lib/sam.ts";
import type { ApiClient } from "../lib/api.ts";
import { appPath, profilePath } from "../lib/theme.ts";

function newUuid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (ch) => {
    const r = (Math.random() * 16) | 0;
    return (ch === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

interface SamMsg {
  id: number;
  from: "sam" | "me";
  text: string;
}

/**
 * Sam's answers carry real links (the Discord invite above all):
 * render every URL / bare domain in her messages as one tappable
 * link instead of dead plain text (Dave's order Nov 1 2026: "these
 * links are not working. There should be one link and it clicks").
 * Only Sam's bubbles are linkified; the user's own stay plain.
 */
const SAM_URL_RE =
  /((?:https?:\/\/)?(?:[a-z0-9-]+\.)+(?:com|org|lol|life|io|net|gg|dev)(?:\/[^\s]*)?)/gi;

function linkifySam(text: string) {
  const out: ReactNode[] = [];
  let last = 0;
  let k = 0;
  for (const m of text.matchAll(SAM_URL_RE)) {
    const raw = m[0];
    const idx = m.index ?? 0;
    // A bare word only counts as a link when it carries a scheme or
    // a path / a well-known short domain; plain "e2.life" counts too.
    let url = raw;
    let trail = "";
    while (/[.,!?;:]$/.test(url)) {
      trail = url.slice(-1) + trail;
      url = url.slice(0, -1);
    }
    if (url.endsWith(")") && !url.includes("(")) {
      trail = ")" + trail;
      url = url.slice(0, -1);
    }
    if (idx > last) out.push(text.slice(last, idx));
    const href = /^https?:\/\//i.test(url) ? url : `https://${url}`;
    out.push(
      <a key={k++} className="sam-link" href={href} target="_blank" rel="noopener noreferrer">
        {url}
      </a>,
    );
    if (trail) out.push(trail);
    last = idx + raw.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

const STORE_KEY = "samai-chat-v1";
const SAM_AVATAR = appPath("/assets/avatars/sam.webp");

function loadMsgs(): SamMsg[] {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as SamMsg[];
      if (Array.isArray(parsed) && parsed.length > 0) return parsed.slice(-100);
    }
  } catch {
    /* start fresh */
  }
  return [{ id: 1, from: "sam", text: SAM_GREETING }];
}

/**
 * Sam AI chat (Dave's call Nov 1 2026): the middle nav button opens
 * Sam right inside LlamaChat, Grok-style. She answers with the same
 * rule-based brain she uses on Discord (no paid AI calls). The thread
 * lives on this device (localStorage), and the layout reuses the DM
 * view's proven viewport pinning so the composer never floats.
 */
export function SamChat({ api }: { api?: ApiClient }) {
  const [messages, setMessages] = useState<SamMsg[]>(loadMsgs);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(messages.reduce((m, x) => Math.max(m, x.id), 1) + 1);
  const timerRef = useRef<number | null>(null);

  // Pin to the visual viewport exactly like DMSplit: height is the
  // visual viewport minus the mobile header, document scroll locked,
  // kb-open drops the bottom-nav lift while the keyboard is up.
  useEffect(() => {
    const el = rootRef.current;
    const vv = window.visualViewport;
    if (!el || !vv) return;
    const root = document.documentElement;
    root.classList.add("dm-lock");
    let fullH = vv.height;
    const update = () => {
      const head = document.querySelector(".mhead");
      const headH =
        head && getComputedStyle(head).display !== "none"
          ? head.getBoundingClientRect().height
          : 0;
      el.style.height = `${Math.max(0, vv.height - headH)}px`;
      el.style.minHeight = el.style.height;
      el.style.transform = vv.offsetTop ? `translateY(${vv.offsetTop}px)` : "";
      const ae = document.activeElement;
      const focused = !!(
        ae &&
        el.contains(ae) &&
        (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA")
      );
      if (!focused) fullH = vv.height;
      el.classList.toggle("kb-open", focused && vv.height < fullH - 80);
    };
    update();
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    el.addEventListener("focusin", update);
    el.addEventListener("focusout", update);
    return () => {
      vv.removeEventListener("resize", update);
      vv.removeEventListener("scroll", update);
      el.removeEventListener("focusin", update);
      el.removeEventListener("focusout", update);
      root.classList.remove("dm-lock");
      el.style.height = "";
      el.style.minHeight = "";
      el.style.transform = "";
      el.classList.remove("kb-open");
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(messages.slice(-100)));
    } catch {
      /* private mode: chat just does not persist */
    }
  }, [messages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length, typing]);

  useEffect(() => () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
  }, []);

  const send = useCallback(
    (preset?: string) => {
      const body = (preset ?? text).trim();
      if (!body || typing) return;
      const myId = idRef.current++;
      setMessages((prev) => [...prev, { id: myId, from: "me", text: body }]);
      if (!preset) setText("");
      setTyping(true);
      const pushSam = (reply: string, minDelay = 0) => {
        const wait = Math.max(0, minDelay - 0);
        timerRef.current = window.setTimeout(() => {
          setMessages((prev) => [...prev, { id: idRef.current++, from: "sam", text: reply }]);
          setTyping(false);
        }, wait);
      };
      // Action first (Dave's call Nov 1 2026): "make a post on my
      // account that says X" means Sam posts X as the signed-in user,
      // for real, then answers properly. Not a how-to.
      const postText = api ? samPostRequest(body) : null;
      if (postText !== null && api) {
        if (postText === "") {
          pushSam("Of course 💛 What should the post say? Tell me the exact words and I will put it on your account.", 650);
          return;
        }
        const started = Date.now();
        api
          .postTweet({ id: newUuid(), text: postText })
          .then(({ tweet }) => {
            pushSam(
              `Done 💛 I posted it on your account: "${postText}"\nIt is live now at llamachat.lol/tweet/${tweet.id}`,
              Math.max(0, 650 - (Date.now() - started)),
            );
          })
          .catch(() => {
            pushSam(
              "I tried, but the post did not go through 💛 Give it another try in a moment, or tap the blue pencil button and I will cheer from here.",
              Math.max(0, 650 - (Date.now() - started)),
            );
          });
        return;
      }
      const reply = samReply(body);
      pushSam(reply, 650 + Math.min(reply.length * 4, 700));
    },
    [text, typing, api],
  );

  const showChips = messages.length <= 1;

  return (
    <div ref={rootRef} className="samchat">
      <div className="dm-thread-header">
        <button
          type="button"
          className="dm-back-btn"
          aria-label="Back"
          onClick={() => window.history.back()}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <Link to={profilePath("sam")} className="dm-thread-profile" aria-label="View Sam's profile">
          <img src={SAM_AVATAR} alt="" className="dm-thread-avatar" />
          <div className="dm-thread-info">
            <div className="dm-thread-name">Sam <span className="sam-ai-badge">AI</span></div>
            <div className="dm-thread-handle">@sam, E2's host. Ask me anything</div>
          </div>
        </Link>
      </div>
      <div className="sam-messages">
        {messages.map((m) =>
          m.from === "me" ? (
            <div key={m.id} className="dm-bubble me"><div>{m.text}</div></div>
          ) : (
            <div key={m.id} className="sam-row">
              <img src={SAM_AVATAR} alt="" className="sam-mini-ava" />
              <div className="dm-bubble them"><div>{linkifySam(m.text)}</div></div>
            </div>
          ),
        )}
        {typing ? (
          <div className="sam-row" aria-label="Sam is typing">
            <img src={SAM_AVATAR} alt="" className="sam-mini-ava" />
            <div className="dm-bubble them sam-typing"><span /><span /><span /></div>
          </div>
        ) : null}
        <div ref={bottomRef} />
      </div>
      {showChips ? (
        <div className="sam-chips">
          {SAM_CHIPS.map((c) => (
            <button key={c} type="button" className="sam-chip" onClick={() => send(c)}>
              {c}
            </button>
          ))}
        </div>
      ) : null}
      <div className="dm-inputbar sam-inputbar">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Message Sam"
          aria-label="Message Sam"
          maxLength={2000}
          onKeyDown={(e) => {
            if (e.key === "Enter") send();
          }}
        />
        <button type="button" onClick={() => send()} disabled={!text.trim() || typing} aria-label="Send to Sam">
          Send
        </button>
      </div>
    </div>
  );
}
