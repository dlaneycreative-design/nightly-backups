import { neon } from '@neondatabase/serverless';
import fs from 'node:fs';
const env = fs.readFileSync('../.env.local', 'utf8');
const url = env.match(/DATABASE_URL\s*=\s*"?([^"\n]+)"?/)[1].trim();
const sql = neon(url);
const rows = await sql`SELECT image_url FROM tweets WHERE image_url LIKE '%/media/llamachat/%' ORDER BY created_at DESC LIMIT 5`;
console.log(JSON.stringify(rows, null, 1));
