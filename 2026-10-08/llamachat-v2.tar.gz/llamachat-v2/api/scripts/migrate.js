// Applies db/migrations/*.sql in filename order, tracking applied
// migrations in schema_migrations. Idempotent: safe to re-run.
const fs = require("fs");
const path = require("path");
const { pool } = require("../lib/db");

async function main() {
  // Migrations live at the repo root: llamachat-v2/db/migrations
  // (api/scripts -> api -> llamachat-v2).
  const dir = path.join(__dirname, "..", "..", "db", "migrations");
  await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    name TEXT PRIMARY KEY, applied_at BIGINT NOT NULL
  )`);
  const applied = new Set(
    (await pool.query("SELECT name FROM schema_migrations")).rows.map((r) => r.name)
  );
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
  for (const f of files) {
    if (applied.has(f)) {
      console.log(`[migrate] skip ${f}`);
      continue;
    }
    const sql = fs.readFileSync(path.join(dir, f), "utf8");
    console.log(`[migrate] applying ${f}...`);
    await pool.query("BEGIN");
    try {
      await pool.query(sql);
      await pool.query("INSERT INTO schema_migrations (name, applied_at) VALUES ($1, $2)", [
        f,
        Date.now(),
      ]);
      await pool.query("COMMIT");
      console.log(`[migrate] done ${f}`);
    } catch (e) {
      await pool.query("ROLLBACK");
      throw e;
    }
  }
  await pool.end();
}

main().catch((e) => {
  console.error("[migrate] fatal", e.message);
  process.exit(1);
});
