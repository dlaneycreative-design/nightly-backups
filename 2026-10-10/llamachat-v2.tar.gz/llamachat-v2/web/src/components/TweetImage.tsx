// Lazy tweet image. Twitter-style aspect-ratio handling (Dave's call Oct 9 2026):
// wide, tall, and square images all display at their natural ratio, fitted
// within max bounds, never cropped, never stretched. Tap opens the full
// image in a lightbox. Images only load when near the viewport (native
// lazy) so long feeds stay fast.
import { useState } from "react";
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  /** The medium image_url stored on the tweet. */
  imageUrl: string;
  alt?: string;
}

export function TweetImage({ imageUrl, alt = "Tweet image" }: Props) {
  const [lightbox, setLightbox] = useState(false);
  const src = resolveImageUrl(imageUrl) || imageUrl;

  return (
    <>
      <div className="tweet-img-wrap">
        <img
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          onClick={() => setLightbox(true)}
          className="tweet-img"
        />
      </div>
      {lightbox ? (
        <div className="lightbox" onClick={() => setLightbox(false)}>
          <img src={src} alt={alt} className="lightbox-img" />
        </div>
      ) : null}
    </>
  );
}
