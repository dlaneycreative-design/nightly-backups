// THE one Composer. V1 had three separate implementations (modal, home
// inline, reply box), each needing its own paste/drop handlers — the home
// composer shipped without them and Dave couldn't paste images there.
// V2: this single component is used everywhere with props.
//
// Props:
//   replyToId   — set when composing a reply (shows "Replying" context)
//   placeholder — default "What's happening?"
//   autofocus   — focus on mount (modal use)
//   compact     — smaller padding for inline use
//   onPosted    — called with the confirmed tweet (server response)
//   onOptimistic— called immediately with a temp tweet for instant UI
import { useCallback, useEffect, useRef, useState } from "react";
import { showToast } from "../lib/toast.ts";
import type { ApiClient, Profile, Tweet } from "../lib/api.ts";
import { uploadImage, fileToPreviewUrl, resolveImageUrl } from "../lib/images.ts";

const MAX_CHARS = 2000;

interface Props {
  api: ApiClient;
  apiBase: string;
  getCallerId: () => string | null;
  /** Logged-in user's avatar. The composer always shows YOUR face, like X. */
  avatarUrl?: string | null;
  replyToId?: string | null;
  /** Suppress the inline "Replying" label (the reply modal renders its own
   *  "Replying to @handle" line under the original tweet). */
  hideReplyingLabel?: boolean;
  placeholder?: string;
  autofocus?: boolean;
  /** Seed text for a FRESH composer (used once, as the initial state).
   *  The compose modal passes "@Handle " when opened from a profile page.
   *  Because the modal mounts a new Composer per open, this can never
   *  clobber an existing draft. */
  initialText?: string;
  compact?: boolean;
  onPosted?: (tweet: Tweet) => void;
  onOptimistic?: (temp: TempTweet) => void;
  onSettled?: (tempId: string, tweet: Tweet | null) => void;
}

export interface TempTweet {
  tempId: string;
  text: string;
  image_url: string | null;
  reply_to_id: string | null;
  // NOTE: no created_at. Dave's #1 rule: the client NEVER generates
  // timestamps. Optimistic tweets render "sending..." via tweetTime()
  // until the server responds with the real stamp.
  pending: true;
}

function newId(): string {
  // RFC 4122 v4. crypto.randomUUID where available.
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

export function Composer({
  api, apiBase, getCallerId, avatarUrl = null,
  replyToId = null,
  hideReplyingLabel = false,
  placeholder = "What's happening?",
  autofocus = false,
  initialText,
  onPosted, onOptimistic, onSettled,
}: Props) {
  const [text, setText] = useState(() => initialText ?? "");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!autofocus) return;
    const ta = taRef.current;
    if (!ta) return;
    ta.focus();
    // Caret after any seeded text (e.g. the "@Jen " profile prefill).
    const end = ta.value.length;
    ta.setSelectionRange(end, end);
  }, [autofocus]);

  // Auto-grow the textarea.
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 320)}px`;
  }, [text]);

  // ---- @mention autocomplete -------------------------------------------
  // While the caret sits inside an @token, offer matching people from the
  // same /search users endpoint the sidebar autocomplete uses. This lives
  // in the ONE Composer, so it works identically in the home composer, the
  // compose modal (any route, profile pages included), and the reply
  // modal. Selecting a person completes "@Handle " with the first letter
  // capitalized (Dave's writing style); the server mention parser
  // (render.js MENTION_RE) linkifies any case.
  interface MentionState { start: number; query: string }
  const [mention, setMention] = useState<MentionState | null>(null);
  const [mUsers, setMUsers] = useState<Profile[]>([]);
  const [mActive, setMActive] = useState(0);
  const caretRef = useRef(0);
  const mTimer = useRef<number | null>(null);
  const mSeq = useRef(0);

  const refreshMention = useCallback((value: string, caret: number) => {
    caretRef.current = caret;
    const upto = value.slice(0, caret);
    const m = /(?:^|\s)@([A-Za-z0-9_]*)$/.exec(upto);
    if (!m) {
      setMention(null);
      setMUsers([]);
      return;
    }
    setMention({ start: caret - m[1].length - 1, query: m[1] });
  }, []);

  // Debounced people search for the active mention token.
  useEffect(() => {
    if (mTimer.current) window.clearTimeout(mTimer.current);
    if (!mention || mention.query.length < 1) {
      setMUsers([]);
      return;
    }
    const q = mention.query;
    mTimer.current = window.setTimeout(async () => {
      const seq = ++mSeq.current;
      try {
        const res = await api.search(q, "users");
        if (seq !== mSeq.current) return;
        setMUsers((res.users || []).slice(0, 7));
        setMActive(0);
      } catch {
        // Silent: dropdown just stays closed on error.
      }
    }, 180);
    return () => {
      if (mTimer.current) window.clearTimeout(mTimer.current);
    };
  }, [mention, api]);

  const applyMention = useCallback(
    (u: Profile) => {
      if (!mention) return;
      const insert = `@${u.handle.charAt(0).toUpperCase()}${u.handle.slice(1)} `;
      const caret = caretRef.current;
      setText(text.slice(0, mention.start) + insert + text.slice(caret));
      setMention(null);
      setMUsers([]);
      const pos = mention.start + insert.length;
      requestAnimationFrame(() => {
        const ta = taRef.current;
        if (ta) {
          ta.focus();
          ta.setSelectionRange(pos, pos);
        }
      });
    },
    [mention, text]
  );

  const attachFile = useCallback(async (f: File) => {
    if (!f.type.startsWith("image/")) {
      setError("Only images can be attached.");
      return;
    }
    setError(null);
    setFile(f);
    try {
      setPreview(await fileToPreviewUrl(f));
    } catch {
      setPreview(null);
    }
  }, []);

  const onPaste = useCallback(
    (e: React.ClipboardEvent) => {
      // Finder copies land in clipboardData.files; screenshots in .items.
      const dt = e.clipboardData;
      const fromFiles = dt.files && dt.files.length > 0 ? dt.files[0] : null;
      if (fromFiles && fromFiles.type.startsWith("image/")) {
        e.preventDefault();
        void attachFile(fromFiles);
        return;
      }
      for (const item of Array.from(dt.items || [])) {
        if (item.type.startsWith("image/")) {
          const f = item.getAsFile();
          if (f) {
            e.preventDefault();
            void attachFile(f);
            return;
          }
        }
      }
    },
    [attachFile]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const f = e.dataTransfer.files && e.dataTransfer.files[0];
      if (f && f.type.startsWith("image/")) void attachFile(f);
    },
    [attachFile]
  );

  const clearAttachment = useCallback(() => {
    setFile(null);
    setPreview(null);
    if (fileRef.current) fileRef.current.value = "";
  }, []);

  const canPost = (text.trim().length > 0 || preview) && text.length <= MAX_CHARS && !busy;

  const post = useCallback(async () => {
    const body = text.trim();
    if ((!body && !preview) || body.length > MAX_CHARS || busy) return;
    const caller = getCallerId();
    if (!caller) {
      setError("You're not signed in.");
      return;
    }
    setBusy(true);
    setError(null);

    const tempId = newId();
    const temp: TempTweet = {
      tempId, text: body, image_url: preview, reply_to_id: replyToId,
      pending: true,
    };
    onOptimistic?.(temp);

    try {
      // 1. Upload image first (to Vercel Blob via the API).
      let image_url: string | null = null;
      if (file) {
        setStatus("Uploading image...");
        image_url = await uploadImage(apiBase, caller, file, "tweet", (stage) =>
          setStatus(stage === "uploading" ? "Uploading image..." : null)
        );
      }
      // 2. Create the tweet. Idempotent: same tempId -> no duplicate.
      setStatus("Posting...");
      const { tweet, deduped } = await api.postTweet({
        id: tempId, text: body, image_url, reply_to_id: replyToId,
      });
      setStatus(null);
      setText("");
      setMention(null);
      setMUsers([]);
      clearAttachment();
      onPosted?.(tweet);
      showToast("Your post was sent.", { label: "View", href: `/tweet/${tweet.id}` });
      onSettled?.(tempId, tweet);
      if (deduped) setStatus("Already posted.");
    } catch (e) {
      // STATIC (Dave's call Oct 8 2026): no retry queue. Show the error;
      // the user's text stays in the box so nothing is lost.
      const msg = e instanceof Error ? e.message : String(e);
      setError(`Couldn't post (${msg}). Please try again.`);
      onSettled?.(tempId, null);
    } finally {
      setBusy(false);
      setStatus(null);
    }
  }, [text, busy, file, preview, replyToId, api, apiBase, getCallerId, onOptimistic, onPosted, onSettled, clearAttachment]);

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      // Mention dropdown keys win while it is open (plain keys only, so
      // Cmd/Ctrl+Enter still posts).
      if (mention && mUsers.length > 0 && !e.metaKey && !e.ctrlKey) {
        if (e.key === "ArrowDown") {
          e.preventDefault();
          setMActive((a) => (a + 1) % mUsers.length);
          return;
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          setMActive((a) => (a - 1 + mUsers.length) % mUsers.length);
          return;
        }
        if (e.key === "Enter" || e.key === "Tab") {
          e.preventDefault();
          const u = mUsers[mActive];
          if (u) applyMention(u);
          return;
        }
        if (e.key === "Escape") {
          e.preventDefault();
          e.stopPropagation();
          setMention(null);
          setMUsers([]);
          return;
        }
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        void post();
      }
    },
    [post, mention, mUsers, mActive, applyMention]
  );

  // V1: the composer avatar is always the logged-in user's face.
  const avatarSrc = resolveImageUrl(avatarUrl) || resolveImageUrl("/assets/avatars/dave-dlaney-face-400.webp") || undefined;

  return (
    <div
      className="composer"
      onPaste={onPaste}
      onDrop={onDrop}
      onDragOver={(e) => e.preventDefault()}
    >
      <img className="avatar" src={avatarSrc} alt="You" />
      <div className="composer-main">
      {replyToId && !hideReplyingLabel ? <div className="composer-replying">Replying</div> : null}
      <div className="composer-ta-wrap">
        <textarea
          ref={taRef}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            refreshMention(e.target.value, e.target.selectionStart ?? e.target.value.length);
          }}
          onSelect={(e) =>
            refreshMention(e.currentTarget.value, e.currentTarget.selectionStart ?? 0)
          }
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          rows={1}
          aria-label={placeholder}
        />
        {mention && mUsers.length > 0 ? (
          <div className="search-ac mention-ac" role="listbox" aria-label="Mention people">
            {mUsers.map((u, i) => {
              const src = resolveImageUrl(u.avatar_url);
              return (
                <button
                  key={u.id}
                  type="button"
                  role="option"
                  aria-selected={i === mActive}
                  className={`search-ac-row${i === mActive ? " active" : ""}`}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    applyMention(u);
                  }}
                  onMouseEnter={() => setMActive(i)}
                >
                  {src ? (
                    <img src={src} alt="" loading="lazy" decoding="async" />
                  ) : (
                    <div className="avatar-fallback" aria-hidden="true">
                      {(u.display_name || "?").slice(0, 1).toUpperCase()}
                    </div>
                  )}
                  <div className="search-ac-txt">
                    <div className="search-ac-name">{u.display_name}</div>
                    <div className="search-ac-handle">@{u.handle}</div>
                  </div>
                </button>
              );
            })}
          </div>
        ) : null}
      </div>
      {preview ? (
        <div className="composer-preview">
          <img src={preview} alt="Attachment preview" />
          <button type="button" onClick={clearAttachment} aria-label="Remove image">✕</button>
        </div>
      ) : null}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        aria-label="Attach an image to your post"
        className="composer-file-input"
        onChange={(e) => {
          const f = e.target.files && e.target.files[0];
          if (f) void attachFile(f);
        }}
      />
      <div className="composer-bar">
        <div className="cicons">
          <button type="button" onClick={() => fileRef.current?.click()} aria-label="Attach image" disabled={busy}>
            <svg viewBox="0 0 24 24" className="nic" style={{width:18,height:18}}><path fill="currentColor" d="M4 4h16a1 1 0 011 1v14a1 1 0 01-1 1H4a1 1 0 01-1-1V5a1 1 0 011-1zm1 2v12h14V6H5zm3 2.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3zM6 17l4-4 3 3 2.5-2.5L19 17H6z"/></svg>
          </button>
        </div>

        <button type="button" className={`postbtn${canPost ? " ready" : ""}`} onClick={() => void post()} disabled={!canPost}>
          {busy ? "Posting..." : replyToId ? "Reply" : "Post"}
        </button>
      </div>
      {status ? <div className="composer-status">{status}</div> : null}
      {error ? <div className="composer-error">{error}</div> : null}
      </div>
    </div>
  );
}
