// Edit media: the adjust step between picking a photo and saving it,
// modeled on X's screen (Dave's reference, Oct 19 2026): back arrow +
// "Edit media" title + black Apply pill; the photo draggable inside a
// blue-bordered frame on a light gray canvas; a zoom slider between
// magnifier icons at the bottom. For avatars the frame is square with
// a circular guide (avatars render round); for banners it is 3:1.
// Opening this screen pre-frames a sane center crop, so tapping Apply
// without touching anything IS the easy path.
import { useEffect, useRef, useState } from "react";
import {
  frameScale,
  renderAvatarFile,
  renderBannerFile,
  type FrameView,
  type LoadedAvatarImage,
} from "../lib/images.ts";

interface Props {
  loaded: LoadedAvatarImage;
  shape: "avatar" | "banner";
  onApply: (file: File) => void;
  onBack: () => void;
}

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

export function EditMedia({ loaded, shape, onApply, onBack }: Props) {
  const frameRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ x: number; y: number; tx: number; ty: number } | null>(null);
  const [frame, setFrame] = useState({ w: shape === "avatar" ? 360 : 560, h: shape === "avatar" ? 360 : 187 });
  const [zoom, setZoom] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState("");

  // Measure the real frame once mounted (and if the window resizes).
  useEffect(() => {
    const measure = () => {
      const el = frameRef.current;
      if (el) setFrame({ w: el.clientWidth, h: el.clientHeight });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const view: FrameView = { frameW: frame.w, frameH: frame.h, zoom, tx, ty };
  const s = frameScale(loaded.width, loaded.height, view);
  const dispW = loaded.width * s;
  const dispH = loaded.height * s;
  const maxTx = Math.max(0, (dispW - frame.w) / 2);
  const maxTy = Math.max(0, (dispH - frame.h) / 2);
  const cTx = clamp(tx, -maxTx, maxTx);
  const cTy = clamp(ty, -maxTy, maxTy);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    dragRef.current = { x: e.clientX, y: e.clientY, tx: cTx, ty: cTy };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    if (!d) return;
    setTx(clamp(d.tx + (e.clientX - d.x), -maxTx, maxTx));
    setTy(clamp(d.ty + (e.clientY - d.y), -maxTy, maxTy));
  };
  const endDrag = () => {
    dragRef.current = null;
  };

  const apply = async () => {
    if (applying) return;
    setApplying(true);
    setError("");
    try {
      const baked = { ...view, tx: cTx, ty: cTy };
      const file =
        shape === "avatar"
          ? await renderAvatarFile(loaded.img, baked)
          : await renderBannerFile(loaded.img, baked);
      onApply(file);
    } catch {
      setError("That photo could not be processed. Please go back and try a different one.");
      setApplying(false);
    }
  };

  return (
    <div>
      <div className="em-head">
        <button type="button" className="em-back" onClick={onBack} aria-label="Back">
          ←
        </button>
        <div className="em-title">Edit media</div>
        <button type="button" className="followbtn" onClick={() => void apply()} disabled={applying}>
          {applying ? "Applying..." : "Apply"}
        </button>
      </div>
      <div className="em-canvas">
        <div
          ref={frameRef}
          className={shape === "avatar" ? "em-frame em-frame-square" : "em-frame em-frame-wide"}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          role="img"
          aria-label="Photo crop frame. Drag to reposition the photo."
        >
          <img
            src={loaded.url}
            alt=""
            draggable={false}
            style={{
              width: dispW,
              height: dispH,
              transform: `translate(-50%, -50%) translate(${cTx}px, ${cTy}px)`,
            }}
          />
          {shape === "avatar" ? <div className="em-circle-guide" aria-hidden="true" /> : null}
        </div>
      </div>
      {loaded.isGif ? (
        <p className="em-note">GIFs become a still photo: we use the first frame.</p>
      ) : null}
      {error ? (
        <p className="em-note" style={{ color: "#f4212e" }} role="alert">
          {error}
        </p>
      ) : null}
      <div className="em-zoombar">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#536471" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4.3-4.3M8 11h6" />
        </svg>
        <input
          type="range"
          min={1}
          max={3}
          step={0.01}
          value={zoom}
          onChange={(e) => setZoom(Number(e.target.value))}
          aria-label="Zoom"
          className="em-slider"
        />
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#536471" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4.3-4.3M8 11h6M11 8v6" />
        </svg>
      </div>
      <p className="em-hint">Drag the photo to reposition it, or just tap Apply: it is already framed for you.</p>
    </div>
  );
}
