// Replace Sam's Enit Walks reply: Dave's no-dashes-in-URLs rule (Oct 31 2026)
// renamed the game from enit-walks to enitwalks, so delete the first reply
// (which carried the dashed link) and repost with the new link.
const { API_BASE, postTweet, getProfileId, serviceHeaders } = require("./lib/botlib");

async function main() {
  const samId = await getProfileId("sam");
  const del = await fetch(`${API_BASE}/tweets/3a1a6af5-dbfd-5ded-b26a-db26e9562434`, {
    method: "DELETE",
    headers: serviceHeaders(samId),
  });
  console.log("[sam-enitwalks-fix] delete ->", del.status, (await del.text()).slice(0, 120));

  const text = `@enit Enit!! Your morning walk is a GAME now!! Dave built Enit Walks from this very photo: you stroll down Meadow Lane, through the walled garden, all the way into town for a coffee at Bean & Bramble. It is live on Open Arcade, come play it!!
https://openarcade.lol/ENITWALKS`;
  const { tweet, deduped } = await postTweet({
    handle: "sam",
    text,
    reply_to_id: "54536c62-295b-48e2-8b3c-cbb97fb2f0f4",
    idempotencyKey: "sam-enitwalks-reply:20261031",
  });
  console.log(`[sam-enitwalks-fix] ${deduped ? "deduped" : "replied"} ${tweet.id}`);
}
main().catch((e) => { console.error("[sam-enitwalks-fix] fatal", e.message); process.exit(1); });
