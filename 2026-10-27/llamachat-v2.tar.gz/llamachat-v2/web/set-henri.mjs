// Henri's avatar: /media/local/henri/henri-hue.webp renders broken for Dave even though
// the file exists in dist. Move him to the canonical /assets/avatars/henri.webp (12,764B,
// in dist, family proven live). Owner: main chat. Idempotent.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const before = await sql`SELECT handle, avatar_url FROM profiles WHERE handle = 'henri'`;
console.log('BEFORE:', before.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
const u = await sql`UPDATE profiles SET avatar_url = '/assets/avatars/henri.webp' WHERE handle = 'henri'`;
console.log('henri update count:', u.count);
const after = await sql`SELECT handle, avatar_url FROM profiles WHERE handle = 'henri'`;
console.log('AFTER:', after.map(r => `${r.handle} -> ${r.avatar_url}`).join(' | '));
console.log('HENRI AVATAR DONE');
