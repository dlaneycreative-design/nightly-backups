// @llama tune-up round 2 (Dave's orders, Nov 1 2026, this side chat):
// 1) Avatar zoomed in a little and the bottom filled out: Dave's screenshot
//    showed the neck's cut edge floating inside the profile circle.
//    New file /assets/avatars/llama-coastal-v2.webp is his pick zoomed 1.20x
//    and shifted up so the neck fur runs off the bottom of the frame.
// 2) "remove" on a screenshot of the bio text: the whole bio
//    ("The official Llama Chat account.\nA place of kindness, run by the
//    Studio.") is removed. That exact text is recorded here so it can be
//    restored in one PATCH if Dave wants it back.
const { API_BASE, getProfileId, serviceHeaders } = require("./lib/botlib");

(async () => {
  const id = await getProfileId("llama");
  const patch = async (fields) => {
    const res = await fetch(`${API_BASE}/profiles/llama`, {
      method: "PATCH",
      headers: serviceHeaders(id, { "Content-Type": "application/json" }),
      body: JSON.stringify(fields),
    });
    if (!res.ok) throw new Error(`PATCH ${JSON.stringify(fields).slice(0, 60)} -> ${res.status} ${(await res.text()).slice(0, 200)}`);
    return (await res.json()).profile;
  };
  let p = await patch({ avatar_url: "/assets/avatars/llama-coastal-v2.webp" });
  console.log("[llama] avatar now:", p.avatar_url);
  p = await patch({ bio: "" });
  console.log("[llama] bio now:", JSON.stringify(p.bio));
})().catch((e) => { console.error("[llama] fatal", e.message); process.exit(1); });
