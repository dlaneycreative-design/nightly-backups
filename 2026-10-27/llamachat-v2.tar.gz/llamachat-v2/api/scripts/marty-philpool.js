const { postTweet } = require("./lib/botlib");

const POSTS = [
  {
    key: "marty:philpool-news-1",
    image_url: "https://llamachat.lol/media/llamachat/tweet/47d96d5b-4b16-4ee1-82df-a450f2f72bf0.webp",
    text: "BREAKING: one ₱1,000/hr remote job has been posted, and half the Philippines has entered the chat. Officials have reclassified this from an applicant pool to an applicant ocean. The deeper the pool gets, the more terrifying the top of the stack becomes.",
  },
  {
    key: "marty:philpool-documentary-1",
    image_url: "https://llamachat.lol/media/llamachat/tweet/49a62816-ccf0-4afe-ab91-f6bf3cf3c4a3.webp",
    text: "And here, in the vast plains of the internet, a ₱1,000/hr remote job appears. Around it gathers a mighty stack, application upon application, each one hoping to rise. Few will reach the summit. But oh, the one who does.",
  },
  {
    key: "marty:philpool-sports-1",
    image_url: "https://llamachat.lol/media/llamachat/tweet/efa6b8ce-1da1-4f4d-86c6-bb71337eba5d.webp",
    text: "IT'S THE APPLICANT PLAYOFFS. One ₱1,000/hr remote job hits the board and suddenly portfolios are flying, AI replies are warming up, and everybody wants a spot in the starting five. The deeper the bench gets, the scarier the top of the stack becomes.",
  },
];

(async () => {
  for (const p of POSTS) {
    const { tweet, deduped } = await postTweet({
      handle: "Marty",
      text: p.text,
      image_url: p.image_url,
      idempotencyKey: p.key,
    });
    console.log(deduped ? "deduped" : "posted", p.key, "https://llamachat.lol/tweet/" + tweet.id);
  }
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
