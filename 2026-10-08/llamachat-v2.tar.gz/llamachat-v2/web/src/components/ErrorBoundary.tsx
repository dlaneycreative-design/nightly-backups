import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  label?: string;
}

interface State {
  failed: boolean;
}

/**
 * One bad tweet never kills the feed. Every view is wrapped in one of
 * these; an individual Tweet crash is caught lower (see Tweet.tsx).
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { failed: false };

  static getDerivedStateFromError(): State {
    return { failed: true };
  }

  componentDidCatch(err: unknown): void {
    // eslint-disable-next-line no-console
    console.error("[ErrorBoundary]", this.props.label, err);
  }

  render(): ReactNode {
    if (this.state.failed) {
      return (
        <div className="errorbox" role="alert">
          <h2>Something hiccuped</h2>
          <p>This {this.props.label || "view"} could not load. Your feed is fine, try again.</p>
          <button type="button" className="ghost" onClick={() => this.setState({ failed: false })}>
            Try again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
