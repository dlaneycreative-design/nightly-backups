// Global reply-modal opener. Any Tweet reply button can open the X-style
// reply modal without prop drilling: Tweet.tsx calls openReplyModal(tweet),
// and ReplyModalHost (mounted once in App) renders the modal.
import type { Tweet } from "./api.ts";

type Listener = (tweet: Tweet | null) => void;
const listeners = new Set<Listener>();

let current: Tweet | null = null;

/** Open the reply modal for a tweet (no-op for pending tweets). */
export function openReplyModal(tweet: Tweet): void {
  current = tweet;
  for (const l of listeners) l(current);
}

/** Close the reply modal. */
export function closeReplyModal(): void {
  current = null;
  for (const l of listeners) l(current);
}

/** The tweet the modal is currently open for (null = closed). */
export function currentReplyTarget(): Tweet | null {
  return current;
}

export function subscribeReplyModal(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
