import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
const sql = neon(url);
// who is the lone participant of the malformed shell?
const shell = await sql`SELECT cp.user_id, p.handle FROM conversation_participants cp LEFT JOIN profiles p ON p.id = cp.user_id WHERE cp.conversation_id = '26148d02-08ea-4ca3-afd4-a1c0ff621f5c'`;
console.log('SHELL PARTICIPANTS:', JSON.stringify(shell));
const shellMsgs = await sql`SELECT count(*)::int AS n FROM messages WHERE conversation_id = '26148d02-08ea-4ca3-afd4-a1c0ff621f5c'`;
console.log('SHELL MESSAGES:', JSON.stringify(shellMsgs));
// does oldray appear in messages anywhere as sender?
const orMsgs = await sql`SELECT count(*)::int AS n FROM messages WHERE sender_id = '4c08bb11-2e07-59d7-a30e-ed42d3e2bc55'`;
console.log('OLDRAY MESSAGES SENT:', JSON.stringify(orMsgs));
