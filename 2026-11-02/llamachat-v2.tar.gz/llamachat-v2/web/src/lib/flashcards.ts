// Starvard flashcards, in-app edition. Ships in both skins since
// Apps V1 (Oct 19 2026): built in on Starvard, installable on Llama.
//
// This is a faithful port of the engine that already powers
// starvard.org/flashcards, NOT a parallel system:
// - Deck content is baked from that page's own DECKS/NAMES literals by
//   scripts/fetch-flashcards.mjs into /feed/flashcards-es.json.
// - Progress lives in the SAME localStorage keys the page uses
//   (sv_fc_known_<deckId>, sv_fc_working_<deckId>, sv_fc_seen_<deckId>,
//   sv_fc_ui), so on this origin the two surfaces share one store the
//   moment either writes.
// - Server sync uses the SAME contract as /account.js's SVAccount
//   adapter: GET /api/account/me and PUT /api/account/progress with the
//   sv_account bearer token, the same collect shape, and the same
//   union merge (server + local combine, Review beats Known, never a
//   deletion). Grading here therefore lands in the exact progress
//   document /dash and the flashcards page read.
// - Since Oct 19 2026 there is a second server store: the caller's
//   Llama feed profile (GET/PUT /api/v2/flashcards/progress, keyed by
//   the x-llama-user session). The SVAccount store only exists on the
//   starvard.org origin, which is why the Llama skin used to show 0%:
//   no token, different origin's localStorage. The profile store
//   follows the PERSON, so boot sync merges local + SVAccount +
//   profile with the same union merge and pushes the result to every
//   store present; progress is then identical on both skins.
//
// Model (identical to the page): a card is either Known, or in the
// Working (review) pile with {missed: day, ok: [days]}, or untouched.
// "I know this" moves it to Known; "I don't know this" moves it to
// Working stamped with today.

import { appPath } from "./theme.ts";
import { getAuthToken, getCallerId } from "./session.ts";

/** One card: [front term, pronunciation, translation, note]. */
export type FcCard = [string, string, string, string];

export interface FcDeckData {
  lang: string;
  langName: string;
  frontLabel: string;
  backLabel: string;
  speakLang: string;
  names: string[];
  decks: FcCard[][];
}

export interface WorkingEntry {
  missed: string;
  ok: string[];
}

export interface FcProgressDoc {
  flashcards: {
    known: Record<string, number[]>;
    working: Record<string, Record<string, WorkingEntry>>;
  };
}

let deckDataPromise: Promise<FcDeckData> | null = null;

export function loadDeckData(): Promise<FcDeckData> {
  if (!deckDataPromise) {
    deckDataPromise = fetch(appPath("/flashcards-es.json")).then((r) => {
      if (!r.ok) throw new Error(`deck data failed: ${r.status}`);
      return r.json() as Promise<FcDeckData>;
    });
  }
  return deckDataPromise;
}

export function deckIds(data: FcDeckData): string[] {
  return data.decks.map((_, l) => `${data.lang}${l + 1}`);
}

/* ---------- date + localStorage helpers (ported from the page) ---------- */

function pad(n: number): string {
  return (n < 10 ? "0" : "") + n;
}

export function todayStr(d?: Date): string {
  const t = d || new Date();
  return `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())}`;
}

function lsGet(k: string): number[] {
  try {
    const a: unknown = JSON.parse(localStorage.getItem(k) || "[]");
    return Array.isArray(a) ? (a as number[]) : [];
  } catch {
    return [];
  }
}

function lsObj<T>(k: string): Record<string, T> {
  try {
    const o: unknown = JSON.parse(localStorage.getItem(k) || "{}");
    return o && typeof o === "object" && !Array.isArray(o) ? (o as Record<string, T>) : {};
  } catch {
    return {};
  }
}

function lsSet(k: string, v: unknown): void {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {
    /* storage full/blocked: progress keeps living in memory this session */
  }
}

function lsDel(k: string): void {
  try {
    localStorage.removeItem(k);
  } catch {
    /* ignore */
  }
}

/* ---------- in-memory progress state (the page's K / W / SEEN maps) ---------- */

export type KnownMap = Record<string, Record<number, true>>;
export type WorkingMap = Record<string, Record<number, WorkingEntry>>;
export type SeenMap = Record<string, Record<number, string>>;

export const fcState: { K: KnownMap; W: WorkingMap; SEEN: SeenMap } = {
  K: {},
  W: {},
  SEEN: {},
};

export function loadAll(ids: string[]): void {
  const K: KnownMap = {};
  const W: WorkingMap = {};
  const SEEN: SeenMap = {};
  ids.forEach((id) => {
    const known: Record<number, true> = {};
    lsGet(`sv_fc_known_${id}`).forEach((i) => {
      known[i] = true;
    });
    // Legacy single-deck keys from the page's first version (es1 only).
    if (id === "es1" && !localStorage.getItem("sv_fc_known_es1")) {
      lsGet("sv_flash_known").forEach((i) => {
        known[i] = true;
      });
    }
    const working = lsObj<WorkingEntry>(`sv_fc_working_${id}`);
    lsGet(`sv_fc_missed_${id}`).forEach((i) => {
      if (!working[i]) working[i] = { missed: todayStr(), ok: [] };
    });
    if (localStorage.getItem(`sv_fc_missed_${id}`)) lsDel(`sv_fc_missed_${id}`);
    Object.keys(working).forEach((i) => {
      delete known[Number(i)];
    });
    K[id] = known;
    W[id] = working;
    SEEN[id] = lsObj<string>(`sv_fc_seen_${id}`);
  });
  fcState.K = K;
  fcState.W = W;
  fcState.SEEN = SEEN;
}

export function saveDeck(id: string): void {
  lsSet(
    `sv_fc_known_${id}`,
    Object.keys(fcState.K[id] || {})
      .map(Number)
      .sort((a, b) => a - b)
  );
  lsSet(`sv_fc_working_${id}`, fcState.W[id] || {});
  lsSet(`sv_fc_seen_${id}`, fcState.SEEN[id] || {});
  notifyChange();
}

export function levelKnown(ids: string[], l: number): number {
  return Object.keys(fcState.K[ids[l]] || {}).length;
}

export function totals(ids: string[]): { known: number; review: number; newToday: number } {
  let known = 0;
  let review = 0;
  let newToday = 0;
  const t = todayStr();
  ids.forEach((id) => {
    known += Object.keys(fcState.K[id] || {}).length;
    review += Object.keys(fcState.W[id] || {}).length;
    Object.values(fcState.SEEN[id] || {}).forEach((d) => {
      if (d === t) newToday++;
    });
  });
  return { known, review, newToday };
}

/* ---------- study UI prefs, shared with the page (sv_fc_ui) ---------- */

export interface FcUi {
  level: number;
  startEs: boolean;
}

export function loadUi(): FcUi {
  const ui: FcUi = { level: 0, startEs: true };
  try {
    const u: unknown = JSON.parse(localStorage.getItem("sv_fc_ui") || "null");
    if (u && typeof u === "object") Object.assign(ui, u as Partial<FcUi>);
  } catch {
    /* defaults */
  }
  return ui;
}

export function saveUi(ui: FcUi): void {
  lsSet("sv_fc_ui", ui);
}

/* ---------- the SVAccount sync contract (ported collect/merge) ---------- */

export function collect(ids: string[]): FcProgressDoc {
  const data: FcProgressDoc = { flashcards: { known: {}, working: {} } };
  ids.forEach((id) => {
    data.flashcards.known[id] = lsGet(`sv_fc_known_${id}`);
    data.flashcards.working[id] = lsObj<WorkingEntry>(`sv_fc_working_${id}`);
  });
  return data;
}

export function mergeProgress(
  ids: string[],
  server: Partial<FcProgressDoc> | null | undefined,
  local: FcProgressDoc
): FcProgressDoc {
  const out: FcProgressDoc = { flashcards: { known: {}, working: {} } };
  const empty: FcProgressDoc["flashcards"] = { known: {}, working: {} };
  const sf = (server && server.flashcards) || empty;
  const lf = local.flashcards || empty;
  ids.forEach((id) => {
    const sk = (sf.known || {})[id] || [];
    const lk = (lf.known || {})[id] || [];
    const sw = (sf.working || {})[id] || {};
    const lw = (lf.working || {})[id] || {};
    const kset = new Set<number>();
    sk.concat(lk).forEach((i) => kset.add(i));
    const w: Record<string, WorkingEntry> = {};
    [...Object.keys(sw), ...Object.keys(lw)].forEach((i) => {
      const a = sw[i];
      const b = lw[i];
      if (a && b) {
        const later = b.missed > a.missed ? b : a;
        const okSet = new Set<string>();
        (a.ok || []).concat(b.ok || []).forEach((d) => okSet.add(d));
        w[i] = { missed: later.missed, ok: [...okSet].sort() };
      } else {
        const only = a || b;
        if (only) w[i] = only;
      }
    });
    Object.keys(w).forEach((i) => kset.delete(Number(i)));
    out.flashcards.known[id] = [...kset].sort((x, y) => x - y);
    out.flashcards.working[id] = w;
  });
  return out;
}

/** Write a (merged) progress document into the shared local keys. */
export function applyProgress(ids: string[], data: Partial<FcProgressDoc> | null | undefined): void {
  const empty: FcProgressDoc["flashcards"] = { known: {}, working: {} };
  const f = (data && data.flashcards) || empty;
  ids.forEach((id) => {
    lsSet(`sv_fc_known_${id}`, (f.known || {})[id] || []);
    lsSet(`sv_fc_working_${id}`, (f.working || {})[id] || {});
  });
  loadAll(ids);
}

/* ---------- account API (same endpoints /account.js uses) ---------- */

function svToken(): string | null {
  try {
    const raw = localStorage.getItem("sv_account");
    if (!raw) return null;
    const s = JSON.parse(raw) as { token?: string };
    return s && s.token ? s.token : null;
  } catch {
    return null;
  }
}

async function accountApi(
  path: string,
  opts: { method?: string; body?: unknown } = {}
): Promise<Record<string, unknown>> {
  const token = svToken();
  const headers: Record<string, string> = {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  const r = await fetch(path, {
    method: opts.method || "GET",
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const j = (await r.json().catch(() => ({}))) as Record<string, unknown>;
  if (!r.ok) throw new Error(typeof j.error === "string" ? j.error : "request failed");
  return j;
}

/* ---------- profile API (progress follows the Llama profile) ---------- */

// Same base resolution as the app client (App.tsx): VITE_API_BASE,
// defaulting to the same-origin /api/v2. The Starvard build bakes the
// absolute workers.dev URL, so both skins reach the same endpoints.
function profileApiBase(): string {
  try {
    const v = (import.meta as unknown as { env?: Record<string, string | undefined> }).env
      ?.VITE_API_BASE;
    return (v || "/api/v2").replace(/\/$/, "");
  } catch {
    return "/api/v2";
  }
}

async function profileApi(
  path: string,
  opts: { method?: string; body?: unknown } = {}
): Promise<Record<string, unknown>> {
  const caller = getCallerId();
  if (!caller) throw new Error("signed out");
  const headers: Record<string, string> = { "x-llama-user": caller };
  // Discord is the only login (Nov 1 2026): the API requires the
  // verified Bearer token alongside the caller id.
  const authToken = getAuthToken();
  if (authToken) headers["Authorization"] = `Bearer ${authToken}`;
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  const r = await fetch(`${profileApiBase()}${path}`, {
    method: opts.method || "GET",
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const j = (await r.json().catch(() => ({}))) as Record<string, unknown>;
  if (!r.ok) {
    const e = j.error as { message?: string } | string | undefined;
    throw new Error(typeof e === "string" ? e : e?.message || "request failed");
  }
  return j;
}

let pushTimer: ReturnType<typeof setTimeout> | null = null;
let syncIds: string[] = [];

function pushSvNow(): void {
  if (!syncIds.length || !svToken()) return;
  let data: FcProgressDoc;
  try {
    data = collect(syncIds);
  } catch {
    return;
  }
  accountApi("/api/account/progress", { method: "PUT", body: { progress: data } }).catch(() => {});
}

function docHasCards(d: FcProgressDoc): boolean {
  const f = d.flashcards;
  return (
    Object.values(f.known).some((a) => a.length > 0) ||
    Object.values(f.working).some((w) => Object.keys(w).length > 0)
  );
}

// True once the profile row is known to exist (the boot GET returned
// a document, or a PUT landed). Until then an all-empty local
// document is NOT pushed: an empty row would masquerade as real
// synced progress and block the server-side SVAccount seed bridge,
// which only fires when there is no row yet.
let profileSyncArmed = false;

function pushProfileNow(): void {
  if (!syncIds.length || !getCallerId()) return;
  let data: FcProgressDoc;
  try {
    data = collect(syncIds);
  } catch {
    return;
  }
  if (!profileSyncArmed && !docHasCards(data)) return;
  profileApi("/flashcards/progress", { method: "PUT", body: { progress: data } })
    .then(() => {
      profileSyncArmed = true;
    })
    .catch(() => {});
}

/** Push the current local document to every server store present. */
function pushNow(): void {
  pushSvNow();
  pushProfileNow();
}

/** The page's SVAccount.notifyChange equivalent: debounce, then push. */
export function notifyChange(): void {
  if (!svToken() && !getCallerId()) return;
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(pushNow, 900);
}

let visibilityHooked = false;
function hookVisibilityFlush(): void {
  if (visibilityHooked || typeof document === "undefined") return;
  visibilityHooked = true;
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") pushNow();
  });
}

/**
 * Boot sync, mirroring SVAccount.attach + pullAndMerge, now for every
 * server store present: pull the server copy, union-merge it with
 * local, apply, and push the merged document back so all stores agree.
 * Resolves true when a server sync ran and the caller should
 * re-render. Silent no-op for any store whose session is absent
 * (progress still works locally, exactly like the flashcards page
 * signed out).
 *
 * Order matters: the SVAccount merge runs first, the profile merge
 * second against the already-enriched local state. On Starvard that
 * seeds the person's profile row from the richest progress they have
 * (their real Starvard history); from then on the profile row is what
 * makes the same progress appear on the Llama skin and any device.
 *
 * Authority rule (Dave, Oct 19 2026): for a signed-in user the
 * backend profile row is the SOURCE OF TRUTH and localStorage is a
 * cache/offline buffer, never the authority. The union merge is how
 * that reads in practice: the server document is the merge base,
 * local state only fills gaps (cards the server has never seen),
 * ties resolve to the server's entry, known cards are never lost,
 * and the merged result is written back up before boot finishes.
 */
export async function syncOnBoot(ids: string[]): Promise<boolean> {
  syncIds = ids;
  hookVisibilityFlush();
  let changed = false;
  if (svToken()) {
    try {
      const res = await accountApi("/api/account/me");
      const server = (res.progress ?? null) as Partial<FcProgressDoc> | null;
      const merged = mergeProgress(ids, server, collect(ids));
      applyProgress(ids, merged);
      pushSvNow();
      changed = true;
    } catch {
      /* silent: local progress still works */
    }
  }
  if (getCallerId()) {
    try {
      const res = await profileApi("/flashcards/progress");
      const server = (res.progress ?? null) as Partial<FcProgressDoc> | null;
      if (server) profileSyncArmed = true;
      // The backend row is the source of truth: with zero local data
      // the merged result IS the server document, applied in full, so
      // a brand-new device renders the person's complete progress.
      const merged = mergeProgress(ids, server, collect(ids));
      applyProgress(ids, merged);
      pushProfileNow();
      changed = true;
    } catch {
      /* silent: same failure posture as every sync here */
    }
  }
  return changed;
}
