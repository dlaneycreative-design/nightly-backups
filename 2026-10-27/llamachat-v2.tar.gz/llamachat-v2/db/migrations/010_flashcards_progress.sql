-- Flashcards progress follows the person (Oct 19 2026): until now the
-- only server copy of flashcards progress lived in the Starvard
-- SVAccount store (starvard.org /api/account), so the Llama Chat skin
-- (llamachat.lol, no SVAccount token, different origin localStorage)
-- always showed 0% even for people mid-course on Starvard.
--
-- flashcards_progress: one row per Llama profile, the progress
-- document stored opaquely as JSONB (same {flashcards:{known,working}}
-- shape the SVAccount adapter and the client merge already use). The
-- client union-merges server + local on load and pushes the merged
-- document back, so rows only ever gain cards, never lose them.
-- Keyed by the caller's own profile id: the API reads/writes only the
-- row belonging to the x-llama-user header's profile.
--
-- The schema is also self-applied by the Worker at runtime
-- (ensureFlashcardsSchema in src/routes/flashcards.js), so production
-- works even before this migration is applied by hand.

CREATE TABLE IF NOT EXISTS flashcards_progress (
  profile_id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  progress   JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at BIGINT NOT NULL
);
