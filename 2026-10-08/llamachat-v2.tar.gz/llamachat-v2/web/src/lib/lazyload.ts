// IntersectionObserver lazy-load helper. Images (and heavy rows) only
// load when within `rootMargin` of the viewport. Falls back to eager
// load where IntersectionObserver is unavailable.

export function observeOnce(
  el: Element,
  onVisible: () => void,
  rootMargin = "800px"
): () => void {
  if (typeof IntersectionObserver === "undefined") {
    onVisible();
    return () => {};
  }
  const io = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          io.disconnect();
          onVisible();
          break;
        }
      }
    },
    { rootMargin }
  );
  io.observe(el);
  return () => io.disconnect();
}

/** Prefetch a URL into the HTTP cache (used for next-page thumbnails). */
export function prefetch(url: string): void {
  try {
    const link = document.createElement("link");
    link.rel = "prefetch";
    link.as = "image";
    link.href = url;
    document.head.appendChild(link);
  } catch {
    /* non-fatal */
  }
}
