// /approved: the link we hand to invited people (Dave's order Oct 19
// 2026). "We invite a person, send them to llamachat.lol/approved, and
// there they claim their account." Same self-serve form as the join
// modal, on its own page so the link works cold from any message app.
import { useState } from "react";
import type { Profile } from "../lib/api.ts";
import { SignupForm } from "./SignupForm.tsx";

const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "/api/v2";

export function ApprovedPage({ me }: { me: Profile | null }) {
  const [created, setCreated] = useState(false);
  return (
    <div style={{ maxWidth: 420, margin: "48px auto", padding: "0 20px" }}>
      {!created ? (
        <>
          <h1 style={{ fontSize: 28, margin: "0 0 8px", textAlign: "center" }}>Welcome to LlamaChat 🦙</h1>
          <p style={{ color: "#536471", margin: "0 0 8px", fontSize: 15, textAlign: "center" }}>
            You were invited. Claim your account below and you are in: pick your username, add your name and Instagram, done.
          </p>
        </>
      ) : null}
      {me && !created ? (
        <p style={{ color: "#536471", fontSize: 14, textAlign: "center", marginBottom: 8 }}>
          You are already logged in as <b>@{me.handle}</b>. This form creates a new account.
        </p>
      ) : null}
      <SignupForm apiBase={API_BASE} onCreated={() => setCreated(true)} />
      {!created ? (
        <p style={{ fontSize: 13, marginTop: 16, textAlign: "center" }}>
          <a href="/login" style={{ color: "#1d9bf0" }}>Already have an account? Log in</a>
        </p>
      ) : null}
    </div>
  );
}
