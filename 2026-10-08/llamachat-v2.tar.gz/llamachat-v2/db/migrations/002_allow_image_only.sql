-- Allow image-only posts: text can be empty if image_url is present.
ALTER TABLE tweets DROP CONSTRAINT IF EXISTS tweets_text_check;
ALTER TABLE tweets ADD CONSTRAINT tweets_text_check
  CHECK (char_length(text) BETWEEN 0 AND 2000 AND (char_length(text) > 0 OR image_url IS NOT NULL));
