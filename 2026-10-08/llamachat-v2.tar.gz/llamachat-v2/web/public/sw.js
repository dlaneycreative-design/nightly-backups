// LlamaChat service worker: network-first for everything to avoid stale data.
// (Dave's call Oct 8 2026: cache was serving old feed)
const CACHE = "llamachat-v3";

self.addEventListener("install", (e) => {
  e.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  // Always go to network, no caching
  return;
});
