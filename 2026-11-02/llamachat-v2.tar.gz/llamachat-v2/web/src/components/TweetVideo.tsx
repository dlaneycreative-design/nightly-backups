// Tweet video player (Nov 1 2026). A video tweet carries a
// video_url pointing at an already-hosted mp4 (LlamaChat stores no
// video bytes, Dave's space rule); the tweet's image_url doubles
// as the poster frame. Native controls, metadata preload only, so
// the feed stays light: nothing downloads until someone presses
// play. Mirrors TweetImage's wrap and frame styling.
import { resolveImageUrl } from "../lib/images.ts";

interface Props {
  videoUrl: string;
  posterUrl?: string | null;
}

export function TweetVideo({ videoUrl, posterUrl }: Props) {
  const poster = posterUrl ? resolveImageUrl(posterUrl) || posterUrl : undefined;
  return (
    <div className="tweet-video-wrap">
      <video
        className="tweet-video"
        src={videoUrl}
        poster={poster}
        controls
        preload="metadata"
        playsInline
      />
    </div>
  );
}
