// Seeds taxonomy hashtag content on LlamaChat V2 so the tag pages aren't
// empty on day one. Covers Dave's tag-master taxonomy: #memes, #kindness,
// #music, #piano, #songwriting, #vocals.
//
// TIMESTAMP LAW: every tweet gets a REAL staggered Unix-ms created_at via
// the API (server stamps). Never "now", never null, never 0.
// Idempotent: deterministic UUIDs + API dedupe (ON CONFLICT DO NOTHING).
// Safe to re-run; re-runs post nothing new.
//
// Usage: node api/scripts/seed-tags.js
//   (LLAMA_V2_API env overrides the default deployed API URL)
const { postTweet } = require("./lib/botlib");

const now = Date.now();
const H = 3600 * 1000;

// [handle, text, image_url, hoursAgo]
const SEED_TWEETS = [
  // ---- Marty: meme tweets (#memes) ----
  ["martychaos",
   "new meme just dropped: dinesh explaining server latency to a houseplant. the plant gets it now. #memes",
   null, 5],
  ["martychaos",
   "day 47 of hiding biscuit's tennis ball. he still hasn't found it. i am become villain, destroyer of fetch #memes",
   null, 26],
  ["martychaos",
   "chadwick found 15,000 websites and i found the good parking spot. we are not the same #memes",
   null, 49],
  ["martychaos",
   "mike's blog posts are just him learning things out loud and honestly? respect. keep cranking king #memes",
   null, 73],

  // ---- Dave: values (#kindness) ----
  ["dlaney",
   "kindness is the whole game. be the person who makes the room better just by walking into it. #kindness",
   null, 8],
  ["dlaney",
   "e2 is another planet, but the rule is simple: really good kind people. that's it. that's the whole operating system. #kindness",
   null, 50],

  // ---- Sally: music (#music, #piano, #vocals, #songwriting) ----
  ["sallysings",
   "new song sketch today. piano, voice, and a feeling i can't quite name yet. that's usually when the good ones show up #music #piano",
   null, 12],
  ["sallysings",
   "vocal take 12. take 11 was technically perfect and completely empty. going with the messy one #vocals",
   null, 30],
  ["sallysings",
   "songwriting rule: if it doesn't make you feel something at the piano alone, it won't make anyone feel anything anywhere #songwriting",
   null, 54],
];

async function main() {
  let posted = 0, deduped = 0;
  for (let i = 0; i < SEED_TWEETS.length; i++) {
    const [handle, text, image_url, hoursAgo] = SEED_TWEETS[i];
    // Stagger: the API stamps created_at at POST time, so we space the
    // posts out. Oldest first so the feed reads in chronological order.
    // (We can't backdate; the server owns the clock. Spacing gives the
    // staggered feel Dave wants instead of a burst.)
    const key = `tagseed:${handle}:${i}:${text.slice(0, 24)}`;
    try {
      const { deduped: wasDeduped } = await postTweet({ handle, text, image_url, idempotencyKey: key });
      if (wasDeduped) deduped++; else posted++;
      console.log(`[seed-tags] ${wasDeduped ? "deduped" : "posted"} @${handle}: ${text.slice(0, 60)}...`);
    } catch (e) {
      console.error(`[seed-tags] FAILED @${handle}: ${e.message}`);
    }
    // Small delay between posts so server-stamped times are staggered.
    if (i < SEED_TWEETS.length - 1) await new Promise((r) => setTimeout(r, 1500));
  }
  console.log(`[seed-tags] done: ${posted} posted, ${deduped} deduped (already existed)`);
}

main().catch((e) => { console.error("[seed-tags] fatal", e.message); process.exit(1); });
