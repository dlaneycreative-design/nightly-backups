# LlamaChat Inspector: standing watchdog for llamachat.lol media + health.
# Dave's order Oct 13 2026, modeled on the Farm's Inspector.
# Full census, NO sampling. A URL passes only if ALL of these hold:
#   1. It resolves (exactly like web/src/lib/images.ts) to llamachat.lol itself.
#   2. The live server returns it with a 200/206.
#   3. The returned bytes sniff as a real image (not HTML, not an error page).
#   4. When the file exists in web/dist, the live byte count equals it.
#   5. The live byte count is at most 100 KB (the Llama Chat media cap,
#      Dave's law; rule name "oversize", added Oct 13 after a 1.4 MB PNG
#      was found by hand on the E2 homepage).
# Also audited: the live /seed-feed.json (every image inside it, same rules,
# plus a dead-host string scan), /api/v2/health, the site root, and that the
# live service worker cache version matches the source tree (stale-deploy
# tripwire). Writes inspector-reports/report-<ts>.json + inspector-state.json.
# Exit: 0 PASS, 1 FAIL, 2 INCOMPLETE (the inspector itself could not finish).
#
# Transport resilience (Oct 15 2026, Dave: "Please fix the inspector"): the
# census used to be one long single pass, so a run killed by the degraded VM
# egress (or a runtime timeout) lost everything and the next run restarted
# from zero. Now definitive per-URL results are checkpointed to
# inspector-progress.json as they land, keyed by a hash of the census inputs;
# a later invocation resumes where the last one stopped. Results whose fetch
# died in transit are NEVER checkpointed as done: they are rechecked on the
# next invocation. A sweep that ends with any check still
# transport-inconclusive writes INCOMPLETE and also keeps its checkpoint;
# only a sweep where every check produced a definitive result earns
# PASS/FAIL and clears it. A soft time budget on the check phase lets a run
# pause cleanly (state INCOMPLETE, checkpoint kept) instead of being killed
# mid-flight. What is checked, the rules, and the verdict format are
# unchanged.
import fcntl, hashlib, json, os, re, ssl, subprocess, sys, time
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor

BASE = "/home/hatch/workspace/llamachat-v2"
HOST = "https://llamachat.lol"
DIST = os.path.join(BASE, "web", "dist")
MAX_IMAGE_BYTES = 100 * 1024
REPORTS = os.path.join(BASE, "inspector-reports")
PROGRESS = os.path.join(BASE, "inspector-progress.json")
CHECK_BUDGET_SECONDS = 1800  # soft cap on the live-check phase per invocation
PROGRESS_MAX_AGE = 86400     # checkpoints older than this are discarded
TRANSPORT_MARKERS = ("IncompleteRead", "RemoteDisconnected", "TimeoutError",
                     "timed out", "URLError", "ConnectionResetError",
                     "Remote end closed", "EOF occurred")

ABS_AVATAR_MAP = {
    "https://www.thestudio.io/casting/willa-portrait.webp": "/assets/avatars/willa.webp",
    "https://www.thestudio.io/casting/finn-portrait.webp": "/assets/avatars/finn.webp",
    "https://www.thestudio.io/daveos/img/chadwick-waving.png": "/assets/avatars/chadwick.webp",
    "https://www.thestudio.io/muse-avatar-final.webp": "/assets/avatars/muse.webp",
    "https://www.thestudio.io/e2/people/judgetootie/judgetootie.webp": "/assets/avatars/judge.webp",
    "https://www.thestudio.io/mike/assets/mike-gym-selfie.webp": "/assets/avatars/songify.webp",
    "https://e2.life/people/sam/sam.webp": "/assets/avatars/sam.webp",
}
LEGACY_AVATAR_MAP = {
    "/sloth/assets/llama-avatar.webp": "/assets/avatars/llama.webp",
    "/shortbus/assets/portraits/sally.jpg": "/assets/avatars/sally.jpg",
    "/shortbus/assets/portraits/marty-face.jpg": "/assets/avatars/martychaos.jpg",
    "/shortbus/assets/portraits/dinesh-solo.webp": "/assets/avatars/dinesh.webp",
    "/sloth/assets/ricky-avatar.webp": "/assets/avatars/memebot.webp",
    "/shortbus/assets/portraits/mateo.webp": "/assets/avatars/mateo.webp",
    "/shortbus/assets/portraits/haddie-face.jpg": "/assets/avatars/haddiesings.jpg",
    "/sloth/assets/harsh-avatar.jpg": "/assets/avatars/harsh.jpg",
    "/shortbus/assets/portraits/tex.jpg": "/assets/avatars/tex.webp",
    "/shortbus/assets/portraits/chadwick-face.jpg": "/assets/avatars/chadwickblaze.jpg",
    "/shortbus/assets/portraits/jaylen-bass.jpg": "/assets/avatars/jaylen.webp",
    "/shortbus/assets/portraits/jah-vibez.jpg": "/assets/avatars/jahvibez.webp",
    "/shortbus/assets/portraits/biscuit-face.jpg": "/assets/avatars/biscuit.jpg",
    "/shortbus/assets/portraits/gloria.jpg": "/assets/avatars/gloria.webp",
    "/sloth/assets/mike-static.png": "/assets/avatars/mike.png",
    "/plume/plume.webp": "/assets/avatars/plume.webp",
    "/henri/henri-hue.webp": "/assets/avatars/henri.webp",
    "/oldray/old-ray.webp": "/assets/avatars/oldray.webp",
    "/enrique/enrique.png": "/assets/avatars/enrique.webp",
    "/lemonHD/assets/leo-remake.webp": "/assets/avatars/leo.webp",
    "/dineshbot/dineshbot-avatar.webp": "/assets/avatars/dineshbot.webp",
    "/sally/doodle-bot.png": "/assets/avatars/doodle.webp",
    "/pixel/buster/buster-portrait.webp": "/assets/avatars/buster.webp",
    "/e2/map/sprite-mappy.webp": "/assets/avatars/mappy.webp",
    "/assets/hank.webp": "/assets/avatars/hank.webp",
    "/assets/ed.webp": "/assets/avatars/ed.webp",
    "/assets/avatars/dave-dlaney-face-400.webp": "/assets/avatars/dave.webp",
}
DEAD_HOSTS = ("thestudio.io", "blob.vercel-storage.com", "media.e2.life", "e2planet.com")

def resolve(url):
    if not url:
        return None
    if url in ABS_AVATAR_MAP:
        return ABS_AVATAR_MAP[url]
    if url.startswith("https://www.thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://www.thestudio.io/"):]
    if url.startswith("https://thestudio.io/"):
        return "https://llamachat.lol/" + url[len("https://thestudio.io/"):]
    if re.match(r"^(https?:|data:|blob:)", url, re.I):
        return url
    if url.startswith("//"):
        return "https:" + url
    if url in LEGACY_AVATAR_MAP:
        return LEGACY_AVATAR_MAP[url]
    if url.startswith("/assets/"):
        return url
    if url.startswith("/"):
        return HOST + url
    return url

def absolute(resolved):
    if resolved and resolved.startswith("/"):
        return HOST + resolved
    return resolved

def sniff(b):
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return "webp"
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if b[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if b[4:8] == b"ftyp":
        return "avif"
    if b[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if b"<svg" in b[:256]:
        return "svg"
    return None

ctx = ssl.create_default_context()

def fetch(url, want_body=True):
    """Return (status, body_bytes_or_None, error_str). 4 attempts with
    growing backoff (Oct 13: the VM egress collapses in waves lasting
    longer than the old 1s retry gaps, so every URL in a wave failed
    together; wider spacing lets a wave pass mid-run)."""
    last = (None, None, "no attempt")
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (LlamaChat Inspector)"})
            with urllib.request.urlopen(req, timeout=25, context=ctx) as r:
                body = r.read() if want_body else None
                return (r.status, body, None)
        except urllib.error.HTTPError as e:
            last = (e.code, None, f"HTTP {e.code}")
            if e.code in (404, 410, 403, 522):
                return last
        except Exception as e:
            last = (None, None, f"{type(e).__name__}")
        time.sleep((2, 5, 10)[min(attempt, 2)])
    return last

def check_media(url):
    """Return list of failure dicts for one resolved absolute URL (empty = pass)."""
    fails = []
    if url.startswith(("data:", "blob:")):
        return fails
    if not (url.startswith(HOST + "/") or url == HOST):
        return [{"url": url, "rule": "home", "detail": "resolves OFF llamachat.lol"}]
    status, body, err = fetch(url)
    if status not in (200, 206):
        return [{"url": url, "rule": "status", "detail": f"live status {status or err}"}]
    kind = sniff(body or b"")
    if not kind:
        return [{"url": url, "rule": "bytes", "detail": "live bytes are not an image (fallback page?)"}]
    if body is not None and len(body) > MAX_IMAGE_BYTES:
        fails.append({"url": url, "rule": "oversize",
                      "detail": f"live image is {len(body)}B, over the 100KB Llama Chat media cap"})
    path = url[len(HOST):]
    disk = os.path.join(DIST, path.lstrip("/"))
    if os.path.isfile(disk) and body is not None and len(body) != os.path.getsize(disk):
        fails.append({"url": url, "rule": "size", "detail": f"live {len(body)}B != dist {os.path.getsize(disk)}B"})
    return fails

# --- checkpoint helpers -------------------------------------------------

def _is_transport_detail(detail):
    return any(t in str(detail) for t in TRANSPORT_MARKERS)

def _media_result_inconclusive(fails):
    """A media result proves nothing when the fetch itself died in transit;
    such results are never checkpointed, so the URL is rechecked next run."""
    return any(f.get("rule") == "status" and _is_transport_detail(f.get("detail", ""))
               for f in fails)

def load_progress():
    try:
        with open(PROGRESS) as fh:
            return json.load(fh)
    except Exception:
        return None

def save_progress(p):
    tmp = PROGRESS + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(p, fh)
    os.replace(tmp, PROGRESS)

def clear_progress():
    try:
        os.remove(PROGRESS)
    except OSError:
        pass

def finalize(failures, notes):
    """Verdict computation, unchanged from the original inspector.
    Transport honesty (Oct 13): when the census network path collapses
    (VM egress under load, dueling runs), most "failures" are read errors
    on files that are fine. A run dominated by transport errors proves
    nothing about the site: verdict INCOMPLETE, real failures kept."""
    transport = [f for f in failures
                 if any(t in str(f.get("detail", "")) for t in TRANSPORT_MARKERS)]
    ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    if failures and len(transport) >= max(10, len(failures) // 2):
        real = [f for f in failures if f not in transport]
        failures = [{"url": HOST + "/", "rule": "transport",
                     "detail": f"census network collapsed: {len(transport)} read errors, {len(real)} real failures; verdict deferred to a clean run"}] + real
        report = {"verdict": "INCOMPLETE", "run_at": ts, "notes": notes, "failures": failures}
        json.dump(report, open(os.path.join(REPORTS, f"report-{ts}.json"), "w"), indent=1)
        clear_progress()
        save_state("INCOMPLETE", failures, ts)
        print(f"INCOMPLETE: {len(transport)} transport errors, {len(real)} real failures")
        return 2
    verdict = "PASS" if not failures else "FAIL"
    report = {"verdict": verdict, "run_at": ts, "notes": notes, "failures": failures}
    json.dump(report, open(os.path.join(REPORTS, f"report-{ts}.json"), "w"), indent=1)
    clear_progress()
    save_state(verdict, failures, ts)
    print(f"{verdict}: {len(failures)} failures | " + " | ".join(notes))
    for f in failures:
        print(" FAIL", f["rule"], f["url"], "-", f["detail"])
    return 0 if verdict == "PASS" else 1

def pause_run(real_failures, done, total):
    """Soft-budget stop: state goes INCOMPLETE (a paused census must never
    look like a healthy site), the checkpoint stays on disk, and the next
    invocation resumes instead of restarting the census from zero."""
    failures = [{"url": HOST + "/", "rule": "transport",
                 "detail": f"census paused for resume: {done} of {total} media URLs verified, {len(real_failures)} real failures so far; next run resumes from checkpoint"}] + real_failures
    save_state("INCOMPLETE", failures)
    print(f"INCOMPLETE: paused at checkpoint ({done}/{total} media URLs verified); next run resumes")
    return 2

def main():
    # Single-runner lock (Oct 13): dueling inspector processes saturate the
    # egress path and manufacture read-error failures. If another run holds
    # the lock, exit WITHOUT touching state; that run writes the verdict.
    lockf = open("/tmp/llamachat-inspector.lock", "w")
    try:
        fcntl.flock(lockf, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("INCOMPLETE: another inspector run is already in progress; skipping")
        return 2
    notes = []
    os.makedirs(REPORTS, exist_ok=True)
    # 1. Refresh the DB enumeration.
    try:
        r = subprocess.run(["node", os.path.join(BASE, "census-enumerate.js")],
                           capture_output=True, text=True, timeout=1200)
    except subprocess.TimeoutExpired:
        print("INCOMPLETE: enumeration timed out after 1200s")
        save_state("INCOMPLETE", [{"url": "(database)", "rule": "enumerate",
                                   "detail": "census-enumerate.js timed out after 1200 seconds"}])
        return 2
    if r.returncode != 0:
        print("INCOMPLETE: enumeration failed:", (r.stderr or r.stdout)[:300])
        save_state("INCOMPLETE", [{"url": "(database)", "rule": "enumerate", "detail": "census-enumerate.js failed"}])
        return 2
    raw = json.load(open(os.path.join(BASE, "census-raw.json")))
    refs = []
    for p in raw["profiles"]:
        if p.get("avatar_url"):
            refs.append(("avatar", p["handle"], p["avatar_url"]))
    for t in raw["tweets"]:
        refs.append(("tweet-image", t["id"], t["image_url"]))
    for m in raw["messages"]:
        refs.append(("message-image", m["id"], m["image_url"]))
    # 2. Home rule on STORED urls: a stored absolute URL on a dead host is a
    # failure even if the client map rescues it today.
    stored_failures = []
    for kind, owner, stored in refs:
        for h in DEAD_HOSTS:
            if h in stored:
                stored_failures.append({"url": stored, "rule": "stored-host",
                                        "detail": f"{kind} of {owner} is stored on {h}"})
    distinct = sorted({absolute(resolve(s)) for _, _, s in refs if resolve(s)})
    # Checkpoint, keyed to THIS census: if the enumerated inputs changed
    # (or the checkpoint is stale), earlier partial results do not apply.
    census_hash = hashlib.sha256(json.dumps(
        {"distinct": distinct, "stored": stored_failures},
        sort_keys=True).encode()).hexdigest()
    progress = load_progress()
    if (not progress or progress.get("census_hash") != census_hash
            or time.time() - progress.get("started_at", 0) > PROGRESS_MAX_AGE):
        progress = {"census_hash": census_hash, "started_at": time.time(),
                    "media": {}, "seed": None, "health": None}
        save_progress(progress)
    # Sanitize a resumed checkpoint: a seed stage checkpointed by an early
    # build may contain inner media checks that died in transit. Those prove
    # nothing; drop the stage so it reruns instead of leaking transport
    # errors into a final verdict as site failures.
    if progress.get("seed") and any(
            f.get("rule") == "seed-status" and _is_transport_detail(f.get("detail", ""))
            for f in progress["seed"].get("failures", [])):
        progress["seed"] = None
        save_progress(progress)
    check_start = time.time()

    def over_budget():
        return time.time() - check_start > CHECK_BUDGET_SECONDS

    def media_failures_so_far(include_inconclusive):
        out = []
        for url in distinct:
            fl = progress["media"].get(url)
            if fl is None and include_inconclusive:
                fl = media_now.get(url, [])
            for f in fl or []:
                f2 = dict(f)
                f2["refs"] = sum(1 for _, _, s in refs if absolute(resolve(s)) == url)
                out.append(f2)
        return out

    # 3. Byte-level live check of every distinct resolved URL, in chunks,
    # checkpointing definitive results as they land. URLs whose fetch died
    # in transit stay OUT of the checkpoint and are rechecked next run.
    media_now = {}  # inconclusive results from THIS invocation only
    todo = [u for u in distinct if u not in progress["media"]]
    if todo:
        with ThreadPoolExecutor(max_workers=3) as ex:
            for i in range(0, len(todo), 12):
                chunk = todo[i:i + 12]
                for url, fl in zip(chunk, ex.map(check_media, chunk)):
                    if _media_result_inconclusive(fl):
                        media_now[url] = fl
                    else:
                        progress["media"][url] = fl
                save_progress(progress)
                if over_budget() and i + 12 < len(todo):
                    return pause_run(stored_failures + media_failures_so_far(False),
                                     len(progress["media"]), len(distinct))
    notes.append(f"media: {len(refs)} refs, {len(distinct)} distinct URLs checked")
    # 4. Seed audit: the live seed file browsers actually paint from.
    seed_now = None  # failures from THIS invocation (stage attempted)
    if progress.get("seed") is None:
        if over_budget():
            return pause_run(stored_failures + media_failures_so_far(False),
                             len(progress["media"]), len(distinct))
        seed_failures = []
        seed_note = None
        seed_done = False
        status, body, err = fetch(HOST + "/seed-feed.json")
        if status is None and _is_transport_detail(err):
            # The fetch itself died in transit: proves nothing, retried next
            # run; the failure still counts toward this run's verdict math.
            seed_failures.append({"url": HOST + "/seed-feed.json", "rule": "seed",
                                  "detail": f"live seed status {err}"})
        elif status != 200 or not body:
            seed_failures.append({"url": HOST + "/seed-feed.json", "rule": "seed",
                                  "detail": f"live seed status {status or err}"})
            seed_done = True
        else:
            seed_done = True
            try:
                seed = json.loads(body.decode("utf-8"))
                text = body.decode("utf-8", "replace")
                for h in DEAD_HOSTS:
                    if h in text:
                        seed_failures.append({"url": HOST + "/seed-feed.json", "rule": "seed-host",
                                              "detail": f"seed contains {h}"})
                # e2.life in tweet TEXT links is approved (Dave, Oct 13: the
                # mikeblog links point at e2.life/mikeblog). It still fails as a
                # media host: no cross-site images, ever.
                seed_media = []
                for t in seed.get("tweets", []):
                    if t.get("image_url"):
                        seed_media.append(t["image_url"])
                    a = t.get("author") or {}
                    if a.get("avatar_url"):
                        seed_media.append(a["avatar_url"])
                for p in seed.get("profiles", []):
                    if isinstance(p, dict) and p.get("avatar_url"):
                        seed_media.append(p["avatar_url"])
                for u in seed_media:
                    if "e2.life" in str(u):
                        seed_failures.append({"url": HOST + "/seed-feed.json", "rule": "seed-host",
                                              "detail": "seed media hosted on e2.life"})
                seed_urls = set()
                for t in seed.get("tweets", []):
                    if t.get("image_url"):
                        seed_urls.add(absolute(resolve(t["image_url"])))
                    a = t.get("author") or {}
                    if a.get("avatar_url"):
                        seed_urls.add(absolute(resolve(a["avatar_url"])))
                seed_urls.discard(None)
                with ThreadPoolExecutor(max_workers=3) as ex:
                    for url, fl in zip(sorted(seed_urls), ex.map(check_media, sorted(seed_urls))):
                        for f in fl:
                            f = dict(f)
                            f["rule"] = "seed-" + f["rule"]
                            seed_failures.append(f)
                seed_note = f"seed: {len(seed.get('tweets', []))} tweets, {len(seed_urls)} image URLs checked"
            except Exception as e:
                seed_failures.append({"url": HOST + "/seed-feed.json", "rule": "seed",
                                      "detail": f"unparseable: {type(e).__name__}"})
        seed_now = seed_failures
        if seed_done and any(f.get("rule") == "seed-status" and _is_transport_detail(f.get("detail", ""))
                             for f in seed_failures):
            # Inner seed media checks that died in transit prove nothing:
            # the stage is NOT done and reruns next invocation, exactly
            # like inconclusive media-census results.
            seed_done = False
        if seed_done:
            progress["seed"] = {"failures": seed_failures, "note": seed_note}
            save_progress(progress)
    if progress.get("seed") is not None:
        seed_failures_final = progress["seed"]["failures"]
        if progress["seed"].get("note"):
            notes.append(progress["seed"]["note"])
    else:
        seed_failures_final = seed_now or []
    # 5. Site + API health and the stale-deploy tripwire.
    health_now = None  # failures from THIS invocation (stage attempted)
    if progress.get("health") is None:
        if over_budget():
            return pause_run(stored_failures + media_failures_so_far(False) + seed_failures_final,
                             len(progress["media"]), len(distinct))
        health_failures = []
        health_done = True
        status, body, err = fetch(HOST + "/")
        if status is None:
            health_done = False
        if status != 200 or not body or b"LlamaChat" not in body:
            health_failures.append({"url": HOST + "/", "rule": "health", "detail": f"root status {status or err}"})
        status, body, err = fetch(HOST + "/api/v2/health")
        if status is None:
            health_done = False
        if status != 200:
            health_failures.append({"url": HOST + "/api/v2/health", "rule": "health", "detail": f"api health {status or err}"})
        local_sw = open(os.path.join(BASE, "web", "public", "sw.js")).read()
        m = re.search(r"const CACHE = '([^']+)'", local_sw)
        status, body, err = fetch(HOST + "/sw.js")
        if status is None:
            health_done = False
        if status != 200 or not body:
            health_failures.append({"url": HOST + "/sw.js", "rule": "health", "detail": f"sw status {status or err}"})
        elif m and m.group(1).encode() not in body:
            health_failures.append({"url": HOST + "/sw.js", "rule": "stale-deploy",
                                    "detail": f"live sw cache != source {m.group(1)} (deploy is behind the tree)"})
        health_now = health_failures
        if health_done:
            progress["health"] = {"failures": health_failures}
            save_progress(progress)
    if progress.get("health") is not None:
        health_failures_final = progress["health"]["failures"]
    else:
        health_failures_final = health_now or []
    failures = stored_failures + media_failures_so_far(True) + seed_failures_final + health_failures_final
    # A census counts as complete only when EVERY check produced a
    # definitive result. If any fetch died in transit (media URLs left in
    # media_now, or a seed/health stage that could not finish), the verdict
    # stays INCOMPLETE and the checkpoint is KEPT, so the next invocation
    # rechecks only what transport took. Transport errors are never
    # promoted to site failures.
    seed_inconclusive = seed_now is not None and progress.get("seed") is None
    health_inconclusive = health_now is not None and progress.get("health") is None
    if media_now or seed_inconclusive or health_inconclusive:
        transport = [f for f in failures
                     if any(t in str(f.get("detail", "")) for t in TRANSPORT_MARKERS)]
        real = [f for f in failures if f not in transport]
        out = [{"url": HOST + "/", "rule": "transport",
                "detail": f"census network collapsed: {len(transport)} read errors, {len(real)} real failures; verdict deferred to a clean run"}] + real
        ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        report = {"verdict": "INCOMPLETE", "run_at": ts, "notes": notes, "failures": out}
        json.dump(report, open(os.path.join(REPORTS, f"report-{ts}.json"), "w"), indent=1)
        save_state("INCOMPLETE", out, ts)
        print(f"INCOMPLETE: {len(transport)} transport errors, {len(real)} real failures; checkpoint kept ({len(progress['media'])}/{len(distinct)} media URLs verified)")
        return 2
    # Every check definitive: aggregate in the original order and compute
    # the verdict exactly as the single-pass inspector did.
    return finalize(failures, notes)

def save_state(verdict, failures, ts=None):
    state = {"verdict": verdict, "run_at": ts or time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()),
             "failure_count": len(failures), "failures": failures[:50]}
    json.dump(state, open(os.path.join(BASE, "inspector-state.json"), "w"), indent=1)

if __name__ == "__main__":
    sys.exit(main())
