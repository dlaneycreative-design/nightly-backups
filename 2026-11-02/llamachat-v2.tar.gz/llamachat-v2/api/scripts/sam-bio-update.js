// Update Sam's LlamaChat bio (Dave's order Nov 1 2026): no Llamagram
// mention; she does social for E2 and is still figuring it all out,
// a little self-deprecating, still catching up with everything.
const { API_BASE, getProfileId, serviceHeaders } = require("./lib/botlib");

const BIO = "E2 social media director. Still figuring all of this out as I go, so bear with me while I catch up. Yes, that is me in the photos.";

(async () => {
  const before = await (await fetch(`${API_BASE}/profiles/sam`)).json();
  console.log("before:", before.profile.bio);
  const id = await getProfileId("sam");
  const res = await fetch(`${API_BASE}/profiles/sam`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify({ bio: BIO }),
  });
  if (!res.ok) throw new Error(`PATCH -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("after:", d.profile.bio);
  const verify = await (await fetch(`${API_BASE}/profiles/sam`)).json();
  console.log("live verify:", verify.profile.bio);
  if (verify.profile.bio !== BIO) throw new Error("live bio does not match");
  console.log("OK");
})().catch((e) => { console.error("ERR", e.message); process.exit(1); });
