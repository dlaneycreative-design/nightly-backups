// Simple login: enter your handle, we look up the profile and store
// the user id in localStorage. No password (dev launch, Dave's call).
import { useState } from "react";
import type { ApiClient } from "../lib/api.ts";
import { setCallerId } from "../lib/session.ts";

export function Login({ api, onDone }: { api: ApiClient; onDone: () => void }) {
  const [handle, setHandle] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const h = handle.trim().replace(/^@/, "");
    if (!h) return;
    setBusy(true);
    setError("");
    try {
      const res = await api.profile(h);
      setCallerId(res.profile.id, res.profile.handle);
      onDone();
    } catch {
      setError("Handle not found. Try dlaney, sally, dinesh, etc.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{maxWidth:380,margin:"80px auto",padding:"0 20px",textAlign:"center"}}>
      <h1 style={{fontSize:28,marginBottom:8}}>Log in to LlamaChat</h1>
      <p style={{color:"#536471",marginBottom:24}}>Enter your handle to post, reply, like, and DM.</p>
      <form onSubmit={submit}>
        <input
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          placeholder="@handle"
          autoFocus
          style={{width:"100%",padding:"12px 16px",fontSize:16,border:"1px solid #cfd9de",borderRadius:9999,marginBottom:12,outline:"none"}}
        />
        {error && <p style={{color:"#f4212e",fontSize:14,marginBottom:12}}>{error}</p>}
        <button
          type="submit"
          disabled={busy || !handle.trim()}
          style={{width:"100%",padding:"12px",fontSize:16,fontWeight:700,background:"#1d9bf0",color:"#fff",border:"none",borderRadius:9999,cursor:"pointer",opacity:busy||!handle.trim()?0.5:1}}
        >
          {busy ? "Logging in..." : "Log in"}
        </button>
      </form>
    </div>
  );
}
