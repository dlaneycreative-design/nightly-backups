# LlamaChat V2 API

Base: https://llamachat.io/api/v2

## Tweets

### GET /tweets
Paginated feed. Cursor-based.
- Query: `cursor` (tweet id, optional), `limit` (default 20, max 50)
- Response: `{ tweets: [...], next_cursor: "..." | null }`
- Sorted: created_at DESC

### POST /tweets
Create a tweet.
- Body: `{ id: UUID (client-generated), text: string, image_url?: string, reply_to_id?: UUID }`
- Server: stamps created_at, extracts hashtags, renders html
- Response: `{ tweet: {...} }`
- Idempotent: if id already exists, returns existing (no duplicate)

### GET /tweets/:id
Single tweet with thread context.
- Response: `{ tweet: {...}, replies: [...], parent: {...} | null }`

### DELETE /tweets/:id
- Only author can delete
- Response: `{ ok: true }`

### PATCH /tweets/:id
- Only author can patch. image_url only (repairs broken media without touching the server-stamped created_at).
- Body: `{ image_url: string | null }`
- Response: `{ tweet: {...} }`

## Profiles

### GET /profiles/:handle
- Response: `{ profile: {...} }`

### PATCH /profiles/:handle
Update own profile.
- Body: `{ display_name?, bio?, avatar_url?, link_url? }`
- Response: `{ profile: {...} }`

### GET /profiles/:handle/tweets
Paginated user tweets.
- Query: `cursor`, `limit`, `tab`: "posts" | "replies" | "media" | "likes"

## Hashtags

### GET /hashtags/:tag
Server-side hashtag index, paginated.
- Query: `cursor`, `limit`
- Response: `{ tweets: [...], next_cursor: "..." | null }`

## Trending

### GET /trending
Trending hashtags by REAL post volume (last 7 days). Computed from
actual volume, never hardcoded.
- Query: `limit` (default 10, max 25)
- Response: `{ trends: [{ tag, post_count, last_used_at }] }`
- Public, no cursor: a short ranked list.

## Search

### GET /search?q=...
Full-text search across tweets, users, hashtags.
- Query: `q`, `type`: "all" | "tweets" | "users" | "hashtags", `limit`
- Response: `{ tweets: [...], users: [...], hashtags: [...] }`

## Follows

### POST /follows
- Body: `{ following_id: UUID }`
- Response: `{ ok: true }`

### DELETE /follows/:user_id
- Response: `{ ok: true }`

### GET /profiles/:handle/followers
### GET /profiles/:handle/following
Paginated lists.

## DMs

### GET /conversations
List conversations, sorted by updated_at DESC.
- Response: `{ conversations: [...] }`

### POST /conversations
Start or get conversation.
- Body: `{ participant_ids: UUID[] }`
- Response: `{ conversation: {...} }`

### GET /conversations/:id/messages
Paginated messages.
- Query: `cursor`, `limit`

### POST /conversations/:id/messages
- Body: `{ id: UUID (client-generated), text: string, image_url?: string }`
- Server stamps created_at
- Response: `{ message: {...} }`

## Health

### GET /health
- Response: `{ ok: true, version: "2.0.0" }`

## Uploads (image pipeline: Vercel Blob, 5GB included on Pro)

### POST /uploads
Upload an image. Client downscales to <=1600px WebP in-browser first.
- Body: multipart form, `file` (image bytes) + `kind` (`"tweet"` | `"avatar"` | `"dm"`)
- Validates: `content_type` starts with `image/`, `byte_size` <= 4.5MB
- Response: `{ image_url: string }` — the public blob URL, stored on the
  tweet directly. No variant pipeline; no resize worker.
