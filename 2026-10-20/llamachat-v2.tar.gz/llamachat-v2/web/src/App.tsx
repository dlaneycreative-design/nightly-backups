import { useEffect, useMemo, useRef, useState, type JSX, type TouchEvent } from "react";
import { BrowserRouter, Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import { createClient, type ApiClient, type Profile } from "./lib/api.ts";
import { getCallerId, ensureDevSession, clearCallerId } from "./lib/session.ts";
import { upsertProfile, clearStore, subscribe, getProfileById } from "./lib/store.ts";
import { resolveImageUrl } from "./lib/images.ts";
import { APP_BASE, HOME_URL, IS_STARVARD, LOGO_URL, SITE_NAME, appPath } from "./lib/theme.ts";
import { lazy, Suspense, type ComponentType, type LazyExoticComponent } from "react";
import { ErrorBoundary } from "./components/ErrorBoundary.tsx";
import { Feed } from "./components/Feed.tsx";
import { SearchAutocomplete } from "./components/SearchAutocomplete.tsx";
/**
 * Lazy view loader with stale-deploy self-healing. Every deploy renames
 * the hashed view chunks; a tab left open across a deploy still holds
 * the OLD chunk names, so its first visit to a lazy view asks the
 * server for a file that no longer exists and the view dies in the
 * error boundary ("Something hiccuped") even though nothing is broken.
 * On a chunk-load failure, reload the page to pick up the current
 * build, exactly like a fresh visit. Two guards keep this safe:
 * a module-scope flag makes concurrent chunk failures in the same
 * document wait on the one reload already on its way (profile views
 * load TWO chunks, header and tabs), and a sessionStorage counter
 * caps heal reloads at 3 per minute, so a genuinely missing chunk
 * ends at the error boundary instead of looping forever. (Oct 19
 * 2026: Dave hit this on People, Messages, and Certificates after
 * several same-day Starvard deploys.)
 */
let healReloading = false;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function lazyView<T extends ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
): LazyExoticComponent<T> {
  const load = async (): Promise<{ default: T }> => {
    try {
      return await factory();
    } catch (err) {
      if (!healReloading) {
        try {
          const KEY = "llama-chunk-heals";
          const now = Date.now();
          let heal: { count: number; firstAt: number } | null = null;
          try {
            const raw = window.sessionStorage.getItem(KEY);
            if (raw) heal = JSON.parse(raw) as { count: number; firstAt: number };
          } catch {
            heal = null;
          }
          if (!heal || typeof heal.count !== "number" || now - heal.firstAt > 60_000) {
            heal = { count: 0, firstAt: now };
          }
          if (heal.count < 3) {
            heal.count += 1;
            window.sessionStorage.setItem(KEY, JSON.stringify(heal));
            healReloading = true;
            window.location.reload();
          }
        } catch {
          /* storage unavailable: fall through to the original error */
        }
      }
      if (healReloading) {
        // A heal reload is on its way; keep Suspense waiting instead
        // of surfacing the stale-chunk error. This await never settles.
        await new Promise<never>(() => {});
      }
      throw err;
    }
  };
  return lazy(load);
}
const TweetThread = lazyView(() => import("./components/TweetThread.tsx").then(m => ({ default: m.TweetThread })));
const ProfileHeader = lazyView(() => import("./components/ProfileHeader.tsx").then(m => ({ default: m.ProfileHeader })));
const ProfileTabs = lazyView(() => import("./components/ProfileTabs.tsx").then(m => ({ default: m.ProfileTabs })));
const DMSplit = lazyView(() => import("./components/DMSplit.tsx").then(m => ({ default: m.DMSplit })));
const SearchView = lazyView(() => import("./components/SearchView.tsx").then(m => ({ default: m.SearchView })));
const HashtagView = lazyView(() => import("./components/HashtagView.tsx").then(m => ({ default: m.HashtagView })));
const ExploreView = lazyView(() => import("./components/ExploreView.tsx").then(m => ({ default: m.ExploreView })));
const NotificationsView = lazyView(() => import("./components/NotificationsView.tsx").then(m => ({ default: m.NotificationsView })));
const FlashcardsView = lazyView(() => import("./components/FlashcardsView.tsx").then(m => ({ default: m.FlashcardsView })));
const AppsView = lazyView(() => import("./components/AppsView.tsx").then(m => ({ default: m.AppsView })));
import { ReplyModalHost } from "./components/ReplyModal.tsx";
import { ComposeModalHost, } from "./components/ComposeModal.tsx";
import { SignupModalHost } from "./components/SignupModal.tsx";
import { Toast } from "./components/Toast.tsx";
import { TermsPage, PrivacyPage } from "./components/Legal.tsx";
import { Login } from "./components/Login.tsx";
import { ApprovedPage } from "./components/ApprovedPage.tsx";
import { NotFound, NoSuchPerson } from "./components/NotFound.tsx";
import { openComposeModal, setViewedProfileHandle } from "./lib/composeModal.ts";
import { useInstalledApps } from "./lib/apps.ts";

// API base: VITE_API_BASE, defaulting to the same-origin /api/v2 (the API
// Worker is routed under llamachat.lol/api/* in production). Never default
// to localhost: a plain production build must talk to the real API.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "/api/v2";

interface Ctx {
  api: ApiClient;
  me: Profile | null;
}

function HomeView({ api, me }: Ctx) {
  const [tab, setTab] = useState<"foryou" | "chron" | "shuffle">("foryou");
  const [shuffleCount, setShuffleCount] = useState(0);
  const [tabsHidden, setTabsHidden] = useState(false);
  const [pullY, setPullY] = useState(0);
  const pullStartY = useRef(0);
  const pullArmed = useRef(false);
  const pullDist = useRef(0);
  const lastScrollY = useRef(0);

  // Dice button in the sidebar dispatches this to shuffle the feed.
  // Counter ensures every click reshuffles, even if already on shuffle tab.
  useEffect(() => {
    const onShuffle = () => {
      setTab("shuffle");
      setShuffleCount((c) => c + 1);
    };
    window.addEventListener("feed-shuffle", onShuffle);
    return () => window.removeEventListener("feed-shuffle", onShuffle);
  }, []);

  // Hide tabs on scroll down (mobile, like X). Show on scroll up.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const isMobile = () => window.matchMedia("(max-width: 999px)").matches;
    const onScroll = () => {
      if (!isMobile()) { setTabsHidden(false); return; }
      const y = window.scrollY;
      const dy = y - lastScrollY.current;
      lastScrollY.current = y;
      if (y < 50) { setTabsHidden(false); return; }
      if (dy > 5) setTabsHidden(true);
      else if (dy < -5) setTabsHidden(false);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Pull-to-refresh -> shuffle (mobile only). Dave's calls Oct 10 + Oct 15
  // 2026: mobile gets the dice button's behavior as a pull gesture. The
  // gesture is armed ONLY at the very top of the feed and can start anywhere
  // on the home view; it used to be bound to the thin tabs strip alone, so
  // a pull starting on the feed itself (the natural gesture) never fired.
  // Releasing past the threshold does exactly what the dice button does:
  // switch to the shuffle tab and reshuffle (random feed of 30). Gesture
  // state lives in refs so touchend reads the true final distance, and a
  // second finger or a mid-feed start cancels the pull outright.
  const PULL_THRESHOLD = 80;
  const onTouchStart = (e: TouchEvent) => {
    if (typeof window === "undefined") return;
    if (!window.matchMedia("(max-width: 999px)").matches) return;
    if (window.scrollY > 10 || e.touches.length !== 1) {
      pullArmed.current = false;
      return;
    }
    pullStartY.current = e.touches[0].clientY;
    pullDist.current = 0;
    pullArmed.current = true;
  };
  const onTouchMove = (e: TouchEvent) => {
    if (!pullArmed.current) return;
    if (e.touches.length !== 1 || window.scrollY > 10) {
      pullArmed.current = false;
      pullDist.current = 0;
      setPullY(0);
      return;
    }
    const dy = e.touches[0].clientY - pullStartY.current;
    pullDist.current = dy > 0 ? Math.min(dy, 120) : 0;
    setPullY(pullDist.current);
  };
  const endPull = (fire: boolean) => {
    if (!pullArmed.current) return;
    pullArmed.current = false;
    if (fire && pullDist.current > PULL_THRESHOLD) {
      setTab("shuffle");
      setShuffleCount((c) => c + 1);
    }
    pullDist.current = 0;
    setPullY(0);
  };

  return (
    <div
      className="home-view"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={() => endPull(true)}
      onTouchCancel={() => endPull(false)}
    >
      {pullY > 0 ? (
        <div className="pull-refresh" style={{ height: pullY, opacity: Math.min(pullY / 80, 1) }}>
          <span className="pull-dice">🎲</span>
          <span>{pullY > 80 ? "Release to shuffle!" : "Pull to shuffle"}</span>
        </div>
      ) : null}
      <div
        className={`feedtabs${tabsHidden ? " tabs-hidden" : ""}`}
        style={me ? undefined : { display: "none" }}
      >
        <button
          className={`ftab${tab === "foryou" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("foryou")}
        >
          For you
        </button>
        <button
          className={`ftab${tab === "chron" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("chron")}
        >
          Following
        </button>
        {tab === "shuffle" ? (
          <button
            className="ftab active"
            type="button"
            onClick={() => setTab("shuffle")}
            title="Shuffle again"
          >
            Shuffle
          </button>
        ) : null}
      </div>
      <Feed key={`${tab}-${shuffleCount}`} api={api} apiBase={API_BASE} me={me} sort={tab} />
    </div>
  );
}

function ThreadView({ api }: Ctx) {
  const { id } = useParams();
  if (!id) return <div className="empty"><p>Missing post id.</p></div>;
  return <TweetThread api={api} id={id} />;
}

function ProfileView({ api }: Ctx) {
  const { handle, tab } = useParams();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);

  // While a profile is on screen, register it so the compose modal can
  // prefill "@Handle " when Dave hits Post from here.
  useEffect(() => {
    setViewedProfileHandle(handle ?? null);
    return () => setViewedProfileHandle(null);
  }, [handle]);

  useEffect(() => {
    if (!handle) return;
    let alive = true;
    setProfile(null);
    setError(null);
    api
      .profile(handle)
      .then(({ profile: p }) => {
        if (!alive) return;
        setProfile(upsertProfile(p));
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e.message : "Profile not found.");
      });
    return () => {
      alive = false;
    };
  }, [api, handle]);

  if (error) {
    // A missing profile is a not-found (audit L5): honest head tags and
    // a way back, not just a dead-end message.
    return <NoSuchPerson handle={handle ?? ""} />;
  }
  if (!profile || !handle) {
    return (
      <div aria-label="Loading profile">
        <div className="pf-banner" />
        <div className="pf-idrow">
          <div className="skel skel-avatar" />
        </div>
        <div className="pf-bio">
          <div className="skel skel-line short" />
          <div className="skel skel-line" />
        </div>
      </div>
    );
  }
  return (
    <div>
      <ProfileHeader api={api} apiBase={API_BASE} profile={profile} onProfile={setProfile} />
      <ProfileTabs api={api} handle={handle} profile={profile} initialTab={tab} />
    </div>
  );
}

function HashtagRoute({ api }: Ctx) {
  const { tag } = useParams();
  if (!tag) return <div className="empty"><p>Missing tag.</p></div>;
  return <HashtagView api={api} tag={tag} />;
}

// Llama skin /flashcards (Apps V1, Oct 19 2026): Flashcards is an
// installable app here. Installed: the study view itself. Not
// installed: the Apps view, where the Install button lives. The
// Starvard skin never passes through this gate (apps default on).
function FlashcardsGate() {
  const installedApps = useInstalledApps();
  if (!installedApps.includes("flashcards")) return <Navigate to="/apps" replace />;
  return <FlashcardsView />;
}

// Single-segment paths that belong to the app itself, not to a person.
// The short profile routes below (/:handle) would happily claim words
// like /api or /dev as usernames; those are infrastructure, not people,
// so they get the honest not-found view instead of a profile lookup.
const RESERVED_HANDLES = new Set(["api", "dev"]);

function ShortProfileRoute({ api, me }: Ctx) {
  const { handle } = useParams();
  if (handle && RESERVED_HANDLES.has(handle.toLowerCase())) return <NotFound />;
  return <ProfileView api={api} me={me} />;
}

// X-style SVG nav icons (from thestudio.io/llama)
const ICONS: Record<string, JSX.Element> = {
  home: <svg className="nic" viewBox="0 0 24 24"><path d="M12 3l9 8h-3v9h-4v-6H10v6H6v-9H3z"/></svg>,
  explore: <svg className="nic" viewBox="0 0 24 24"><path d="M10 2a8 8 0 105.3 14l4 4 1.4-1.4-4-4A8 8 0 0010 2zm0 2a6 6 0 110 12 6 6 0 010-12z"/></svg>,
  notifications: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a7 7 0 00-7 7v3.5L3.5 15h17L19 12.5V9a7 7 0 00-7-7zm0 2a5 5 0 015 5v4H7V9a5 5 0 015-5zm-3 14h6a3 3 0 01-6 0z"/></svg>,
  messages: <svg className="nic" viewBox="0 0 24 24"><path d="M4 4h16a1 1 0 011 1v12a1 1 0 01-1 1H8l-5 4V5a1 1 0 011-1zm1 2v12.7L8.7 15H20V6H5z"/></svg>,
  profile: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a5 5 0 110 10 5 5 0 010-10zm0 2a3 3 0 100 6 3 3 0 000-6zm-7 14c.8-3.2 3.9-5 7-5s6.2 1.8 7 5H5z"/></svg>,
  flashcards: <svg className="nic" viewBox="0 0 24 24"><path d="M9 2h11a2 2 0 012 2v11h-2.2V4.2H9z"/><path d="M4.5 6H16a2 2 0 012 2v12a2 2 0 01-2 2H4.5A2.5 2.5 0 012 19.5v-11A2.5 2.5 0 014.5 6zm-.3 2A.3.3 0 003.9 8.3v11a.3.3 0 00.3.3h11.6a.2.2 0 00.2-.2V8.2a.2.2 0 00-.2-.2z"/></svg>,
  apps: <svg className="nic" viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/></svg>,
};

const NAV: { to: string; label: string; icon: keyof typeof ICONS }[] = [
  { to: "/", label: "Home", icon: "home" },
  { to: "/explore", label: "Explore", icon: "explore" },
  { to: "/search", label: "Search", icon: "explore" },
  { to: "/notifications", label: "Notifications", icon: "notifications" },
  { to: "/messages", label: "Messages", icon: "messages" },
];

// Starvard skin sidebar (Dave's order Oct 19 2026): Home, then the
// learning sections on starvard.org itself, then People and Messages
// inside the app. Rendered only when IS_STARVARD; the Llama sidebar
// above is untouched. External entries are plain anchors: they leave
// the /feed app for the matching starvard.org page, same origin, same
// signed-in browser.
const SV_ICONS: Record<string, JSX.Element> = {
  flashcards: <svg className="nic" viewBox="0 0 24 24"><path d="M9 2h11a2 2 0 012 2v11h-2.2V4.2H9z"/><path d="M4.5 6H16a2 2 0 012 2v12a2 2 0 01-2 2H4.5A2.5 2.5 0 012 19.5v-11A2.5 2.5 0 014.5 6zm-.3 2A.3.3 0 003.9 8.3v11a.3.3 0 00.3.3h11.6a.2.2 0 00.2-.2V8.2a.2.2 0 00-.2-.2z"/></svg>,
  courses: <svg className="nic" viewBox="0 0 24 24"><path d="M12 5.2C10.4 3.9 8.2 3.2 5.8 3.2H3.5v15.6h2.3c2.4 0 4.6.7 6.2 2 1.6-1.3 3.8-2 6.2-2h2.3V3.2h-2.3c-2.4 0-4.6.7-6.2 2zm-1 2v11.4c-1.5-.9-3.3-1.3-5.2-1.3V5.1c1.9 0 3.7.4 5.2 2.1zm2 0c1.5-1.7 3.3-2.1 5.2-2.1v12.2c-1.9 0-3.7.4-5.2 1.3z"/></svg>,
  books: <svg className="nic" viewBox="0 0 24 24"><path d="M7 2h12.5v20H7a3 3 0 01-3-3V5a3 3 0 013-3zm0 2a1 1 0 00-1 1v14a1 1 0 001 1h10.5v-4H9.5v-2h8V4z"/></svg>,
  certificates: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a6.5 6.5 0 110 13 6.5 6.5 0 010-13zm0 2.2a4.3 4.3 0 100 8.6 4.3 4.3 0 000-8.6z"/><path d="M8.2 13.9L6.5 22l5.5-3 5.5 3-1.7-8.1-2.1 1.2a6.4 6.4 0 01-3.4 0z"/></svg>,
  people: <svg className="nic" viewBox="0 0 24 24"><path d="M8.5 3a4 4 0 110 8 4 4 0 010-8zm7.9 1.2a3.6 3.6 0 11-1.5 6.9 5.9 5.9 0 00-1.4-3.2 3.6 3.6 0 002.9-3.7zM8.5 13c3.1 0 6.6 1.5 7.6 4.6l.3 1.4H.6l.3-1.4C1.9 14.5 5.4 13 8.5 13zm9.6 1.2c2.4.6 4.5 2 5.3 4.4l.2.4h-4.3c-.2-1.9-.6-3.5-1.2-4.8z"/></svg>,
};

interface SvNavItem {
  label: string;
  icon: JSX.Element;
  /** In-app route (NavLink). */
  to?: string;
  /** Full starvard.org URL (plain anchor, leaves the app). */
  href?: string;
  /** Link to the signed-in user's own profile tab (certificates). */
  ownTab?: string;
}

function svNavItems(): SvNavItem[] {
  return [
    { label: "Home", icon: ICONS.home, to: "/" },
    // Dave's order Oct 19 2026: flashcards study happens right here in
    // the app (in-page view), not out on the external page. The static
    // starvard.org/flashcards page stays live for the rest of the site.
    { label: "Flashcards", icon: SV_ICONS.flashcards, to: "/flashcards" },
    { label: "Courses", icon: SV_ICONS.courses, href: "https://starvard.org/allcourses/" },
    { label: "Books", icon: SV_ICONS.books, href: "https://starvard.org/books/" },
    { label: "Achievements", icon: SV_ICONS.certificates, ownTab: "certificates" },
    { label: "People", icon: SV_ICONS.people, to: "/explore" },
    { label: "Messages", icon: ICONS.messages, to: "/messages" },
    // Apps directory last (Oct 19 2026). On this skin apps are
    // default on, so the page reads as a directory of what is
    // already in the sidebar, starting with Flashcards.
    { label: "Apps", icon: ICONS.apps, to: "/apps" },
  ];
}

function svItemTarget(item: SvNavItem, me: Profile | null): string {
  if (item.href) return item.href;
  if (item.ownTab) return me ? `/profile/${me.handle}/${item.ownTab}` : "/login";
  return item.to || "/";
}

/** X-style profile chip pinned to the sidebar bottom (Dave's call Oct 19
    2026): avatar, bold display name, @handle, and a "..." button opening a
    small menu with Log out plus the Terms / Privacy links. Logged out, the
    chip area is a simple Log in affordance. */
function MeChip({ me }: { me: Profile | null }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open ]);

  if (!me) {
    return (
      <button type="button" className="me-chip-login" onClick={() => navigate("/login")}>
        Log in
      </button>
    );
  }
  const doLogout = () => { clearCallerId(); clearStore(); window.location.href = HOME_URL; };
  return (
    <div className="me-chip-wrap" ref={wrapRef}>
      {open ? (
        <div className="me-menu" role="menu" aria-label="Account">
          <button type="button" role="menuitem" onClick={doLogout}>Log out</button>
          <Link to="/terms" role="menuitem" onClick={() => setOpen(false)}>Terms</Link>
          <Link to="/privacy" role="menuitem" onClick={() => setOpen(false)}>Privacy</Link>
        </div>
      ) : null}
      <div
        className="me-mini me-chip"
        onClick={() => navigate(`/profile/${me.handle}`)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); navigate(`/profile/${me.handle}`); } }}
        role="link"
        tabIndex={0}
        aria-label={`View profile of ${me.display_name}`}
      >
        {resolveImageUrl(me.avatar_url) ? (
          <img src={resolveImageUrl(me.avatar_url)!} alt={me.display_name} />
        ) : (
          <img src={LOGO_URL} alt={SITE_NAME} />
        )}
        <div className="me-chip-id">
          <div className="n">{me.display_name}</div>
          <div className="h">@{me.handle}</div>
        </div>
        <button
          type="button"
          className="me-chip-more"
          aria-label="Account menu"
          aria-haspopup="menu"
          aria-expanded={open}
          onClick={(e) => { e.stopPropagation(); setOpen((v) => !v); }}
          onKeyDown={(e) => e.stopPropagation()}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8" /><circle cx="12" cy="12" r="1.8" /><circle cx="19" cy="12" r="1.8" /></svg>
        </button>
      </div>
    </div>
  );
}

function SideNav({ me, api, mini = false }: { me: Profile | null; api: any; mini?: boolean }) {
  const navigate = useNavigate();
  const profileTo = me ? `/profile/${me.handle}` : "/login";
  // Apps V1 (Oct 19 2026): on the Llama skin an installed Flashcards
  // pins directly under Home, mirroring Starvard. Uninstalled, the
  // nav is byte-for-byte the old one: the only trace of apps is the
  // quiet Apps item at the very bottom of the list, no badges, no
  // callouts (Dave's progressive-disclosure law).
  const installedApps = useInstalledApps();
  const llamaNav: { to: string; label: string; icon: keyof typeof ICONS }[] =
    !IS_STARVARD && installedApps.includes("flashcards")
      ? [NAV[0], { to: "/flashcards", label: "Flashcards", icon: "flashcards" }, ...NAV.slice(1)]
      : NAV;
  if (mini) {
    return (
      <nav className="sidenav mini" aria-label="Primary">
        <div className="sidenav-scroll mini-scroll">
          <div className="logo mini-logo">
            <a href={HOME_URL} onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label={`${SITE_NAME} home`}>
              <img src={LOGO_URL} alt={SITE_NAME} />
            </a>
          </div>
          {IS_STARVARD ? svNavItems().map((item) => {
            const target = svItemTarget(item, me);
            return item.href ? (
              <a key={item.label} href={target} className="snav mini-snav" aria-label={item.label}>
                <span className="nav-icon-wrap">{item.icon}</span>
              </a>
            ) : (
              <NavLink key={item.label} to={target} end={target === "/"} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label={item.label}>
                <span className="nav-icon-wrap">{item.icon}</span>
              </NavLink>
            );
          }) : llamaNav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label={n.label}>
              <span className="nav-icon-wrap">{ICONS[n.icon]}{n.to === "/notifications" ? <NotifBadge api={api} /> : null}</span>
            </NavLink>
          ))}
          <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label="Profile">
            {ICONS.profile}
          </NavLink>
          {IS_STARVARD ? null : (
            <NavLink to="/apps" className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label="Apps">
              {ICONS.apps}
            </NavLink>
          )}
        </div>
      </nav>
    );
  }
  return (
    <nav className="sidenav" aria-label="Primary">
      <div className="sidenav-scroll">
        <div className="logo">
          <a href={HOME_URL} onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label={`${SITE_NAME} home`}>
            <img src={LOGO_URL} alt={SITE_NAME} />
          </a>
          {IS_STARVARD ? <span className="wordmark">Starvard</span> : null}
        </div>
        {IS_STARVARD ? svNavItems().map((item) => {
          const target = svItemTarget(item, me);
          return item.href ? (
            <a key={item.label} href={target} className="snav">
              <span className="nav-icon-wrap">{item.icon}</span>{item.label}
            </a>
          ) : (
            <NavLink key={item.label} to={target} end={target === "/"} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
              <span className="nav-icon-wrap">{item.icon}</span>{item.label}
            </NavLink>
          );
        }) : (
          <>
            {llamaNav.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
                <span className="nav-icon-wrap">{ICONS[n.icon]}{n.to === "/notifications" ? <NotifBadge api={api} /> : null}</span>{n.label}
              </NavLink>
            ))}
            <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
              {ICONS.profile}Profile
            </NavLink>
            <NavLink to="/apps" className={({ isActive }) => (isActive ? "snav active" : "snav")}>
              <span className="nav-icon-wrap">{ICONS.apps}</span>Apps
            </NavLink>
          </>
        )}
        {me ? (
          <>
            <button type="button" className="bigpost" onClick={() => openComposeModal()}>Post</button>
          </>
        ) : (
          <button type="button" className="bigpost" onClick={() => navigate("/login")}>Log in</button>
        )}
        <button
          type="button"
          className="dice-btn"
          onClick={() => {
            navigate("/");
            window.dispatchEvent(new CustomEvent("feed-shuffle"));
          }}
          title="Shuffle the feed"
          aria-label="Shuffle the feed"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8.5" cy="8.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="15.5" cy="15.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="15.5" cy="8.5" r="1.4" fill="currentColor" stroke="none"/><circle cx="8.5" cy="15.5" r="1.4" fill="currentColor" stroke="none"/></svg>
          {IS_STARVARD ? <span className="dice-label">Shuffle</span> : null}
        </button>
      </div>
      <MeChip me={me} />
    </nav>
  );
}

function SideNavWrap({ me, api }: { me: Profile | null; api: any }) {
  const loc = useLocation();
  const mini = loc.pathname.startsWith("/messages");
  return <SideNav me={me} api={api} mini={mini} />;
}

function WhoRow({ api, n, h, img }: { api: ApiClient; n: string; h: string; img: string }) {
  const navigate = useNavigate();
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);

  // Load actual follow status on mount (Dave's call Oct 9 2026:
  // "doesn't remember who you're following")
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { profile } = await api.profile(h);
        if (alive) setFollowing(!!profile.following);
      } catch {
        /* keep default */
      }
    })();
    return () => { alive = false; };
  }, [api, h]);

  const toggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try {
      const { profile } = await api.profile(h);
      if (following) {
        await api.unfollow(profile.id);
        setFollowing(false);
      } else {
        await api.follow(profile.id);
        setFollowing(true);
      }
    } catch {
      // keep the button state; user can retry
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="who"
      onClick={() => navigate(`/profile/${h}`)}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); navigate(`/profile/${h}`); } }}
      role="link"
      tabIndex={0}
      aria-label={`View profile of ${n}`}
    >
      <img src={img} alt={n} loading="lazy" />
      <div><div className="n">{n}</div><div className="h">@{h}</div></div>
      <button type="button" onClick={toggle} disabled={busy} className={following ? "is-following" : ""}>
        {following ? "Following" : "Follow"}
      </button>
    </div>
  );
}

function RightBarWrap({ api }: { api: ApiClient }) {
  const loc = useLocation();
  if (loc.pathname.startsWith("/messages")) return null;
  return <RightBar api={api} />;
}

function RightBar({ api }: { api: ApiClient }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    if (query) navigate(`/search?q=${encodeURIComponent(query)}`);
  };
  return (
    <aside className="rightbar" aria-label="Trends">
      <div className="rsearch-wrap">
        <form className="rsearch real" onSubmit={submit}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={`Search ${SITE_NAME}`}
            aria-label={`Search ${SITE_NAME}`}
          />
        </form>
        <SearchAutocomplete api={api} query={q} onNavigate={() => setQ("")} />
      </div>
      <div className="rcard">
        <h2>Who to follow</h2>
        {[
          { n: "Sally", h: "sally", img: appPath("/assets/avatars/sally.jpg") },
          { n: "Chadwick", h: "chadwick", img: appPath("/assets/avatars/chadwickblaze.jpg") },
          { n: "Dinesh", h: "dinesh", img: appPath("/assets/avatars/dinesh.webp") },
          { n: "Marty", h: "Marty", img: appPath("/assets/avatars/martychaos.jpg") },
        ].map((w) => (
          <WhoRow key={w.h} api={api} n={w.n} h={w.h} img={w.img} />
        ))}
      </div>
    </aside>
  );
}

function BottomNav({ api }: { api: any }) {
  const loc = useLocation();
  const inDMs = loc.pathname.startsWith("/messages");
  const [hidden, setHidden] = useState(false);
  useEffect(() => {
    let lastY = window.scrollY;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        if (y > lastY && y > 80) setHidden(true);
        else if (y < lastY) setHidden(false);
        lastY = y;
        ticking = false;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <>
    <nav className={`bottomnav${hidden ? " hidden" : ""}`} aria-label="Primary">
      <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")} aria-label="Home">{ICONS.home}</NavLink>
      <NavLink to="/search" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Search">{ICONS.explore}</NavLink>
      <NavLink to="/explore" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Explore">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/></svg>
      </NavLink>
      <NavLink to="/notifications" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Notifications"><span className="nav-icon-wrap">{ICONS.notifications}<NotifBadge api={api} /></span></NavLink>
      <NavLink to="/messages" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Messages">{ICONS.messages}</NavLink>
    </nav>
    {/* Floating compose button, X style (Dave's call Oct 15 2026, screenshot
        checked against x.com): floats bottom right above the nav bar, never
        inside it. Hidden in DMs, where the thread has its own composer. */}
    {!inDMs && (
      <button
        type="button"
        className="compose-fab"
        aria-label="Compose new post"
        onClick={() => openComposeModal()}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg>
      </button>
    )}
    </>
  );
}


function MobileDrawer({ me, onClose }: { me: Profile; onClose: () => void }) {
  const navigate = useNavigate();
  // Apps V1 parity fix (Oct 19 2026): the drawer originally hardcoded
  // five items and never got the Apps entries the desktop sidebar
  // has, so on mobile there was no way to reach Apps or an installed
  // app. Mirror the sidebar: an installed Flashcards pins directly
  // under Home (on Starvard the catalog is default on, so it always
  // shows there), and Apps sits quietly at the bottom of the list.
  const installedApps = useInstalledApps();
  const go = (path: string) => {
    onClose();
    navigate(path);
  };
  return (
    <>
      <button
        type="button"
        className="drawer-scrim"
        onClick={onClose}
        aria-label="Close menu"
        style={{ border: "none", padding: 0, cursor: "pointer" }}
      />
      <div className="mdrawer">
        <div className="mdrawer-head">
          <img
            src={resolveImageUrl(me.avatar_url) || LOGO_URL}
            alt={me.display_name}
            className="mdrawer-avatar"
          />
          <div className="mdrawer-name">{me.display_name}</div>
          <div className="mdrawer-handle">@{me.handle}</div>
          <button type="button" className="mdrawer-close" onClick={onClose} aria-label="Close menu">✕</button>
        </div>
        <nav className="mdrawer-nav">
          <button type="button" onClick={() => go(`/profile/${me.handle}`)}>
            <span className="mdrawer-icon">👤</span> Profile
          </button>
          <button type="button" onClick={() => go("/")}>
            <span className="mdrawer-icon">🏠</span> Home
          </button>
          {installedApps.includes("flashcards") ? (
            <button type="button" onClick={() => go("/flashcards")}>
              <span className="mdrawer-icon">🗂️</span> Flashcards
            </button>
          ) : null}
          <button type="button" onClick={() => go("/explore")}>
            <span className="mdrawer-icon">🔍</span> Explore
          </button>
          <button type="button" onClick={() => go("/notifications")}>
            <span className="mdrawer-icon">🔔</span> Notifications
          </button>
          <button type="button" onClick={() => go("/messages")}>
            <span className="mdrawer-icon">✉️</span> Messages
          </button>
          <button type="button" onClick={() => go("/apps")}>
            <span className="mdrawer-icon">🧩</span> Apps
          </button>
        </nav>
      </div>
    </>
  );
}

// Unread notification badge: polls the unread-count endpoint
function NotifBadge({ api }: { api: any }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let alive = true;
    const fetchCount = async () => {
      try {
        const r = await api.unreadCount();
        if (alive) setCount(r.count || 0);
      } catch { /* not signed in */ }
    };
    fetchCount();
    const t = setInterval(fetchCount, 30000);
    const onFocus = () => fetchCount();
    window.addEventListener("focus", onFocus);
    // Refresh when notifications are marked read elsewhere
    const onRead = () => setCount(0);
    window.addEventListener("notif-read", onRead);
    return () => { alive = false; clearInterval(t); window.removeEventListener("focus", onFocus); window.removeEventListener("notif-read", onRead); };
  }, [api]);
  if (count <= 0) return null;
  return <span className="notif-badge">{count > 9 ? "9+" : count}</span>;
}

export function App() {
  const [me, setMe] = useState<Profile | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const api = useMemo(() => createClient(API_BASE, getCallerId), []);

  useEffect(() => {
    let alive = true;
    void ensureDevSession(api).then((p) => {
      if (alive && p) setMe(upsertProfile(p));
    });
    return () => {
      alive = false;
    };
  }, [api]);

  // Keep `me` in step with the normalized store. The Edit profile sheet
  // upserts the PATCH result into the store, but `me` used to stay the
  // boot-time snapshot, so the sidebar row, mobile header, drawer and
  // composers kept rendering the old avatar/banner until a full reload.
  // Now any store update to the signed-in user's profile flows into `me`.
  useEffect(() => {
    if (!me) return;
    return subscribe(() => {
      const fresh = getProfileById(me.id);
      if (fresh && fresh !== me) setMe(fresh);
    });
  }, [me]);

  const ctx: Ctx = { api, me };

  return (
    <BrowserRouter basename={APP_BASE || undefined}>
      <div className="app">
        <div className="mhead">
          {me ? (
            <button
              type="button"
              className="mhead-avatar"
              aria-label="Open menu"
              onClick={() => setDrawerOpen(true)}
            >
              <img
                src={resolveImageUrl(me.avatar_url) || LOGO_URL}
                alt={me.display_name}
              />
            </button>
          ) : null}
          <a href={HOME_URL} onClick={(e) => { e.preventDefault(); window.location.href = HOME_URL; }} aria-label={`${SITE_NAME} home`} style={{display:"flex",alignItems:"center"}}>
            <img className="mhead-logo" src={LOGO_URL} alt={SITE_NAME} />
            {IS_STARVARD ? <span className="wordmark" style={{ marginLeft: 8 }}>Starvard</span> : null}
          </a>
        </div>
        {drawerOpen && me ? (
          <MobileDrawer me={me} onClose={() => setDrawerOpen(false)} />
        ) : null}
        <div className="shell">
          <SideNavWrap me={me} api={api} />
          <main className="maincol feed-pad">
            <Suspense fallback={<div className="loading">Loading...</div>}>
            <Routes>
              <Route path="/" element={<ErrorBoundary label="home feed"><HomeView {...ctx} /></ErrorBoundary>} />
              <Route path="/profile/:handle" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="/profile/:handle/:tab" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="/tweet/:id" element={<ErrorBoundary label="post"><ThreadView {...ctx} /></ErrorBoundary>} />
              <Route path="/hashtag/:tag" element={<ErrorBoundary label="hashtag"><HashtagRoute {...ctx} /></ErrorBoundary>} />
              <Route path="/search" element={<ErrorBoundary label="search"><SearchView api={api} /></ErrorBoundary>} />
              <Route path="/messages" element={<ErrorBoundary label="messages"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/messages/:id" element={<ErrorBoundary label="conversation"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/explore" element={<ErrorBoundary label="explore"><ExploreView api={api} /></ErrorBoundary>} />
              {/* Apps directory (both skins, Oct 19 2026). Must come
                  before /:handle like the other app-owned paths. */}
              <Route path="/apps" element={<ErrorBoundary label="apps"><AppsView /></ErrorBoundary>} />
              {/* The in-app flashcards view. Starvard: built in.
                  Llama: an installable app, so the gate sends anyone
                  who has not installed it to the Apps view instead. */}
              <Route path="/flashcards" element={IS_STARVARD ? <ErrorBoundary label="flashcards"><FlashcardsView /></ErrorBoundary> : <ErrorBoundary label="flashcards"><FlashcardsGate /></ErrorBoundary>} />
              <Route path="/notifications" element={<ErrorBoundary label="notifications"><NotificationsView api={api} /></ErrorBoundary>} />
              <Route path="/login" element={<ErrorBoundary label="login"><Login api={api} onDone={() => window.location.href = HOME_URL} /></ErrorBoundary>} />
              {/* Dave's order Oct 19 2026: the invite link. /approved is where invited people claim their account. */}
              <Route path="/approved" element={<ErrorBoundary label="approved"><ApprovedPage me={me} /></ErrorBoundary>} />
              {/* Dave's call Oct 10 2026 (legal audit): static legal pages. Must come before /:handle. */}
              <Route path="/terms" element={<ErrorBoundary label="terms"><TermsPage /></ErrorBoundary>} />
              <Route path="/privacy" element={<ErrorBoundary label="privacy"><PrivacyPage /></ErrorBoundary>} />
              {/* Dave's call Oct 9 2026: Twitter-style short profile URLs. /dave -> profile. Must come after all specific routes, before the catch-all. */}
              <Route path="/:handle" element={<ErrorBoundary label="profile"><ShortProfileRoute {...ctx} /></ErrorBoundary>} />
              <Route path="/:handle/:tab" element={<ErrorBoundary label="profile"><ShortProfileRoute {...ctx} /></ErrorBoundary>} />
              {/* Catch-all LAST (audit item L5, Oct 17 2026): any path no
                  real route claimed gets the genuine not-found view, not
                  the app shell pretending the page exists. */}
              <Route path="*" element={<ErrorBoundary label="not found"><NotFound /></ErrorBoundary>} />
            </Routes>
            </Suspense>
          </main>
          <RightBarWrap api={api} />
        </div>
        <BottomNav api={api} />
        <ReplyModalHost api={api} apiBase={API_BASE} me={me} />
        <ComposeModalHost api={api} apiBase={API_BASE} me={me} />
        <SignupModalHost />
        <Toast />
      </div>
    </BrowserRouter>
  );
}
