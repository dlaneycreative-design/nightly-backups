import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) { const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/); if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; } }
if (!url) { console.log('NO DATABASE_URL'); process.exit(1); }
const sql = neon(url);

const profs = await sql`SELECT id, handle FROM profiles WHERE handle IN ('oldray','dave')`;
console.log('PROFILES:', JSON.stringify(profs));
const oldray = profs.find(p => p.handle === 'oldray');
const dave = profs.find(p => p.handle === 'dave');
if (!oldray) { console.log('OLDRAY MISSING'); process.exit(0); }

// schema of the three tables
const cols = await sql`SELECT table_name, column_name, data_type, column_default, is_nullable FROM information_schema.columns WHERE table_name IN ('conversations','conversation_participants','messages') ORDER BY table_name, ordinal_position`;
console.log('COLUMNS:', JSON.stringify(cols, null, 0));
const cons = await sql`SELECT conrelid::regclass AS tbl, conname, pg_get_constraintdef(oid) AS def FROM pg_constraint WHERE conrelid::regclass::text IN ('conversations','conversation_participants','messages')`;
console.log('CONSTRAINTS:', JSON.stringify(cons, null, 0));

// all conversations touching either user, with participant roster
const convs = await sql`
  SELECT c.id, c.created_at, c.updated_at,
         (SELECT json_agg(json_build_object('user_id', cp2.user_id, 'handle', p.handle)) FROM conversation_participants cp2 LEFT JOIN profiles p ON p.id = cp2.user_id WHERE cp2.conversation_id = c.id) AS participants,
         (SELECT count(*)::int FROM messages m WHERE m.conversation_id = c.id) AS msg_count
  FROM conversations c
  WHERE EXISTS (SELECT 1 FROM conversation_participants cp WHERE cp.conversation_id = c.id AND cp.user_id IN (${dave.id}, ${oldray.id}))
  ORDER BY c.updated_at DESC`;
console.log('CONVS_TOUCHING_EITHER:', JSON.stringify(convs, null, 1));

// any conversation in the whole DB with participant count != 2 (shells/dupes)
const weird = await sql`
  SELECT c.id, count(cp.user_id)::int AS n FROM conversations c LEFT JOIN conversation_participants cp ON cp.conversation_id = c.id GROUP BY c.id HAVING count(cp.user_id) <> 2 ORDER BY n`;
console.log('CONVS_WITH_PARTICIPANT_COUNT_NE_2 (whole DB):', JSON.stringify(weird));
