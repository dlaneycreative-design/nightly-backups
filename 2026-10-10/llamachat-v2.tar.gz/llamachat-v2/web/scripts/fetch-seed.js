// Build-time: snapshot the latest feed into public/seed-feed.json.
// Dave's call Oct 8 2026: first batch of tweets is STATIC (edge-cached,
// ~50ms) so the homepage paints instantly. The API is only hit when the
// user scrolls for more ("load more") or pulls to refresh.
import { writeFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const API = process.env.SEED_API_BASE || "https://llamachat.io/api/v2";
const LIMIT = 8; // Dave's call Oct 9 2026: speed first, 8 tweets on load

async function main() {
  const url = `${API}/tweets?limit=${LIMIT}&sort=chron`;
  console.log(`[seed] fetching ${url}`);
  const res = await fetch(url, { headers: { "x-llama-user": "seed-builder" } });
  if (!res.ok) throw new Error(`seed fetch failed: ${res.status}`);
  const data = await res.json();
  const seed = {
    built_at: new Date().toISOString(),
    tweets: data.tweets || [],
    next_cursor: data.next_cursor || null,
  };
  const out = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "seed-feed.json");
  writeFileSync(out, JSON.stringify(seed));
  console.log(`[seed] wrote ${seed.tweets.length} tweets -> ${out}`);
}

main().catch((e) => {
  console.error(`[seed] FAILED: ${e.message} (build continues with stale seed)`);
  process.exit(0); // never break the build over a seed fetch
});
