// Bring the Mike log #114 tweet image home: its DB image_url pointed at
// thestudio.io (cross-site, and the file was never in the llamachat tree).
// The identical bytes already serve on e2.life/mikeblog/img/ (the E2 blog's
// own copy); they were copied into dist/media/studio/mike/assets/ and this
// repoints the row at the local path, same pattern as the media census.
import { neon } from '@neondatabase/serverless';
import fs from 'fs';
const env = fs.readFileSync('../.env.local', 'utf8');
let url = null;
for (const line of env.split('\n')) {
  const m = line.match(/^\s*DATABASE_URL\s*=\s*(.+)\s*$/);
  if (m) { url = m[1].replace(/^["']|["']$/g, '').trim(); break; }
}
const sql = neon(url);
const ID = 'c4ba3a00-cefd-571c-ab7c-ac4b5e5335b2';
const before = await sql`SELECT image_url FROM tweets WHERE id = ${ID}`;
console.log('BEFORE:', before[0]?.image_url);
await sql`UPDATE tweets SET image_url = '/media/studio/mike/assets/log114-dave-eye-pass.webp' WHERE id = ${ID}`;
const after = await sql`SELECT image_url FROM tweets WHERE id = ${ID}`;
console.log('AFTER:', after[0]?.image_url);
const left = await sql`SELECT count(*)::int AS n FROM tweets WHERE image_url ILIKE '%thestudio.io%'`;
console.log('tweets with thestudio.io image_url now:', left[0].n);
console.log('LOG114 IMAGE FIX DONE');
