import { useEffect } from "react";
import { Link } from "react-router-dom";
import { IS_STARVARD, SITE_NAME } from "../lib/theme.ts";

// Unknown-route views (audit item L5, Oct 17 2026). llamachat.lol is a
// single-page app: the host serves this shell for every path by design,
// so the router is the only place a missing page can be honest. Any path
// that matches no real route lands here instead of rendering the app
// under a made-up URL (a soft 404). While a not-found view is on screen
// it marks the page noindex and retitles the tab; both are restored on
// the way out so real pages keep their normal head tags.
export function useNotFoundHead() {
  useEffect(() => {
    const prevTitle = document.title;
    document.title = `Page not found · ${SITE_NAME}`;
    let meta = document.querySelector<HTMLMetaElement>('meta[name="robots"]');
    const created = !meta;
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "robots";
      document.head.appendChild(meta);
    }
    const prevContent = meta.content;
    meta.content = "noindex";
    return () => {
      document.title = prevTitle;
      if (created) meta.remove();
      else meta.content = prevContent;
    };
  }, []);
}

function NotFoundLinks() {
  return (
    <div className="notfound-links">
      <Link className="ghost" to="/">Back home</Link>
      <Link className="ghost" to="/explore">Explore {SITE_NAME}</Link>
    </div>
  );
}

export function NotFound() {
  useNotFoundHead();
  return (
    <div className="empty notfound">
      <div className="notfound-llama" aria-hidden="true">{IS_STARVARD ? "🎓" : "🦙"}</div>
      <h2>This page wandered off</h2>
      <p>
        The llama looked everywhere, but there is nothing at this address.
        It may have been moved, or the link may have a typo.
      </p>
      <NotFoundLinks />
    </div>
  );
}

// The /:handle routes claim every one or two segment path, so a missing
// person is where most bad URLs actually land. That state is a not-found
// too: same noindex head and the same way back, in profile wording.
export function NoSuchPerson({ handle }: { handle: string }) {
  useNotFoundHead();
  return (
    <div className="empty notfound">
      <h2>No such person</h2>
      <p>@{handle} does not exist here yet.</p>
      <NotFoundLinks />
    </div>
  );
}
