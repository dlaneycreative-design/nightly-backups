import { useEffect, useMemo, useState, type JSX } from "react";
import { BrowserRouter, NavLink, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import { createClient, type ApiClient, type Profile } from "./lib/api.ts";
import { getCallerId, ensureDevSession } from "./lib/session.ts";
import { upsertProfile } from "./lib/store.ts";
import { resolveImageUrl } from "./lib/images.ts";
import { onFeedReady } from "./lib/perf.ts";
import { ErrorBoundary } from "./components/ErrorBoundary.tsx";
import { Feed } from "./components/Feed.tsx";
import { TweetThread } from "./components/TweetThread.tsx";
import { ProfileHeader } from "./components/ProfileHeader.tsx";
import { ProfileTabs } from "./components/ProfileTabs.tsx";
import { DMSplit } from "./components/DMSplit.tsx";
import { SearchView } from "./components/SearchView.tsx";
import { HashtagView } from "./components/HashtagView.tsx";
import { ExploreView } from "./components/ExploreView.tsx";
import { NotificationsView } from "./components/NotificationsView.tsx";
import { ReplyModalHost } from "./components/ReplyModal.tsx";
import { ComposeModalHost, } from "./components/ComposeModal.tsx";
import { Login } from "./components/Login.tsx";
import { openComposeModal } from "./lib/composeModal.ts";
import { DevView } from "./components/DevView.tsx";

// API base: VITE_API_BASE, defaulting to the local dev server. The real
// server mounts every route under /api/v2, so the default includes it.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, "") || "http://localhost:3000/api/v2";

interface Ctx {
  api: ApiClient;
  me: Profile | null;
}

function HomeView({ api, me }: Ctx) {
  const [tab, setTab] = useState<"foryou" | "chron">("foryou");
  return (
    <>
      <div className="feedtabs">
        <button
          className={`ftab${tab === "foryou" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("foryou")}
        >
          For you
        </button>
        <button
          className={`ftab${tab === "chron" ? " active" : ""}`}
          type="button"
          onClick={() => setTab("chron")}
        >
          Following
        </button>
      </div>
      <Feed key={tab} api={api} apiBase={API_BASE} me={me} sort={tab} />
    </>
  );
}

function ThreadView({ api }: Ctx) {
  const { id } = useParams();
  if (!id) return <div className="empty"><p>Missing post id.</p></div>;
  return <TweetThread api={api} id={id} />;
}

function ProfileView({ api }: Ctx) {
  const { handle } = useParams();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!handle) return;
    let alive = true;
    setProfile(null);
    setError(null);
    api
      .profile(handle)
      .then(({ profile: p }) => {
        if (!alive) return;
        setProfile(upsertProfile(p));
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e.message : "Profile not found.");
      });
    return () => {
      alive = false;
    };
  }, [api, handle]);

  if (error) {
    return (
      <div className="empty">
        <h2>No such person</h2>
        <p>@{handle} does not exist here yet.</p>
      </div>
    );
  }
  if (!profile || !handle) {
    return (
      <div aria-label="Loading profile">
        <div className="pf-banner" />
        <div className="pf-idrow">
          <div className="skel skel-avatar" />
        </div>
        <div className="pf-bio">
          <div className="skel skel-line short" />
          <div className="skel skel-line" />
        </div>
      </div>
    );
  }
  return (
    <div>
      <ProfileHeader api={api} profile={profile} onProfile={setProfile} />
      <ProfileTabs api={api} handle={handle} />
    </div>
  );
}

function HashtagRoute({ api }: Ctx) {
  const { tag } = useParams();
  if (!tag) return <div className="empty"><p>Missing tag.</p></div>;
  return <HashtagView api={api} tag={tag} />;
}

function NotFound() {
  return (
    <div className="empty">
      <h2>Lost in the Studio</h2>
      <p>This page does not exist.</p>
    </div>
  );
}

// X-style SVG nav icons (from thestudio.io/llama)
const ICONS: Record<string, JSX.Element> = {
  home: <svg className="nic" viewBox="0 0 24 24"><path d="M12 3l9 8h-3v9h-4v-6H10v6H6v-9H3z"/></svg>,
  explore: <svg className="nic" viewBox="0 0 24 24"><path d="M10 2a8 8 0 105.3 14l4 4 1.4-1.4-4-4A8 8 0 0010 2zm0 2a6 6 0 110 12 6 6 0 010-12z"/></svg>,
  notifications: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a7 7 0 00-7 7v3.5L3.5 15h17L19 12.5V9a7 7 0 00-7-7zm0 2a5 5 0 015 5v4H7V9a5 5 0 015-5zm-3 14h6a3 3 0 01-6 0z"/></svg>,
  messages: <svg className="nic" viewBox="0 0 24 24"><path d="M4 4h16a1 1 0 011 1v12a1 1 0 01-1 1H8l-5 4V5a1 1 0 011-1zm1 2v12.7L8.7 15H20V6H5z"/></svg>,
  profile: <svg className="nic" viewBox="0 0 24 24"><path d="M12 2a5 5 0 110 10 5 5 0 010-10zm0 2a3 3 0 100 6 3 3 0 000-6zm-7 14c.8-3.2 3.9-5 7-5s6.2 1.8 7 5H5z"/></svg>,
};

const NAV: { to: string; label: string; icon: keyof typeof ICONS }[] = [
  { to: "/", label: "Home", icon: "home" },
  { to: "/explore", label: "Explore", icon: "explore" },
  { to: "/search", label: "Search", icon: "explore" },
  { to: "/notifications", label: "Notifications", icon: "notifications" },
  { to: "/messages", label: "Messages", icon: "messages" },
];

function SideNav({ me, mini = false }: { me: Profile | null; mini?: boolean }) {
  const navigate = useNavigate();
  const profileTo = me ? `/profile/${me.handle}` : "/profile/dlaney";
  if (mini) {
    return (
      <nav className="sidenav mini" aria-label="Primary">
        <div className="sidenav-scroll mini-scroll">
          <div className="logo mini-logo">
            <a href="/" onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label="LlamaChat home">
              <img src="/llama-logo.png" alt="LlamaChat" />
            </a>
          </div>
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label={n.label}>
              {ICONS[n.icon]}
            </NavLink>
          ))}
          <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav mini-snav active" : "snav mini-snav")} aria-label="Profile">
            {ICONS.profile}
          </NavLink>
        </div>
      </nav>
    );
  }
  return (
    <nav className="sidenav" aria-label="Primary">
      <div className="sidenav-scroll">
        <div className="logo">
          <a href="/" onClick={(e) => { e.preventDefault(); navigate("/"); }} aria-label="LlamaChat home">
            <img src="/llama-logo.png" alt="LlamaChat" />
          </a>
        </div>
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
            {ICONS[n.icon]}{n.label}
          </NavLink>
        ))}
        <NavLink to={profileTo} className={({ isActive }) => (isActive ? "snav active" : "snav")}>
          {ICONS.profile}Profile
        </NavLink>
        <button type="button" className="bigpost" onClick={() => openComposeModal()}>Post</button>
      </div>
      {me ? (
        <div className="me-mini" onClick={() => navigate(`/profile/${me.handle}`)}>
          {resolveImageUrl(me.avatar_url) ? (
            <img src={resolveImageUrl(me.avatar_url)!} alt={me.display_name} />
          ) : (
            <img src="/llama-logo.png" alt="LlamaChat" />
          )}
          <div><div className="n">{me.display_name}</div><div className="h">@{me.handle}</div></div>
        </div>
      ) : null}
    </nav>
  );
}

/** Persistent bottom-left footer: dev link + page generation time + version. */
function SideNavWrap({ me }: { me: Profile | null }) {
  const loc = useLocation();
  const mini = loc.pathname.startsWith("/messages");
  return <SideNav me={me} mini={mini} />;
}

function SideNavFoot() {
  const [genMs, setGenMs] = useState<number | null>(null);
  useEffect(() => onFeedReady(setGenMs), []);
  return (
    <div className="sidenav-foot">
      <NavLink to="/dev" className="dev-link">dev</NavLink>
      {genMs !== null ? (
        <span className="gen-time"> | {(genMs / 1000).toFixed(1)}s</span>
      ) : null}
      <span className="version-tag"> | V2</span>
      <a href="https://e2planet.com/map" target="_blank" rel="noopener" className="map-link" title="E2 map"> | 🗺️</a>
    </div>
  );
}

function WhoRow({ api, n, h, img }: { api: ApiClient; n: string; h: string; img: string }) {
  const navigate = useNavigate();
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);

  const toggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try {
      const { profile } = await api.profile(h);
      if (following) {
        await api.unfollow(profile.id);
        setFollowing(false);
      } else {
        await api.follow(profile.id);
        setFollowing(true);
      }
    } catch {
      // keep the button state; user can retry
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="who" onClick={() => navigate(`/profile/${h}`)}>
      <img src={img} alt={n} loading="lazy" />
      <div><div className="n">{n}</div><div className="h">@{h}</div></div>
      <button type="button" onClick={toggle} disabled={busy}>
        {following ? "Following" : "Follow"}
      </button>
    </div>
  );
}

function RightBarWrap({ api }: { api: ApiClient }) {
  const loc = useLocation();
  if (loc.pathname.startsWith("/messages")) return null;
  return <RightBar api={api} />;
}

function RightBar({ api }: { api: ApiClient }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    if (query) navigate(`/search?q=${encodeURIComponent(query)}`);
  };
  return (
    <aside className="rightbar" aria-label="Trends">
      <div className="rsearch-wrap">
        <form className="rsearch real" onSubmit={submit}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search LlamaChat"
            aria-label="Search LlamaChat"
          />
        </form>
      </div>
      <div className="rcard">
        <h2>Who to follow</h2>
        {[
          { n: "Sally", h: "sally", img: "https://www.thestudio.io/shortbus/assets/portraits/sally.jpg" },
          { n: "Chadwick Blaze", h: "chadwickblaze", img: "https://www.thestudio.io/shortbus/assets/portraits/chadwick.jpg" },
          { n: "Dinesh", h: "dinesh", img: "https://www.thestudio.io/shortbus/assets/portraits/dinesh-solo.jpg" },
          { n: "Marty", h: "martychaos", img: "https://www.thestudio.io/shortbus/assets/portraits/marty.jpg" },
        ].map((w) => (
          <WhoRow key={w.h} api={api} n={w.n} h={w.h} img={w.img} />
        ))}
      </div>
    </aside>
  );
}

function BottomNav() {
  const loc = useLocation();
  const inDMs = loc.pathname.startsWith("/messages");
  return (
    <>
      {!inDMs && (
        <button
          type="button"
          className="fab-compose"
          aria-label="Compose new post"
          onClick={() => openComposeModal()}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg>
        </button>
      )}
      <nav className="bottomnav" aria-label="Primary">
      <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")} aria-label="Home">{ICONS.home}</NavLink>
      <NavLink to="/search" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Search">{ICONS.explore}</NavLink>
      <NavLink to="/explore" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Explore">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/></svg>
      </NavLink>
      <NavLink to="/notifications" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Notifications">{ICONS.notifications}</NavLink>
      <NavLink to="/messages" className={({ isActive }) => (isActive ? "active" : "")} aria-label="Messages">{ICONS.messages}</NavLink>
    </nav>
    </>
  );
}

export function App() {
  const [me, setMe] = useState<Profile | null>(null);

  const api = useMemo(() => createClient(API_BASE, getCallerId), []);

  useEffect(() => {
    let alive = true;
    void ensureDevSession(api).then((p) => {
      if (alive && p) setMe(p);
    });
    return () => {
      alive = false;
    };
  }, [api]);

  const ctx: Ctx = { api, me };

  return (
    <BrowserRouter>
      <div className="app">
        <div className="mhead">
          <img className="mhead-logo" src="/llama-logo.png" alt="LlamaChat" />
        </div>
        <div className="shell">
          <SideNavWrap me={me} />
          <main className="maincol feed-pad">
            <Routes>
              <Route path="/" element={<ErrorBoundary label="home feed"><HomeView {...ctx} /></ErrorBoundary>} />
              <Route path="/profile/:handle" element={<ErrorBoundary label="profile"><ProfileView {...ctx} /></ErrorBoundary>} />
              <Route path="/tweet/:id" element={<ErrorBoundary label="post"><ThreadView {...ctx} /></ErrorBoundary>} />
              <Route path="/hashtag/:tag" element={<ErrorBoundary label="hashtag"><HashtagRoute {...ctx} /></ErrorBoundary>} />
              <Route path="/search" element={<ErrorBoundary label="search"><SearchView api={api} /></ErrorBoundary>} />
              <Route path="/messages" element={<ErrorBoundary label="messages"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/messages/:id" element={<ErrorBoundary label="conversation"><DMSplit api={api} /></ErrorBoundary>} />
              <Route path="/explore" element={<ErrorBoundary label="explore"><ExploreView api={api} /></ErrorBoundary>} />
              <Route path="/notifications" element={<ErrorBoundary label="notifications"><NotificationsView api={api} /></ErrorBoundary>} />
              <Route path="/dev" element={<ErrorBoundary label="dev notes"><DevView api={api} apiBase={API_BASE} /></ErrorBoundary>} />
              <Route path="/login" element={<ErrorBoundary label="login"><Login api={api} onDone={() => window.location.href = "/"} /></ErrorBoundary>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <RightBarWrap api={api} />
        </div>
        <BottomNav />
        <SideNavFoot />
        <ReplyModalHost api={api} apiBase={API_BASE} me={me} />
        <ComposeModalHost api={api} apiBase={API_BASE} me={me} />
      </div>
    </BrowserRouter>
  );
}
