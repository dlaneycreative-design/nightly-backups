// HTTP-level timestamp contract (Dave's #1 bug):
//   1. POST /tweets IGNORES any client-supplied timestamp; the server stamps.
//   2. GET /tweets returns created_at as a positive integer on EVERY tweet.
//   3. Invalid cursor timestamps are rejected with 400.
// Needs DATABASE_URL pointing at a seeded DB.
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { randomUUID } = require("node:crypto");

const hasDb = !!process.env.DATABASE_URL;
let base, server, callerId, query;

before(async (t) => {
  if (!hasDb) return t.skip("DATABASE_URL not set");
  ({ query } = require("../lib/db"));
  const app = require("../server");
  const r = await query("SELECT id FROM profiles WHERE handle = 'dlaney'");
  assert.ok(r.rows[0], "seeded dlaney profile must exist");
  callerId = r.rows[0].id;
  server = app.listen(0);
  await new Promise((res) => server.on("listening", res));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  if (server) await new Promise((res) => server.close(res));
  if (hasDb) {
    const { pool } = require("../lib/db");
    await pool.end();
  }
});

function headers() {
  return { "content-type": "application/json", "x-llama-user": callerId };
}

test("POST /tweets ignores client-supplied created_at", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const id = randomUUID();
  const before = Date.now();
  const res = await fetch(`${base}/api/v2/tweets`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({
      id,
      text: "timestamp contract probe",
      created_at: 1, // bogus: V1-style garbage the server must ignore
      updated_at: 999,
    }),
  });
  assert.equal(res.status, 201);
  const { tweet } = await res.json();
  const after = Date.now();
  assert.ok(Number.isInteger(tweet.created_at), "created_at must be an integer");
  assert.ok(tweet.created_at > 1, "client value must be ignored");
  assert.ok(tweet.created_at >= before && tweet.created_at <= after,
    `server stamp ${tweet.created_at} must be within the request window`);
  // Cleanup.
  const del = await fetch(`${base}/api/v2/tweets/${id}`, { method: "DELETE", headers: headers() });
  assert.equal(del.status, 200);
});

test("GET /tweets returns positive-integer created_at on every tweet", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const res = await fetch(`${base}/api/v2/tweets?limit=50`);
  assert.equal(res.status, 200);
  const { tweets } = await res.json();
  assert.ok(tweets.length > 0, "seeded feed must be non-empty");
  for (const tw of tweets) {
    assert.ok(Number.isInteger(tw.created_at) && tw.created_at > 0,
      `tweet ${tw.id} has bad created_at: ${tw.created_at}`);
  }
});

test("invalid cursor timestamps are rejected", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const badCursors = [
    "not-a-cursor",
    Buffer.from("0:abc").toString("base64url"), // created_at = 0
    Buffer.from("-5:abc").toString("base64url"), // negative
    Buffer.from("abc:def").toString("base64url"), // non-integer
    Buffer.from("999").toString("base64url"), // missing id part
  ];
  for (const c of badCursors) {
    const res = await fetch(`${base}/api/v2/tweets?cursor=${encodeURIComponent(c)}`);
    assert.equal(res.status, 400, `cursor ${c} should be rejected`);
    const body = await res.json();
    assert.equal(body.error.code, "INVALID_CURSOR");
  }
});

test("valid cursor paginates without created_at anomalies", { skip: !hasDb && "DATABASE_URL not set" }, async () => {
  const p1 = await (await fetch(`${base}/api/v2/tweets?limit=5`)).json();
  assert.ok(p1.next_cursor, "first page should have a next cursor");
  const p2 = await (await fetch(`${base}/api/v2/tweets?limit=5&cursor=${encodeURIComponent(p1.next_cursor)}`)).json();
  assert.equal(p2.tweets.length > 0, true);
  const last1 = p1.tweets[p1.tweets.length - 1].created_at;
  const first2 = p2.tweets[0].created_at;
  assert.ok(first2 <= last1, "cursor pagination must not go backwards in time");
});
