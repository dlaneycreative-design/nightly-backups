-- Per-user profile banner + achievement chips (Dave's call Oct 16 2026).
-- banner_url: profiles could already be PATCHed with it, but the column
-- was never created. achievements: JSONB array of
-- {icon, label, sub, url} rendered as chips on the profile, each chip
-- linking to the Starvard class it celebrates.

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS banner_url TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS achievements JSONB;
