// Creates the @bloggy profile (Bloggy, the little postbird who delivers
// The E2 Blog) and posts his deliveries: an intro first, then the blog's
// current posts oldest first so the newest post crowns the profile.
// Dave's order (Nov 1 2026, this side chat): "Yeah, let's do that. Let's
// have the little bloggy bird. Good idea. And he carries like a letter
// in his beak." Avatar and banner are the generated Bloggy art in
// ~/workspace/bloggy-assets (blue/cream bird, white letter with a gold
// heart seal in his beak, brown post satchel).
// Follows the e2-account.js pattern: profile creation via POST /profiles
// with the bot service secret (the Discord-only lock gates public
// creation; @bloggy is on the BOT_SERVICE_HANDLES allowlist so botlib
// posts work), uploads through the API so images live on
// llamachat.lol/media, tweets via botlib with deterministic keys.
// Idempotent: creation 409s if @bloggy exists, uploads cached in
// ~/workspace/bloggy-assets/upload-state.json, tweets dedupe on keys.
// Usage: node api/scripts/bloggy-account.js
const fs = require("fs");
const { API_BASE, postTweet, getProfileId, serviceHeaders, botServiceSecret } = require("./lib/botlib");

const handle = String.fromCharCode(98, 108, 111, 103, 103, 121); // bloggy
const UPLOAD_STATE = "/home/hatch/workspace/bloggy-assets/upload-state.json";

const LOCAL_IMAGES = {
  avatar: [
    "/home/hatch/workspace/bloggy-assets/bloggy-avatar.webp",
    "image/webp",
    "bloggy-avatar.webp",
  ],
  banner: [
    "/home/hatch/workspace/bloggy-assets/bloggy-banner.webp",
    "image/webp",
    "bloggy-banner.webp",
  ],
  blog1: [
    "/home/hatch/workspace/e2-carve/blog/img/sam-carrying-boxes.webp",
    "image/webp",
    "bloggy-blog1.webp",
  ],
  blog2: [
    "/home/hatch/workspace/e2-carve/blog/img/ermalieh-challenger-v2.webp",
    "image/webp",
    "bloggy-blog2.webp",
  ],
  blog3: [
    "/home/hatch/workspace/e2-carve/blog/img/sam-at-her-desk.webp",
    "image/webp",
    "bloggy-blog3.webp",
  ],
};

async function ensureProfile() {
  const res = await fetch(`${API_BASE}/profiles`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-llama-service": botServiceSecret() },
    body: JSON.stringify({ handle, display_name: "Bloggy" }),
  });
  if (res.status === 201) {
    const d = await res.json();
    console.log("created @bloggy via API:", d.profile.id);
    return d.profile.id;
  }
  if (res.status === 409) {
    const id = await getProfileId(handle);
    console.log("@bloggy already exists:", id);
    return id;
  }
  throw new Error(`POST /profiles -> ${res.status} ${(await res.text()).slice(0, 200)}`);
}

async function uploadAll(id) {
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(UPLOAD_STATE, "utf8"));
  } catch {}
  const urls = {};
  for (const [key, [path, type, name]] of Object.entries(LOCAL_IMAGES)) {
    if (saved[key]) {
      urls[key] = saved[key];
      console.log(`[bloggy] reusing upload ${key}: ${saved[key]}`);
      continue;
    }
    const bytes = fs.readFileSync(path);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type }), name);
    form.append("kind", "tweet");
    const up = await fetch(`${API_BASE}/uploads`, {
      method: "POST",
      headers: serviceHeaders(id),
      body: form,
    });
    if (!up.ok) throw new Error(`upload ${key} -> ${up.status} ${(await up.text()).slice(0, 200)}`);
    const { image_url } = await up.json();
    console.log(`[bloggy] uploaded ${key}: ${image_url}`);
    urls[key] = image_url;
    saved[key] = image_url;
    fs.writeFileSync(UPLOAD_STATE, JSON.stringify(saved, null, 2));
  }
  return urls;
}

async function patchProfile(id, urls) {
  const fields = {
    display_name: "Bloggy",
    avatar_url: urls.avatar,
    bio: "🐦 I deliver The E2 Blog. Stories and notes from around E2, carried in fresh, one letter at a time. Written by the team, delivered by me.",
    link_url: "https://e2.life/blog/",
    link_label: "e2.life/blog",
    banner_url: urls.banner,
  };
  const res = await fetch(`${API_BASE}/profiles/${handle}`, {
    method: "PATCH",
    headers: serviceHeaders(id, { "Content-Type": "application/json" }),
    body: JSON.stringify(fields),
  });
  if (!res.ok) throw new Error(`PATCH /profiles/${handle} -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  const d = await res.json();
  console.log("[bloggy] profile set:", d.profile.handle, "| banner:", d.profile.banner_url ? "yes" : "NO");
  return d.profile;
}

function tweets(urls) {
  return [
    {
      key: "bloggy:intro",
      image_url: urls.banner,
      text: "🐦 Hi! I am Bloggy.\n\nI deliver The E2 Blog. Every time the team writes a story or a note from around E2, I put it in my beak and fly it straight here, letter and all.\n\nWritten by the team, delivered by me. First deliveries below, newest on top. Read them all: https://e2.life/blog/",
    },
    {
      key: "bloggy:blog-1",
      image_url: urls.blog1,
      text: "📬 Delivery! A letter from Sam: \"Come on in, I just moved in\" (Oct 19).\n\nSam got the keys, carried the boxes in, and put the welcome mat down first, before a single box was open. That is how this blog started.\n\nWritten by Sam. Read it: https://e2.life/blog/#blog-1",
    },
    {
      key: "bloggy:blog-2",
      image_url: urls.blog2,
      text: "📬 Delivery! A new letter from Sam: \"A new challenger has joined us\" (Oct 30).\n\nErmalieh picked up a controller, played her first games, and earned her very first Points. Her name is on the board now. A real moment around here.\n\nWritten by Sam. Read it: https://e2.life/blog/#blog-2",
    },
    {
      key: "bloggy:blog-3",
      image_url: urls.blog3,
      text: "📬 Fresh delivery! Sam's newest letter: \"The past month was wild!\" (Oct 31).\n\n900+ hellos, a building spree, first Points, first songs, and a kettle that is very much on. Wild is the only word for it.\n\nWritten by Sam. Read it: https://e2.life/blog/#blog-3",
    },
  ];
}

(async () => {
  const id = await ensureProfile();
  const urls = await uploadAll(id);
  await patchProfile(id, urls);
  for (const t of tweets(urls)) {
    const { tweet, deduped } = await postTweet({
      handle,
      text: t.text,
      image_url: t.image_url,
      idempotencyKey: t.key,
    });
    console.log(`[bloggy] ${deduped ? "deduped" : "posted"} ${t.key} -> ${tweet.id}`);
    await new Promise((res) => setTimeout(res, 1500));
  }
  console.log("[bloggy] done");
})().catch((e) => {
  console.error("[bloggy] fatal", e.message);
  process.exit(1);
});
